# Website Enimo Group (Crystal Ice & Coffee)

Website satu portal untuk dua perusahaan, dengan absensi karyawan dan laporan stok barang. Dibuat dengan HTML/CSS/JS biasa (tidak perlu proses build) + Supabase sebagai database & login.

## Struktur file
```
index.html          -> Halaman pilih perusahaan (Crystal Ice / Coffee)
login.html           -> Halaman login karyawan & admin
karyawan.html         -> Dashboard karyawan (absen + input laporan stok)
admin.html            -> Dashboard admin (atur jam absen + lihat semua laporan)
config.js             -> Isi URL & anon key Supabase kamu di sini
database.sql          -> Jalankan di Supabase SQL Editor untuk membuat tabel
css/style.css
js/supabaseClient.js
js/auth.js
js/login.js
js/karyawan.js
js/admin.js
src/image/logo.png    -> Logo Enimo Ice yang kamu kirim
```

## Langkah setup

### 1. Buat project Supabase
1. Buka https://supabase.com, buat project baru (gratis).
2. Masuk ke **Project Settings -> API**, salin:
   - **Project URL**
   - **anon public** key (JANGAN pakai `service_role` key — lihat catatan keamanan di `config.js`)
3. Tempel keduanya ke `config.js`.

### 2. Buat tabel database
1. Di dashboard Supabase, buka **SQL Editor**.
2. Copy-paste seluruh isi `database.sql`, lalu klik **Run**.
   Ini otomatis membuat: data 2 perusahaan (Crystal Ice & Coffee), tabel profil, pengaturan jam absensi (default 08:00–08:30), tabel absensi, dan tabel laporan stok — lengkap dengan aturan keamanan (RLS) supaya karyawan hanya bisa lihat datanya sendiri, dan admin bisa lihat semua data perusahaannya.

### 3. Buat akun karyawan & admin
1. Buka **Authentication -> Users -> Add user**, isi email + password, lalu buat usernya.
2. Salin **User UID** yang muncul.
3. Buka **SQL Editor**, jalankan (ganti sesuai kebutuhan):
```sql
insert into profiles (id, company_id, full_name, role)
values (
  'TEMPEL-USER-UID-DI-SINI',
  (select id from companies where slug = 'crystal-ice'), -- atau 'coffee'
  'Nama Karyawan',
  'karyawan' -- atau 'admin'
);
```
4. Ulangi untuk setiap karyawan/admin di kedua perusahaan.

### 4. Jalankan websitenya
Karena tidak ada proses build, kamu tinggal buka foldernya dengan web server sederhana (browser tidak bisa langsung buka `file://` untuk fitur modul tertentu). Cara termudah:
- **VS Code**: install ekstensi "Live Server", klik kanan `index.html` -> "Open with Live Server".
- Atau upload semua file ini ke hosting statis gratis seperti **Vercel**, **Netlify**, atau **GitHub Pages**.

## Alur pemakaian
1. **index.html** — user pilih "Crystal Ice" atau "Coffee".
2. **login.html** — login pakai email & password yang sudah dibuat di Supabase. Sistem otomatis cek akun ini terdaftar di perusahaan yang sama dengan yang dipilih, lalu mengarahkan ke dashboard admin atau karyawan sesuai role.
3. **karyawan.html**:
   - Tombol "Absen Sekarang" hanya berhasil dalam rentang jam yang diatur admin. Kalau di dalam rentang jam -> status "Tepat waktu". Kalau sudah lewat -> "Terlambat". Kalau belum masuk jam -> ditolak.
   - Form laporan stok: karyawan isi jumlah barang yang dibawa dan yang terjual, sisa dihitung otomatis oleh database.
4. **admin.html**:
   - Tab **Pengaturan Absensi**: admin ubah jam mulai/selesai absen kapan saja.
   - Tab **Laporan Absensi**: lihat siapa saja yang absen per tanggal.
   - Tab **Laporan Stok**: lihat semua laporan stok karyawan per tanggal, termasuk total dibawa/terjual/sisa.

## Catatan pengembangan lanjutan
- Saat ini setiap karyawan didaftarkan manual lewat SQL Editor. Kalau nanti butuh, bisa ditambahkan halaman "Tambah Karyawan" khusus admin.
- Nama barang di laporan stok bisa diisi bebas (default "Es"), jadi bisa dipakai juga untuk mencatat barang lain seperti kopi/bahan baku.
