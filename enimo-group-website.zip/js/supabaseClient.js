// Membuat satu koneksi Supabase yang dipakai di semua halaman
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
