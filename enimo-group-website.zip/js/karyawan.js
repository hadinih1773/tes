let profilSaya = null;

function formatTanggal(d) {
  return new Date(d).toLocaleDateString("id-ID", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}
function formatJam(iso) {
  return new Date(iso).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}
function hariIniStr() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

async function init() {
  profilSaya = await wajibLogin("karyawan");
  if (!profilSaya) return;

  document.body.setAttribute("data-theme", profilSaya.companies.slug === "coffee" ? "coffee" : "ice");
  document.getElementById("brandLabel").textContent = profilSaya.companies.name;
  document.getElementById("userPill").textContent = "Karyawan";
  document.getElementById("namaUser").textContent = profilSaya.full_name;
  document.getElementById("tanggalHariIni").textContent = formatTanggal(new Date());

  await muatJamAturan();
  await muatStatusAbsenHariIni();
  await muatRiwayatAbsen();
  await muatRiwayatStok();

  document.getElementById("formStok").addEventListener("submit", kirimLaporanStok);
}

let jamMulai = "08:00", jamSelesai = "08:30";

async function muatJamAturan() {
  const { data, error } = await sb
    .from("attendance_settings")
    .select("start_time, end_time")
    .eq("company_id", profilSaya.company_id)
    .single();

  if (!error && data) {
    jamMulai = data.start_time.slice(0, 5);
    jamSelesai = data.end_time.slice(0, 5);
  }
  document.getElementById("jamAturan").textContent = `Jam absensi berlaku: ${jamMulai} - ${jamSelesai}`;
}

async function muatStatusAbsenHariIni() {
  const { data } = await sb
    .from("attendance_records")
    .select("*")
    .eq("user_id", profilSaya.id)
    .eq("tanggal", hariIniStr())
    .maybeSingle();

  const area = document.getElementById("absenArea");
  if (data) {
    const label = data.status === "tepat_waktu" ? "Tepat waktu" : (data.status === "terlambat" ? "Terlambat" : "Di luar jam absensi");
    const badgeClass = data.status === "tepat_waktu" ? "ok" : "warn";
    area.innerHTML = `<p>Sudah absen jam <b>${formatJam(data.jam_absen)}</b> — <span class="badge ${badgeClass}">${label}</span></p>`;
  } else {
    area.innerHTML = `<button class="btn-primary" id="btnAbsen">Absen Sekarang</button>`;
    document.getElementById("btnAbsen").addEventListener("click", prosesAbsen);
  }
}

async function prosesAbsen() {
  const msg = document.getElementById("absenMsg");
  msg.textContent = "";
  msg.className = "form-msg";

  const now = new Date();
  const jamSekarang = now.toTimeString().slice(0, 5);

  let status;
  if (jamSekarang < jamMulai) {
    msg.textContent = `Belum masuk jam absensi (mulai ${jamMulai}).`;
    msg.classList.add("error");
    return;
  } else if (jamSekarang <= jamSelesai) {
    status = "tepat_waktu";
  } else {
    status = "terlambat";
  }

  const { error } = await sb.from("attendance_records").insert({
    user_id: profilSaya.id,
    company_id: profilSaya.company_id,
    tanggal: hariIniStr(),
    jam_absen: now.toISOString(),
    status
  });

  if (error) {
    msg.textContent = "Gagal absen: " + error.message;
    msg.classList.add("error");
    return;
  }

  msg.textContent = "Absen berhasil dicatat.";
  msg.classList.add("ok");
  await muatStatusAbsenHariIni();
  await muatRiwayatAbsen();
}

async function muatRiwayatAbsen() {
  const { data, error } = await sb
    .from("attendance_records")
    .select("*")
    .eq("user_id", profilSaya.id)
    .order("tanggal", { ascending: false })
    .limit(10);

  const box = document.getElementById("riwayatAbsen");
  if (error || !data || data.length === 0) {
    box.innerHTML = `<p class="empty">Belum ada riwayat absensi.</p>`;
    return;
  }
  box.innerHTML = `<table><thead><tr><th>Tanggal</th><th>Jam</th><th>Status</th></tr></thead><tbody>
    ${data.map(r => `<tr>
      <td>${new Date(r.tanggal).toLocaleDateString("id-ID")}</td>
      <td>${formatJam(r.jam_absen)}</td>
      <td><span class="badge ${r.status === 'tepat_waktu' ? 'ok' : 'warn'}">${r.status.replace('_',' ')}</span></td>
    </tr>`).join("")}
  </tbody></table>`;
}

async function kirimLaporanStok(e) {
  e.preventDefault();
  const msg = document.getElementById("stokMsg");
  msg.textContent = "";
  msg.className = "form-msg";

  const nama_barang = document.getElementById("namaBarang").value.trim();
  const stok_dibawa = parseFloat(document.getElementById("stokDibawa").value);
  const stok_terjual = parseFloat(document.getElementById("stokTerjual").value);
  const catatan = document.getElementById("catatan").value.trim();

  if (stok_terjual > stok_dibawa) {
    msg.textContent = "Jumlah terjual tidak boleh lebih besar dari jumlah dibawa.";
    msg.classList.add("error");
    return;
  }

  const { error } = await sb.from("stock_reports").insert({
    user_id: profilSaya.id,
    company_id: profilSaya.company_id,
    tanggal: hariIniStr(),
    nama_barang,
    stok_dibawa,
    stok_terjual,
    catatan: catatan || null
  });

  if (error) {
    msg.textContent = "Gagal mengirim laporan: " + error.message;
    msg.classList.add("error");
    return;
  }

  msg.textContent = "Laporan stok berhasil dikirim.";
  msg.classList.add("ok");
  document.getElementById("formStok").reset();
  document.getElementById("namaBarang").value = "Es";
  await muatRiwayatStok();
}

async function muatRiwayatStok() {
  const { data, error } = await sb
    .from("stock_reports")
    .select("*")
    .eq("user_id", profilSaya.id)
    .order("created_at", { ascending: false })
    .limit(10);

  const box = document.getElementById("riwayatStok");
  if (error || !data || data.length === 0) {
    box.innerHTML = `<p class="empty">Belum ada laporan stok.</p>`;
    return;
  }
  box.innerHTML = `<table><thead><tr><th>Tanggal</th><th>Barang</th><th>Dibawa</th><th>Terjual</th><th>Sisa</th></tr></thead><tbody>
    ${data.map(r => `<tr>
      <td>${new Date(r.tanggal).toLocaleDateString("id-ID")}</td>
      <td>${r.nama_barang}</td>
      <td>${r.stok_dibawa}</td>
      <td>${r.stok_terjual}</td>
      <td>${r.stok_sisa}</td>
    </tr>`).join("")}
  </tbody></table>`;
}

init();
