// Kumpulan fungsi bantu untuk sesi login & profil user

function getPerusahaanTerpilih() {
  const data = localStorage.getItem("perusahaan_terpilih");
  return data ? JSON.parse(data) : null;
}

function setPerusahaanTerpilih(company) {
  localStorage.setItem("perusahaan_terpilih", JSON.stringify(company));
}

async function ambilProfilSaya() {
  const { data: sessionData } = await sb.auth.getSession();
  const session = sessionData.session;
  if (!session) return null;

  const { data: profil, error } = await sb
    .from("profiles")
    .select("*, companies(name, slug)")
    .eq("id", session.user.id)
    .single();

  if (error) {
    console.error("Gagal mengambil profil:", error.message);
    return null;
  }
  return profil;
}

// Melindungi halaman: kalau belum login atau role tidak cocok, lempar ke login.html
async function wajibLogin(roleYangDiizinkan) {
  const profil = await ambilProfilSaya();
  if (!profil) {
    window.location.href = "login.html";
    return null;
  }
  if (roleYangDiizinkan && profil.role !== roleYangDiizinkan) {
    alert("Halaman ini bukan untuk akun kamu.");
    window.location.href = profil.role === "admin" ? "admin.html" : "karyawan.html";
    return null;
  }
  return profil;
}

async function logout() {
  await sb.auth.signOut();
  window.location.href = "index.html";
}
