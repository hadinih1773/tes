let profilSaya = null;

function formatTanggal(d) {
  return new Date(d).toLocaleDateString("id-ID", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}
function formatJam(iso) {
  return new Date(iso).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}
function hariIniStr() {
  return new Date().toISOString().slice(0, 10);
}

async function init() {
  profilSaya = await wajibLogin("admin");
  if (!profilSaya) return;

  document.body.setAttribute("data-theme", profilSaya.companies.slug === "coffee" ? "coffee" : "ice");
  document.getElementById("brandLabel").textContent = profilSaya.companies.name + " · Admin";
  document.getElementById("namaUser").textContent = profilSaya.full_name;
  document.getElementById("tanggalHariIni").textContent = formatTanggal(new Date());

  document.getElementById("filterTanggalAbsen").value = hariIniStr();
  document.getElementById("filterTanggalStok").value = hariIniStr();

  setupTabs();
  await muatJamAturan();
  await muatRingkasan();
  await muatTabelAbsen();
  await muatTabelStok();

  document.getElementById("formJam").addEventListener("submit", simpanJamAturan);
  document.getElementById("btnFilterAbsen").addEventListener("click", muatTabelAbsen);
  document.getElementById("btnFilterStok").addEventListener("click", muatTabelStok);
}

function setupTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
    });
  });
}

async function muatJamAturan() {
  const { data, error } = await sb
    .from("attendance_settings")
    .select("start_time, end_time")
    .eq("company_id", profilSaya.company_id)
    .single();

  if (!error && data) {
    document.getElementById("jamMulai").value = data.start_time.slice(0, 5);
    document.getElementById("jamSelesai").value = data.end_time.slice(0, 5);
  }
}

async function simpanJamAturan(e) {
  e.preventDefault();
  const msg = document.getElementById("jamMsg");
  msg.textContent = "";
  msg.className = "form-msg";

  const start_time = document.getElementById("jamMulai").value;
  const end_time = document.getElementById("jamSelesai").value;

  if (start_time >= end_time) {
    msg.textContent = "Jam mulai harus sebelum jam selesai.";
    msg.classList.add("error");
    return;
  }

  const { error } = await sb
    .from("attendance_settings")
    .update({ start_time, end_time, updated_at: new Date().toISOString() })
    .eq("company_id", profilSaya.company_id);

  if (error) {
    msg.textContent = "Gagal menyimpan: " + error.message;
    msg.classList.add("error");
    return;
  }
  msg.textContent = "Jam absensi berhasil diperbarui.";
  msg.classList.add("ok");
}

async function muatRingkasan() {
  const hariIni = hariIniStr();

  const { count: jumlahHadir } = await sb
    .from("attendance_records")
    .select("*", { count: "exact", head: true })
    .eq("company_id", profilSaya.company_id)
    .eq("tanggal", hariIni);

  const { data: stok } = await sb
    .from("stock_reports")
    .select("stok_dibawa, stok_sisa")
    .eq("company_id", profilSaya.company_id)
    .eq("tanggal", hariIni);

  document.getElementById("sHadir").textContent = jumlahHadir ?? 0;

  const totalDibawa = (stok || []).reduce((a, r) => a + Number(r.stok_dibawa), 0);
  const totalSisa = (stok || []).reduce((a, r) => a + Number(r.stok_sisa), 0);
  document.getElementById("sDibawa").textContent = totalDibawa;
  document.getElementById("sSisa").textContent = totalSisa;
}

async function muatTabelAbsen() {
  const tanggal = document.getElementById("filterTanggalAbsen").value || hariIniStr();
  const box = document.getElementById("tabelAbsen");

  const { data, error } = await sb
    .from("attendance_records")
    .select("*, profiles(full_name)")
    .eq("company_id", profilSaya.company_id)
    .eq("tanggal", tanggal)
    .order("jam_absen", { ascending: true });

  if (error || !data || data.length === 0) {
    box.innerHTML = `<p class="empty">Belum ada data absensi untuk tanggal ini.</p>`;
    return;
  }

  box.innerHTML = `<table><thead><tr><th>Karyawan</th><th>Jam Absen</th><th>Status</th></tr></thead><tbody>
    ${data.map(r => `<tr>
      <td>${r.profiles?.full_name ?? "-"}</td>
      <td>${formatJam(r.jam_absen)}</td>
      <td><span class="badge ${r.status === 'tepat_waktu' ? 'ok' : 'warn'}">${r.status.replace('_',' ')}</span></td>
    </tr>`).join("")}
  </tbody></table>`;
}

async function muatTabelStok() {
  const tanggal = document.getElementById("filterTanggalStok").value || hariIniStr();
  const box = document.getElementById("tabelStok");

  const { data, error } = await sb
    .from("stock_reports")
    .select("*, profiles(full_name)")
    .eq("company_id", profilSaya.company_id)
    .eq("tanggal", tanggal)
    .order("created_at", { ascending: false });

  if (error || !data || data.length === 0) {
    box.innerHTML = `<p class="empty">Belum ada laporan stok untuk tanggal ini.</p>`;
    return;
  }

  const totalDibawa = data.reduce((a, r) => a + Number(r.stok_dibawa), 0);
  const totalTerjual = data.reduce((a, r) => a + Number(r.stok_terjual), 0);
  const totalSisa = data.reduce((a, r) => a + Number(r.stok_sisa), 0);

  box.innerHTML = `<table><thead><tr><th>Karyawan</th><th>Barang</th><th>Dibawa</th><th>Terjual</th><th>Sisa</th><th>Catatan</th></tr></thead><tbody>
    ${data.map(r => `<tr>
      <td>${r.profiles?.full_name ?? "-"}</td>
      <td>${r.nama_barang}</td>
      <td>${r.stok_dibawa}</td>
      <td>${r.stok_terjual}</td>
      <td>${r.stok_sisa}</td>
      <td>${r.catatan ?? "-"}</td>
    </tr>`).join("")}
    <tr style="font-weight:700;">
      <td colspan="2">Total</td>
      <td>${totalDibawa}</td>
      <td>${totalTerjual}</td>
      <td>${totalSisa}</td>
      <td></td>
    </tr>
  </tbody></table>`;
}

init();
