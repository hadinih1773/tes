const perusahaan = getPerusahaanTerpilih();

if (!perusahaan) {
  window.location.href = "index.html";
} else {
  document.body.setAttribute("data-theme", perusahaan.theme);
  document.getElementById("brandLabel").innerHTML = `${perusahaan.name}`;
  document.getElementById("companySub").textContent = `Login karyawan & admin ${perusahaan.name}`;
}

const form = document.getElementById("formLogin");
const msg = document.getElementById("msg");
const btn = document.getElementById("btnLogin");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "";
  msg.className = "form-msg";
  btn.disabled = true;
  btn.textContent = "Memproses...";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const { data, error } = await sb.auth.signInWithPassword({ email, password });

  if (error) {
    msg.textContent = "Email atau kata sandi salah.";
    msg.classList.add("error");
    btn.disabled = false;
    btn.textContent = "Masuk";
    return;
  }

  const profil = await ambilProfilSaya();

  if (!profil) {
    msg.textContent = "Akun ini belum terdaftar sebagai karyawan/admin.";
    msg.classList.add("error");
    await sb.auth.signOut();
    btn.disabled = false;
    btn.textContent = "Masuk";
    return;
  }

  if (profil.companies.slug !== perusahaan.slug) {
    msg.textContent = `Akun ini terdaftar di ${profil.companies.name}, bukan ${perusahaan.name}.`;
    msg.classList.add("error");
    await sb.auth.signOut();
    btn.disabled = false;
    btn.textContent = "Masuk";
    return;
  }

  msg.textContent = "Berhasil masuk, mengalihkan...";
  msg.classList.add("ok");
  window.location.href = profil.role === "admin" ? "admin.html" : "karyawan.html";
});
