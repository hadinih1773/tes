-- ============================================================
-- SKEMA DATABASE - ENIMO GROUP (Crystal Ice & Coffee)
-- Jalankan file ini di Supabase Dashboard -> SQL Editor -> Run
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- PERUSAHAAN ----------
create table if not exists companies (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  slug text not null unique
);

insert into companies (name, slug) values
  ('Crystal Ice', 'crystal-ice'),
  ('Coffee', 'coffee')
on conflict (slug) do nothing;

-- ---------- PROFIL KARYAWAN / ADMIN ----------
-- id sama dengan id di auth.users (dibuat saat user pertama login/signup)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid references companies(id) not null,
  full_name text not null,
  role text not null check (role in ('admin','karyawan')) default 'karyawan',
  created_at timestamptz default now()
);

-- ---------- PENGATURAN JAM ABSENSI (per perusahaan, diatur admin) ----------
create table if not exists attendance_settings (
  company_id uuid primary key references companies(id),
  start_time time not null default '08:00',
  end_time time not null default '08:30',
  updated_at timestamptz default now()
);

insert into attendance_settings (company_id, start_time, end_time)
select id, '08:00', '08:30' from companies
on conflict (company_id) do nothing;

-- ---------- ABSENSI ----------
create table if not exists attendance_records (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) not null,
  company_id uuid references companies(id) not null,
  tanggal date not null default current_date,
  jam_absen timestamptz not null default now(),
  status text not null check (status in ('tepat_waktu','terlambat','di_luar_jam')),
  unique (user_id, tanggal)
);

-- ---------- LAPORAN STOK BARANG ----------
create table if not exists stock_reports (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) not null,
  company_id uuid references companies(id) not null,
  tanggal date not null default current_date,
  nama_barang text not null default 'Es',
  stok_dibawa numeric not null default 0,
  stok_terjual numeric not null default 0,
  stok_sisa numeric generated always as (stok_dibawa - stok_terjual) stored,
  catatan text,
  created_at timestamptz default now()
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table companies enable row level security;
alter table profiles enable row level security;
alter table attendance_settings enable row level security;
alter table attendance_records enable row level security;
alter table stock_reports enable row level security;

-- Semua orang yang login boleh lihat daftar perusahaan (untuk halaman pilih perusahaan)
create policy "companies_select_all" on companies
  for select using (true);

-- Fungsi bantu: cek role admin milik user yang sedang login
create or replace function is_admin(check_company uuid)
returns boolean as $$
  select exists (
    select 1 from profiles
    where id = auth.uid()
      and role = 'admin'
      and company_id = check_company
  );
$$ language sql security definer;

-- PROFILES
create policy "profiles_select_own_or_admin" on profiles
  for select using (
    id = auth.uid() or is_admin(company_id)
  );

create policy "profiles_insert_self" on profiles
  for insert with check (id = auth.uid());

create policy "profiles_update_own_or_admin" on profiles
  for update using (id = auth.uid() or is_admin(company_id));

-- ATTENDANCE SETTINGS (semua karyawan boleh baca jam absensi, hanya admin boleh ubah)
create policy "settings_select_all" on attendance_settings
  for select using (true);

create policy "settings_update_admin_only" on attendance_settings
  for update using (is_admin(company_id));

-- ATTENDANCE RECORDS
create policy "attendance_select_own_or_admin" on attendance_records
  for select using (user_id = auth.uid() or is_admin(company_id));

create policy "attendance_insert_own" on attendance_records
  for insert with check (user_id = auth.uid());

-- STOCK REPORTS
create policy "stock_select_own_or_admin" on stock_reports
  for select using (user_id = auth.uid() or is_admin(company_id));

create policy "stock_insert_own" on stock_reports
  for insert with check (user_id = auth.uid());

create policy "stock_update_own_or_admin" on stock_reports
  for update using (user_id = auth.uid() or is_admin(company_id));

-- ============================================================
-- CATATAN
-- ============================================================
-- 1. Buat user admin/karyawan lewat Supabase Dashboard -> Authentication -> Add user
--    (atau lewat halaman signup kalau kamu tambahkan nanti).
-- 2. Setelah user dibuat, jalankan insert manual ke tabel profiles, contoh:
--    insert into profiles (id, company_id, full_name, role)
--    values (
--      'UUID-USER-DARI-AUTH',
--      (select id from companies where slug = 'crystal-ice'),
--      'Nama Karyawan',
--      'karyawan'   -- atau 'admin'
--    );
