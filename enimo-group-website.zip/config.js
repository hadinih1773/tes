// ============================================================
// KONFIGURASI SUPABASE
// ============================================================
// Isi 2 nilai di bawah ini dengan data dari project Supabase kamu:
// Supabase Dashboard -> Project Settings -> API
//
// PENTING SOAL KEAMANAN:
// - Pakai "anon public" key di sini, JANGAN pakai "service_role" key.
//   service_role key punya akses penuh tanpa batas (bypass semua rule
//   keamanan/RLS) dan kalau dipakai di file yang jalan di browser,
//   siapapun yang buka website bisa mencurinya lewat DevTools dan
//   mengambil alih seluruh database.
// - Keamanan data (siapa boleh lihat/ubah data siapa) diatur lewat
//   Row Level Security (RLS) di file database.sql, bukan lewat key.
// ============================================================

const SUPABASE_URL = "https://ISI-PROJECT-ID-KAMU.supabase.co";
const SUPABASE_ANON_KEY = "ISI-ANON-PUBLIC-KEY-KAMU";
