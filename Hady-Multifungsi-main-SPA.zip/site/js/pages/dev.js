// Halaman: Developer
// Dikonversi otomatis dari html/dev.html
window.PAGES = window.PAGES || {};
window.PAGES.dev = {
  title: 'Developer',
  html: `<div class="container">

<a class="back" href="#/home">← Kembali Ke Halaman Depan</a>

<h1 class="title">Hady Tools <span>Multifungsi</span></h1>

<div class="card">

  <div class="avatar-wrap">
    <img src="src/image/pphady.png" alt="Foto Profil">
  </div>

  <div class="dev-name">@Hadinih_</div>

  <div class="dev-role">
    <i class="fas fa-star"></i>
    Lead Developer & Founder
  </div>

  <div class="bio-box">
    <div class="bio-arabic">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</div>
    <div class="bio-latin">Bismillahirrahmanirrahim</div>
    <div class="bio-artinya">"Dengan menyebut nama Allah Yang Maha Pengasih lagi Maha Penyayang"</div>
  </div>

  <div class="socials">
    <a class="social-icon s-discord" href="https://discord.gg/4uzdM25KYv" target="_blank">
      <i class="fab fa-discord"></i>
    </a>
    <a class="social-icon s-github" href="https://github.com/hadinih1773" target="_blank">
      <i class="fab fa-github"></i>
    </a>
    <a class="social-icon s-tiktok" href="https://www.tiktok.com/@hadinih_" target="_blank">
      <i class="fab fa-tiktok"></i>
    </a>
  </div>

</div>

</div>`,
  run: function() {
(function(){


// -- expose top-level functions used by inline HTML handlers --

})();
  }
};
