// Halaman: URL Bypass Tool
// Dikonversi otomatis dari html/bps.html
window.PAGES = window.PAGES || {};
window.PAGES.bps = {
  title: 'URL Bypass Tool',
  html: `<div class="container">

<a class="back" href="#/home">← Kembali Ke Halaman Depan</a>

<h1 class="title">URL <span>Bypass</span></h1>

<div class="card">

<input id="url" placeholder="Masukkan URL (https://sfl.gl/...)" />

<button onclick="bypass()">Bypass</button>

<div id="resultBox" class="result" style="display:none;">
  <div class="small">Hasil Bypass:</div>
  <div id="resultText">-</div>

  <div class="actions">
    <button class="copy" onclick="copyResult()">Copy</button>
    <button class="open" id="openBtn">Open</button>
  </div>
</div>

</div>

</div>

<div class="toast-container" id="toastContainer"></div>`,
  run: function() {
(function(){
/* ---------- Toast Modern ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

/* ===== API FUNCTION (SESUAI REQUEST KAMU) ===== */
async function izenlolBypass(url, apikey) {
  try {
    const response = await fetch(
      `https://anabot.my.id/api/tools/izenLOL?url=${encodeURIComponent(url)}&apikey=${encodeURIComponent(apikey)}`,
      { method: 'GET' }
    );

    const data = await response.json();
    return data;

  } catch (error) {
    return error;
  }
}

/* ===== MAIN BYPASS ===== */
async function bypass(){

  const url = document.getElementById("url").value.trim();
  const box = document.getElementById("resultBox");
  const text = document.getElementById("resultText");

  if(!url){
    showToast("Masukkan URL dulu!", "error");
    return;
  }

  box.style.display = "block";
  text.innerText = "Sedang memproses...";

  const json = await izenlolBypass(url, "freeApikey");

  const result = json?.data?.result?.result;

  if(result){

    text.innerText = result;

    document.getElementById("openBtn").onclick = () => {
      window.open(result, "_blank");
    };

  } else {
    text.innerText = "Gagal bypass link.";
  }
}

/* ===== COPY RESULT ===== */
function copyResult(){
  const text = document.getElementById("resultText").innerText;

  if(!text || text === "-") return showToast("Tidak ada hasil!", "error");

  navigator.clipboard.writeText(text);
  showToast("Berhasil di-copy!", "success");
}

// -- expose top-level functions used by inline HTML handlers --
  window.copyResult = copyResult;
  window.showToast = showToast;
})();
  }
};
