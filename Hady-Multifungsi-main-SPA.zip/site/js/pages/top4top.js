// Halaman: Top4Top Converter
// Dikonversi otomatis dari html/top4top.html
window.PAGES = window.PAGES || {};
window.PAGES.top4top = {
  title: 'Top4Top Converter',
  html: `<div class="container">
  <a class="back" href="#/home">← Kembali Ke Halaman Depan</a>
  <h1 class="title">Top4Top <span>Converter</span></h1>

  <div class="card">
    <label>Link YouTube / Spotify / TikTok</label>
    <input id="url" placeholder="https://youtube.com/... , https://open.spotify.com/... , https://tiktok.com/..." />
    <button onclick="convert()">Convert ke Top4Top</button>

    <div id="resultBox" class="result" style="display:none;">
      <img id="resultThumb" class="result-thumb" style="display:none;">
      <div class="result-title" id="resultTitle">-</div>
      <div class="result-platform" id="resultPlatform">-</div>
      <div class="small">Hasil Top4Top:</div>
      <div id="resultText">-</div>
      <div class="actions">
        <button class="copy" onclick="copyResult()">Copy</button>
        <button class="open" id="openBtn">Open</button>
      </div>
    </div>
  </div>
</div>

<div class="toast-container" id="toastContainer"></div>`,
  run: function() {
(function(){
/* ---------- Toast ---------- */
  function showToast(message, type = "info") {
    const container = document.getElementById("toastContainer");
    const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("hide");
      setTimeout(() => toast.remove(), 250);
    }, 3500);
  }

  /* ---------- Safe error message ---------- */
  function getErrorMessage(err) {
    if (err instanceof Error) return err.message;
    if (typeof err === 'string') return err;
    if (err && typeof err === 'object') {
      return err.message || err.error || JSON.stringify(err);
    }
    return 'Terjadi kesalahan tidak diketahui';
  }

  /* ---------- Convert API call ---------- */
  async function convertToTop4Top(audioUrl, title) {
    const response = await fetch('/api/top4top', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ audioUrl, title })
    });

    const contentType = response.headers.get('content-type') || '';

    if (!contentType.includes('application/json')) {
      const text = await response.text();
      throw new Error(`Server tidak mengembalikan JSON (${response.status}). Response: "${text.slice(0, 150)}..."`);
    }

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || data.message || `HTTP ${response.status}`);
    }

    if (!data.status) {
      throw new Error(data.error || 'Gagal convert ke Top4Top.');
    }

    return data.result.top4top;
  }

  /* ---------- Downloader API calls ---------- */
  async function getYoutubeData(link) {
    const response = await fetch(`https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(link)}`);
    const data = await response.json();
    if (!data.status || !data.result || !data.result.mp3) {
      throw new Error('Gagal mengambil data dari API YouTube.');
    }
    return {
      audioUrl: data.result.mp3,
      title: data.result.title || '-',
      thumbnail: data.result.thumbnail || '-',
      duration: data.result.duration || '-'
    };
  }

  async function getTikTokData(link) {
    const response = await fetch(`https://kyzznekoo.zone.id/api/downloader/tiktok?url=${encodeURIComponent(link)}`);
    const data = await response.json();
    if (data.status !== 200 || !data.result) {
      throw new Error('Gagal mengambil data TikTok.');
    }
    const d = data.result;
    return {
      audioUrl: d.music?.url,
      title: d.title || '-',
      thumbnail: d.music?.thumbnail || '-',
      views: d.views,
      like: d.like,
      channel: d.author?.nickname
    };
  }

  async function getSpotifyData(link) {
    const response = await fetch(`https://api.nexray.eu.cc/downloader/spotify?url=${encodeURIComponent(link)}`);
    const data = await response.json();
    if (!data.status || !data.result) {
      throw new Error('Gagal mengambil data Spotify.');
    }
    const d = data.result;
    return {
      audioUrl: d.url,
      title: d.title || '-',
      artist: d.artist || '-',
      thumbnail: '-'
    };
  }

  /* ===== MAIN CONVERT ===== */
  async function convert() {
    const url = document.getElementById('url').value.trim();
    const box = document.getElementById('resultBox');
    const text = document.getElementById('resultText');
    const titleEl = document.getElementById('resultTitle');
    const platformEl = document.getElementById('resultPlatform');
    const thumbEl = document.getElementById('resultThumb');

    if (!url) {
      showToast('Masukkan link dulu!', 'error');
      return;
    }

    box.style.display = 'block';
    thumbEl.style.display = 'none';
    titleEl.innerText = '-';
    platformEl.innerText = '-';
    text.innerText = '⏳ Sedang memproses...';

    const isYt = /youtube\.com|youtu\.be/.test(url);
    const isSp = /spotify/i.test(url);
    const isTt = /tiktok/i.test(url);

    try {
      let data, platform;

      if (isYt) {
        data = await getYoutubeData(url);
        platform = 'YouTube';
      } else if (isTt) {
        data = await getTikTokData(url);
        platform = 'TikTok';
      } else if (isSp) {
        data = await getSpotifyData(url);
        platform = 'Spotify';
      } else {
        throw new Error('URL tidak didukung. Gunakan YouTube, Spotify, atau TikTok.');
      }

      if (!data.audioUrl) {
        throw new Error('Tidak dapat mengambil URL audio dari platform tersebut.');
      }

      const top4topLink = await convertToTop4Top(data.audioUrl, data.title);

      titleEl.innerText = data.title || 'Tanpa judul';
      platformEl.innerText = platform;
      text.innerText = top4topLink;

      if (data.thumbnail && data.thumbnail.startsWith('http')) {
        thumbEl.src = data.thumbnail;
        thumbEl.style.display = 'block';
      }

      document.getElementById('openBtn').onclick = () => {
        window.open(top4topLink, '_blank');
      };

      showToast('✅ Berhasil convert ke Top4Top!', 'success');

    } catch (err) {
      const msg = getErrorMessage(err);
      text.innerText = '❌ Gagal convert link.';
      showToast(`⚠️ ${msg}`, 'error');
      console.error('[Convert Error]', err);
    }
  }

  /* ===== COPY RESULT ===== */
  function copyResult() {
    const text = document.getElementById('resultText').innerText;
    if (!text || text === '-' || text.includes('Gagal') || text.includes('❌')) {
      return showToast('Tidak ada hasil untuk di-copy!', 'error');
    }

    navigator.clipboard.writeText(text)
      .then(() => showToast('📋 Berhasil di-copy!', 'success'))
      .catch(() => {
        // fallback
        const range = document.createRange();
        const sel = window.getSelection();
        const el = document.getElementById('resultText');
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('copy');
        sel.removeAllRanges();
        showToast('📋 Berhasil di-copy!', 'success');
      });
  }

// -- expose top-level functions used by inline HTML handlers --

})();
  }
};
