// Halaman: Webhook Spam & Checker
// Dikonversi otomatis dari html/webhook.html
window.PAGES = window.PAGES || {};
window.PAGES.webhook = {
  title: 'Webhook Spam & Checker',
  html: `<div class="container">

<a href="#/home" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">Spam & Check <span>Webhook</span></h1>

<div class="card">

<label>URL Webhook</label>
<input id="url" placeholder="https://discord.com/api/webhooks/...">

<label>Pesan</label>
<textarea id="msg" placeholder="Tulis pesan..."></textarea>

<label>Jumlah Spam</label>
<input id="jumlah" type="number" value="1" min="1">

<button class="btn-check" onclick="cekWebhook()">Cek Webhook</button>

<div id="status" class="status"></div>

<button class="btn-spam" onclick="spamWebhook()">Start Spam</button>

</div>

<div class="card">

<h3>Spam Log</h3>
<div class="log-box" id="log"></div>

</div>

</div>`,
  run: function() {
(function(){
const logBox = document.getElementById("log");
const status = document.getElementById("status");

function log(text){
  logBox.innerHTML += text + "<br>";
  logBox.scrollTop = logBox.scrollHeight;
}

async function cekWebhook(){

  const url = document.getElementById("url").value.trim();
  if(!url){
    status.textContent = "Masukkan URL webhook!";
    status.className = "status bad";
    return;
  }

  try{
    const res = await fetch(url);
    const data = await res.json();

    status.textContent = "Webhook Aktif ✔";
    status.className = "status ok";

    log("✔ Webhook aktif: " + (data.name || "unknown"));

  }catch(err){
    status.textContent = "Webhook Tidak Aktif ✖";
    status.className = "status bad";

    log("✖ Webhook error / tidak ditemukan");
  }

}

async function spamWebhook(){

  const url = document.getElementById("url").value.trim();
  const msg = document.getElementById("msg").value.trim();
  const jumlah = parseInt(document.getElementById("jumlah").value);

  if(!url || !msg){
    status.textContent = "URL dan pesan wajib diisi!";
    status.className = "status bad";
    return;
  }

  log("🚀 Mulai spam...");

  for(let i=1;i<=jumlah;i++){

    try{

      await fetch(url, {
        method:"POST",
        headers:{
          "Content-Type":"application/json"
        },
        body: JSON.stringify({
          content: msg,
          username: "Spamming Bot"
        })
      });

      log("✔ Pesan terkirim #" + i);

    }catch(err){
      log("✖ Gagal kirim #" + i);
    }

    await new Promise(r => setTimeout(r, 1000));

  }

  log("✅ Selesai spam");

}

// -- expose top-level functions used by inline HTML handlers --
  window.log = log;
})();
  }
};
