// Halaman: Beranda
window.PAGES = window.PAGES || {};
window.PAGES.home = {
  title: 'Beranda',
  run: function() {
    const el = document.getElementById("visitCount");
    if (el) el.textContent = window.__visitCount || localStorage.getItem("visitCount") || "0";
  },
  html: `<div class="section-tag">// welcome</div>  
  <h1 class="section-title">Hady Tools <span>Multifungsi</span></h1>  

  <div class="about-card">  
    <p>  
      Selamat datang di <strong>Hady Tools Multifungsi</strong>, sebuah website kumpulan tools serba guna
      yang dibuat untuk mempermudah berbagai kebutuhan sehari-hari kamu. Di sini kamu bisa menemukan
      <strong>downloader</strong> untuk TikTok, YouTube, Instagram, dan Facebook, tools khusus
      <strong>SA-MP</strong> seperti Webhook Spam & Checker, Top4Top Converter, File Uploader, Lua
      Obfuscator & Deobfuscator, hingga URL Bypass. Ada juga fitur <strong>Code Snippet</strong> untuk
      berbagi script dan mod dengan mudah. Semua tools dikemas dalam satu tempat, simpel, dan gratis
      untuk digunakan siapa saja.  
    </p>  
  </div>  

  <div class="section-tag">// site.stats</div>  
  <h2 class="section-title" style="font-size:1.7rem; margin-bottom:20px;">Statistik <span>Kunjungan</span></h2>  

  <div class="stats-grid">  
    <div class="stat-card">  
      <div class="stat-num" id="visitCount">0</div>  
      <div class="stat-label">Total Kunjungan</div>  
    </div>  
    <div class="stat-card">  
      <div class="stat-num" id="toolCount">14</div>  
      <div class="stat-label">Tools Tersedia</div>  
    </div>  
    <div class="stat-card">  
      <div class="stat-num">24/7</div>  
      <div class="stat-label">Online</div>  
    </div>  
  </div>  

  <div class="section-tag">// featured.tools</div>  
  <h2 class="section-title" style="font-size:1.7rem; margin-bottom:20px;">Jelajahi <span>Tools</span></h2>  

  <div class="edu-slider">  
    <a href="#/aiodl" class="edu-card">  
      <div class="edu-icon-box">  
        <i class="fas fa-download"></i>  
      </div>  
      <div>  
        <div class="edu-level">Downloader</div>  
        <div class="edu-name">All In One Downloader</div>  
      </div>  
    </a>  

    <a href="#/webhook" class="edu-card">  
      <div class="edu-icon-box">  
        <i class="fas fa-link"></i>  
      </div>  
      <div>  
        <div class="edu-level">Samp Tools</div>  
        <div class="edu-name">Webhook Spam & Checker</div>  
      </div>  
    </a>  

    <a href="#/obf" class="edu-card">  
      <div class="edu-icon-box">  
        <i class="fas fa-code"></i>  
      </div>  
      <div>  
        <div class="edu-level">Samp Tools</div>  
        <div class="edu-name">Lua Obfuscator</div>  
      </div>  
    </a>  

    <a href="#/snippet" class="edu-card">  
      <div class="edu-icon-box">  
        <i class="fas fa-code"></i>  
      </div>  
      <div>  
        <div class="edu-level">Share</div>  
        <div class="edu-name">Code Snippet</div>  
      </div>  
    </a>  
  </div>  

  <div class="section-tag">// about.dev</div>  
  <h2 class="section-title" style="font-size:1.7rem; margin-bottom:20px;">Temukan <span>Saya</span></h2>  

  <div class="socials-grid">  
    <a href="https://www.youtube.com/@hadinih" target="_blank" class="social-card s-yt" id="link-youtube">  
      <i class="fab fa-youtube"></i>  
      <span>YouTube</span>  
    </a>  
    <a href="https://www.tiktok.com/@hadinih_" target="_blank" class="social-card s-tt" id="link-tiktok">  
      <i class="fab fa-tiktok"></i>  
      <span>TikTok</span>  
    </a>  
    <a href="https://discord.gg/4uzdM25KYv" target="_blank" class="social-card s-dc" id="link-discord">  
      <i class="fab fa-discord"></i>  
      <span>Discord</span>  
    </a>  
    <a href="https://www.instagram.com/hadinih_" target="_blank" class="social-card s-ig" id="link-instagram">  
      <i class="fab fa-instagram"></i>  
      <span>Instagram</span>  
    </a>  
    <a href="https://github.com/hadinih1773" target="_blank" class="social-card s-gh" id="link-github">  
      <i class="fab fa-github"></i>  
      <span>GitHub</span>  
    </a>  
    <a href="https://x.com/hadinih_" target="_blank" class="social-card s-tw" id="link-twitter">  
      <i class="fab fa-twitter"></i>  
      <span>Twitter</span>  
    </a>  
  </div>`
};
