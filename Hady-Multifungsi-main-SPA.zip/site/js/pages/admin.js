// Halaman: Admin Panel
// Dikonversi & digabung dari html/lock.html — sekarang pakai login username+password dari config.js
window.PAGES = window.PAGES || {};
window.PAGES.admin = {
  title: 'Admin Panel',
  html: `<div class="card" id="mainCard" style="display:none;">

<h1>🛡️ Admin Panel</h1>

<div class="status" id="status">
Status : Loading...
</div>

<button class="btn lock" id="lockBtn">
LOCK WEBSITE
</button>

<button class="btn unlock" id="unlockBtn">
UNLOCK WEBSITE
</button>

<button class="btn back" id="logoutBtn" style="cursor:pointer;">
Logout Admin
</button>

<a href="#/home" class="btn back">
  ← Kembali Ke Halaman Depan
</a>

</div>

<div class="modal-overlay" id="passwordOverlay">
  <div class="password-modal">
    <div class="password-icon">🛡️</div>
    <h3>Admin Panel</h3>
    <p>Login untuk mengelola kunci website</p>

    <input type="text" id="adminUsernameInput" placeholder="Username" maxlength="30" autocomplete="username">
    <input type="password" id="adminPasswordInput" placeholder="••••••••" maxlength="30" autocomplete="current-password">
    <div class="password-error" id="adminPasswordError"></div>

    <button class="btn unlock" id="adminPasswordSubmit">Masuk</button>
  </div>
</div>

<div class="toast-container" id="toastContainer"></div>`,
  run: function() {
(function(){

/* ---------- Toast Modern ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

const passwordOverlay = document.getElementById("passwordOverlay");
const adminUsernameInput = document.getElementById("adminUsernameInput");
const adminPasswordInput = document.getElementById("adminPasswordInput");
const adminPasswordError = document.getElementById("adminPasswordError");
const mainCard = document.getElementById("mainCard");

function submitAdminPassword(){
  const user = adminUsernameInput.value.trim();
  const pass = adminPasswordInput.value;

  if(user !== window.CONFIG.adminUsername || pass !== window.CONFIG.adminPassword){
    adminPasswordError.innerText = "❌ Username atau Password Salah";
    return;
  }

  sessionStorage.setItem("adminLoggedIn", "true");
  passwordOverlay.style.display = "none";
  mainCard.style.display = "block";
  updateStatus();
}

document
.getElementById("adminPasswordSubmit")
.onclick = submitAdminPassword;

[adminUsernameInput, adminPasswordInput].forEach(el => {
  el.addEventListener("keypress", e => {
    if(e.key === "Enter"){
      submitAdminPassword();
    }
  });
});

// Kalau sudah login di sesi ini, langsung buka panel tanpa minta login ulang
if(sessionStorage.getItem("adminLoggedIn") === "true"){
  passwordOverlay.style.display = "none";
  mainCard.style.display = "block";
} else {
  adminUsernameInput.focus();
}

const statusText =
document.getElementById("status");

function updateStatus(){

  const locked =
  localStorage.getItem("websiteLocked");

  statusText.innerHTML =
  locked === "true"
  ? "Status : 🔒 LOCKED"
  : "Status : 🔓 UNLOCKED";

}

updateStatus();

document
.getElementById("lockBtn")
.onclick = () => {

  localStorage.setItem(
    "websiteLocked",
    "true"
  );

  updateStatus();

  showToast("🔒 Website berhasil dikunci", "success");

};

document
.getElementById("unlockBtn")
.onclick = () => {

  localStorage.setItem(
    "websiteLocked",
    "false"
  );

  updateStatus();

  showToast("🔓 Website berhasil dibuka", "success");

};

document
.getElementById("logoutBtn")
.onclick = () => {
  sessionStorage.removeItem("adminLoggedIn");
  location.hash = "#/home";
  location.reload();
};

})();
  }
};
