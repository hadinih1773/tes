// Halaman: TikTok Downloader
// Dikonversi otomatis dari html/ttdl.html
window.PAGES = window.PAGES || {};
window.PAGES.ttdl = {
  title: 'TikTok Downloader',
  html: `<div class="container">

<a href="#/home" class="back">
← Kembali Ke Halaman Depan
</a>

<h1 class="title">
TikTok <span>Downloader</span>
</h1>

<div class="card">

<label>URL TikTok</label>

<input
id="url"
placeholder="https://vt.tiktok.com/..."
>

<button id="downloadBtn">
Download
</button>

<div id="result" class="result"></div>

</div>

</div>`,
  run: function() {
(function(){
const btn = document.getElementById("downloadBtn");

btn.addEventListener("click", async ()=>{

  const url =
    document.getElementById("url").value.trim();

  const result =
    document.getElementById("result");

  if(!url){
    result.innerHTML =
      "<p>Masukkan URL TikTok terlebih dahulu.</p>";
    return;
  }

  result.innerHTML =
    "<p>Sedang mengambil data...</p>";

  try{

    const res = await fetch(
      `https://api.nexray.eu.cc/downloader/tiktok?url=${encodeURIComponent(url)}`
    );

    const json = await res.json();

    if(!json.status){
      throw new Error("Gagal mengambil data");
    }

    const data = json.result;

    result.innerHTML = `

      <img src="${data.cover}" alt="Cover TikTok">

      <h3>${data.title}</h3>

      <a
      href="${data.data}"
      target="_blank"
      class="download-btn">
      Download Video
      </a>

      <a
      href="${data.music_info.url}"
      target="_blank"
      class="download-btn">
      Download Audio
      </a>

    `;

  }catch(err){

    console.error(err);

    result.innerHTML =
      "<p>Gagal mengambil data TikTok.</p>";

  }

});

// -- expose top-level functions used by inline HTML handlers --

})();
  }
};
