// Halaman: Facebook Downloader
// Dikonversi otomatis dari html/fbdl.html
window.PAGES = window.PAGES || {};
window.PAGES.fbdl = {
  title: 'Facebook Downloader',
  html: `<div class="container">

<a href="#/home" class="back">
← Kembali Ke Halaman Depan
</a>

<h1 class="title">
Facebook <span>Downloader</span>
</h1>

<div class="card">

<label>URL Facebook</label>
<input id="url" placeholder="https://www.facebook.com/share/v/...">

<button id="downloadBtn">
Download
</button>

<div id="result" class="result"></div>

</div>

</div>`,
  run: function() {
(function(){
document.getElementById("downloadBtn").addEventListener("click", async () => {

  const url = document.getElementById("url").value.trim();
  const result = document.getElementById("result");

  if(!url){
    result.innerHTML = "<p>Masukkan URL Facebook terlebih dahulu.</p>";
    return;
  }

  result.innerHTML = "<p>Sedang mengambil data...</p>";

  try{

    const res = await fetch(
      `https://api-faa.my.id/faa/fbdownload?url=${encodeURIComponent(url)}`
    );

    const json = await res.json();

    if(!json.status){
      throw new Error("Gagal mengambil data");
    }

    const data = json.result;

    result.innerHTML = `
      <h3 style="margin-bottom:15px;">${data.info.title}</h3>

      <video controls src="${data.media.video_hd || data.media.video_sd}"></video>

      <a
      href="${data.media.video_hd}"
      target="_blank"
      class="download-btn">
      Download HD
      </a>

      <a
      href="${data.media.video_sd}"
      target="_blank"
      class="download-btn">
      Download SD
      </a>
    `;

  }catch(err){

    console.error(err);
    result.innerHTML = "<p>Gagal mengambil data Facebook.</p>";

  }

});

// -- expose top-level functions used by inline HTML handlers --

})();
  }
};
