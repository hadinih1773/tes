// Halaman: Lua Deobfuscator
// Dikonversi otomatis dari html/deobf.html
window.PAGES = window.PAGES || {};
window.PAGES.deobf = {
  title: 'Lua Deobfuscator',
  html: `<div class="container">

<a href="#/home" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">Lua <span>Deobfuscator</span></h1>

<div class="card">

<label>Paste Script Lua Ter-obfuscate</label>
<textarea id="input"></textarea>

<label>Atau Upload File (.lua / .txt)</label>
<input type="file" id="fileInput" accept=".lua,.txt">

<button onclick="deobfuscate()">Deobfuscate</button>

</div>

<div class="card">

<label>Hasil Deobfuscate</label>
<textarea id="output" readonly></textarea>

<div class="actions">
<button class="copy" onclick="copyText()">Copy</button>
<button class="download" onclick="downloadLua()">Download .lua</button>
<button class="download" onclick="downloadTxt()">Download .txt</button>
</div>

</div>

</div>

<div class="toast-container" id="toastContainer"></div>`,
  run: function() {
(function(){
// Menyimpan nama file asli secara global
let originalFileName = "script";

/* ---------- Toast Modern ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

async function deobfuscateLua(script, filename){
  const res = await fetch("/api/deobf", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ script, filename })
  });

  const data = await res.json();

  if(!res.ok){
    throw new Error(data.error || "Gagal deobfuscate");
  }

  return data.result;
}

/* BUTTON DEOBFUSCATE */
async function deobfuscate(){
  const input = document.getElementById("input").value.trim();
  const output = document.getElementById("output");

  if(!input){
    showToast("Isi script ter-obfuscate dulu!", "error");
    return;
  }

  output.value = "Processing...";

  try{
    const result = await deobfuscateLua(input, originalFileName + ".lua");
    output.value = result;
    showToast("Berhasil men-deobfuscate kode!", "success");
  }catch(err){
    output.value = "Error: " + err.message;
    showToast(err.message, "error");
  }
}

/* FILE INPUT LISTENER */
document.getElementById("fileInput").addEventListener("change", function(e){
  const file = e.target.files[0];
  if(!file) return;

  const parts = file.name.split(".");
  const ext = parts.pop().toLowerCase();
  
  if(!["lua","txt"].includes(ext)){
    showToast("File harus .lua atau .txt", "error");
    this.value = "";
    return;
  }

  // Simpan nama dasar file untuk penamaan download nanti
  originalFileName = parts.join(".");

  const reader = new FileReader();
  reader.onload = (evt)=>{
    document.getElementById("input").value = evt.target.result;
  };
  reader.readAsText(file);
});

/* COPY TEXT */
function copyText(){
  const output = document.getElementById("output");
  if(!output.value || output.value.startsWith("Processing...") || output.value.startsWith("Error:")) {
    return showToast("Tidak ada hasil yang valid untuk di-copy!", "error");
  }
  navigator.clipboard.writeText(output.value);
  showToast("Berhasil di-copy!", "success");
}

/* DOWNLOAD LOGIC */
function downloadFile(name, content){
  const blob = new Blob([content], {type:"text/plain"});
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();

  URL.revokeObjectURL(url);
}

function downloadLua(){
  const output = document.getElementById("output").value;
  if(!output || output.startsWith("Processing...") || output.startsWith("Error:")) {
    return showToast("Tidak ada hasil deobfuscate!", "error");
  }
  downloadFile(`${originalFileName}_deobfuscator.lua`, output);
}

function downloadTxt(){
  const output = document.getElementById("output").value;
  if(!output || output.startsWith("Processing...") || output.startsWith("Error:")) {
    return showToast("Tidak ada hasil deobfuscate!", "error");
  }
  downloadFile(`${originalFileName}_deobfuscator.txt`, output);
}

// -- expose top-level functions used by inline HTML handlers --
  window.copyText = copyText;
  window.downloadFile = downloadFile;
  window.downloadLua = downloadLua;
  window.downloadTxt = downloadTxt;
  window.showToast = showToast;
})();
  }
};
