// Halaman: Uploader
// Dikonversi otomatis dari html/uploader.html
window.PAGES = window.PAGES || {};
window.PAGES.uploader = {
  title: 'Uploader',
  html: `<div class="container">
  <a class="back" href="#/home">← Kembali Ke Halaman Depan</a>
  <h1 class="title">File <span>Uploader</span></h1>

  <div class="card">
    <label>Pilih Gambar / Video</label>
    <input id="fileInput" type="file" accept="image/*,video/*" />
    <button onclick="uploadFile()">Upload</button>

    <div id="resultBox" class="result" style="display:none;">
      <img id="resultThumb" class="result-thumb" style="display:none;">
      <div class="result-title" id="resultTitle">-</div>
      <div class="result-platform" id="resultPlatform">-</div>
      <div class="small">Hasil URL:</div>
      <div id="resultText">-</div>
      <div class="actions">
        <button class="copy" onclick="copyResult()">Copy</button>
        <button class="open" id="openBtn">Open</button>
      </div>
    </div>

    <!-- Dokumentasi API / cURL / Node.js / Python -->
    <div class="api-docs">
      <h3>Dokumentasi API</h3>
      
      <label>cURL (POST):</label>
      <div class="code-wrapper">
        <pre id="code-curl">curl -X POST https://hadytools.vercel.app/api/uploader -F "file=@/path/to/file.jpg"</pre>
        <button class="copy-code-btn" onclick="copyCode('code-curl')"><i class="fas fa-copy"></i></button>
      </div>

      <label>Node.js / Bot WhatsApp (Axios & FormData):</label>
      <div class="code-wrapper">
        <pre id="code-nodejs">const axios = require('axios');
const FormData = require('form-data');

async function uploadMedia(buffer, filename) {
  const form = new FormData();
  form.append('file', buffer, filename);

  const res = await axios.post('https://hadytools.vercel.app/api/uploader', form, {
    headers: form.getHeaders()
  });

  return res.data.result.url;
}</pre>
        <button class="copy-code-btn" onclick="copyCode('code-nodejs')"><i class="fas fa-copy"></i></button>
      </div>

      <label>Python (Requests):</label>
      <div class="code-wrapper">
        <pre id="code-python">import requests

url = "https://hadytools.vercel.app/api/uploader"
files = {'file': open('image.png', 'rb')}

response = requests.post(url, files=files)
print(response.json()['result']['url'])</pre>
        <button class="copy-code-btn" onclick="copyCode('code-python')"><i class="fas fa-copy"></i></button>
      </div>
    </div>

  </div>
</div>

<div class="toast-container" id="toastContainer"></div>`,
  run: function() {
(function(){
/* ---------- Toast ---------- */
  function showToast(message, type = "info") {
    const container = document.getElementById("toastContainer");
    const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("hide");
      setTimeout(() => toast.remove(), 250);
    }, 3500);
  }

  /* ---------- Safe error message ---------- */
  function getErrorMessage(err) {
    if (err instanceof Error) return err.message;
    if (typeof err === 'string') return err;
    if (err && typeof err === 'object') {
      return err.message || err.error || JSON.stringify(err);
    }
    return 'Terjadi kesalahan tidak diketahui';
  }

  /* ===== MAIN UPLOAD ===== */
  async function uploadFile() {
    const fileInput = document.getElementById('fileInput');
    const box = document.getElementById('resultBox');
    const text = document.getElementById('resultText');
    const titleEl = document.getElementById('resultTitle');
    const platformEl = document.getElementById('resultPlatform');
    const thumbEl = document.getElementById('resultThumb');

    const file = fileInput.files[0];

    if (!file) {
      showToast('Pilih file dulu!', 'error');
      return;
    }

    box.style.display = 'block';
    thumbEl.style.display = 'none';
    titleEl.innerText = '-';
    platformEl.innerText = '-';
    text.innerText = '⏳ Sedang mengupload...';

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/uploader', {
        method: 'POST',
        body: formData
      });

      const contentType = response.headers.get('content-type') || '';

      if (!contentType.includes('application/json')) {
        const raw = await response.text();
        throw new Error(`Server tidak mengembalikan JSON (${response.status}). Response: "${raw.slice(0, 150)}..."`);
      }

      const data = await response.json();

      if (!response.ok || !data.status) {
        throw new Error(data.error || data.message || `HTTP ${response.status}`);
      }

      titleEl.innerText = file.name;
      platformEl.innerText = file.type.startsWith('video') ? 'Video' : 'Gambar';
      text.innerText = data.result.url;

      if (file.type.startsWith('image')) {
        thumbEl.src = data.result.url;
        thumbEl.style.display = 'block';
      }

      document.getElementById('openBtn').onclick = () => {
        window.open(data.result.url, '_blank');
      };

      showToast('✅ Berhasil diupload!', 'success');

    } catch (err) {
      const msg = getErrorMessage(err);
      text.innerText = '❌ Gagal upload file.';
      showToast(`⚠️ ${msg}`, 'error');
      console.error('[Upload Error]', err);
    }
  }

  /* ===== COPY RESULT ===== */
  function copyResult() {
    const text = document.getElementById('resultText').innerText;
    if (!text || text === '-' || text.includes('Gagal') || text.includes('❌')) {
      return showToast('Tidak ada hasil untuk di-copy!', 'error');
    }

    navigator.clipboard.writeText(text)
      .then(() => showToast('📋 Berhasil di-copy!', 'success'))
      .catch(() => {
        // fallback
        const range = document.createRange();
        const sel = window.getSelection();
        const el = document.getElementById('resultText');
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('copy');
        sel.removeAllRanges();
        showToast('📋 Berhasil di-copy!', 'success');
      });
  }

  /* ===== COPY CODE DOKUMENTASI ===== */
  function copyCode(elementId) {
    const codeText = document.getElementById(elementId).innerText;
    navigator.clipboard.writeText(codeText)
      .then(() => showToast('📋 Kode berhasil disalin!', 'success'))
      .catch(() => showToast('Gagal menyalin kode', 'error'));
  }

// -- expose top-level functions used by inline HTML handlers --

})();
  }
};
