// Halaman: GET Request Tool
// Dikonversi otomatis dari html/get.html
window.PAGES = window.PAGES || {};
window.PAGES.get = {
  title: 'GET Request Tool',
  html: `<div class="container">

<a href="#/home" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">GET <span>Request Tool</span></h1>
<div class="subtitle">Ambil isi dari sebuah URL langsung dari browser — JSON, teks, gambar, video, audio, atau dokumen.</div>

<div class="card">

<label>URL Target</label>
<input id="url" placeholder="https://contoh.com/data.json">

<button id="btnGet">
  <i class="fas fa-arrow-down"></i> Kirim GET Request
</button>

<div id="status" class="status"></div>

</div>

<div class="card" id="resultCard" style="display:none;">
<h3 style="margin-bottom:12px;">Response</h3>
<div id="resultMeta" class="result-meta"></div>
<div id="resultBox" class="result-box"></div>
</div>

</div>`,
  run: function() {
(function(){
const urlInput = document.getElementById("url");
const btnGet = document.getElementById("btnGet");
const status = document.getElementById("status");
const resultCard = document.getElementById("resultCard");
const resultBox = document.getElementById("resultBox");
const resultMeta = document.getElementById("resultMeta");

function setStatus(text, ok){
  status.textContent = text;
  status.className = "status " + (ok ? "ok" : "bad");
}

function guessFileName(url, contentDisposition){
  let fileName = "file";
  if(contentDisposition){
    const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
    if(match){
      fileName = match[1].replace(/['"]/g, "");
    }
  } else {
    const urlFileName = url.split("/").pop().split("?")[0];
    if(urlFileName && urlFileName.includes(".")){
      fileName = urlFileName;
    }
  }
  return fileName;
}

async function doGet(){

  const url = urlInput.value.trim();

  if(!url){
    setStatus("Masukkan URL terlebih dahulu!", false);
    return;
  }

  btnGet.disabled = true;
  setStatus("⏳ Mengirim request...", true);
  resultCard.style.display = "none";
  resultBox.className = "result-box";
  resultBox.innerHTML = "";
  resultMeta.textContent = "";

  try{

    const response = await fetch(url);
    const contentType = response.headers.get("content-type") || "";
    const contentDisposition = response.headers.get("content-disposition");
    const fileName = guessFileName(url, contentDisposition);

    resultMeta.textContent = `Status: ${response.status} ${response.statusText} • Content-Type: ${contentType || "tidak diketahui"}`;
    resultCard.style.display = "block";
    resultBox.classList.add("show");

    if(contentType.includes("application/json")){
      const jsonData = await response.json();
      resultBox.textContent = JSON.stringify(jsonData, null, 2);

    } else if(contentType.includes("image")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `<img src="${objUrl}" alt="response image">`;

    } else if(contentType.includes("video")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `<video src="${objUrl}" controls></video>`;

    } else if(contentType.includes("audio")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `<audio src="${objUrl}" controls style="width:100%;"></audio>`;

    } else if(contentType.includes("application") || contentType.includes("text/csv") || contentType.includes("octet-stream")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `📁 Dokumen diterima: <b>${fileName}</b>`;
      resultBox.innerHTML += `<br><a class="download-link" href="${objUrl}" download="${fileName}"><i class="fas fa-download"></i> Unduh ${fileName}</a>`;

    } else {
      const data = await response.text();
      resultBox.textContent = data;
    }

    setStatus("✅ Request berhasil", true);

  } catch(err){
    resultCard.style.display = "block";
    resultBox.classList.add("show");
    resultBox.textContent = "Detail error: " + err.message;
    setStatus("❌ Gagal melakukan request GET (cek URL atau CORS)", false);
  } finally {
    btnGet.disabled = false;
  }

}

btnGet.addEventListener("click", doGet);
urlInput.addEventListener("keypress", e => {
  if(e.key === "Enter") doGet();
});

// -- expose top-level functions used by inline HTML handlers --
  window.guessFileName = guessFileName;
  window.setStatus = setStatus;
})();
  }
};
