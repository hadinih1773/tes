// Halaman: All In One Downloader
// Dikonversi otomatis dari html/aiodl.html
window.PAGES = window.PAGES || {};
window.PAGES.aiodl = {
  title: 'All In One Downloader',
  html: `<div class="container">

<a href="#/home" class="back">
← Kembali Ke Halaman Depan
</a>

<h1 class="title">
All In One <span>Downloader</span>
</h1>

<div class="card">

<label>Masukkan URL</label>

<input
id="url"
placeholder="https://vt.tiktok.com/... / Instagram / Facebook / YouTube dll"
>

<button id="downloadBtn">
Download
</button>

<div id="result" class="result"></div>

</div>

</div>`,
  run: function() {
(function(){
const btn = document.getElementById("downloadBtn");

btn.addEventListener("click", async ()=>{

  const url =
    document.getElementById("url").value.trim();

  const result =
    document.getElementById("result");

  if(!url){

    result.innerHTML =
      "<p>Masukkan URL terlebih dahulu.</p>";

    return;
  }

  result.innerHTML =
    "<p>Sedang mengambil data...</p>";

  try{

    const res = await fetch(
      `https://api-faa.my.id/faa/aio?url=${encodeURIComponent(url)}`
    );

    const json = await res.json();

    if(!json.status){
      throw new Error("Gagal mengambil data");
    }

    const data = json.result;

    let altLinks = "";

    if(data.alternative_urls && data.alternative_urls.length){

      data.alternative_urls.forEach(item => {

        altLinks += `
          <a
          href="${item.url}"
          target="_blank"
          class="download-btn">
          ${item.type.toUpperCase()}
          </a>
        `;

      });

    }

    result.innerHTML = `

      <img
      src="${data.thumbnail}"
      alt="Thumbnail"
      onerror="this.style.display='none'"
      >

      <h3>${data.title}</h3>

      <a
      href="${data.download_url}"
      target="_blank"
      class="download-btn">
      Download Utama
      </a>

      <div class="alt-title">
      Alternative Download Links
      </div>

      ${altLinks}

    `;

  }catch(err){

    console.error(err);

    result.innerHTML =
      "<p>Gagal mengambil data.</p>";

  }

});

// -- expose top-level functions used by inline HTML handlers --

})();
  }
};
