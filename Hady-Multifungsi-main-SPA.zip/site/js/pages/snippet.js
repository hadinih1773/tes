// Halaman: Code Snippet
// Dikonversi otomatis dari html/snippet.html
window.PAGES = window.PAGES || {};
window.PAGES.snippet = {
  title: 'Code Snippet',
  html: `<div class="container">

<a href="#/home" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">Code <span>Snippet</span></h1>

<div class="search-wrap">
  <span class="search-icon">🔍</span>
  <input id="searchInput" placeholder="Cari snippet berdasarkan judul, deskripsi, atau tag..." oninput="filterSnippets()">
</div>

<div class="loading-db" id="loadingDb">
  <div class="loading-spinner"></div>
  <span>Load From Database...</span>
</div>

<div id="list" class="snippets"></div>

</div>

<button class="fab" onclick="openModal()">+</button>

<div class="toast-container" id="toastContainer"></div>

<div class="modal" id="passwordModal">
  <div class="modal-content password-modal-content">
    <div class="password-icon">🔒</div>
    <h3>Konfirmasi Password</h3>
    <p>Masukkan password untuk menghapus snippet ini</p>

    <input type="password" id="passwordInput" placeholder="••••••••" maxlength="20">
    <div class="password-error" id="passwordError"></div>

    <div class="action-row">
      <button class="btn-delete" onclick="submitPassword()">Hapus</button>
      <button class="btn-close" onclick="closePasswordModal()">Batal</button>
    </div>
  </div>
</div>

<div class="modal" id="modal">
  <div class="modal-content">

    <h3>Tambah Snippet</h3>

    <input id="title" placeholder="Judul Snippet">
    <input id="author" placeholder="Nama Author">
    <input id="contact" placeholder="Contact Author">

    <select id="lang">
      <option>JavaScript</option>
      <option>Python</option>
      <option>TypeScript</option>
      <option>HTML</option>
      <option>CSS</option>
      <option>PHP</option>
      <option>Java</option>
    </select>

    <input id="tags" placeholder="Tag (javascript,discord)">
    <textarea id="desc" placeholder="Deskripsi"></textarea>
    <textarea id="code" placeholder="Paste Code"></textarea>

    <button onclick="uploadSnippet()">Upload</button>
    <button class="btn-close" onclick="closeModal()">Close</button>

  </div>
</div>

<div class="modal" id="detailModal" onclick="closeDetailModal(event)">
  <div class="modal-content modal-detail" onclick="event.stopPropagation()">
    <div class="detail-scroll">
      <div class="card-header">
        <span class="lang-badge" id="detLang">JavaScript</span>
        <span class="card-date" id="detDate">15 April 2026</span>
      </div>

      <h3 id="detTitle" style="margin-top:10px; font-size:1.8rem;"></h3>
      <p id="detDesc" style="margin-top:8px;"></p>

      <div class="code-window" style="margin-top:15px;">
        <div class="code-header">
          <div class="dot red"></div>
          <div class="dot yellow"></div>
          <div class="dot green"></div>
          <div class="code-title" id="detCodeTitle">code.js</div>
        </div>
        <pre id="detCode" style="white-space:pre-wrap; max-height:400px; overflow-y:auto;"></pre>
      </div>

      <div class="tags-container" id="detTags" style="margin-top:15px;"></div>

      <div class="card-footer" style="margin-top:20px;">
        <div class="author-info">
          <div class="author-avatar" id="detAvatar">A</div>
          <span id="detAuthor"></span>
        </div>
        <div class="card-stats">
          <span>👁 <span id="detViews">1</span> dilihat</span>
          <span>📋 <span id="detCopies">0</span> disalin</span>
        </div>
      </div>
    </div>

    <div class="action-row">
      <button class="btn-copy" onclick="copyCode()">📋 Copy</button>
      <button class="btn-download" onclick="downloadCode()">📥 Download</button>
      <button class="btn-delete" onclick="deleteSnippet()">🗑 Delete</button>
      <button class="btn-close" onclick="document.getElementById('detailModal').classList.remove('active')">Close</button>
    </div>
  </div>
</div>`,
  run: function() {
(function(){
const API = "/api/snippet";
let currentSnippets = [];
let currentDetailId = null;

/* ---------- Toast Modern ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

/* ---------- Slug Helper ---------- */
function slugify(text){
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "");
}

async function load(){
  const loadingDb = document.getElementById("loadingDb");
  loadingDb.classList.remove("hidden");

  const res = await fetch(API);
  const data = await res.json();
  currentSnippets = data;

  renderList(data);
  handleUrlSlug();

  loadingDb.classList.add("hidden");
}

function renderList(data){
  const list = document.getElementById("list");
  list.innerHTML = "";

  if(data.length === 0){
    list.innerHTML = `<div class="empty-state">Tidak ada snippet ditemukan.</div>`;
    return;
  }

  data.slice().reverse().forEach((s, index)=>{
    const originalIndex = currentSnippets.indexOf(s);
    const initial = s.author ? s.author.charAt(0).toUpperCase() : "A";
    const dateStr = s.createdAt ? new Date(s.createdAt).toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" }) : "-";

    list.innerHTML += `
      <div class="card" onclick="openDetailModal(${originalIndex})">
        <div class="card-header">
          <span class="lang-badge">${s.language}</span>
          <span class="card-date">${dateStr}</span>
        </div>
        
        <h3>${s.title}</h3>
        
        <p>${s.description}</p>
        
        <div class="code-window">
          <div class="code-header">
            <div class="dot red"></div>
            <div class="dot yellow"></div>
            <div class="dot green"></div>
            <div class="code-title">${s.title.toLowerCase().replace(/\s+/g, '-')}.js</div>
          </div>
          <pre style="white-space:pre-wrap">${s.code.slice(0,200)}${s.code.length > 200 ? '...' : ''}</pre>
        </div>

        <div class="tags-container">
          ${s.tags.map(t => `<span class="tag">#${t.trim()}</span>`).join("")}
        </div>

        <div class="card-footer">
          <div class="author-info">
            <div class="author-avatar">${initial}</div>
            <span>${s.author}</span>
          </div>
          <div class="card-stats">
            <span>👁 ${s.views || 1}</span>
            <span>📋 ${s.copies || 0}</span>
          </div>
        </div>
      </div>
    `;
  });
}

function filterSnippets(){
  const q = document.getElementById("searchInput").value.toLowerCase().trim();

  if(!q){
    renderList(currentSnippets);
    return;
  }

  const filtered = currentSnippets.filter(s=>{
    const inTitle = s.title && s.title.toLowerCase().includes(q);
    const inDesc = s.description && s.description.toLowerCase().includes(q);
    const inTags = s.tags && s.tags.some(t => t.toLowerCase().includes(q));
    const inLang = s.language && s.language.toLowerCase().includes(q);
    return inTitle || inDesc || inTags || inLang;
  });

  renderList(filtered);
}

function handleUrlSlug(){
  const urlParams = new URLSearchParams(window.location.search);
  const querySlug = urlParams.get('s');
  if(querySlug){
    const found = currentSnippets.findIndex(s => slugify(s.title) === querySlug);
    if(found !== -1){
      openDetailModal(found, false);
    }
  }
}

load();

function openModal(){
  modal.classList.add("active");
}

function closeModal(){
  modal.classList.remove("active");
}

function openDetailModal(index, updateUrl = true) {
  const s = currentSnippets[index];
  currentDetailId = s.id;

  document.getElementById("detLang").innerText = s.language;
  document.getElementById("detTitle").innerText = s.title;
  document.getElementById("detDesc").innerText = s.description;
  document.getElementById("detCodeTitle").innerText = `${s.title.toLowerCase().replace(/\s+/g, '-')}.js`;
  document.getElementById("detCode").innerText = s.code;
  document.getElementById("detAuthor").innerText = s.author;
  document.getElementById("detAvatar").innerText = s.author ? s.author.charAt(0).toUpperCase() : "A";
  document.getElementById("detViews").innerText = s.views || 1;
  document.getElementById("detCopies").innerText = s.copies || 0;

  const dateStr = s.createdAt ? new Date(s.createdAt).toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" }) : "-";
  document.getElementById("detDate").innerText = dateStr;

  const tagsContainer = document.getElementById("detTags");
  tagsContainer.innerHTML = s.tags.map(t => `<span class="tag">#${t.trim()}</span>`).join("");

  document.getElementById("detailModal").classList.add("active");

  if(updateUrl){
    const slug = slugify(s.title);
    const newUrl = `${window.location.origin}${window.location.pathname}?s=${slug}`;
    history.pushState({ slug }, "", newUrl);
  }
}

function closeDetailModal(event) {
  if(event.target === document.getElementById("detailModal")) {
    document.getElementById("detailModal").classList.remove("active");
    const cleanUrl = `${window.location.origin}${window.location.pathname}`;
    history.pushState({}, "", cleanUrl);
  }
}

document.getElementById("detailModal").querySelector(".btn-close")?.addEventListener("click", ()=>{
  const cleanUrl = `${window.location.origin}${window.location.pathname}`;
  history.pushState({}, "", cleanUrl);
});

window.addEventListener("popstate", ()=>{
  const urlParams = new URLSearchParams(window.location.search);
  if(!urlParams.get('s')){
    document.getElementById("detailModal").classList.remove("active");
  } else {
    handleUrlSlug();
  }
});

async function copyCode(){
  const codeText = document.getElementById("detCode").innerText;

  try {
    await navigator.clipboard.writeText(codeText);
    showToast("Kode berhasil disalin!", "success");
  } catch (err) {
    showToast("Gagal menyalin kode.", "error");
    return;
  }

  // update jumlah copy ke server
  try {
    const res = await fetch(API, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: currentDetailId })
    });
    if(res.ok){
      const updated = await res.json();
      document.getElementById("detCopies").innerText = updated.copies;
      load();
    }
  } catch (err) {
    console.error("Gagal update jumlah copy:", err);
  }
}

function downloadCode(){
  const codeText = document.getElementById("detCode").innerText;
  const titleText = document.getElementById("detTitle").innerText;

  const fileName = `${slugify(titleText)}.js`;

  const blob = new Blob([codeText], { type: "text/javascript" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showToast(`Mengunduh ${fileName}...`, "success");
}

function deleteSnippet(){
  document.getElementById("detailModal").classList.remove("active");
  document.getElementById("passwordInput").value = "";
  document.getElementById("passwordError").innerText = "";
  document.getElementById("passwordModal").classList.add("active");
  document.getElementById("passwordInput").focus();
}

function closePasswordModal(){
  document.getElementById("passwordModal").classList.remove("active");
  document.getElementById("detailModal").classList.add("active");
}

async function submitPassword(){
  const password = document.getElementById("passwordInput").value;

  if(password !== window.CONFIG.snippetDeletePassword){
    document.getElementById("passwordError").innerText = "Password salah!";
    return;
  }

  document.getElementById("passwordModal").classList.remove("active");

  if(!confirm("Yakin ingin menghapus snippet ini?")) {
    document.getElementById("detailModal").classList.add("active");
    return;
  }

  try {
    const res = await fetch(API, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: currentDetailId, password: password })
    });

    if(res.ok){
      showToast("Snippet berhasil dihapus.", "success");
      document.getElementById("detailModal").classList.remove("active");
      const cleanUrl = `${window.location.origin}${window.location.pathname}`;
      history.pushState({}, "", cleanUrl);
      load();
    } else {
      const err = await res.json();
      showToast(err.error || "Gagal menghapus snippet.", "error");
      document.getElementById("detailModal").classList.add("active");
    }
  } catch (err) {
    showToast("Terjadi kesalahan saat menghapus.", "error");
    console.error(err);
    document.getElementById("detailModal").classList.add("active");
  }
}

async function uploadSnippet(){

  const data = {
    title: title.value,
    author: author.value,
    contact: contact.value,
    language: lang.value,
    tags: tags.value.split(",").map(t=>t.trim()).filter(t => t.length > 0),
    description: desc.value,
    code: code.value,
    createdAt: new Date().toISOString()
  };

  if(!data.title || !data.code){
    showToast("Judul & Code wajib!", "error");
    return;
  }

  try {
    const res = await fetch(API,{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body:JSON.stringify(data)
    });

    if(!res.ok){
      const err = await res.json();
      showToast(err.error || "Gagal upload snippet.", "error");
      return;
    }

    // reset form
    title.value = "";
    author.value = "";
    contact.value = "";
    tags.value = "";
    desc.value = "";
    code.value = "";

    closeModal();
    load();
  } catch (err) {
    showToast("Terjadi kesalahan saat upload.", "error");
    console.error(err);
  }
}

// -- expose top-level functions used by inline HTML handlers --
  window.closeDetailModal = closeDetailModal;
  window.closeModal = closeModal;
  window.closePasswordModal = closePasswordModal;
  window.deleteSnippet = deleteSnippet;
  window.downloadCode = downloadCode;
  window.filterSnippets = filterSnippets;
  window.handleUrlSlug = handleUrlSlug;
  window.openDetailModal = openDetailModal;
  window.openModal = openModal;
  window.renderList = renderList;
  window.showToast = showToast;
  window.slugify = slugify;
})();
  }
};
