// ============================================
// router.js — Router SPA sederhana berbasis hash (#/nama-halaman)
// Menampilkan konten dari window.PAGES[nama] (didefinisikan di js/pages/*.js)
// ============================================

const pageContent = document.getElementById("page-content");

function navigate(name) {
  if (!window.PAGES || !window.PAGES[name]) {
    name = "home";
  }
  const page = window.PAGES[name];

  // Ganti konten halaman (satu halaman aktif dalam DOM pada satu waktu,
  // supaya id-id elemen antar tools seperti #url / #result tidak bentrok)
  pageContent.innerHTML = `<div class="page active" id="page-${name}">${page.html}</div>`;

  document.title = page.title ? `${page.title} - Hady Tools Multifungsi` : "Hady Tools Multifungsi";

  // Jalankan ulang script halaman setiap kali dibuka supaya selalu
  // terhubung ke elemen-elemen yang baru saja dirender.
  try {
    if (typeof page.run === "function") {
      page.run();
    }
  } catch (err) {
    console.error(`Gagal menjalankan halaman "${name}":`, err);
  }

  // Tandai link sidebar yang aktif
  document.querySelectorAll(".sidebar a[data-route]").forEach(a => {
    a.classList.toggle("active-link", a.getAttribute("data-route") === name);
  });

  sidebar.classList.remove("show");
  window.scrollTo(0, 0);
}

function routeFromHash() {
  const hash = location.hash; // contoh: "#/aiodl"
  let name = hash.startsWith("#/") ? hash.slice(2) : "";

  // Dukung link share Code Snippet (?s=slug) walau dibuka tanpa hash
  if (!name && new URLSearchParams(location.search).get("s")) {
    name = "snippet";
  }

  navigate(name || "home");
}

window.addEventListener("hashchange", routeFromHash);
window.addEventListener("DOMContentLoaded", routeFromHash);

// Kalau script ini jalan setelah DOMContentLoaded (misal karena defer),
// langsung render juga.
if (document.readyState === "interactive" || document.readyState === "complete") {
  routeFromHash();
}
