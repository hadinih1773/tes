// ============================================
// config.js — Konfigurasi Website Hady Tools Multifungsi
// ============================================
// Ubah username / password di sini kalau mau ganti kredensial.

window.CONFIG = {
  // Username & password untuk login Admin Panel
  // (dipakai juga untuk membuka website saat status "Locked")
  adminUsername: "hadinih",
  adminPassword: "hadinih2009",

  // Password untuk menghapus Code Snippet di halaman Snippet
  snippetDeletePassword: "31012009"
};
