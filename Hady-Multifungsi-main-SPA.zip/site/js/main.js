// ============================================
// main.js — Logika utama shell website (dulu tersebar di index.html)
// ============================================

/* ---------- Sidebar / Menu Toggle ---------- */
const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");

menuBtn.addEventListener("click", () => {
  sidebar.classList.toggle("show");
});

document.addEventListener("click", (e) => {
  if (
    !sidebar.contains(e.target) &&
    !menuBtn.contains(e.target)
  ) {
    sidebar.classList.remove("show");
  }
});

/* ---------- AI Chat Widget (Hady Assistant) ---------- */
const aiBtn = document.getElementById("aiBtn");
const aiChat = document.getElementById("aiChat");
const aiSend = document.getElementById("aiSend");
const aiInput = document.getElementById("aiInput");
const aiMessages = document.getElementById("aiMessages");

const ARNARU_AI_API = 'https://arnaru-ai.vercel.app/api/chat';
const SYSTEM_PROMPT = "Kamu adalah asisten AI super pintar, andal, dan gaul. Wajib gunakan bahasa kasual Indonesia (gw, lu, bro, legit, dll). TAMPILAN VISUAL ADALAH PRIORITAS UTAMA. Ikuti gaya formatting premium ini:\n1. PENGGUNAAN EMOJI: Gunakan emoji secara rapi dan estetis HANYA di luar blok kode markdown (misal untuk mempertegas judul \ud83c\udfc6, status \u2705\u274c, atau reaksi \ud83d\udc80\ud83d\udca5).\n2. DATA TERSTRUKTUR: Saat menyajikan info model, konsep dasar, desain sistem, spesifikasi, statistik, probabilitas, atau rincian spesifik, WAJIB bungkus teks tersebut ke dalam blok kode markdown. Di dalam blok kode, buat tata letak yang sejajar/presisi dan rapi. Gunakan simbol peluru sederhana seperti '-', '\u2713', atau '\u2192'.\n3. KODE SCRIPT: Jika memberikan source code murni, taruh di blok kode dengan nama bahasanya (contoh blok kode lua, pawn, html).\n4. PEMBATAS & HEADER: Gunakan teks tebal (**teks**) untuk judul di luar blok kode. Gunakan garis pembatas Markdown resmi (---) HANYA untuk memisahkan section besar agar elegan. DILARANG KERAS mengetik deretan garis manual panjang seperti ------- atau =======.\n5. Intinya: Buat respons yang visualnya memanjakan mata, perpaduan pas antara obrolan santai ber-emoji di luar, dan blok data yang rapi/teknis di dalam.";

aiBtn.addEventListener("click", () => {
  aiChat.classList.toggle("show");
});

async function askAI(question, userId = 'default_user', model = 'claude-sonnet-5', webSearch = false, onStreamUpdate = null) {
  const conversationId = `${userId}_session_1`;

  try {
    const payload = {
      question: question,
      model: model,
      conversationId: conversationId,
      systemPrompt: SYSTEM_PROMPT,
      webSearch: webSearch
    };

    const response = await fetch(ARNARU_AI_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let fullAnswer = "";
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      let lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const jsonStr = line.substring(6).trim();
          if (jsonStr === '[DONE]') continue;

          try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.answer) {
              fullAnswer += parsed.answer;
              let cleanedText = fullAnswer.replace(/[-=_]{3,}/g, '');
              if (onStreamUpdate) {
                onStreamUpdate(cleanedText);
              }
            }
          } catch (e) {}
        }
      }
    }

    if (buffer.startsWith('data: ')) {
      try {
        const jsonStr = buffer.substring(6).trim();
        if (jsonStr !== '[DONE]') {
          const parsed = JSON.parse(jsonStr);
          if (parsed.answer) fullAnswer += parsed.answer;
        }
      } catch (e) {}
    }

    let finalCleaned = fullAnswer.replace(/[-=_]{3,}/g, '');
    return finalCleaned || "Sori ngab, server AInya lagi ampas nih ga ngasih jawaban bener.";
  } catch (error) {
    throw new Error(error.message);
  }
}

async function sendAI() {

  const text = aiInput.value.trim();

  if (!text) return;

  aiMessages.innerHTML += `
    <div class="ai-msg">
      <b>Kamu:</b><br>${text}
    </div>
  `;

  aiInput.value = "";

  const botMsgId = "ai-msg-" + Date.now();
  aiMessages.innerHTML += `
    <div class="ai-msg" id="${botMsgId}">
      <b>Hady Assistant:</b><br><span class="msg-content">Sedang mengetik...</span>
    </div>
  `;
  aiMessages.scrollTop = aiMessages.scrollHeight;

  const botMsgEl = document.getElementById(botMsgId).querySelector('.msg-content');

  try {

    const answer = await askAI(text, 'default_user', 'claude-sonnet-5', false, (streamText) => {
      botMsgEl.innerText = streamText;
      aiMessages.scrollTop = aiMessages.scrollHeight;
    });

    botMsgEl.innerText = answer;
    aiMessages.scrollTop = aiMessages.scrollHeight;

  } catch (err) {

    botMsgEl.innerText = "Gagal terhubung ke AI.";

  }

}

aiSend.addEventListener("click", sendAI);

aiInput.addEventListener("keypress", e => {
  if (e.key === "Enter") {
    sendAI();
  }
});

/* ---------- Kunci Website (dibuka pakai password Admin Panel di config.js) ---------- */
if (localStorage.getItem("websiteLocked") === "true") {

  document.body.insertAdjacentHTML("beforeend", `
    <div class="lock-overlay" id="lockOverlay">
      <div class="lock-password-modal">
        <div class="lock-password-icon">🔒</div>
        <h3>Website Terkunci</h3>
        <p>Masukkan Password</p>

        <input type="password" id="lockPasswordInput" placeholder="••••••••" maxlength="30">
        <div class="lock-password-error" id="lockPasswordError"></div>

        <button id="lockPasswordSubmit">Masuk</button>
      </div>
    </div>
  `);

  const lockPasswordInput = document.getElementById("lockPasswordInput");
  const lockPasswordError = document.getElementById("lockPasswordError");
  const lockOverlay = document.getElementById("lockOverlay");

  function submitLockPassword() {

    const pass = lockPasswordInput.value;

    if (pass !== window.CONFIG.adminPassword) {

      lockPasswordError.innerText = "❌ Password Salah";
      lockPasswordInput.value = "";
      return;

    }

    lockOverlay.remove();

  }

  document
    .getElementById("lockPasswordSubmit")
    .onclick = submitLockPassword;

  lockPasswordInput.addEventListener("keypress", e => {
    if (e.key === "Enter") {
      submitLockPassword();
    }
  });

  lockPasswordInput.focus();

}

/* ---------- Statistik Kunjungan ---------- */
// Dihitung sekali per load website; ditampilkan oleh halaman Beranda (home.js)
let visits = parseInt(localStorage.getItem("visitCount") || "0", 10);
visits += 1;
localStorage.setItem("visitCount", visits);
window.__visitCount = visits;
