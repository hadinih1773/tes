// ==========================================================
// config.js
// Semua konfigurasi website (password + kredensial) ada di sini.
// File ini dipakai baik oleh browser (lewat <script src="config.js">)
// maupun oleh server (server.js & api/*.js baca file ini juga).
//
// Catatan: karena file ini juga dikirim ke browser, isinya bisa dilihat
// siapa saja lewat "View Page Source". Isi sesuai kebutuhanmu di bawah ini.
// ==========================================================

const SITE_CONFIG = {
  // Password untuk buka kunci website (index.html)
  LOCK_PASSWORD: "hadinih",

  // Password untuk hapus Code Snippet (html/snippet.html)
  SNIPPET_DELETE_PASSWORD: "31012009",

  // Login Admin Panel (html/lock.html) - kelola lock website & changelog
  ADMIN_USERNAME: "1",
  ADMIN_PASSWORD: "1",

  // Ambil di: Supabase Dashboard > Project Settings > API
  SUPABASE_URL: "",
  SUPABASE_SERVICE_ROLE_KEY: "",

  // Dibutuhkan untuk fitur File Uploader (html/uploader.html -> api/uploader.js)
  // Ambil di: Vercel Dashboard > Storage > Blob, atau lewat `vercel blob` CLI.
  // Kalau dikosongin, fitur uploader saja yang tidak jalan, fitur lain tetap normal.
  BLOB_READ_WRITE_TOKEN: ""
};
