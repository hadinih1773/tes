// Auto-converted from html/obf.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Lua Obfuscator</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">



  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-obf">

<div class="container">

<a href="../index.html" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">Lua <span>Obfuscator</span></h1>

<div class="card">

<label>Paste Script Lua / Text</label>
<textarea id="input"></textarea>

<label>Atau Upload File (.lua / .txt)</label>
<input type="file" id="fileInput" accept=".lua,.txt">

<button onclick="obfuscate()">Obfuscate</button>

</div>

<div class="card">

<label>Hasil Obfuscate</label>
<textarea id="output" readonly></textarea>

<div class="actions">
<button class="copy" onclick="copyText()">Copy</button>
<button class="download" onclick="downloadLua()">Download .lua</button>
<button class="download" onclick="downloadTxt()">Download .txt</button>
</div>

</div>

</div>

<div class="toast-container" id="toastContainer"></div>

<script src="/js/obf.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
