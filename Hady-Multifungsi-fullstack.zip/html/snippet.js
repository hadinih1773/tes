// Auto-converted from html/snippet.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Code Snippet</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>

<body class="page-snippet">

<div class="container">

<a href="../index.html" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">Code <span>Snippet</span></h1>

<div class="search-wrap">
  <span class="search-icon">🔍</span>
  <input id="searchInput" placeholder="Cari snippet berdasarkan judul, deskripsi, atau tag..." oninput="filterSnippets()">
</div>

<div class="loading-db" id="loadingDb">
  <div class="loading-spinner"></div>
  <span>Load From Database...</span>
</div>

<div id="list" class="snippets"></div>

</div>

<button class="fab" onclick="openModal()">+</button>

<div class="toast-container" id="toastContainer"></div>

<div class="modal" id="passwordModal">
  <div class="modal-content password-modal-content">
    <div class="password-icon">🔒</div>
    <h3>Konfirmasi Password</h3>
    <p>Masukkan password untuk menghapus snippet ini</p>

    <input type="password" id="passwordInput" placeholder="••••••••" maxlength="20">
    <div class="password-error" id="passwordError"></div>

    <div class="action-row">
      <button class="btn-delete" onclick="submitPassword()">Hapus</button>
      <button class="btn-close" onclick="closePasswordModal()">Batal</button>
    </div>
  </div>
</div>

<div class="modal" id="modal">
  <div class="modal-content">

    <h3>Tambah Snippet</h3>

    <input id="title" placeholder="Judul Snippet">
    <input id="author" placeholder="Nama Author">
    <input id="contact" placeholder="Contact Author">

    <select id="lang">
      <option>JavaScript</option>
      <option>Python</option>
      <option>TypeScript</option>
      <option>HTML</option>
      <option>CSS</option>
      <option>PHP</option>
      <option>Java</option>
    </select>

    <input id="tags" placeholder="Tag (javascript,discord)">
    <textarea id="desc" placeholder="Deskripsi"></textarea>
    <textarea id="code" placeholder="Paste Code"></textarea>

    <button onclick="uploadSnippet()">Upload</button>
    <button class="btn-close" onclick="closeModal()">Close</button>

  </div>
</div>

<div class="modal" id="detailModal" onclick="closeDetailModal(event)">
  <div class="modal-content modal-detail" onclick="event.stopPropagation()">
    <div class="detail-scroll">
      <div class="card-header">
        <span class="lang-badge" id="detLang">JavaScript</span>
        <span class="card-date" id="detDate">15 April 2026</span>
      </div>

      <h3 id="detTitle" style="margin-top:10px; font-size:1.8rem;"></h3>
      <p id="detDesc" style="margin-top:8px;"></p>

      <div class="code-window" style="margin-top:15px;">
        <div class="code-header">
          <div class="dot red"></div>
          <div class="dot yellow"></div>
          <div class="dot green"></div>
          <div class="code-title" id="detCodeTitle">code.js</div>
        </div>
        <pre id="detCode" style="white-space:pre-wrap; max-height:400px; overflow-y:auto;"></pre>
      </div>

      <div class="tags-container" id="detTags" style="margin-top:15px;"></div>

      <div class="card-footer" style="margin-top:20px;">
        <div class="author-info">
          <div class="author-avatar" id="detAvatar">A</div>
          <span id="detAuthor"></span>
        </div>
        <div class="card-stats">
          <span>👁 <span id="detViews">1</span> dilihat</span>
          <span>📋 <span id="detCopies">0</span> disalin</span>
        </div>
      </div>
    </div>

    <div class="action-row">
      <button class="btn-copy" onclick="copyCode()">📋 Copy</button>
      <button class="btn-download" onclick="downloadCode()">📥 Download</button>
      <button class="btn-delete" onclick="deleteSnippet()">🗑 Delete</button>
      <button class="btn-close" onclick="document.getElementById('detailModal').classList.remove('active')">Close</button>
    </div>
  </div>
</div>

<script src="../config.js"></script>
<script src="/js/snippet.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
