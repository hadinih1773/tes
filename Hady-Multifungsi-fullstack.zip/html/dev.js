// Auto-converted from html/dev.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Developer</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>


<link rel="stylesheet" href="/css/style.css">
</head>

<body class="page-dev">

<div class="container">

<a class="back" href="../index.html">← Kembali Ke Halaman Depan</a>

<h1 class="title">Hady Tools <span>Multifungsi</span></h1>

<div class="card">

  <div class="avatar-wrap">
    <img src="../src/image/pphady.png" alt="Foto Profil">
  </div>

  <div class="dev-name">@Hadinih_</div>

  <div class="dev-role">
    <i class="fas fa-star"></i>
    Lead Developer & Founder
  </div>

  <div class="bio-box">
    <div class="bio-arabic">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</div>
    <div class="bio-latin">Bismillahirrahmanirrahim</div>
    <div class="bio-artinya">"Dengan menyebut nama Allah Yang Maha Pengasih lagi Maha Penyayang"</div>
  </div>

  <div class="socials">
    <a class="social-icon s-discord" href="https://discord.gg/4uzdM25KYv" target="_blank">
      <i class="fab fa-discord"></i>
    </a>
    <a class="social-icon s-github" href="https://github.com/hadinih1773" target="_blank">
      <i class="fab fa-github"></i>
    </a>
    <a class="social-icon s-tiktok" href="https://www.tiktok.com/@hadinih_" target="_blank">
      <i class="fab fa-tiktok"></i>
    </a>
  </div>

</div>

</div>
<script src="/js/dev.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
