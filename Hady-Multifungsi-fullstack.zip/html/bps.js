// Auto-converted from html/bps.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>URL Bypass Tool</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>

<body class="page-bps">

<div class="container">

<a class="back" href="../index.html">← Kembali Ke Halaman Depan</a>

<h1 class="title">URL <span>Bypass</span></h1>

<div class="card">

<input id="url" placeholder="Masukkan URL (https://sfl.gl/...)" />

<button onclick="bypass()">Bypass</button>

<div id="resultBox" class="result" style="display:none;">
  <div class="small">Hasil Bypass:</div>
  <div id="resultText">-</div>

  <div class="actions">
    <button class="copy" onclick="copyResult()">Copy</button>
    <button class="open" id="openBtn">Open</button>
  </div>
</div>

</div>

</div>

<div class="toast-container" id="toastContainer"></div>

<script src="/js/bps.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
