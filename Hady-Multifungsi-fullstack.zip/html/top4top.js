// Auto-converted from html/top4top.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Top4Top Converter</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-top4top">

<div class="container">
  <a class="back" href="../index.html">← Kembali Ke Halaman Depan</a>
  <h1 class="title">Top4Top <span>Converter</span></h1>

  <div class="card">
    <label>Link YouTube / Spotify / TikTok</label>
    <input id="url" placeholder="https://youtube.com/... , https://open.spotify.com/... , https://tiktok.com/..." />
    <button onclick="convert()">Convert ke Top4Top</button>

    <div id="resultBox" class="result" style="display:none;">
      <img id="resultThumb" class="result-thumb" style="display:none;">
      <div class="result-title" id="resultTitle">-</div>
      <div class="result-platform" id="resultPlatform">-</div>
      <div class="small">Hasil Top4Top:</div>
      <div id="resultText">-</div>
      <div class="actions">
        <button class="copy" onclick="copyResult()">Copy</button>
        <button class="open" id="openBtn">Open</button>
      </div>
    </div>
  </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script src="/js/top4top.js"></script>
</body>
</html>`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
