// Auto-converted from html/get.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>GET Request Tool</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-get">

<div class="container">

<a href="../index.html" class="back">← Kembali Ke Halaman Depan</a>

<h1 class="title">GET <span>Request Tool</span></h1>
<div class="subtitle">Ambil isi dari sebuah URL langsung dari browser — JSON, teks, gambar, video, audio, atau dokumen.</div>

<div class="card">

<label>URL Target</label>
<input id="url" placeholder="https://contoh.com/data.json">

<button id="btnGet">
  <i class="fas fa-arrow-down"></i> Kirim GET Request
</button>

<div id="status" class="status"></div>

</div>

<div class="card" id="resultCard" style="display:none;">
<h3 style="margin-bottom:12px;">Response</h3>
<div id="resultMeta" class="result-meta"></div>
<div id="resultBox" class="result-box"></div>
</div>

</div>


<script src="/js/get.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
