// Auto-converted from html/lock.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel</title>

<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-lock">

<div id="appArea" style="display:none;">

  <header class="topbar">
    <div class="logo">🛠️ Admin Panel</div>
    <button id="menuBtn"><i class="fas fa-bars"></i></button>
  </header>

  <div class="sidebar" id="sidebar">
    <div class="sidebar-category">Menu</div>
    <a href="#" data-page="page-lock" class="nav-link active">
      <i class="fas fa-lock"></i> Lock Manager
    </a>
    <a href="#" data-page="page-changelog" class="nav-link">
      <i class="fas fa-clipboard-list"></i> Changelogs
    </a>
    <a href="../index.html">
      <i class="fas fa-arrow-left"></i> Kembali Ke Beranda
    </a>
  </div>

  <main>
    <div class="wrap">

      <!-- ===== PAGE: LOCK MANAGER ===== -->
      <div class="page active" id="page-lock">
        <div class="card">
          <h1>🔒 Lock Manager</h1>
          <div class="date-badge" id="todayDate">📅 -</div>

          <div class="status" id="status">
            Status Website : Loading...
          </div>

          <button class="btn lock" id="lockBtn">🔒 LOCK WEBSITE</button>
          <button class="btn unlock" id="unlockBtn">🔓 UNLOCK WEBSITE</button>

          <a href="../index.html" class="btn back">← Kembali Ke Halaman Depan</a>
        </div>
      </div>

      <!-- ===== PAGE: CHANGELOGS ===== -->
      <div class="page" id="page-changelog">
        <div class="card">
          <div class="section-label">➕ Tambah Changelog</div>

          <label>Judul</label>
          <input id="clTitle" placeholder="Contoh: Update Fitur Downloader">

          <label>Versi (opsional)</label>
          <input id="clVersion" placeholder="Contoh: v1.2.0">

          <label>Tanggal</label>
          <input id="clDate" type="date">

          <label>Tag</label>
          <select id="clTag">
            <option value="feature">Feature</option>
            <option value="update" selected>Update</option>
            <option value="fix">Fix</option>
            <option value="remove">Remove</option>
          </select>

          <label>Daftar Perubahan (1 baris = 1 poin)</label>
          <textarea id="clChanges" placeholder="Menambahkan fitur X&#10;Memperbaiki bug Y"></textarea>

          <button class="btn unlock" id="clAddBtn" style="margin-top:14px;">
            Simpan Changelog
          </button>
        </div>

        <div class="card">
          <div class="section-label">📋 Daftar Changelog</div>
          <div id="clList">Memuat...</div>
        </div>
      </div>

    </div>
  </main>

</div>

<div class="modal-overlay" id="passwordOverlay">
  <div class="password-modal">
    <div class="password-icon">🛠️</div>
    <h3>Admin Panel</h3>
    <p>Masuk untuk mengelola website & changelog</p>

    <label style="text-align:left;">Username</label>
    <input type="text" id="adminUsernameInput" placeholder="Username" autocomplete="off">

    <label style="text-align:left;">Password</label>
    <input type="password" id="adminPasswordInput" placeholder="••••••••" maxlength="30">

    <div class="password-error" id="adminPasswordError"></div>

    <button class="btn unlock" id="adminPasswordSubmit">Masuk</button>
  </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script src="../config.js"></script>
<script src="/js/lock.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
