// Auto-converted from html/changelogs.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Changelogs</title>

<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>


<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-changelogs">

<div class="container">

  <a href="../index.html" class="back">← Kembali Ke Halaman Depan</a>

  <h1 class="title">Change<span>logs</span></h1>
  <div class="subtitle">Riwayat pembaruan, perbaikan, dan fitur baru di Hady Tools Multifungsi.</div>

  <div id="changelogArea">
    <div class="state-box" id="stateBox">⏳ Memuat changelog...</div>
  </div>

</div>


<script src="/js/changelogs.js"></script>
</body>
</html>
`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
