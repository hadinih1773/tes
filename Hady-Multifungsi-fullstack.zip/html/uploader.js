// Auto-converted from html/uploader.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Uploader</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-uploader">

<div class="container">
  <a class="back" href="../index.html">← Kembali Ke Halaman Depan</a>
  <h1 class="title">File <span>Uploader</span></h1>

  <div class="card">
    <label>Pilih Gambar / Video</label>
    <input id="fileInput" type="file" accept="image/*,video/*" />
    <button onclick="uploadFile()">Upload</button>

    <div id="resultBox" class="result" style="display:none;">
      <img id="resultThumb" class="result-thumb" style="display:none;">
      <div class="result-title" id="resultTitle">-</div>
      <div class="result-platform" id="resultPlatform">-</div>
      <div class="small">Hasil URL:</div>
      <div id="resultText">-</div>
      <div class="actions">
        <button class="copy" onclick="copyResult()">Copy</button>
        <button class="open" id="openBtn">Open</button>
      </div>
    </div>

    <!-- Dokumentasi API / cURL / Node.js / Python -->
    <div class="api-docs">
      <h3>Dokumentasi API</h3>
      
      <label>cURL (POST):</label>
      <div class="code-wrapper">
        <pre id="code-curl">curl -X POST https://hadytools.vercel.app/api/uploader -F "file=@/path/to/file.jpg"</pre>
        <button class="copy-code-btn" onclick="copyCode('code-curl')"><i class="fas fa-copy"></i></button>
      </div>

      <label>Node.js / Bot WhatsApp (Axios & FormData):</label>
      <div class="code-wrapper">
        <pre id="code-nodejs">const axios = require('axios');
const FormData = require('form-data');

async function uploadMedia(buffer, filename) {
  const form = new FormData();
  form.append('file', buffer, filename);

  const res = await axios.post('https://hadytools.vercel.app/api/uploader', form, {
    headers: form.getHeaders()
  });

  return res.data.result.url;
}</pre>
        <button class="copy-code-btn" onclick="copyCode('code-nodejs')"><i class="fas fa-copy"></i></button>
      </div>

      <label>Python (Requests):</label>
      <div class="code-wrapper">
        <pre id="code-python">import requests

url = "https://hadytools.vercel.app/api/uploader"
files = {'file': open('image.png', 'rb')}

response = requests.post(url, files=files)
print(response.json()['result']['url'])</pre>
        <button class="copy-code-btn" onclick="copyCode('code-python')"><i class="fas fa-copy"></i></button>
      </div>
    </div>

  </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script src="/js/uploader.js"></script>
</body>
</html>`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
