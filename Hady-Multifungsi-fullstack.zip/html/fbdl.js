// Auto-converted from html/fbdl.html
const PAGE_HTML = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Facebook Downloader</title>

<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&display=swap" rel="stylesheet">



  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="page-fbdl">

<div class="container">

<a href="../index.html" class="back">
← Kembali Ke Halaman Depan
</a>

<h1 class="title">
Facebook <span>Downloader</span>
</h1>

<div class="card">

<label>URL Facebook</label>
<input id="url" placeholder="https://www.facebook.com/share/v/...">

<button id="downloadBtn">
Download
</button>

<div id="result" class="result"></div>

</div>

</div>

<script src="/js/fbdl.js"></script>
</body>
</html>`;

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(PAGE_HTML);
};
