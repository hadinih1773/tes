const logBox = document.getElementById("log");
const status = document.getElementById("status");

function log(text){
  logBox.innerHTML += text + "<br>";
  logBox.scrollTop = logBox.scrollHeight;
}

async function cekWebhook(){

  const url = document.getElementById("url").value.trim();
  if(!url){
    status.textContent = "Masukkan URL webhook!";
    status.className = "status bad";
    return;
  }

  try{
    const res = await fetch(url);
    const data = await res.json();

    status.textContent = "Webhook Aktif ✔";
    status.className = "status ok";

    log("✔ Webhook aktif: " + (data.name || "unknown"));

  }catch(err){
    status.textContent = "Webhook Tidak Aktif ✖";
    status.className = "status bad";

    log("✖ Webhook error / tidak ditemukan");
  }

}
