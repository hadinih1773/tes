/* ---------- Toast Modern ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

async function obfuscateLua(script){
  const res = await fetch("/api/obf", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ script })
  });

  const data = await res.json();

  if(!res.ok){
    throw new Error(data.error || "Gagal obfuscate");
  }

  return data.result;
}

/* BUTTON */
async function obfuscate(){
  const input = document.getElementById("input").value.trim();
  const output = document.getElementById("output");

  if(!input){
    showToast("Isi script dulu!", "error");
    return;
  }

  output.value = "Processing...";

  try{
    const result = await obfuscateLua(input);
    output.value = result;
  }catch(err){
    output.value = "Error: " + err.message;
  }
}

/* FILE */
document.getElementById("fileInput").addEventListener("change", function(e){
  const file = e.target.files[0];
  if(!file) return;

  const ext = file.name.split(".").pop().toLowerCase();
  if(!["lua","txt"].includes(ext)){
    showToast("File harus .lua atau .txt", "error");
    this.value = "";
    return;
  }

  const reader = new FileReader();
  reader.onload = (evt)=>{
    document.getElementById("input").value = evt.target.result;
  };
  reader.readAsText(file);
});

/* COPY */
function copyText(){
  const output = document.getElementById("output");
  if(!output.value) return showToast("Tidak ada hasil!", "error");
  navigator.clipboard.writeText(output.value);
  showToast("Berhasil di-copy!", "success");
}

/* DOWNLOAD */
function downloadFile(name, content){
  const blob = new Blob([content], {type:"text/plain"});
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();

  URL.revokeObjectURL(url);
}

function downloadLua(){
  const output = document.getElementById("output").value;
  if(!output) return showToast("Tidak ada hasil!", "error");
  downloadFile("script.lua", output);
}

function downloadTxt(){
  const output = document.getElementById("output").value;
  if(!output) return showToast("Tidak ada hasil!", "error");
  downloadFile("script.txt", output);
}
