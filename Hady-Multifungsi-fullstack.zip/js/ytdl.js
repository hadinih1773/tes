const btn = document.getElementById("downloadBtn");
    btn.addEventListener("click", async () => {
      const url = document.getElementById("url").value.trim();
      const result = document.getElementById("result");
      
      if (!url) {
        result.innerHTML = "<p>Masukkan URL YouTube terlebih dahulu.</p>";
        return;
      }
      
      result.innerHTML = "<p>Sedang mengambil data...</p>";
      
      try {
        const mp3Res = await fetch(
          `https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(url)}`
        );
        const mp3Json = await mp3Res.json();
        
        if (!mp3Json.status) {
          throw new Error("Gagal mengambil MP3");
        }
        
        const mp4Res = await fetch(
          `https://api-faa.my.id/faa/ytmp4?url=${encodeURIComponent(url)}`
        );
        const mp4Json = await mp4Res.json();
        
        if (!mp4Json.status) {
          throw new Error("Gagal mengambil MP4");
        }
        
        const mp3 = mp3Json.result;
        const mp4 = mp4Json.result;
        
        result.innerHTML = `
          <img src="${mp3.thumbnail}" alt="Thumbnail">
          <h3>${mp3.title}</h3>
          <div class="info">Durasi: ${mp3.duration}</div>
          <a href="${mp4.download_url}" target="_blank" class="download-btn">Download MP4</a>
          <a href="${mp3.mp3}" target="_blank" class="download-btn">Download MP3</a>
        `;
      } catch (err) {
        console.error(err);
        result.innerHTML = "<p>Gagal mengambil data YouTube.</p>";
      }
    });
