const menuBtn =  
document.getElementById("menuBtn");  

const sidebar =  
document.getElementById("sidebar");  

menuBtn.addEventListener("click",()=>{  

  sidebar.classList.toggle("show");  

});  

document.addEventListener("click",(e)=>{  

  if(  
    !sidebar.contains(e.target) &&  
    !menuBtn.contains(e.target)  
  ){  
    sidebar.classList.remove("show");  
  }  

});

const PASSWORD = SITE_CONFIG.LOCK_PASSWORD;

if(localStorage.getItem("websiteLocked") === "true"){

  document.body.insertAdjacentHTML("beforeend", `
    <div class="lock-overlay" id="lockOverlay">
      <div class="lock-password-modal">
        <div class="lock-password-icon">🔒</div>
        <h3>Website Terkunci</h3>
        <p>Masukkan Password</p>

        <input type="password" id="lockPasswordInput" placeholder="••••••••" maxlength="30">
        <div class="lock-password-error" id="lockPasswordError"></div>

        <button id="lockPasswordSubmit">Masuk</button>
      </div>
    </div>
  `);

  const lockPasswordInput = document.getElementById("lockPasswordInput");
  const lockPasswordError = document.getElementById("lockPasswordError");
  const lockOverlay = document.getElementById("lockOverlay");

  function submitLockPassword(){

    const pass = lockPasswordInput.value;

    if(pass !== PASSWORD){

      document.body.innerHTML = `
        <div style="
        background:#0a0a0f;
        color:white;
        min-height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        font-size:24px;
        font-family:sans-serif;
        ">
        🔒 Akses Ditolak
        </div>
      `;

      throw new Error("Locked");

    }

    lockOverlay.remove();

  }

  document
  .getElementById("lockPasswordSubmit")
  .onclick = submitLockPassword;

  lockPasswordInput.addEventListener("keypress", e => {
    if(e.key === "Enter"){
      submitLockPassword();
    }
  });

  lockPasswordInput.focus();

}

const visitCountEl = document.getElementById("visitCount");
let visits = parseInt(localStorage.getItem("visitCount") || "0", 10);
visits += 1;
localStorage.setItem("visitCount", visits);
visitCountEl.textContent = visits;
