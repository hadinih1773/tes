/* ---------- Toast ---------- */
  function showToast(message, type = "info") {
    const container = document.getElementById("toastContainer");
    const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("hide");
      setTimeout(() => toast.remove(), 250);
    }, 3500);
  }

  /* ---------- Safe error message ---------- */
  function getErrorMessage(err) {
    if (err instanceof Error) return err.message;
    if (typeof err === 'string') return err;
    if (err && typeof err === 'object') {
      return err.message || err.error || JSON.stringify(err);
    }
    return 'Terjadi kesalahan tidak diketahui';
  }

  /* ===== MAIN UPLOAD ===== */
  async function uploadFile() {
    const fileInput = document.getElementById('fileInput');
    const box = document.getElementById('resultBox');
    const text = document.getElementById('resultText');
    const titleEl = document.getElementById('resultTitle');
    const platformEl = document.getElementById('resultPlatform');
    const thumbEl = document.getElementById('resultThumb');

    const file = fileInput.files[0];

    if (!file) {
      showToast('Pilih file dulu!', 'error');
      return;
    }

    box.style.display = 'block';
    thumbEl.style.display = 'none';
    titleEl.innerText = '-';
    platformEl.innerText = '-';
    text.innerText = '⏳ Sedang mengupload...';

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/uploader', {
        method: 'POST',
        body: formData
      });

      const contentType = response.headers.get('content-type') || '';

      if (!contentType.includes('application/json')) {
        const raw = await response.text();
        throw new Error(`Server tidak mengembalikan JSON (${response.status}). Response: "${raw.slice(0, 150)}..."`);
      }

      const data = await response.json();

      if (!response.ok || !data.status) {
        throw new Error(data.error || data.message || `HTTP ${response.status}`);
      }

      titleEl.innerText = file.name;
      platformEl.innerText = file.type.startsWith('video') ? 'Video' : 'Gambar';
      text.innerText = data.result.url;

      if (file.type.startsWith('image')) {
        thumbEl.src = data.result.url;
        thumbEl.style.display = 'block';
      }

      document.getElementById('openBtn').onclick = () => {
        window.open(data.result.url, '_blank');
      };

      showToast('✅ Berhasil diupload!', 'success');

    } catch (err) {
      const msg = getErrorMessage(err);
      text.innerText = '❌ Gagal upload file.';
      showToast(`⚠️ ${msg}`, 'error');
      console.error('[Upload Error]', err);
    }
  }

  /* ===== COPY RESULT ===== */
  function copyResult() {
    const text = document.getElementById('resultText').innerText;
    if (!text || text === '-' || text.includes('Gagal') || text.includes('❌')) {
      return showToast('Tidak ada hasil untuk di-copy!', 'error');
    }

    navigator.clipboard.writeText(text)
      .then(() => showToast('📋 Berhasil di-copy!', 'success'))
      .catch(() => {
        // fallback
        const range = document.createRange();
        const sel = window.getSelection();
        const el = document.getElementById('resultText');
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('copy');
        sel.removeAllRanges();
        showToast('📋 Berhasil di-copy!', 'success');
      });
  }

  /* ===== COPY CODE DOKUMENTASI ===== */
  function copyCode(elementId) {
    const codeText = document.getElementById(elementId).innerText;
    navigator.clipboard.writeText(codeText)
      .then(() => showToast('📋 Kode berhasil disalin!', 'success'))
      .catch(() => showToast('Gagal menyalin kode', 'error'));
  }
