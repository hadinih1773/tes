const API = "/api/changelog";
const changelogArea = document.getElementById("changelogArea");

function formatDate(dateStr){
  if(!dateStr) return "-";
  const d = new Date(dateStr);
  if(isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" });
}

function escapeHtml(str){
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function renderChangelogs(list){

  if(!list.length){
    changelogArea.innerHTML = `<div class="state-box">📭 Belum ada changelog yang ditambahkan.</div>`;
    return;
  }

  const items = list.map(item => `
    <div class="entry">
      <div class="entry-card">
        <div class="entry-head">
          <div class="entry-title">${escapeHtml(item.title)}</div>
          <div class="entry-meta">
            ${item.version ? `<span class="entry-version">${escapeHtml(item.version)}</span>` : ""}
            <span class="entry-tag ${escapeHtml(item.tag || "update")}">${escapeHtml(item.tag || "update")}</span>
          </div>
        </div>
        <div class="entry-date">📅 ${formatDate(item.date)}</div>
        <br>
        <ul class="entry-list">
          ${(item.changes || []).map(c => `<li>${escapeHtml(c)}</li>`).join("")}
        </ul>
      </div>
    </div>
  `).join("");

  changelogArea.innerHTML = `<div class="timeline">${items}</div>`;
}

async function loadChangelogs(){
  try{
    const res = await fetch(API);
    if(!res.ok) throw new Error("Gagal mengambil data");
    const data = await res.json();
    renderChangelogs(data);
  }catch(err){
    changelogArea.innerHTML = `<div class="state-box">⚠️ Gagal memuat changelog. Coba refresh halaman.</div>`;
  }
}

loadChangelogs();
