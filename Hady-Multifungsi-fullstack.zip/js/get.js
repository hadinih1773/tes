const urlInput = document.getElementById("url");
const btnGet = document.getElementById("btnGet");
const status = document.getElementById("status");
const resultCard = document.getElementById("resultCard");
const resultBox = document.getElementById("resultBox");
const resultMeta = document.getElementById("resultMeta");

function setStatus(text, ok){
  status.textContent = text;
  status.className = "status " + (ok ? "ok" : "bad");
}

function guessFileName(url, contentDisposition){
  let fileName = "file";
  if(contentDisposition){
    const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
    if(match){
      fileName = match[1].replace(/['"]/g, "");
    }
  } else {
    const urlFileName = url.split("/").pop().split("?")[0];
    if(urlFileName && urlFileName.includes(".")){
      fileName = urlFileName;
    }
  }
  return fileName;
}

async function doGet(){

  const url = urlInput.value.trim();

  if(!url){
    setStatus("Masukkan URL terlebih dahulu!", false);
    return;
  }

  btnGet.disabled = true;
  setStatus("⏳ Mengirim request...", true);
  resultCard.style.display = "none";
  resultBox.className = "result-box";
  resultBox.innerHTML = "";
  resultMeta.textContent = "";

  try{

    const response = await fetch(url);
    const contentType = response.headers.get("content-type") || "";
    const contentDisposition = response.headers.get("content-disposition");
    const fileName = guessFileName(url, contentDisposition);

    resultMeta.textContent = `Status: ${response.status} ${response.statusText} • Content-Type: ${contentType || "tidak diketahui"}`;
    resultCard.style.display = "block";
    resultBox.classList.add("show");

    if(contentType.includes("application/json")){
      const jsonData = await response.json();
      resultBox.textContent = JSON.stringify(jsonData, null, 2);

    } else if(contentType.includes("image")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `<img src="${objUrl}" alt="response image">`;

    } else if(contentType.includes("video")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `<video src="${objUrl}" controls></video>`;

    } else if(contentType.includes("audio")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `<audio src="${objUrl}" controls style="width:100%;"></audio>`;

    } else if(contentType.includes("application") || contentType.includes("text/csv") || contentType.includes("octet-stream")){
      const blob = await response.blob();
      const objUrl = URL.createObjectURL(blob);
      resultBox.innerHTML = `📁 Dokumen diterima: <b>${fileName}</b>`;
      resultBox.innerHTML += `<br><a class="download-link" href="${objUrl}" download="${fileName}"><i class="fas fa-download"></i> Unduh ${fileName}</a>`;

    } else {
      const data = await response.text();
      resultBox.textContent = data;
    }

    setStatus("✅ Request berhasil", true);

  } catch(err){
    resultCard.style.display = "block";
    resultBox.classList.add("show");
    resultBox.textContent = "Detail error: " + err.message;
    setStatus("❌ Gagal melakukan request GET (cek URL atau CORS)", false);
  } finally {
    btnGet.disabled = false;
  }

}

btnGet.addEventListener("click", doGet);
urlInput.addEventListener("keypress", e => {
  if(e.key === "Enter") doGet();
});
