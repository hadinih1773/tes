document.getElementById("downloadBtn").addEventListener("click", async () => {

  const url = document.getElementById("url").value.trim();
  const result = document.getElementById("result");

  if(!url){
    result.innerHTML = "<p>Masukkan URL Instagram terlebih dahulu.</p>";
    return;
  }

  result.innerHTML = "<p>Sedang mengambil data...</p>";

  try{

    const res = await fetch(
      `https://api.nexray.eu.cc/downloader/instagram?url=${encodeURIComponent(url)}`
    );

    const json = await res.json();

    if(!json.status){
      throw new Error("Gagal mengambil data");
    }

    const data = json.result;

    let html = "";

    data.forEach(item => {

      if(item.type === "video"){
        html += `
          <img src="${item.thumbnail}">
          <a href="${item.url}" target="_blank" class="download-btn">
            Download Video
          </a>
        `;
      }

    });

    result.innerHTML = html || "<p>Data tidak ditemukan.</p>";

  }catch(err){

    console.error(err);
    result.innerHTML = "<p>Gagal mengambil data Instagram.</p>";

  }

});
