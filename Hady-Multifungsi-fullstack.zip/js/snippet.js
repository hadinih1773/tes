const API = "/api/snippet";
const BASE_PATH = "/html/snippet";
let currentSnippets = [];
let currentDetailId = null;

/* ---------- Toast Modern ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

/* ---------- Slug Helper ---------- */
function slugify(text){
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "");
}

async function load(){
  const loadingDb = document.getElementById("loadingDb");
  loadingDb.classList.remove("hidden");

  const res = await fetch(API);
  const data = await res.json();
  currentSnippets = data;

  renderList(data);
  handleUrlSlug();

  loadingDb.classList.add("hidden");
}

function renderList(data){
  const list = document.getElementById("list");
  list.innerHTML = "";

  if(data.length === 0){
    list.innerHTML = `<div class="empty-state">Tidak ada snippet ditemukan.</div>`;
    return;
  }

  data.slice().reverse().forEach((s, index)=>{
    const originalIndex = currentSnippets.indexOf(s);
    const initial = s.author ? s.author.charAt(0).toUpperCase() : "A";
    const dateStr = s.createdAt ? new Date(s.createdAt).toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" }) : "-";

    list.innerHTML += `
      <div class="card" onclick="openDetailModal(${originalIndex})">
        <div class="card-header">
          <span class="lang-badge">${s.language}</span>
          <span class="card-date">${dateStr}</span>
        </div>
        
        <h3>${s.title}</h3>
        
        <p>${s.description}</p>
        
        <div class="code-window">
          <div class="code-header">
            <div class="dot red"></div>
            <div class="dot yellow"></div>
            <div class="dot green"></div>
            <div class="code-title">${s.title.toLowerCase().replace(/\s+/g, '-')}.js</div>
          </div>
          <pre style="white-space:pre-wrap">${s.code.slice(0,200)}${s.code.length > 200 ? '...' : ''}</pre>
        </div>

        <div class="tags-container">
          ${s.tags.map(t => `<span class="tag">#${t.trim()}</span>`).join("")}
        </div>

        <div class="card-footer">
          <div class="author-info">
            <div class="author-avatar">${initial}</div>
            <span>${s.author}</span>
          </div>
          <div class="card-stats">
            <span>👁 ${s.views || 1}</span>
            <span>📋 ${s.copies || 0}</span>
          </div>
        </div>
      </div>
    `;
  });
}

function filterSnippets(){
  const q = document.getElementById("searchInput").value.toLowerCase().trim();

  if(!q){
    renderList(currentSnippets);
    return;
  }

  const filtered = currentSnippets.filter(s=>{
    const inTitle = s.title && s.title.toLowerCase().includes(q);
    const inDesc = s.description && s.description.toLowerCase().includes(q);
    const inTags = s.tags && s.tags.some(t => t.toLowerCase().includes(q));
    const inLang = s.language && s.language.toLowerCase().includes(q);
    return inTitle || inDesc || inTags || inLang;
  });

  renderList(filtered);
}

function handleUrlSlug(){
  const urlParams = new URLSearchParams(window.location.search);
  const querySlug = urlParams.get('s');
  if(querySlug){
    const found = currentSnippets.findIndex(s => slugify(s.title) === querySlug);
    if(found !== -1){
      openDetailModal(found, false);
    }
  }
}

load();

function openModal(){
  modal.classList.add("active");
}

function closeModal(){
  modal.classList.remove("active");
}

function openDetailModal(index, updateUrl = true) {
  const s = currentSnippets[index];
  currentDetailId = s.id;

  document.getElementById("detLang").innerText = s.language;
  document.getElementById("detTitle").innerText = s.title;
  document.getElementById("detDesc").innerText = s.description;
  document.getElementById("detCodeTitle").innerText = `${s.title.toLowerCase().replace(/\s+/g, '-')}.js`;
  document.getElementById("detCode").innerText = s.code;
  document.getElementById("detAuthor").innerText = s.author;
  document.getElementById("detAvatar").innerText = s.author ? s.author.charAt(0).toUpperCase() : "A";
  document.getElementById("detViews").innerText = s.views || 1;
  document.getElementById("detCopies").innerText = s.copies || 0;

  const dateStr = s.createdAt ? new Date(s.createdAt).toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" }) : "-";
  document.getElementById("detDate").innerText = dateStr;

  const tagsContainer = document.getElementById("detTags");
  tagsContainer.innerHTML = s.tags.map(t => `<span class="tag">#${t.trim()}</span>`).join("");

  document.getElementById("detailModal").classList.add("active");

  if(updateUrl){
    const slug = slugify(s.title);
    const newUrl = `${window.location.origin}${window.location.pathname}?s=${slug}`;
    history.pushState({ slug }, "", newUrl);
  }
}

function closeDetailModal(event) {
  if(event.target === document.getElementById("detailModal")) {
    document.getElementById("detailModal").classList.remove("active");
    const cleanUrl = `${window.location.origin}${window.location.pathname}`;
    history.pushState({}, "", cleanUrl);
  }
}

document.getElementById("detailModal").querySelector(".btn-close")?.addEventListener("click", ()=>{
  const cleanUrl = `${window.location.origin}${window.location.pathname}`;
  history.pushState({}, "", cleanUrl);
});

window.addEventListener("popstate", ()=>{
  const urlParams = new URLSearchParams(window.location.search);
  if(!urlParams.get('s')){
    document.getElementById("detailModal").classList.remove("active");
  } else {
    handleUrlSlug();
  }
});

async function copyCode(){
  const codeText = document.getElementById("detCode").innerText;

  try {
    await navigator.clipboard.writeText(codeText);
    showToast("Kode berhasil disalin!", "success");
  } catch (err) {
    showToast("Gagal menyalin kode.", "error");
    return;
  }

  // update jumlah copy ke server
  try {
    const res = await fetch(API, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: currentDetailId })
    });
    if(res.ok){
      const updated = await res.json();
      document.getElementById("detCopies").innerText = updated.copies;
      load();
    }
  } catch (err) {
    console.error("Gagal update jumlah copy:", err);
  }
}

function downloadCode(){
  const codeText = document.getElementById("detCode").innerText;
  const titleText = document.getElementById("detTitle").innerText;

  const fileName = `${slugify(titleText)}.js`;

  const blob = new Blob([codeText], { type: "text/javascript" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showToast(`Mengunduh ${fileName}...`, "success");
}

function deleteSnippet(){
  document.getElementById("detailModal").classList.remove("active");
  document.getElementById("passwordInput").value = "";
  document.getElementById("passwordError").innerText = "";
  document.getElementById("passwordModal").classList.add("active");
  document.getElementById("passwordInput").focus();
}

function closePasswordModal(){
  document.getElementById("passwordModal").classList.remove("active");
  document.getElementById("detailModal").classList.add("active");
}

async function submitPassword(){
  const password = document.getElementById("passwordInput").value;

  if(password !== SITE_CONFIG.SNIPPET_DELETE_PASSWORD){
    document.getElementById("passwordError").innerText = "Password salah!";
    return;
  }

  document.getElementById("passwordModal").classList.remove("active");

  if(!confirm("Yakin ingin menghapus snippet ini?")) {
    document.getElementById("detailModal").classList.add("active");
    return;
  }

  try {
    const res = await fetch(API, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: currentDetailId, password: password })
    });

    if(res.ok){
      showToast("Snippet berhasil dihapus.", "success");
      document.getElementById("detailModal").classList.remove("active");
      const cleanUrl = `${window.location.origin}${window.location.pathname}`;
      history.pushState({}, "", cleanUrl);
      load();
    } else {
      const err = await res.json();
      showToast(err.error || "Gagal menghapus snippet.", "error");
      document.getElementById("detailModal").classList.add("active");
    }
  } catch (err) {
    showToast("Terjadi kesalahan saat menghapus.", "error");
    console.error(err);
    document.getElementById("detailModal").classList.add("active");
  }
}

async function uploadSnippet(){

  const data = {
    title: title.value,
    author: author.value,
    contact: contact.value,
    language: lang.value,
    tags: tags.value.split(",").map(t=>t.trim()).filter(t => t.length > 0),
    description: desc.value,
    code: code.value,
    createdAt: new Date().toISOString()
  };

  if(!data.title || !data.code){
    showToast("Judul & Code wajib!", "error");
    return;
  }

  try {
    const res = await fetch(API,{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body:JSON.stringify(data)
    });

    if(!res.ok){
      const err = await res.json();
      showToast(err.error || "Gagal upload snippet.", "error");
      return;
    }

    // reset form
    title.value = "";
    author.value = "";
    contact.value = "";
    tags.value = "";
    desc.value = "";
    code.value = "";

    closeModal();
    load();
  } catch (err) {
    showToast("Terjadi kesalahan saat upload.", "error");
    console.error(err);
  }
}
