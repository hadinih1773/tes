const API_CHANGELOG = "/api/changelog";

/* ---------- Toast ---------- */
function showToast(message, type = "info"){
  const container = document.getElementById("toastContainer");
  const icons = { success: "✅", error: "⚠️", info: "ℹ️" };

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(()=>{
    toast.classList.add("hide");
    setTimeout(()=> toast.remove(), 250);
  }, 3000);
}

function escapeHtml(str){
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/* ---------- LOGIN ---------- */
const passwordOverlay = document.getElementById("passwordOverlay");
const adminUsernameInput = document.getElementById("adminUsernameInput");
const adminPasswordInput = document.getElementById("adminPasswordInput");
const adminPasswordError = document.getElementById("adminPasswordError");
const appArea = document.getElementById("appArea");

function submitAdminLogin(){
  const username = adminUsernameInput.value.trim();
  const password = adminPasswordInput.value;

  if(username !== SITE_CONFIG.ADMIN_USERNAME || password !== SITE_CONFIG.ADMIN_PASSWORD){
    adminPasswordError.innerText = "❌ Username atau Password salah";
    return;
  }

  passwordOverlay.style.display = "none";
  appArea.style.display = "block";

  updateStatus();
  showTodayDate();
  loadChangelogList();
}

document.getElementById("adminPasswordSubmit").onclick = submitAdminLogin;

[adminUsernameInput, adminPasswordInput].forEach(el => {
  el.addEventListener("keypress", e => {
    if(e.key === "Enter") submitAdminLogin();
  });
});

adminUsernameInput.focus();

/* ---------- HAMBURGER MENU & PAGE SWITCH ---------- */
const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");

menuBtn.addEventListener("click", () => {
  sidebar.classList.toggle("show");
});

document.addEventListener("click", (e) => {
  if(!sidebar.contains(e.target) && !menuBtn.contains(e.target)){
    sidebar.classList.remove("show");
  }
});

document.querySelectorAll(".nav-link").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();

    document.querySelectorAll(".nav-link").forEach(a => a.classList.remove("active"));
    link.classList.add("active");

    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    document.getElementById(link.dataset.page).classList.add("active");

    sidebar.classList.remove("show");
  });
});

/* ---------- TANGGAL HARI INI ---------- */
function showTodayDate(){
  const now = new Date();
  const formatted = now.toLocaleDateString("id-ID", {
    weekday: "long", day: "numeric", month: "long", year: "numeric"
  });
  document.getElementById("todayDate").innerText = "📅 " + formatted;

  const iso = now.toISOString().slice(0, 10);
  document.getElementById("clDate").value = iso;
}

/* ---------- LOCK / UNLOCK WEBSITE ---------- */
const statusText = document.getElementById("status");

function updateStatus(){
  const locked = localStorage.getItem("websiteLocked");
  statusText.innerHTML = locked === "true"
    ? "Status Website : 🔒 LOCKED"
    : "Status Website : 🔓 UNLOCKED";
}

document.getElementById("lockBtn").onclick = () => {
  localStorage.setItem("websiteLocked", "true");
  updateStatus();
  showToast("🔒 Website berhasil dikunci", "success");
};

document.getElementById("unlockBtn").onclick = () => {
  localStorage.setItem("websiteLocked", "false");
  updateStatus();
  showToast("🔓 Website berhasil dibuka", "success");
};

/* ---------- CHANGELOG MANAGEMENT ---------- */
const clList = document.getElementById("clList");

function formatDate(dateStr){
  if(!dateStr) return "-";
  const d = new Date(dateStr);
  if(isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" });
}

async function loadChangelogList(){
  clList.innerHTML = "Memuat...";

  try{
    const res = await fetch(API_CHANGELOG);
    if(!res.ok) throw new Error("Gagal mengambil data");
    const data = await res.json();

    if(!data.length){
      clList.innerHTML = `<p style="color:var(--text2);font-size:0.9rem;">Belum ada changelog.</p>`;
      return;
    }

    clList.innerHTML = data.map(item => `
      <div class="cl-item" data-id="${item.id}">
        <div class="cl-item-head">
          <div>
            <div class="cl-item-title">${escapeHtml(item.title)} ${item.version ? `<span style="color:var(--text2);font-weight:400;">(${escapeHtml(item.version)})</span>` : ""}</div>
            <div class="cl-item-date">${formatDate(item.date)} · ${escapeHtml(item.tag || "update")}</div>
          </div>
          <button class="cl-del-btn" data-id="${item.id}">🗑️ Hapus</button>
        </div>
        <ul>
          ${(item.changes || []).map(c => `<li>${escapeHtml(c)}</li>`).join("")}
        </ul>
      </div>
    `).join("");

    document.querySelectorAll(".cl-del-btn").forEach(btn => {
      btn.addEventListener("click", () => deleteChangelog(btn.dataset.id));
    });

  }catch(err){
    clList.innerHTML = `<p style="color:#ff8a8a;font-size:0.9rem;">⚠️ Gagal memuat changelog.</p>`;
  }
}

document.getElementById("clAddBtn").addEventListener("click", async () => {
  const title = document.getElementById("clTitle").value.trim();
  const version = document.getElementById("clVersion").value.trim();
  const date = document.getElementById("clDate").value;
  const tag = document.getElementById("clTag").value;
  const changesRaw = document.getElementById("clChanges").value;

  const changes = changesRaw
    .split("\n")
    .map(s => s.trim())
    .filter(Boolean);

  if(!title || changes.length === 0){
    showToast("Judul & daftar perubahan wajib diisi!", "error");
    return;
  }

  try{
    const res = await fetch(API_CHANGELOG, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title, version, tag, changes, date,
        password: SITE_CONFIG.ADMIN_PASSWORD
      })
    });

    const result = await res.json();

    if(!res.ok){
      throw new Error(result.error || "Gagal menyimpan changelog");
    }

    showToast("✅ Changelog berhasil ditambahkan", "success");

    document.getElementById("clTitle").value = "";
    document.getElementById("clVersion").value = "";
    document.getElementById("clChanges").value = "";
    document.getElementById("clTag").value = "update";
    showTodayDate();

    loadChangelogList();

  }catch(err){
    showToast(err.message, "error");
  }
});

async function deleteChangelog(id){
  if(!confirm("Yakin ingin menghapus changelog ini?")) return;

  try{
    const res = await fetch(API_CHANGELOG, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, password: SITE_CONFIG.ADMIN_PASSWORD })
    });

    const result = await res.json();

    if(!res.ok){
      throw new Error(result.error || "Gagal menghapus changelog");
    }

    showToast("🗑️ Changelog berhasil dihapus", "success");
    loadChangelogList();

  }catch(err){
    showToast(err.message, "error");
  }
}
