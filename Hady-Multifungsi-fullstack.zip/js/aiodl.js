const btn = document.getElementById("downloadBtn");

btn.addEventListener("click", async ()=>{

  const url =
    document.getElementById("url").value.trim();

  const result =
    document.getElementById("result");

  if(!url){

    result.innerHTML =
      "<p>Masukkan URL terlebih dahulu.</p>";

    return;
  }

  result.innerHTML =
    "<p>Sedang mengambil data...</p>";

  try{

    const res = await fetch(
      `https://api-faa.my.id/faa/aio?url=${encodeURIComponent(url)}`
    );

    const json = await res.json();

    if(!json.status){
      throw new Error("Gagal mengambil data");
    }

    const data = json.result;

    let altLinks = "";

    if(data.alternative_urls && data.alternative_urls.length){

      data.alternative_urls.forEach(item => {

        altLinks += `
          <a
          href="${item.url}"
          target="_blank"
          class="download-btn">
          ${item.type.toUpperCase()}
          </a>
        `;

      });

    }

    result.innerHTML = `

      <img
      src="${data.thumbnail}"
      alt="Thumbnail"
      onerror="this.style.display='none'"
      >

      <h3>${data.title}</h3>

      <a
      href="${data.download_url}"
      target="_blank"
      class="download-btn">
      Download Utama
      </a>

      <div class="alt-title">
      Alternative Download Links
      </div>

      ${altLinks}

    `;

  }catch(err){

    console.error(err);

    result.innerHTML =
      "<p>Gagal mengambil data.</p>";

  }

});
