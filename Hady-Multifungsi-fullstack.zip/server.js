const express = require("express");
const path = require("path");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());

// ==========================================================
// Static assets (css, js, gambar) & file statis di root
// ==========================================================
app.use("/css", express.static(path.join(__dirname, "css")));
app.use("/js", express.static(path.join(__dirname, "js")));
app.use("/src", express.static(path.join(__dirname, "src")));

app.get("/config.js", (req, res) => {
  res.sendFile(path.join(__dirname, "config.js"));
});

app.get(["/", "/index.html"], (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// ==========================================================
// API routes
// PENTING: /api/uploader butuh raw body (multipart) jadi harus
// didaftarkan SEBELUM express.json(), supaya body belum "dimakan"
// duluan oleh body-parser.
// ==========================================================
app.post("/api/uploader", require("./api/uploader"));

app.use(express.json({ limit: "25mb" }));

app.all("/api/changelog", require("./api/changelog"));
app.all("/api/snippet", require("./api/snippet"));
app.all("/api/top4top", require("./api/top4top"));
app.post("/api/obf", require("./api/obf"));
app.post("/api/deobf", require("./api/deobf"));

// ==========================================================
// Halaman-halaman di folder html/ (dulu .html, sekarang .js)
// URL tetap sama persis seperti sebelumnya: /html/nama.html
// biar semua link & tombol di website ini tidak ada yang berubah.
// ==========================================================
const PAGES = [
  "aiodl", "bps", "changelogs", "deobf", "dev", "fbdl", "get", "igdl",
  "lock", "obf", "snippet", "top4top", "ttdl", "uploader", "webhook", "ytdl"
];

for (const slug of PAGES) {
  app.get(`/html/${slug}.html`, require(`./html/${slug}.js`));
}

// 404 sederhana
app.use((req, res) => {
  res.status(404).send("404 - Halaman tidak ditemukan");
});

app.listen(PORT, () => {
  console.log(`✅ Server jalan di http://localhost:${PORT}`);
});
