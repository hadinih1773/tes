const { nanoid } = require("nanoid");
const { put } = require("@vercel/blob");
const { loadSiteConfig } = require("./_config");

module.exports = async (req, res) => {
    try {
        if (req.method !== "POST") {
            return res.status(405).json({
                status: false,
                error: "Method tidak diizinkan."
            });
        }

        const chunks = [];
        for await (const chunk of req) {
            chunks.push(chunk);
        }
        const rawBody = Buffer.concat(chunks);

        const contentType = req.headers["content-type"] || "";
        const boundaryMatch = contentType.match(/boundary=(.+)$/);

        if (!boundaryMatch) {
            return res.status(400).json({
                status: false,
                error: "Request bukan multipart/form-data."
            });
        }

        const boundary = "--" + boundaryMatch[1];
        const parts = rawBody.toString("binary").split(boundary);

        let fileBuffer = null;
        let fileName = null;
        let fileType = null;

        for (const part of parts) {
            if (part.includes("Content-Disposition") && part.includes("filename=")) {
                const nameMatch = part.match(/filename="(.+?)"/);
                const typeMatch = part.match(/Content-Type: (.+)/);

                if (nameMatch) fileName = nameMatch[1];
                if (typeMatch) fileType = typeMatch[1].trim();

                const dataStart = part.indexOf("\r\n\r\n") + 4;
                const dataEnd = part.lastIndexOf("\r\n");
                const binaryData = part.slice(dataStart, dataEnd);

                fileBuffer = Buffer.from(binaryData, "binary");
            }
        }

        if (!fileBuffer || !fileName) {
            return res.status(400).json({
                status: false,
                error: "Tidak ada file yang diupload."
            });
        }

        const ext = fileName.includes(".") ? fileName.split(".").pop() : "";
        const id = nanoid(6);
        const storageName = ext ? `${id}.${ext}` : id;

        const { BLOB_READ_WRITE_TOKEN } = loadSiteConfig();

        const blob = await put(storageName, fileBuffer, {
            access: "public",
            contentType: fileType || "application/octet-stream",
            token: BLOB_READ_WRITE_TOKEN || undefined
        });

        return res.status(200).json({
            status: true,
            result: {
                url: blob.url,
                filename: storageName
            }
        });

    } catch (err) {
        const errorMessage = err.message || String(err);
        console.error('[Uploader API Error]', errorMessage);
        return res.status(500).json({
            status: false,
            error: errorMessage
        });
    }
};

module.exports.config = {
    api: {
        bodyParser: false
    }
};
