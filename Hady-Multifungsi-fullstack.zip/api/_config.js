const fs = require("fs");
const path = require("path");
const vm = require("vm");

// config.js adalah script browser biasa (const SITE_CONFIG = {...} tanpa
// module.exports), jadi tidak bisa di-require() langsung di Node.
// Helper ini baca & jalankan isinya di sandbox terpisah supaya semua file
// di /api bisa ambil SITE_CONFIG tanpa perlu ubah config.js atau pakai .env.
function loadSiteConfig() {
  const configPath = path.join(__dirname, "..", "config.js");
  const code = fs.readFileSync(configPath, "utf-8");
  const sandbox = {};
  vm.createContext(sandbox);
  vm.runInContext(code + "\nthis.SITE_CONFIG = SITE_CONFIG;", sandbox);
  return sandbox.SITE_CONFIG;
}

module.exports = { loadSiteConfig };
