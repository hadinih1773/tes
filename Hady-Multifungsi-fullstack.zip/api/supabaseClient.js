const { createClient } = require("@supabase/supabase-js");
const { loadSiteConfig } = require("./_config");

const SITE_CONFIG = loadSiteConfig();

const supabaseUrl = SITE_CONFIG.SUPABASE_URL;
const supabaseKey = SITE_CONFIG.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("SUPABASE_URL atau SUPABASE_SERVICE_ROLE_KEY belum diisi di config.js!");
}

const supabase = createClient(supabaseUrl, supabaseKey);

module.exports = supabase;
