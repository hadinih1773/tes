const axios = require("axios");
const FormData = require("form-data");
const { load } = require("cheerio");
const https = require("https");

const axiosClient = axios.create({
    timeout: 0,
    httpsAgent: new https.Agent({
        keepAlive: true,
        maxSockets: Infinity,
        maxFreeSockets: 256,
        scheduling: 'fifo',
        rejectUnauthorized: false
    }),
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
});

/* ================= UTILS ================= */
async function streamToBuffer(url) {
    const response = await axiosClient.get(url, {
        responseType: 'stream',
        timeout: 0,
        headers: {
            "Referer": "https://googlevideo.com/",
            "Origin": "https://googlevideo.com/"
        }
    });
    return new Promise((resolve, reject) => {
        const chunks = [];
        response.data.on('data', (chunk) => chunks.push(chunk));
        response.data.on('end', () => resolve(Buffer.concat(chunks)));
        response.data.on('error', (err) => reject(err));
    });
}

async function uploadTop4Top(buffer, filename = 'file.mp3') {
    const form = new FormData();
    form.append('file_0_', buffer, { filename, contentType: 'audio/mpeg' });
    form.append('submitr', '[ رفع الملفات ]');
    const response = await axiosClient.post('https://top4top.io/index.php', form, {
        timeout: 0,
        headers: { ...form.getHeaders() }
    });
    const html = response.data;
    const $ = load(html);
    let link = $('input.all_boxes').val() ||
               $('.alert-success a').attr('href') ||
               $('a[href*="top4top.io/download"]').attr('href') ||
               html.match(/https?:\/\/d\.top4top\.io\/m_[^"]+\.mp3/g)?.[0];

    if (!link) throw new Error('Link Top4Top tidak ditemukan');
    return link.replace(/^https:/, 'http:');
}

/* ================= API HANDLER ================= */
module.exports = async (req, res) => {
    // Selalu kirim JSON, bahkan saat error
    try {
        const body = req.method === "GET" ? req.query : req.body;
        const { audioUrl, title } = body;

        if (!audioUrl) {
            return res.status(400).json({
                status: false,
                error: "Parameter 'audioUrl' wajib diisi."
            });
        }

        const buffer = await streamToBuffer(audioUrl);
        const safeTitle = (title || "audio").replace(/[^\w\s.-]/gi, '');
        const top4topLink = await uploadTop4Top(buffer, `${safeTitle}.mp3`);

        return res.status(200).json({
            status: true,
            result: {
                top4top: top4topLink
            }
        });

    } catch (err) {
        // Pastikan error selalu berupa string
        const errorMessage = err.message || String(err);
        console.error('[Top4Top API Error]', errorMessage);
        return res.status(500).json({
            status: false,
            error: errorMessage
        });
    }
};