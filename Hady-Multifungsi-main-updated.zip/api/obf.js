const axios = require("axios");

async function obfuscate(script) {
  try {
    const response = await axios.post(
      "https://wearedevs.net/api/obfuscate",
      { script },
      {
        headers: {
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36",
          "Referer": "https://wearedevs.net/obfuscator"
        }
      }
    );

    const data = response.data;

    if (typeof data === "object") {
      if (data.obfuscated) return data.obfuscated;
      if (data.result) return data.result;
      if (data.data) return data.data;
    }

    if (typeof data === "string") return data;

    throw new Error("Invalid API response");
  } catch (error) {
    throw new Error(
      error.response?.data?.message || error.message
    );
  }
}

module.exports = async (req, res) => {
  // CORS biar aman dipanggil dari HTML
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({
      status: false,
      message: "Method not allowed"
    });
  }

  try {
    const { script } = req.body;

    if (!script) {
      return res.status(400).json({
        status: false,
        message: "script kosong"
      });
    }

    const result = await obfuscate(script);

    return res.status(200).json({
      status: true,
      result
    });

  } catch (err) {
    return res.status(500).json({
      status: false,
      message: err.message
    });
  }
};