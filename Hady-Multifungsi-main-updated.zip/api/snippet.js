const supabase = require("./supabaseClient");

const DELETE_PASSWORD = "31012009";

module.exports = async (req, res) => {

    if (req.method === "GET") {
        const { data, error } = await supabase
            .from("snippets")
            .select("*")
            .order("created_at", { ascending: true });

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal mengambil data: " + error.message });
        }

        // Mapping supaya field cocok dengan yang dipakai di frontend (createdAt bukan created_at)
        const mapped = data.map(s => ({
            id: s.id,
            title: s.title,
            author: s.author,
            contact: s.contact,
            language: s.language,
            tags: s.tags || [],
            description: s.description,
            code: s.code,
            views: s.views,
            copies: s.copies,
            createdAt: s.created_at
        }));

        return res.status(200).json(mapped);
    }

    if (req.method === "POST") {
        const body = req.body || {};
        const { title, author, contact, language, tags, description, code } = body;

        if (!title || !code) {
            return res.status(400).json({ error: "Judul & Code wajib diisi!" });
        }

        const { data, error } = await supabase
            .from("snippets")
            .insert([{
                title,
                author: author || "Anonim",
                contact: contact || "",
                language: language || "JavaScript",
                tags: Array.isArray(tags) ? tags : [],
                description: description || "",
                code,
                views: 1,
                copies: 0
            }])
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menyimpan ke storage: " + error.message });
        }

        return res.status(201).json({
            id: data.id,
            title: data.title,
            author: data.author,
            contact: data.contact,
            language: data.language,
            tags: data.tags || [],
            description: data.description,
            code: data.code,
            views: data.views,
            copies: data.copies,
            createdAt: data.created_at
        });
    }

    if (req.method === "DELETE") {
        const body = req.body || {};
        const { id, password } = body;

        if (password !== DELETE_PASSWORD) {
            return res.status(401).json({ error: "Password salah!" });
        }

        if (!id) {
            return res.status(400).json({ error: "ID snippet wajib diisi!" });
        }

        const { error } = await supabase
            .from("snippets")
            .delete()
            .eq("id", id);

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menghapus dari storage: " + error.message });
        }

        return res.status(200).json({ success: true });
    }

    if (req.method === "PATCH") {
        const body = req.body || {};
        const { id } = body;

        if (!id) {
            return res.status(400).json({ error: "ID snippet wajib diisi!" });
        }

        // Ambil dulu nilai copies saat ini
        const { data: current, error: fetchError } = await supabase
            .from("snippets")
            .select("copies")
            .eq("id", id)
            .single();

        if (fetchError) {
            console.error(fetchError);
            return res.status(404).json({ error: "Snippet tidak ditemukan" });
        }

        const { data, error } = await supabase
            .from("snippets")
            .update({ copies: (current.copies || 0) + 1 })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal update storage: " + error.message });
        }

        return res.status(200).json({
            id: data.id,
            copies: data.copies
        });
    }

    res.setHeader("Allow", ["GET", "POST", "DELETE", "PATCH"]);
    return res.status(405).json({ error: `Method ${req.method} tidak diizinkan` });
};