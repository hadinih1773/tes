const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "..", "database", "snippet.json");

const loadInitialData = () => {
    try {
        if (fs.existsSync(dbPath)) {
            const rawData = fs.readFileSync(dbPath, "utf-8");
            return JSON.parse(rawData);
        }
    } catch (error) {
        console.error("Gagal membaca snippet.json, menggunakan data default:", error);
    }
    return [];
};

// Memuat data dari snippet.json ke memori RAM agar aman di Vercel
let database = loadInitialData();

module.exports = database;