const axios = require("axios");
const FormData = require("form-data");

module.exports = async (req, res) => {
  // Hanya menerima metode POST
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }

  try {
    const { script, filename } = req.body;

    if (!script) {
      return res.status(400).json({ error: "Script tidak boleh kosong!" });
    }

    const targetFilename = filename || "script.lua";
    
    // Konversi text script dari frontend menjadi buffer
    const fileBuffer = Buffer.from(script, "utf-8");

    // Bungkus ke multipart form data sesuai kebutuhan target API
    const form = new FormData();
    form.append("file", fileBuffer, {
      filename: targetFilename,
      contentType: "text/plain"
    });

    let apiResponse;
    let lastError = null;

    // Sistem Retry Percobaan (Max 3 Kali) seperti pada bot Discord
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        apiResponse = await axios.post("https://tw8rev-deobfuscator.vercel.app/api/deobfuscate", form, {
          headers: {
            ...form.getHeaders()
          },
          timeout: 90000 // 90 detik timeout
        });
        lastError = null;
        break; // Jika sukses, keluar dari loop
      } catch (err) {
        lastError = err;
      }
    }

    if (lastError) {
      throw new Error(`Koneksi API Gagal setelah 3 kali percobaan: ${lastError.message}`);
    }

    const data = apiResponse.data;

    // Memvalidasi kembalian data struktur API
    if (data && (data.success || data.result)) {
      const resultClean = data.result || data.deobfuscated || "";
      
      // Kirim balik respon bersih ke frontend html
      return res.status(200).json({ success: true, result: resultClean });
    } else {
      return res.status(500).json({ error: data.result || "Struktur data respons dari API mengembalikan nilai gagal." });
    }

  } catch (error) {
    console.error("❌ Error Web Deobfuscator Router:", error.message);
    return res.status(500).json({ error: error.message || "Terjadi kesalahan pada server internal." });
  }
};
