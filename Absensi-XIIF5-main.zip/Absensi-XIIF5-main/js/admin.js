// ============================================================
// ADMIN - kelola akun (CRUD)
// ============================================================

let adminRole = "siswa";
let adminCache = [];
let adminSearchTerm = "";

function renderAdmin() {
  bindAdminEvents();
  loadAdminTable();
}

function bindAdminEvents() {
  if (bindAdminEvents._done) return;
  bindAdminEvents._done = true;

  document.getElementById("adminTabs").addEventListener("click", (e) => {
    const tab = e.target.closest(".tab-btn");
    if (!tab) return;
    document.querySelectorAll("#adminTabs .tab-btn").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    adminRole = tab.dataset.role;
    loadAdminTable();
  });

  document.getElementById("btnAddUser").addEventListener("click", () => openUserModal(null));

  const searchInput = document.getElementById("adminSearch");
  if (searchInput) {
    searchInput.addEventListener("input", () => {
      adminSearchTerm = searchInput.value.trim().toLowerCase();
      renderAdminTableRows();
    });
  }
}

async function loadAdminTable() {
  const tbody = document.querySelector("#adminTable tbody");
  tbody.innerHTML = `<tr class="empty-row"><td colspan="5">Memuat data...</td></tr>`;

  const { data, error } = await db.from("users").select("*").eq("role", adminRole).order("nomor_absen", { ascending: true, nullsFirst: false });
  if (error) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5">Gagal memuat data.</td></tr>`;
    return;
  }

  adminCache = data || [];
  renderAdminTableRows();
}

function renderAdminTableRows() {
  const tbody = document.querySelector("#adminTable tbody");
  const data = adminSearchTerm
    ? adminCache.filter(u => u.nama.toLowerCase().includes(adminSearchTerm) || u.username.toLowerCase().includes(adminSearchTerm))
    : adminCache;

  if (!data.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5">${adminSearchTerm ? "Tidak ada akun yang cocok." : "Belum ada akun untuk peran ini."}</td></tr>`;
    return;
  }

  tbody.innerHTML = data.map((u, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${escapeHtml(u.nama)}</td>
      <td>${escapeHtml(u.username)}</td>
      <td>${escapeHtml(u.password)}</td>
      <td style="display:flex;gap:6px;">
        <button class="btn btn-outline btn-sm btn-edit-user" data-id="${u.id}">Ubah</button>
        <button class="btn btn-danger btn-sm btn-del-user" data-id="${u.id}" data-nama="${escapeHtml(u.nama)}">Hapus</button>
      </td>
    </tr>`).join("");

  tbody.querySelectorAll(".btn-edit-user").forEach(btn => {
    btn.addEventListener("click", () => {
      const user = data.find(u => u.id === btn.dataset.id);
      openUserModal(user);
    });
  });
  tbody.querySelectorAll(".btn-del-user").forEach(btn => {
    btn.addEventListener("click", () => confirmDeleteUser(btn.dataset.id, btn.dataset.nama));
  });
}

function openUserModal(user) {
  const isEdit = !!user;
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="userModalOverlay">
      <div class="modal-box">
        <h3>${isEdit ? "Ubah Akun" : "Tambah Akun"}</h3>
        <div class="field">
          <label>Peran</label>
          <select id="mRole" ${isEdit ? "disabled" : ""}>
            <option value="siswa" ${adminRole === "siswa" ? "selected" : ""}>Siswa</option>
            <option value="walas" ${adminRole === "walas" ? "selected" : ""}>Wali Kelas</option>
            <option value="orangtua" ${adminRole === "orangtua" ? "selected" : ""}>Orang Tua</option>
            <option value="admin" ${adminRole === "admin" ? "selected" : ""}>Admin</option>
          </select>
        </div>
        <div class="field">
          <label>Nama</label>
          <input type="text" id="mNama" value="${isEdit ? escapeHtml(user.nama) : ""}" required>
        </div>
        <div class="field">
          <label>Username</label>
          <input type="text" id="mUsername" value="${isEdit ? escapeHtml(user.username) : ""}" required>
        </div>
        <div class="field">
          <label>Password</label>
          <input type="text" id="mPassword" value="${isEdit ? escapeHtml(user.password) : ""}" required>
        </div>
        <div class="field" id="mNomorField">
          <label>Nomor Absen (khusus siswa)</label>
          <input type="number" id="mNomor" value="${isEdit && user.nomor_absen ? user.nomor_absen : ""}">
        </div>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="mCancel">Batal</button>
          <button class="btn btn-primary" id="mSave">${isEdit ? "Simpan Perubahan" : "Tambah"}</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById("mCancel").addEventListener("click", closeModal);
  document.getElementById("userModalOverlay").addEventListener("click", (e) => {
    if (e.target.id === "userModalOverlay") closeModal();
  });

  document.getElementById("mSave").addEventListener("click", async () => {
    const nama = document.getElementById("mNama").value.trim();
    const username = document.getElementById("mUsername").value.trim().toLowerCase();
    const password = document.getElementById("mPassword").value.trim();
    const role = document.getElementById("mRole").value;
    const nomorRaw = document.getElementById("mNomor").value;
    const nomor_absen = nomorRaw ? parseInt(nomorRaw, 10) : null;

    if (!nama || !username || !password) { toast("Lengkapi semua field wajib.", "err"); return; }

    const saveBtn = document.getElementById("mSave");
    saveBtn.disabled = true;
    saveBtn.textContent = "Menyimpan...";

    let result;
    if (isEdit) {
      result = await db.from("users").update({ nama, username, password, nomor_absen }).eq("id", user.id);
    } else {
      result = await db.from("users").insert({ nama, username, password, role, nomor_absen });
    }

    saveBtn.disabled = false;
    saveBtn.textContent = isEdit ? "Simpan Perubahan" : "Tambah";

    if (result.error) {
      toast(result.error.message.includes("duplicate") ? "Username sudah dipakai." : "Gagal menyimpan akun.", "err");
      return;
    }

    toast(isEdit ? "Akun diperbarui." : "Akun ditambahkan.", "ok");
    closeModal();
    loadAdminTable();
  });
}

function closeModal() {
  document.getElementById("modalRoot").innerHTML = "";
}

function confirmDeleteUser(id, nama) {
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="delModalOverlay">
      <div class="modal-box">
        <h3>Hapus Akun?</h3>
        <p style="color:var(--ink-600);font-size:14px;">Akun <b>${nama}</b> beserta seluruh riwayat absensinya akan dihapus permanen. Tindakan ini tidak bisa dibatalkan.</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="delCancel">Batal</button>
          <button class="btn btn-danger" id="delConfirm">Hapus</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById("delCancel").addEventListener("click", closeModal);
  document.getElementById("delModalOverlay").addEventListener("click", (e) => { if (e.target.id === "delModalOverlay") closeModal(); });
  document.getElementById("delConfirm").addEventListener("click", async () => {
    const { error } = await db.from("users").delete().eq("id", id);
    closeModal();
    if (error) { toast("Gagal menghapus akun.", "err"); return; }
    toast("Akun dihapus.", "ok");
    loadAdminTable();
  });
}

// ============================================================
// ADMIN PANEL - reset & hapus absensi massal
// ============================================================

let panelSiswaFilled = false;
let panelCache = [];

async function renderAdminPanel() {
  if (!panelSiswaFilled) await fillPanelSiswaFilter();
  bindAdminPanelEvents();
  await loadPanelTable();
}

async function fillPanelSiswaFilter() {
  const { data } = await db.from("users").select("id, nama, nomor_absen").eq("role", "siswa").order("nomor_absen");
  const sel = document.getElementById("panelSiswa");
  (data || []).forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.nama;
    sel.appendChild(opt);
  });
  panelSiswaFilled = true;
}

function bindAdminPanelEvents() {
  if (bindAdminPanelEvents._done) return;
  bindAdminPanelEvents._done = true;

  document.getElementById("btnResetAllAbsensi").addEventListener("click", confirmResetAllAbsensi);
  const btnHapusChat = document.getElementById("btnHapusSemuaChat");
  if (btnHapusChat) btnHapusChat.addEventListener("click", confirmHapusSemuaChat);

  ["panelFrom", "panelTo", "panelSiswa", "panelStatus"].forEach(id => {
    document.getElementById(id).addEventListener("change", loadPanelTable);
  });
  document.getElementById("btnPanelFilterReset").addEventListener("click", () => {
    document.getElementById("panelFrom").value = "";
    document.getElementById("panelTo").value = "";
    document.getElementById("panelSiswa").value = "";
    document.getElementById("panelStatus").value = "";
    loadPanelTable();
  });
  document.getElementById("panelCheckAll").addEventListener("change", (e) => {
    document.querySelectorAll(".panel-row-check").forEach(cb => cb.checked = e.target.checked);
  });
  document.getElementById("btnDeleteSelectedAbsensi").addEventListener("click", confirmDeleteSelectedAbsensi);
}

async function loadPanelTable() {
  const tbody = document.querySelector("#panelTable tbody");
  tbody.innerHTML = `<tr class="empty-row"><td colspan="7">Memuat data...</td></tr>`;
  document.getElementById("panelCheckAll").checked = false;

  const from = document.getElementById("panelFrom").value;
  const to = document.getElementById("panelTo").value;
  const siswaId = document.getElementById("panelSiswa").value;
  const status = document.getElementById("panelStatus").value;

  let q = db.from("attendance").select("id, tanggal, status, keterangan, users:siswa_id(nama, nomor_absen)").order("tanggal", { ascending: false });
  if (from) q = q.gte("tanggal", from);
  if (to) q = q.lte("tanggal", to);
  if (siswaId) q = q.eq("siswa_id", siswaId);
  if (status) q = q.eq("status", status);

  const { data, error } = await q;
  if (error) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="7">Gagal memuat data.</td></tr>`;
    return;
  }

  panelCache = data || [];
  if (!panelCache.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="7">Tidak ada data untuk filter ini.</td></tr>`;
    return;
  }

  tbody.innerHTML = panelCache.map((r, i) => `
    <tr>
      <td><input type="checkbox" class="panel-row-check" data-id="${r.id}"></td>
      <td>${i + 1}</td>
      <td>${escapeHtml(r.users?.nama || "-")}</td>
      <td>${namaHari(r.tanggal)}</td>
      <td>${formatTanggalID(r.tanggal)}</td>
      <td>${statusPill(r.status)}</td>
      <td>${r.keterangan ? escapeHtml(r.keterangan) : "-"}</td>
    </tr>`).join("");
}

function confirmResetAllAbsensi() {
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="resetAllOverlay">
      <div class="modal-box">
        <h3>⚠️ Reset Semua Absensi?</h3>
        <p style="color:var(--ink-600);font-size:14px;">Seluruh riwayat absensi <b>semua siswa</b> akan dihapus permanen. Akun tidak terpengaruh. Tindakan ini tidak bisa dibatalkan.</p>
        <div class="field">
          <label>Ketik <b>RESET</b> untuk konfirmasi</label>
          <input type="text" id="resetConfirmInput" autocomplete="off">
        </div>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="resetCancel">Batal</button>
          <button class="btn btn-danger" id="resetConfirmBtn">Hapus Semua</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById("resetCancel").addEventListener("click", closeModal);
  document.getElementById("resetAllOverlay").addEventListener("click", (e) => { if (e.target.id === "resetAllOverlay") closeModal(); });
  document.getElementById("resetConfirmBtn").addEventListener("click", async () => {
    if (document.getElementById("resetConfirmInput").value.trim().toUpperCase() !== "RESET") {
      toast("Ketik RESET terlebih dahulu untuk konfirmasi.", "err");
      return;
    }
    const btn = document.getElementById("resetConfirmBtn");
    btn.disabled = true;
    btn.textContent = "Menghapus...";

    const { error } = await db.from("attendance").delete().not("id", "is", null);

    closeModal();
    if (error) { toast("Gagal mereset absensi.", "err"); return; }
    toast("Semua absensi berhasil direset.", "ok");
    loadPanelTable();
  });
}

// ============================================================
// ADMIN PANEL - hapus semua chat (Chat Wali Murid & Chat Siswa) + medianya
// ============================================================

function confirmHapusSemuaChat() {
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="hapusChatOverlay">
      <div class="modal-box">
        <h3>⚠️ Hapus Semua Chat?</h3>
        <p style="color:var(--ink-600);font-size:14px;">Seluruh pesan di <b>Chat Wali Murid</b> dan <b>Chat Siswa</b> beserta seluruh media (foto/video/file) yang pernah dikirim akan dihapus permanen. Tindakan ini tidak bisa dibatalkan.</p>
        <div class="field">
          <label>Ketik <b>HAPUS</b> untuk konfirmasi</label>
          <input type="text" id="hapusChatConfirmInput" autocomplete="off">
        </div>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="hapusChatCancel">Batal</button>
          <button class="btn btn-danger" id="hapusChatConfirmBtn">Hapus Semua Chat</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById("hapusChatCancel").addEventListener("click", closeModal);
  document.getElementById("hapusChatOverlay").addEventListener("click", (e) => { if (e.target.id === "hapusChatOverlay") closeModal(); });
  document.getElementById("hapusChatConfirmBtn").addEventListener("click", async () => {
    if (document.getElementById("hapusChatConfirmInput").value.trim().toUpperCase() !== "HAPUS") {
      toast("Ketik HAPUS terlebih dahulu untuk konfirmasi.", "err");
      return;
    }
    const btn = document.getElementById("hapusChatConfirmBtn");
    btn.disabled = true;
    btn.textContent = "Menghapus...";

    try {
      // Hapus semua file media chat dari storage (folder "chat")
      const { data: files } = await db.storage.from(LAMPIRAN_BUCKET).list("chat", { limit: 1000 });
      if (files && files.length) {
        const paths = files.map(f => `chat/${f.name}`);
        await db.storage.from(LAMPIRAN_BUCKET).remove(paths);
      }
      // Hapus semua baris pesan (kedua channel)
      const { error } = await db.from("messages").delete().not("id", "is", null);
      if (error) throw error;

      toast("Semua chat berhasil dihapus.", "ok");
    } catch (err) {
      console.error(err);
      toast("Gagal menghapus sebagian/seluruh chat.", "err");
    } finally {
      closeModal();
    }
  });
}

function confirmDeleteSelectedAbsensi() {
  const ids = Array.from(document.querySelectorAll(".panel-row-check:checked")).map(cb => cb.dataset.id);
  if (!ids.length) { toast("Pilih minimal satu baris absensi.", "err"); return; }

  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="delSelOverlay">
      <div class="modal-box">
        <h3>Hapus Absensi Terpilih?</h3>
        <p style="color:var(--ink-600);font-size:14px;"><b>${ids.length}</b> catatan absensi akan dihapus permanen. Tindakan ini tidak bisa dibatalkan.</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="delSelCancel">Batal</button>
          <button class="btn btn-danger" id="delSelConfirm">Hapus</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById("delSelCancel").addEventListener("click", closeModal);
  document.getElementById("delSelOverlay").addEventListener("click", (e) => { if (e.target.id === "delSelOverlay") closeModal(); });
  document.getElementById("delSelConfirm").addEventListener("click", async () => {
    const { error } = await db.from("attendance").delete().in("id", ids);
    closeModal();
    if (error) { toast("Gagal menghapus absensi.", "err"); return; }
    toast("Absensi terpilih berhasil dihapus.", "ok");
    loadPanelTable();
  });
}
