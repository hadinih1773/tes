// ============================================================
// KONFIGURASI - Absensi Kelas XII F 5
// Isi URL dan Anon Key project Supabase kamu di bawah ini.
// Ambil di: Supabase Dashboard > Project Settings > API
// ============================================================

const SUPABASE_CONFIG = {
  url: "https://dibqnbkoibxvisntoiez.supabase.co",   // <-- ganti dengan Project URL kamu
  anonKey: "sb_publishable_rFYXRcVYyTeDi7_C9c58dQ_2pQmU8Tl"     // <-- ganti dengan anon public key kamu
};

// Akun admin cadangan (dipakai jika belum sempat isi tabel users di Supabase).
// Setelah database terisi lewat schema.sql, login admin akan memakai data
// dari tabel `users`. Config ini tetap dicek sebagai jalur cadangan.
const ADMIN_FALLBACK = {
  username: "admin",
  password: "admin123"
};

const APP_INFO = {
  namaKelas: "XII F 5",
  waliKelas: "Sury"
};
