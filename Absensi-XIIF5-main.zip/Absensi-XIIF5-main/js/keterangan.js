// ============================================================
// KETERANGAN - kelola & ajukan keterangan izin/sakit/alfa (+ foto opsional)
// ============================================================

let keteranganFotoFiles = {}; // { rowId: File } untuk tabel walas/admin
let ajukanFotoFile = null;    // File untuk form pengajuan orangtua

async function renderKeterangan() {
  const root = document.getElementById("keteranganRoot");
  root.innerHTML = `<div class="skeleton" style="height:260px;"></div>`;

  try {
    if (SESSION.role === "orangtua") {
      await renderKeteranganOrangtua(root);
    } else {
      await renderKeteranganWalas(root);
    }
  } catch (err) {
    console.error(err);
    root.innerHTML = `<div class="card" style="padding:20px;color:var(--bad);">Gagal memuat data keterangan.</div>`;
  }
}

async function fetchKeteranganList() {
  const { data, error } = await db
    .from("attendance")
    .select("id, tanggal, status, keterangan, foto_url, siswa_id, users:siswa_id(nama, nomor_absen)")
    .in("status", ["Izin", "Sakit", "Alfa"])
    .order("tanggal", { ascending: false })
    .limit(150);
  if (error) throw error;
  return data || [];
}

// ---------- Wali Kelas & Admin: kelola keterangan ----------
async function renderKeteranganWalas(root) {
  const rows = await fetchKeteranganList();
  keteranganFotoFiles = {};

  root.innerHTML = `
    <div class="card" style="padding:18px;">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Nama</th><th>Tanggal</th><th>Status</th><th>Keterangan</th><th>Foto</th><th></th></tr></thead>
          <tbody id="ketTbody">
            ${rows.length ? rows.map(r => ketRowEditable(r)).join("") : `<tr class="empty-row"><td colspan="6">Belum ada catatan izin/sakit/alfa.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;

  root.querySelectorAll(".ket-foto-input").forEach(input => {
    input.addEventListener("change", () => {
      const id = input.dataset.id;
      keteranganFotoFiles[id] = input.files[0] || null;
      const preview = document.getElementById("ketFotoPreview-" + id);
      if (keteranganFotoFiles[id] && preview) {
        preview.innerHTML = `<img src="${URL.createObjectURL(keteranganFotoFiles[id])}" class="lampiran-thumb">`;
      }
    });
  });

  root.querySelectorAll(".btn-save-ket").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      const row = btn.closest("tr");
      const status = row.querySelector(".status-select").value;
      const keterangan = row.querySelector(".ket-input").value.trim();

      btn.disabled = true;
      btn.textContent = "...";

      try {
        const update = { status, keterangan: keterangan || null };
        const file = keteranganFotoFiles[id];
        if (file) {
          update.foto_url = await uploadLampiran(file, `keterangan/${id}`);
        }
        const { error } = await db.from("attendance").update(update).eq("id", id);
        if (error) throw error;
        toast("Keterangan diperbarui.", "ok");
        delete keteranganFotoFiles[id];
      } catch (err) {
        console.error(err);
        toast(err.message || "Gagal menyimpan perubahan.", "err");
      } finally {
        btn.disabled = false;
        btn.textContent = "Simpan";
      }
    });
  });
}

function ketRowEditable(r) {
  return `
    <tr>
      <td>${escapeHtml(r.users?.nama || "-")}</td>
      <td>${formatTanggalID(r.tanggal)}</td>
      <td>
        <select class="status-select">
          <option value="Izin" ${r.status === "Izin" ? "selected" : ""}>Izin</option>
          <option value="Sakit" ${r.status === "Sakit" ? "selected" : ""}>Sakit</option>
          <option value="Alfa" ${r.status === "Alfa" ? "selected" : ""}>Alfa</option>
          <option value="Hadir" ${r.status === "Hadir" ? "selected" : ""}>Hadir</option>
        </select>
      </td>
      <td><input type="text" class="ket-input" value="${r.keterangan ? escapeHtml(r.keterangan) : ""}" placeholder="Tulis keterangan..."></td>
      <td>
        <div class="ket-foto-cell">
          <div id="ketFotoPreview-${r.id}" class="lampiran-preview">${r.foto_url ? lampiranThumb(r.foto_url, "Foto keterangan") : ""}</div>
          <input type="file" class="ket-foto-input" data-id="${r.id}" accept="image/*" title="Unggah/ganti foto">
        </div>
      </td>
      <td><button class="btn btn-outline btn-sm btn-save-ket" data-id="${r.id}">Simpan</button></td>
    </tr>`;
}

// ---------- Orang Tua: ajukan izin/sakit ----------
async function renderKeteranganOrangtua(root) {
  const { data: siswaList } = await db.from("users").select("id, nama").eq("role", "siswa").order("nomor_absen");
  const rows = await fetchKeteranganList();
  ajukanFotoFile = null;

  root.innerHTML = `
    <div class="card" style="padding:20px; margin-bottom:16px;">
      <h3 style="margin:0 0 4px;">Ajukan Izin / Sakit</h3>
      <p class="panel-sub">Isi form berikut untuk mengajukan keterangan tidak hadir anak.</p>
      <div class="toolbar">
        <div class="field">
          <label>Nama Siswa</label>
          <select id="ajuSiswa">${(siswaList || []).map(s => `<option value="${s.id}">${escapeHtml(s.nama)}</option>`).join("")}</select>
        </div>
        <div class="field">
          <label>Tanggal</label>
          <input type="date" id="ajuTanggal" value="${todayStr()}">
        </div>
        <div class="field">
          <label>Jenis</label>
          <select id="ajuJenis"><option value="Izin">Izin</option><option value="Sakit">Sakit</option></select>
        </div>
      </div>
      <div class="field">
        <label>Keterangan</label>
        <input type="text" id="ajuKeterangan" placeholder="Contoh: izin acara keluarga">
      </div>
      <div class="field">
        <label>Foto Bukti (opsional)</label>
        <input type="file" id="ajuFoto" accept="image/*">
        <div id="ajuFotoPreview" class="lampiran-preview hidden"></div>
      </div>
      <button class="btn btn-primary" id="btnAjukan">Ajukan</button>
    </div>

    <div class="card" style="padding:18px;">
      <h3 style="margin:0 0 12px;">Riwayat Keterangan</h3>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Nama</th><th>Tanggal</th><th>Status</th><th>Keterangan</th><th>Foto</th></tr></thead>
          <tbody>
            ${rows.length ? rows.map(r => `
              <tr>
                <td>${escapeHtml(r.users?.nama || "-")}</td>
                <td>${formatTanggalID(r.tanggal)}</td>
                <td>${statusPill(r.status)}</td>
                <td>${r.keterangan ? escapeHtml(r.keterangan) : "-"}</td>
                <td>${r.foto_url ? lampiranThumb(r.foto_url, "Foto keterangan") : "-"}</td>
              </tr>`).join("") : `<tr class="empty-row"><td colspan="5">Belum ada catatan.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById("ajuFoto").addEventListener("change", (e) => {
    ajukanFotoFile = e.target.files[0] || null;
    const preview = document.getElementById("ajuFotoPreview");
    if (ajukanFotoFile) {
      preview.innerHTML = `<img src="${URL.createObjectURL(ajukanFotoFile)}" class="lampiran-thumb">`;
      preview.classList.remove("hidden");
    } else {
      preview.innerHTML = "";
      preview.classList.add("hidden");
    }
  });

  document.getElementById("btnAjukan").addEventListener("click", async () => {
    const siswaId = document.getElementById("ajuSiswa").value;
    const tanggal = document.getElementById("ajuTanggal").value;
    const jenis = document.getElementById("ajuJenis").value;
    const keterangan = document.getElementById("ajuKeterangan").value.trim();

    if (!siswaId || !tanggal) { toast("Lengkapi form terlebih dahulu.", "err"); return; }

    const btn = document.getElementById("btnAjukan");
    btn.disabled = true;
    btn.textContent = "Mengirim...";

    try {
      let foto_url = null;
      if (ajukanFotoFile) {
        foto_url = await uploadLampiran(ajukanFotoFile, `keterangan/${siswaId}`);
      }

      const { error } = await db.from("attendance").upsert({
        siswa_id: siswaId,
        tanggal,
        status: jenis,
        keterangan: keterangan || null,
        foto_url,
        created_by: "orangtua"
      }, { onConflict: "siswa_id,tanggal" });

      if (error) throw error;

      toast("Pengajuan berhasil dikirim.", "ok");
      renderKeterangan();
    } catch (err) {
      console.error(err);
      toast(err.message || "Gagal mengirim pengajuan.", "err");
      btn.disabled = false;
      btn.textContent = "Ajukan";
    }
  });
}
