// ============================================================
// DASHBOARD
// ============================================================

async function renderDashboard() {
  const root = document.getElementById("dashboardRoot");
  root.innerHTML = `<div class="skeleton" style="height:220px;"></div>`;

  try {
    if (SESSION.role === "siswa") {
      await renderDashboardSiswa(root);
    } else {
      await renderDashboardClass(root);
    }
  } catch (err) {
    console.error(err);
    root.innerHTML = `<div class="card" style="padding:20px;color:var(--bad);">Gagal memuat dashboard. Periksa koneksi Supabase kamu (js/config.js).</div>`;
  }
}

async function fetchAllAttendance() {
  const { data, error } = await db
    .from("attendance")
    .select("id, siswa_id, tanggal, status, keterangan, users:siswa_id(nama, nomor_absen)")
    .order("tanggal", { ascending: false });
  if (error) throw error;
  return data || [];
}

async function renderDashboardClass(root) {
  document.getElementById("dashSub").textContent = "Ringkasan kehadiran seluruh siswa kelas XII F 5.";
  const rows = await fetchAllAttendance();
  const today = todayStr();

  const todayRows = rows.filter(r => r.tanggal === today);
  const count = (arr, status) => arr.filter(r => r.status === status).length;

  const totalHadirToday = count(todayRows, "Hadir");
  const totalIzinToday = count(todayRows, "Izin");
  const totalSakitToday = count(todayRows, "Sakit");
  const totalAlfaToday = count(todayRows, "Alfa");

  // Rekap per siswa (seluruh waktu)
  const per = {};
  rows.forEach(r => {
    const key = r.siswa_id;
    if (!per[key]) per[key] = { nama: r.users?.nama || "-", Hadir: 0, Izin: 0, Sakit: 0, Alfa: 0 };
    per[key][r.status] = (per[key][r.status] || 0) + 1;
  });
  const perArr = Object.values(per);

  const topBy = (field) => [...perArr].sort((a, b) => b[field] - a[field]).filter(x => x[field] > 0).slice(0, 5);
  const topHadir = topBy("Hadir");
  const topAlfa = topBy("Alfa");
  const topIzin = topBy("Izin");
  const topSakit = topBy("Sakit");
  const maxAny = Math.max(1, ...perArr.map(p => p.Hadir));

  root.innerHTML = `
    <div class="stat-grid">
      ${statCard("Hadir Hari Ini", totalHadirToday, "ic-ok", "✅")}
      ${statCard("Izin Hari Ini", totalIzinToday, "ic-warn", "📩")}
      ${statCard("Sakit Hari Ini", totalSakitToday, "ic-sick", "🤒")}
      ${statCard("Alfa Hari Ini", totalAlfaToday, "ic-bad", "🚫")}
    </div>

    <div class="grid-2">
      <div class="card panel">
        <h3>Ranking Kehadiran Terbanyak</h3>
        <p class="panel-sub">Siswa dengan jumlah "Hadir" terbanyak (sepanjang waktu)</p>
        ${rankList(topHadir, "Hadir", maxAny)}
      </div>
      <div class="card panel">
        <h3>Perlu Perhatian</h3>
        <p class="panel-sub">Rekap Alfa, Izin, dan Sakit terbanyak</p>
        <div style="display:flex;flex-direction:column;gap:14px;">
          ${miniRankBlock("🚫 Alfa Terbanyak", topAlfa, "Alfa")}
          ${miniRankBlock("📩 Izin Terbanyak", topIzin, "Izin")}
          ${miniRankBlock("🤒 Sakit Terbanyak", topSakit, "Sakit")}
        </div>
      </div>
    </div>
  `;
}

async function renderDashboardSiswa(root) {
  document.getElementById("dashSub").textContent = "Rekap kehadiranmu sepanjang semester.";
  const { data, error } = await db
    .from("attendance")
    .select("tanggal, status, keterangan")
    .eq("siswa_id", SESSION.id)
    .order("tanggal", { ascending: false });
  if (error) throw error;
  const rows = data || [];

  const count = (status) => rows.filter(r => r.status === status).length;
  const hadir = count("Hadir"), izin = count("Izin"), sakit = count("Sakit"), alfa = count("Alfa");
  const total = rows.length || 1;
  const persenHadir = Math.round((hadir / total) * 100);

  root.innerHTML = `
    <div class="stat-grid">
      ${statCard("Total Hadir", hadir, "ic-ok", "✅")}
      ${statCard("Total Izin", izin, "ic-warn", "📩")}
      ${statCard("Total Sakit", sakit, "ic-sick", "🤒")}
      ${statCard("Total Alfa", alfa, "ic-bad", "🚫")}
    </div>
    <div class="card panel">
      <h3>Persentase Kehadiran</h3>
      <p class="panel-sub">${persenHadir}% dari ${rows.length} hari tercatat</p>
      <div class="bar-track"><div class="bar-fill" style="width:${persenHadir}%"></div></div>
      <p class="panel-sub" style="margin-top:18px;">10 catatan terbaru</p>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Tanggal</th><th>Status</th><th>Keterangan</th></tr></thead>
          <tbody>
            ${rows.slice(0, 10).map(r => `
              <tr>
                <td>${formatTanggalID(r.tanggal)}</td>
                <td>${statusPill(r.status)}</td>
                <td>${r.keterangan ? escapeHtml(r.keterangan) : "-"}</td>
              </tr>`).join("") || `<tr class="empty-row"><td colspan="3">Belum ada data absensi.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function statCard(label, num, iconClass, emoji) {
  return `
    <div class="card stat-card">
      <div class="top"><div class="ic ${iconClass}">${emoji}</div></div>
      <div class="num">${num}</div>
      <div class="label">${label}</div>
    </div>`;
}

function rankList(list, field, max) {
  if (!list.length) return `<p class="panel-sub">Belum ada data.</p>`;
  return list.map((item, i) => `
    <div class="rank-row">
      <div class="rk">${i + 1}</div>
      <div style="flex:1;min-width:0;">
        <div class="nm">${escapeHtml(item.nama)}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${Math.round((item[field] / max) * 100)}%"></div></div>
      </div>
      <div class="ct">${item[field]}</div>
    </div>`).join("");
}

function miniRankBlock(title, list, field) {
  if (!list.length) return `<div><b style="font-size:13px;">${title}</b><p class="panel-sub" style="margin:4px 0 0;">Belum ada data.</p></div>`;
  return `
    <div>
      <b style="font-size:13px;">${title}</b>
      ${list.slice(0, 3).map(item => `
        <div class="rank-row" style="padding:7px 0;">
          <div class="nm">${escapeHtml(item.nama)}</div>
          <div class="ct">${item[field]}</div>
        </div>`).join("")}
    </div>`;
}

function statusPill(status) {
  const map = { Hadir: "pill-hadir", Izin: "pill-izin", Sakit: "pill-sakit", Alfa: "pill-alfa" };
  return `<span class="pill ${map[status] || ""}">${status}</span>`;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[s]));
}
