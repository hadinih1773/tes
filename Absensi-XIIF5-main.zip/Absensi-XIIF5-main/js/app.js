// ============================================================
// APP SHELL - navigasi, sesi, dan util bersama
// ============================================================

const NAV_ITEMS = {
  about:       { label: "About",              icon: "ℹ️", view: "about" },
  dashboard:   { label: "Dashboard",          icon: "📊", view: "dashboard" },
  absensi:     { label: "Absensi",            icon: "📝", view: "absensi" },
  laporan:     { label: "Laporan Absensi",    icon: "📑", view: "laporan" },
  keterangan:  { label: "Keterangan",         icon: "🗒️", view: "keterangan" },
  pengumuman:  { label: "Pengumuman",         icon: "📢", view: "pengumuman" },
  chat:        { label: "Chat Wali Murid",    icon: "👨‍👩‍👧", view: "chat" },
  chatsiswa:   { label: "Chat Siswa",         icon: "🎓", view: "chatsiswa" },
  social:      { label: "Social Media",       icon: "🌐", view: "social" },
  admin:       { label: "Kelola Akun",        icon: "👤", view: "admin" },
  panel:       { label: "Admin Panel",        icon: "🛠️", view: "panel" },
};

// Urutan menu dirapikan per peran: About -> Dashboard -> Absensi -> Laporan Absensi
// -> Keterangan -> Pengumuman -> Chat -> Social -> (khusus admin) Kelola Akun & Admin Panel
const ROLE_MENUS = {
  siswa:    ["about", "dashboard", "absensi", "pengumuman", "chatsiswa", "social"],
  walas:    ["about", "dashboard", "laporan", "keterangan", "pengumuman", "chat", "social"],
  orangtua: ["about", "dashboard", "laporan", "keterangan", "pengumuman", "chat", "social"],
  admin:    ["about", "dashboard", "absensi", "laporan", "keterangan", "pengumuman", "chat", "chatsiswa", "social", "admin", "panel"],
};

const ROLE_LABELS = { walas: "Wali Kelas", siswa: "Siswa", orangtua: "Orang Tua", admin: "Admin" };

// ---------- Sesi ----------
const SESSION = (() => {
  const raw = localStorage.getItem("absensi_session");
  if (!raw) { window.location.href = "index.html"; return null; }
  try { return JSON.parse(raw); } catch { window.location.href = "index.html"; return null; }
})();

function logout() {
  localStorage.removeItem("absensi_session");
  window.location.href = "index.html";
}

// ---------- Toast ----------
function toast(msg, type = "") {
  const root = document.getElementById("toastRoot");
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

// ---------- Init shell ----------
function initShell() {
  document.getElementById("userAvatar").textContent = SESSION.nama.charAt(0).toUpperCase();
  document.getElementById("userName").textContent = SESSION.nama;
  document.getElementById("userRole").textContent = ROLE_LABELS[SESSION.role];

  const today = new Date();
  document.getElementById("topbarDate").textContent = today.toLocaleDateString("id-ID", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });

  buildNav();
  document.getElementById("logoutBtn").addEventListener("click", logout);

  document.getElementById("menuToggle").addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("open");
  });

  initThemeToggle();

  const menu = ROLE_MENUS[SESSION.role] || [];
  goToView(menu[0] || "about");
}

// ---------- Dark / Light Mode ----------
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("absensi_theme", theme);
  const btn = document.getElementById("themeToggle");
  if (btn) btn.textContent = theme === "dark" ? "🌙" : "☀️";
}

function initThemeToggle() {
  const saved = localStorage.getItem("absensi_theme") || "light";
  applyTheme(saved);
  const btn = document.getElementById("themeToggle");
  if (!btn) return;
  btn.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
    applyTheme(current === "dark" ? "light" : "dark");
  });
}

function buildNav() {
  const menu = ROLE_MENUS[SESSION.role] || [];
  const nav = document.getElementById("navMenu");
  nav.innerHTML = menu.map(key => {
    const item = NAV_ITEMS[key];
    return `<a href="#" class="navlink" data-view="${item.view}"><span class="ic">${item.icon}</span>${item.label}</a>`;
  }).join("");

  nav.querySelectorAll(".navlink").forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      goToView(link.dataset.view);
      document.getElementById("sidebar").classList.remove("open");
    });
  });
}

function goToView(view) {
  document.querySelectorAll(".view-block").forEach(b => b.classList.toggle("hidden", b.dataset.view !== view));
  document.querySelectorAll(".navlink").forEach(l => l.classList.toggle("active", l.dataset.view === view));
  document.getElementById("topbarTitle").textContent = NAV_ITEMS[view] ? NAV_ITEMS[view].label : "";

  if (view === "dashboard" && window.renderDashboard) renderDashboard();
  if (view === "absensi" && window.renderAbsensi) renderAbsensi();
  if (view === "laporan" && window.renderLaporan) renderLaporan();
  if (view === "keterangan" && window.renderKeterangan) renderKeterangan();
  if (view === "admin" && window.renderAdmin) renderAdmin();
  if (view === "pengumuman" && window.renderPengumuman) renderPengumuman();
  if (view === "chat" && window.renderChat) renderChat();
  if (view === "chatsiswa" && window.renderChatSiswa) renderChatSiswa();
  if (view === "panel" && window.renderAdminPanel) renderAdminPanel();
}

// ---------- Upload gambar (Supabase Storage) ----------
// Dipakai bersama oleh Absensi, Keterangan, dan Pengumuman.
// Pastikan bucket "lampiran" (public) sudah dibuat - lihat supabase/schema.sql
// atau supabase/update_v3_migration.sql untuk database yang sudah ada.
const LAMPIRAN_BUCKET = "lampiran";
const MAX_LAMPIRAN_MB = 5;

async function uploadLampiran(file, folder) {
  if (!file) return null;
  if (file.size > MAX_LAMPIRAN_MB * 1024 * 1024) {
    throw new Error(`Ukuran gambar maksimal ${MAX_LAMPIRAN_MB}MB.`);
  }
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;

  const { error } = await db.storage.from(LAMPIRAN_BUCKET).upload(path, file, {
    upsert: false,
    contentType: file.type || undefined
  });
  if (error) throw error;

  const { data } = db.storage.from(LAMPIRAN_BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

function lampiranThumb(url, alt = "Lampiran") {
  if (!url) return "";
  return `<a href="${url}" target="_blank" rel="noopener" class="lampiran-thumb-link"><img src="${url}" alt="${escapeHtml(alt)}" class="lampiran-thumb"></a>`;
}

// ---------- Helper tanggal ----------
const HARI_ID = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
function formatTanggalID(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
}
function namaHari(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  return HARI_ID[d.getDay()];
}
function todayStr() {
  const d = new Date();
  const off = d.getTimezoneOffset() * 60000;
  return new Date(d - off).toISOString().slice(0, 10);
}

initShell();
