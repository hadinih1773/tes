// ============================================================
// ABSENSI - Check-in harian untuk siswa
// ============================================================

let absensiSelectedFile = null;

async function renderAbsensi() {
  const root = document.getElementById("absensiRoot");
  root.innerHTML = `<div class="skeleton" style="height:260px;max-width:520px;margin:0 auto;"></div>`;

  const today = todayStr();
  const { data, error } = await db
    .from("attendance")
    .select("*")
    .eq("siswa_id", SESSION.id)
    .eq("tanggal", today)
    .maybeSingle();

  if (error) {
    root.innerHTML = `<div class="card" style="padding:20px;color:var(--bad);">Gagal memuat data absensi.</div>`;
    return;
  }

  drawAbsensi(root, data);
}

function drawAbsensi(root, existing) {
  const today = todayStr();
  const status = existing ? existing.status : null;
  absensiSelectedFile = null;

  root.innerHTML = `
    <div class="card checkin-card">
      <div class="today">${namaHari(today)}, ${formatTanggalID(today)}</div>
      <h2>Halo, ${escapeHtml(SESSION.nama)} 👋</h2>

      ${status ? `<div class="checkin-status ${statusPillClass(status)}">${statusEmoji(status)} Kamu tercatat: ${status}</div>` : ""}

      <div class="checkin-options">
        <button type="button" class="opt-hadir ${status === "Hadir" ? "active" : ""}" data-status="Hadir"><span class="em">✅</span>Hadir</button>
        <button type="button" class="opt-izin ${status === "Izin" ? "active" : ""}" data-status="Izin"><span class="em">📩</span>Izin</button>
        <button type="button" class="opt-sakit ${status === "Sakit" ? "active" : ""}" data-status="Sakit"><span class="em">🤒</span>Sakit</button>
        <button type="button" class="opt-alfa ${status === "Alfa" ? "active" : ""}" data-status="Alfa"><span class="em">🚫</span>Alfa</button>
      </div>

      <div class="field" id="ketField" style="display:none; text-align:left;">
        <label>Keterangan (opsional)</label>
        <input type="text" id="ketInput" placeholder="Contoh: demam sejak semalam" value="${existing?.keterangan ? escapeHtml(existing.keterangan) : ""}">
      </div>

      <div class="field" id="fotoField" style="display:none; text-align:left;">
        <label>Foto Bukti Izin/Sakit (opsional)</label>
        <input type="file" id="fotoInput" accept="image/*">
        ${existing?.foto_url ? `<div class="lampiran-preview">${lampiranThumb(existing.foto_url, "Foto bukti")}<span class="field-hint">Foto tersimpan. Pilih file baru untuk mengganti.</span></div>` : `<div id="fotoPreview" class="lampiran-preview hidden"></div>`}
      </div>

      <button class="btn btn-primary" id="btnSimpanAbsen" style="margin-top:6px;">${status ? "Perbarui Absensi" : "Simpan Absensi"}</button>
      <p style="font-size:12.5px;color:var(--ink-400);margin-top:14px;">Kamu bisa memperbarui status absensi hari ini kapan saja sebelum pergantian hari.</p>
    </div>
  `;

  let selected = status;
  const ketField = document.getElementById("ketField");
  const ketInput = document.getElementById("ketInput");
  const fotoField = document.getElementById("fotoField");
  const fotoInput = document.getElementById("fotoInput");
  toggleFields(selected);

  function toggleFields(s) {
    const show = (s === "Izin" || s === "Sakit");
    ketField.style.display = show ? "block" : "none";
    fotoField.style.display = show ? "block" : "none";
  }

  fotoInput.addEventListener("change", () => {
    absensiSelectedFile = fotoInput.files[0] || null;
    const preview = document.getElementById("fotoPreview");
    if (!preview) return;
    if (absensiSelectedFile) {
      preview.innerHTML = `<img src="${URL.createObjectURL(absensiSelectedFile)}" class="lampiran-thumb">`;
      preview.classList.remove("hidden");
    } else {
      preview.innerHTML = "";
      preview.classList.add("hidden");
    }
  });

  root.querySelectorAll(".checkin-options button").forEach(btn => {
    btn.addEventListener("click", () => {
      selected = btn.dataset.status;
      root.querySelectorAll(".checkin-options button").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      toggleFields(selected);
    });
  });

  document.getElementById("btnSimpanAbsen").addEventListener("click", async () => {
    if (!selected) { toast("Pilih status kehadiran terlebih dahulu.", "err"); return; }
    const saveBtn = document.getElementById("btnSimpanAbsen");
    saveBtn.disabled = true;
    saveBtn.textContent = "Menyimpan...";

    try {
      let foto_url = existing?.foto_url || null;
      if (absensiSelectedFile) {
        foto_url = await uploadLampiran(absensiSelectedFile, `absensi/${SESSION.id}`);
      }
      if (selected !== "Izin" && selected !== "Sakit") foto_url = null;

      const { error } = await db.from("attendance").upsert({
        siswa_id: SESSION.id,
        tanggal: today,
        status: selected,
        keterangan: ketInput.value.trim() || null,
        foto_url,
        created_by: "siswa"
      }, { onConflict: "siswa_id,tanggal" });

      if (error) throw error;

      toast("Absensi berhasil disimpan!", "ok");
      renderAbsensi();
    } catch (err) {
      console.error(err);
      toast(err.message || "Gagal menyimpan absensi.", "err");
      saveBtn.disabled = false;
      saveBtn.textContent = status ? "Perbarui Absensi" : "Simpan Absensi";
    }
  });
}

function statusEmoji(s) { return { Hadir: "✅", Izin: "📩", Sakit: "🤒", Alfa: "🚫" }[s] || ""; }
function statusPillClass(s) { return { Hadir: "pill-hadir", Izin: "pill-izin", Sakit: "pill-sakit", Alfa: "pill-alfa" }[s] || ""; }
