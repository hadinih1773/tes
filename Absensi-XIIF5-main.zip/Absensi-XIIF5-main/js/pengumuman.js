// ============================================================
// PENGUMUMAN - admin bisa memposting (teks + foto opsional),
// wali kelas, siswa, dan orang tua hanya bisa membaca (read only).
// ============================================================

let pengumumanChannel = null;
let pengumumanLoaded = false;
let pengumumanSelectedFile = null;

async function renderPengumuman() {
  const root = document.getElementById("pengumumanRoot");
  root.innerHTML = `<div class="skeleton" style="height:220px;"></div>`;

  const canPost = SESSION.role === "admin" || SESSION.role === "walas";

  root.innerHTML = `
    ${canPost ? `
    <div class="card" style="padding:18px; margin-bottom:16px;">
      <h3 style="margin:0 0 4px;">Buat Pengumuman</h3>
      <p class="panel-sub">Pengumuman ini akan tampil untuk wali kelas, siswa, dan orang tua (read only).</p>
      <form id="pengumumanForm">
        <div class="field">
          <label>Isi Pengumuman</label>
          <textarea id="pengumumanInput" rows="3" placeholder="Tulis pengumuman di sini..." required style="width:100%; padding:12px 14px; border-radius:9px; border:1.5px solid var(--border); font-size:14.5px; font-family:inherit; resize:vertical;"></textarea>
        </div>
        <div class="field">
          <label>Foto (opsional)</label>
          <input type="file" id="pengumumanFile" accept="image/*">
          <div id="pengumumanPreview" class="lampiran-preview hidden"></div>
        </div>
        <button type="submit" class="btn btn-primary" id="pengumumanSendBtn">Posting Pengumuman</button>
      </form>
    </div>` : ""}
    <div class="card" style="padding:18px;">
      <div id="pengumumanList" class="announce-list"><div class="chat-empty">Memuat pengumuman...</div></div>
    </div>
  `;

  if (canPost) bindPengumumanForm();

  await loadPengumuman();
  if (!pengumumanLoaded) {
    pengumumanLoaded = true;
    subscribePengumuman();
  }
}

function bindPengumumanForm() {
  const form = document.getElementById("pengumumanForm");
  const fileInput = document.getElementById("pengumumanFile");
  const preview = document.getElementById("pengumumanPreview");

  pengumumanSelectedFile = null;

  fileInput.addEventListener("change", () => {
    pengumumanSelectedFile = fileInput.files[0] || null;
    if (pengumumanSelectedFile) {
      preview.innerHTML = `<img src="${URL.createObjectURL(pengumumanSelectedFile)}" class="lampiran-thumb">`;
      preview.classList.remove("hidden");
    } else {
      preview.innerHTML = "";
      preview.classList.add("hidden");
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = document.getElementById("pengumumanInput");
    const isi = input.value.trim();
    if (!isi) return;

    const btn = document.getElementById("pengumumanSendBtn");
    btn.disabled = true;
    btn.textContent = "Memposting...";

    try {
      let image_url = null;
      if (pengumumanSelectedFile) {
        image_url = await uploadLampiran(pengumumanSelectedFile, "pengumuman");
      }

      const { error } = await db.from("announcements").insert({
        sender_id: SESSION.id,
        sender_nama: SESSION.nama,
        sender_role: SESSION.role,
        isi,
        image_url
      });
      if (error) throw error;

      input.value = "";
      fileInput.value = "";
      pengumumanSelectedFile = null;
      document.getElementById("pengumumanPreview").innerHTML = "";
      document.getElementById("pengumumanPreview").classList.add("hidden");
      toast("Pengumuman berhasil diposting.", "ok");
    } catch (err) {
      console.error(err);
      toast(err.message || "Gagal memposting pengumuman.", "err");
    } finally {
      btn.disabled = false;
      btn.textContent = "Posting Pengumuman";
    }
  });
}

async function loadPengumuman() {
  const list = document.getElementById("pengumumanList");
  const { data, error } = await db
    .from("announcements")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(50);

  if (error) {
    list.innerHTML = `<div class="chat-empty">Gagal memuat pengumuman. Pastikan tabel <code>announcements</code> sudah dibuat (lihat supabase/update_v3_migration.sql).</div>`;
    return;
  }

  if (!data || !data.length) {
    list.innerHTML = `<div class="chat-empty">Belum ada pengumuman.</div>`;
    return;
  }

  list.innerHTML = data.map(announceCardHtml).join("");
  bindAnnounceDeleteButtons(list);
}

function subscribePengumuman() {
  if (pengumumanChannel) return;
  pengumumanChannel = db
    .channel("pengumuman-xii-f5")
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "announcements" }, (payload) => {
      const list = document.getElementById("pengumumanList");
      if (!list) return;
      const emptyEl = list.querySelector(".chat-empty");
      if (emptyEl) emptyEl.remove();
      if (document.getElementById("ann-" + payload.new.id)) return;
      list.insertAdjacentHTML("afterbegin", announceCardHtml(payload.new));
      bindAnnounceDeleteButtons(list);
    })
    .on("postgres_changes", { event: "DELETE", schema: "public", table: "announcements" }, (payload) => {
      const el = document.getElementById("ann-" + payload.old.id);
      if (el) el.remove();
    })
    .subscribe();
}

function announceCardHtml(a) {
  // Hapus pengumuman: hanya wali kelas (guru) dan admin
  const canDelete = SESSION.role === "walas" || SESSION.role === "admin";
  return `
    <div class="announce-card" id="ann-${a.id}">
      <div class="announce-head">
        <span class="chat-name">${escapeHtml(a.sender_nama)}</span>
        <span class="chat-role-tag role-${a.sender_role}">${CHAT_ROLE_LABEL[a.sender_role] || a.sender_role}</span>
        <span class="announce-time">${formatChatTime(a.created_at)}</span>
        ${canDelete ? `<button type="button" class="announce-del-btn" data-id="${a.id}" data-img="${a.image_url ? escapeHtml(a.image_url) : ""}" title="Hapus pengumuman">🗑️</button>` : ""}
      </div>
      <div class="announce-text">${escapeHtml(a.isi)}</div>
      ${a.image_url ? lampiranThumb(a.image_url, "Foto pengumuman") : ""}
    </div>`;
}

function bindAnnounceDeleteButtons(scope) {
  scope.querySelectorAll(".announce-del-btn").forEach(btn => {
    btn.addEventListener("click", () => confirmDeleteAnnouncement(btn.dataset.id, btn.dataset.img, btn.closest(".announce-card")));
  });
}

function confirmDeleteAnnouncement(id, imgUrl, cardEl) {
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="delAnnOverlay">
      <div class="modal-box">
        <h3>Hapus Pengumuman?</h3>
        <p style="color:var(--ink-600);font-size:14px;">Pengumuman ini beserta foto (jika ada) akan dihapus permanen.</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="delAnnCancel">Batal</button>
          <button class="btn btn-danger" id="delAnnConfirm">Hapus</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById("delAnnCancel").addEventListener("click", closeModal);
  document.getElementById("delAnnOverlay").addEventListener("click", (e) => { if (e.target.id === "delAnnOverlay") closeModal(); });
  document.getElementById("delAnnConfirm").addEventListener("click", async () => {
    const { error } = await db.from("announcements").delete().eq("id", id);
    closeModal();
    if (error) { toast("Gagal menghapus pengumuman.", "err"); return; }
    if (imgUrl) {
      const path = lampiranPathFromUrl(imgUrl);
      if (path) db.storage.from(LAMPIRAN_BUCKET).remove([path]).catch(() => {});
    }
    if (cardEl) cardEl.remove();
    toast("Pengumuman dihapus.", "ok");
  });
}

function lampiranPathFromUrl(url) {
  const marker = `/object/public/${LAMPIRAN_BUCKET}/`;
  const idx = url.indexOf(marker);
  if (idx === -1) return null;
  return url.slice(idx + marker.length);
}
