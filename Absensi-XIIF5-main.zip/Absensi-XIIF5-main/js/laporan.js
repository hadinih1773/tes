// ============================================================
// LAPORAN ABSENSI - tabel rekap + unduh PDF
// ============================================================

let laporanCache = [];
let laporanSiswaFilled = false;

async function renderLaporan() {
  // Tombol unduh PDF & CSV hanya untuk wali kelas & admin (guru)
  const canDownload = ["walas", "admin"].includes(SESSION.role);
  document.getElementById("btnDownloadPdf").classList.toggle("hidden", !canDownload);
  document.getElementById("btnDownloadCsv").classList.toggle("hidden", !canDownload);

  if (!laporanSiswaFilled) await fillSiswaFilter();
  bindLaporanEvents();
  await loadLaporan();
}

async function fillSiswaFilter() {
  const { data } = await db.from("users").select("id, nama, nomor_absen").eq("role", "siswa").order("nomor_absen");
  const sel = document.getElementById("filterSiswa");
  (data || []).forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.nama;
    sel.appendChild(opt);
  });
  laporanSiswaFilled = true;
}

function bindLaporanEvents() {
  if (bindLaporanEvents._done) return;
  bindLaporanEvents._done = true;

  ["filterFrom", "filterTo", "filterSiswa", "filterStatus"].forEach(id => {
    document.getElementById(id).addEventListener("change", loadLaporan);
  });
  document.getElementById("btnFilterReset").addEventListener("click", () => {
    document.getElementById("filterFrom").value = "";
    document.getElementById("filterTo").value = "";
    document.getElementById("filterSiswa").value = "";
    document.getElementById("filterStatus").value = "";
    loadLaporan();
  });
  document.getElementById("btnDownloadPdf").addEventListener("click", downloadLaporanPdf);
  document.getElementById("btnDownloadCsv").addEventListener("click", downloadLaporanCsv);
}

function downloadLaporanCsv() {
  if (!laporanCache.length) { toast("Tidak ada data untuk diunduh.", "err"); return; }

  const header = ["No", "Nama", "Hari", "Tanggal", "Status", "Keterangan"];
  const rows = laporanCache.map((r, i) => [
    i + 1,
    r.users?.nama || "-",
    namaHari(r.tanggal),
    formatTanggalID(r.tanggal),
    r.status,
    (r.keterangan || "-").replace(/[\r\n]+/g, " ")
  ]);

  const csvEscape = (v) => `"${String(v).replace(/"/g, '""')}"`;
  const csv = [header, ...rows].map(row => row.map(csvEscape).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `laporan-absensi-xii-f5-${todayStr()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

async function loadLaporan() {
  const tbody = document.querySelector("#laporanTable tbody");
  tbody.innerHTML = `<tr class="empty-row"><td colspan="6">Memuat data...</td></tr>`;

  const from = document.getElementById("filterFrom").value;
  const to = document.getElementById("filterTo").value;
  const siswaId = document.getElementById("filterSiswa").value;
  const status = document.getElementById("filterStatus").value;

  let q = db.from("attendance").select("id, tanggal, status, keterangan, users:siswa_id(nama, nomor_absen)").order("tanggal", { ascending: false });
  if (from) q = q.gte("tanggal", from);
  if (to) q = q.lte("tanggal", to);
  if (siswaId) q = q.eq("siswa_id", siswaId);
  if (status) q = q.eq("status", status);

  const { data, error } = await q;
  if (error) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="6">Gagal memuat data.</td></tr>`;
    return;
  }

  laporanCache = data || [];
  if (!laporanCache.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="6">Tidak ada data untuk filter ini.</td></tr>`;
    return;
  }

  tbody.innerHTML = laporanCache.map((r, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${escapeHtml(r.users?.nama || "-")}</td>
      <td>${namaHari(r.tanggal)}</td>
      <td>${formatTanggalID(r.tanggal)}</td>
      <td>${statusPill(r.status)}</td>
      <td>${r.keterangan ? escapeHtml(r.keterangan) : "-"}</td>
    </tr>`).join("");
}

function downloadLaporanPdf() {
  if (!laporanCache.length) { toast("Tidak ada data untuk diunduh.", "err"); return; }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  doc.setFontSize(14);
  doc.text("Laporan Absensi - Kelas XII F 5", 14, 16);
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Diunduh: ${new Date().toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" })}`, 14, 22);

  const rows = laporanCache.map((r, i) => [
    i + 1,
    r.users?.nama || "-",
    namaHari(r.tanggal),
    formatTanggalID(r.tanggal),
    r.status,
    r.keterangan || "-"
  ]);

  doc.autoTable({
    head: [["No", "Nama", "Hari", "Tanggal", "Status", "Keterangan"]],
    body: rows,
    startY: 28,
    styles: { fontSize: 9 },
    headStyles: { fillColor: [29, 78, 216] },
  });

  doc.save(`laporan-absensi-xii-f5-${todayStr()}.pdf`);
}
