// ============================================================
// Inisialisasi Supabase Client (memakai supabase-js versi CDN)
// ============================================================
const { createClient } = supabase;
const db = createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
