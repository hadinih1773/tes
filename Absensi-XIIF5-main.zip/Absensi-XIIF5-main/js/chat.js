// ============================================================
// CHAT - live chat, tersimpan permanen di Supabase
// Mendukung 2 kanal:
//   - "kelas" -> Chat Wali Murid (khusus admin, wali kelas, orang tua - siswa TIDAK bisa lihat)
//   - "siswa" -> Chat Siswa (siswa, admin ikut memantau/membalas)
// Fitur: kirim teks, kirim media (gambar/video/file), hapus pesan
// (tahan pesan -> menu Salin / Hapus), realtime.
// ============================================================

const CHAT_ROLE_LABEL = { admin: "Admin", walas: "Wali Kelas", siswa: "Siswa", orangtua: "Orang Tua" };
const CHAT_MEDIA_MAX_MB = 20;

function createChatController(channel, ids) {
  let channelSub = null;
  let loaded = false;
  let oldestLoadedAt = null;
  let bound = false;
  let selectedFile = null;

  const els = () => ({
    list: document.getElementById(ids.list),
    form: document.getElementById(ids.form),
    input: document.getElementById(ids.input),
    sendBtn: document.getElementById(ids.sendBtn),
    fileInput: document.getElementById(ids.fileInput),
    attachBtn: document.getElementById(ids.attachBtn),
    preview: document.getElementById(ids.preview)
  });

  function canAccess() {
    if (channel === "kelas") {
      // Chat Wali Murid: hanya admin, wali kelas, orang tua
      return ["admin", "walas", "orangtua"].includes(SESSION.role);
    }
    return true;
  }

  function canDelete(m) {
    if (m.sender_id === SESSION.id) return true;
    if (SESSION.role === "admin") return true;
    if (channel === "kelas" && SESSION.role === "walas") return true;
    return false;
  }

  function bindEvents() {
    if (bound) return;
    bound = true;
    const { form, input, list, fileInput, attachBtn, preview } = els();

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      await sendMessage();
    });

    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        form.requestSubmit();
      }
    });

    list.addEventListener("scroll", () => {
      if (list.scrollTop < 40) loadOlderMessages();
    });

    if (attachBtn && fileInput) {
      attachBtn.addEventListener("click", () => fileInput.click());
      fileInput.addEventListener("change", () => {
        const f = fileInput.files[0];
        if (!f) return;
        if (f.size > CHAT_MEDIA_MAX_MB * 1024 * 1024) {
          toast(`Ukuran media maksimal ${CHAT_MEDIA_MAX_MB}MB.`, "err");
          fileInput.value = "";
          return;
        }
        selectedFile = f;
        renderPreview();
      });
    }

    // Menu tahan-pesan (long press di HP, klik kanan / klik di desktop)
    list.addEventListener("contextmenu", (e) => {
      const bubble = e.target.closest(".chat-msg");
      if (!bubble) return;
      e.preventDefault();
      openMsgMenu(bubble, e.clientX, e.clientY);
    });

    let pressTimer = null;
    list.addEventListener("touchstart", (e) => {
      const bubble = e.target.closest(".chat-msg");
      if (!bubble) return;
      const touch = e.touches[0];
      pressTimer = setTimeout(() => {
        openMsgMenu(bubble, touch.clientX, touch.clientY);
      }, 480);
    }, { passive: true });
    ["touchend", "touchmove", "touchcancel"].forEach(evt => {
      list.addEventListener(evt, () => { if (pressTimer) clearTimeout(pressTimer); }, { passive: true });
    });
  }

  function renderPreview() {
    const { preview } = els();
    if (!preview) return;
    if (!selectedFile) { preview.innerHTML = ""; preview.classList.add("hidden"); return; }
    const isImg = selectedFile.type.startsWith("image/");
    const isVid = selectedFile.type.startsWith("video/");
    preview.classList.remove("hidden");
    if (isImg) {
      preview.innerHTML = `<img src="${URL.createObjectURL(selectedFile)}" class="lampiran-thumb"><span class="media-preview-name">${escapeHtml(selectedFile.name)}</span><button type="button" class="media-preview-remove" title="Batal">✕</button>`;
    } else if (isVid) {
      preview.innerHTML = `<video src="${URL.createObjectURL(selectedFile)}" class="lampiran-thumb" muted></video><span class="media-preview-name">${escapeHtml(selectedFile.name)}</span><button type="button" class="media-preview-remove" title="Batal">✕</button>`;
    } else {
      preview.innerHTML = `<span class="media-file-chip">📎 ${escapeHtml(selectedFile.name)}</span><button type="button" class="media-preview-remove" title="Batal">✕</button>`;
    }
    preview.querySelector(".media-preview-remove").addEventListener("click", () => {
      selectedFile = null;
      const { fileInput } = els();
      if (fileInput) fileInput.value = "";
      renderPreview();
    });
  }

  function openMsgMenu(bubbleEl, x, y) {
    closeMsgMenu();
    const msgId = bubbleEl.dataset.msgId;
    const allowDelete = bubbleEl.dataset.canDelete === "1";
    const textEl = bubbleEl.querySelector(".chat-text");
    const rawText = textEl ? textEl.textContent : "";

    const menu = document.createElement("div");
    menu.className = "msg-context-menu";
    menu.id = "msgContextMenu";
    menu.innerHTML = `
      ${rawText ? `<button type="button" data-act="copy">📋 Salin</button>` : ""}
      ${allowDelete ? `<button type="button" data-act="del" class="danger">🗑️ Hapus</button>` : ""}
    `;
    document.body.appendChild(menu);

    const menuW = 160;
    let left = Math.min(x, window.innerWidth - menuW - 12);
    let top = Math.min(y, window.innerHeight - 100);
    menu.style.left = Math.max(8, left) + "px";
    menu.style.top = Math.max(8, top) + "px";

    menu.querySelector('[data-act="copy"]')?.addEventListener("click", () => {
      navigator.clipboard?.writeText(rawText).then(() => toast("Pesan disalin.", "ok")).catch(() => toast("Gagal menyalin.", "err"));
      closeMsgMenu();
    });
    menu.querySelector('[data-act="del"]')?.addEventListener("click", () => {
      closeMsgMenu();
      deleteMessage(msgId, bubbleEl);
    });

    // Delay sedikit supaya "ghost click/tap" yang mengakhiri long-press
    // tidak langsung menutup menu yang baru saja terbuka.
    // Catatan: sengaja HANYA pakai event "click" (bukan "touchstart") supaya
    // tap di tombol Salin/Hapus sempat diproses dulu sebelum menu ditutup.
    setTimeout(() => {
      document.addEventListener("click", closeMsgMenu, { once: true });
    }, 350);
  }

  function closeMsgMenu() {
    document.getElementById("msgContextMenu")?.remove();
  }

  async function deleteMessage(id, bubbleEl) {
    const { data: row } = await db.from("messages").select("media_path").eq("id", id).single();
    const { error } = await db.from("messages").delete().eq("id", id);
    if (error) { toast("Gagal menghapus pesan.", "err"); return; }
    if (row && row.media_path) {
      db.storage.from(LAMPIRAN_BUCKET).remove([row.media_path]).catch(() => {});
    }
    bubbleEl.remove();
    toast("Pesan dihapus.", "ok");
  }

  async function loadInitialMessages() {
    const { list } = els();
    list.innerHTML = `<div class="chat-empty">Memuat percakapan...</div>`;

    const { data, error } = await db
      .from("messages")
      .select("*")
      .eq("channel", channel)
      .order("created_at", { ascending: false })
      .limit(40);

    if (error) {
      list.innerHTML = `<div class="chat-empty">Gagal memuat chat. Pastikan migrasi <code>supabase/update_v4_migration.sql</code> sudah dijalankan.</div>`;
      return;
    }

    const msgs = (data || []).slice().reverse();
    oldestLoadedAt = msgs.length ? msgs[0].created_at : null;

    list.innerHTML = "";
    if (!msgs.length) {
      list.innerHTML = `<div class="chat-empty">Belum ada pesan. Mulai percakapan pertama di sini 👋</div>`;
      return;
    }
    msgs.forEach(m => appendMessageEl(m, false));
  }

  async function loadOlderMessages() {
    if (!oldestLoadedAt || loadOlderMessages._busy) return;
    loadOlderMessages._busy = true;

    const { list } = els();
    const prevHeight = list.scrollHeight;

    const { data, error } = await db
      .from("messages")
      .select("*")
      .eq("channel", channel)
      .lt("created_at", oldestLoadedAt)
      .order("created_at", { ascending: false })
      .limit(30);

    loadOlderMessages._busy = false;
    if (error || !data || !data.length) return;

    const msgs = data.slice().reverse();
    oldestLoadedAt = msgs[0].created_at;

    msgs.forEach(m => appendMessageEl(m, false, true));
    list.scrollTop = list.scrollHeight - prevHeight;
  }

  function subscribe() {
    if (channelSub) return;
    channelSub = db
      .channel("chat-" + channel + "-xii-f5")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (payload) => {
        if (payload.new.channel !== channel) return;
        appendMessageEl(payload.new, true);
      })
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "messages" }, (payload) => {
        const el = document.getElementById(ids.msgPrefix + payload.old.id);
        if (el) el.remove();
      })
      .subscribe();
  }

  async function sendMessage() {
    const { input, sendBtn, fileInput } = els();
    const isi = input.value.trim();
    if (!isi && !selectedFile) return;

    sendBtn.disabled = true;
    const fileToSend = selectedFile;
    input.value = "";
    selectedFile = null;
    renderPreview();
    if (fileInput) fileInput.value = "";

    try {
      let media_url = null, media_path = null, media_type = null, media_name = null;
      if (fileToSend) {
        const up = await uploadLampiranChat(fileToSend, "chat");
        media_url = up.url; media_path = up.path;
        media_type = fileToSend.type.startsWith("image/") ? "image" : fileToSend.type.startsWith("video/") ? "video" : "file";
        media_name = fileToSend.name;
      }

      const { error } = await db.from("messages").insert({
        sender_id: SESSION.id,
        sender_nama: SESSION.nama,
        sender_role: SESSION.role,
        channel,
        isi,
        media_url, media_path, media_type, media_name
      });
      if (error) throw error;
    } catch (err) {
      console.error(err);
      toast(err.message || "Pesan gagal terkirim. Coba lagi.", "err");
      if (!fileToSend) input.value = isi;
    } finally {
      sendBtn.disabled = false;
      input.focus();
    }
  }

  function mediaHtml(m) {
    if (!m.media_url) return "";
    if (m.media_type === "image") {
      return `<a href="${m.media_url}" target="_blank" rel="noopener" class="chat-media-link"><img src="${m.media_url}" class="chat-media-img" alt="media"></a>`;
    }
    if (m.media_type === "video") {
      return `<video src="${m.media_url}" class="chat-media-video" controls></video>`;
    }
    return `<a href="${m.media_url}" target="_blank" rel="noopener" class="chat-media-file">📎 ${escapeHtml(m.media_name || "File")}</a>`;
  }

  function appendMessageEl(m, isLive, prepend = false) {
    const { list } = els();
    const emptyEl = list.querySelector(".chat-empty");
    if (emptyEl) emptyEl.remove();

    if (!prepend && document.getElementById(ids.msgPrefix + m.id)) return;

    const mine = m.sender_id === SESSION.id;
    const el = document.createElement("div");
    el.className = `chat-msg ${mine ? "mine" : ""}`;
    el.id = ids.msgPrefix + m.id;
    el.dataset.msgId = m.id;
    el.dataset.canDelete = canDelete(m) ? "1" : "0";
    el.innerHTML = `
      <div class="chat-bubble">
        ${!mine ? `<div class="chat-meta"><span class="chat-name">${escapeHtml(m.sender_nama)}</span><span class="chat-role-tag role-${m.sender_role}">${CHAT_ROLE_LABEL[m.sender_role] || m.sender_role}</span></div>` : ""}
        ${mediaHtml(m)}
        ${m.isi ? `<div class="chat-text">${escapeHtml(m.isi)}</div>` : ""}
        <div class="chat-time">${formatChatTime(m.created_at)}</div>
      </div>`;

    if (prepend) {
      list.prepend(el);
    } else {
      list.appendChild(el);
      if (isLive) scrollToBottom();
    }
  }

  function scrollToBottom() {
    const { list } = els();
    requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
  }

  return async function render() {
    const { list } = els();
    if (!canAccess()) {
      list.innerHTML = `<div class="chat-empty">Kamu tidak memiliki akses ke chat ini.</div>`;
      return;
    }
    bindEvents();
    if (!loaded) {
      await loadInitialMessages();
      loaded = true;
      subscribe();
    }
    scrollToBottom();
  };
}

// Upload media chat (gambar/video/file apa saja), mengembalikan url + path
async function uploadLampiranChat(file, folder) {
  if (file.size > CHAT_MEDIA_MAX_MB * 1024 * 1024) {
    throw new Error(`Ukuran media maksimal ${CHAT_MEDIA_MAX_MB}MB.`);
  }
  const ext = (file.name.split(".").pop() || "bin").toLowerCase().replace(/[^a-z0-9]/g, "") || "bin";
  const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;

  const { error } = await db.storage.from(LAMPIRAN_BUCKET).upload(path, file, {
    upsert: false,
    contentType: file.type || undefined
  });
  if (error) throw error;

  const { data } = db.storage.from(LAMPIRAN_BUCKET).getPublicUrl(path);
  return { url: data.publicUrl, path };
}

function formatChatTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const time = d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
  if (sameDay) return time;
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }) + " " + time;
}

// Chat Wali Murid: khusus admin, wali kelas, orang tua (siswa tidak melihat kanal ini)
window.renderChat = createChatController("kelas", {
  list: "chatMessages", form: "chatForm", input: "chatInput", sendBtn: "chatSendBtn", msgPrefix: "msg-kelas-",
  fileInput: "chatFile", attachBtn: "chatAttachBtn", preview: "chatMediaPreview"
});

// Chat Siswa: siswa (+ admin bisa ikut memantau/membalas)
window.renderChatSiswa = createChatController("siswa", {
  list: "chatSiswaMessages", form: "chatSiswaForm", input: "chatSiswaInput", sendBtn: "chatSiswaSendBtn", msgPrefix: "msg-siswa-",
  fileInput: "chatSiswaFile", attachBtn: "chatSiswaAttachBtn", preview: "chatSiswaMediaPreview"
});
