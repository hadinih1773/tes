// ============================================================
// LOGIKA LOGIN
// ============================================================

const roleHints = {
  siswa:   { user: "Nama lengkap kamu, contoh: hadi saputra", pass: "Password: <b>nomor absen kamu</b> (misal 1, 2, 3, dst.)" },
  walas:   { user: "Username wali kelas", pass: "Password wali kelas" },
  orangtua:{ user: "Username: <b>orang tua</b>", pass: "Password: <b>orangtua</b>" },
  admin:   { user: "Username admin", pass: "Password admin" }
};

// ---------- Dark / Light Mode (halaman login) ----------
(function initLoginTheme() {
  const btn = document.getElementById("loginThemeToggle");
  if (!btn) return;
  const apply = (theme) => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("absensi_theme", theme);
    btn.textContent = theme === "dark" ? "🌙" : "☀️";
  };
  apply(localStorage.getItem("absensi_theme") || "light");
  btn.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
    apply(current === "dark" ? "light" : "dark");
  });
})();

let currentRole = "siswa";

document.getElementById("roleTabs").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-role]");
  if (!btn) return;
  document.querySelectorAll("#roleTabs button").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  currentRole = btn.dataset.role;
  document.getElementById("userHint").innerHTML = roleHints[currentRole].user;
  document.getElementById("passHint").innerHTML = roleHints[currentRole].pass;
  hideError();
});

function showError(msg) {
  const el = document.getElementById("loginError");
  el.textContent = msg;
  el.classList.remove("hidden");
}
function hideError() {
  document.getElementById("loginError").classList.add("hidden");
}

// Jika sudah login, langsung lempar ke app.html
(function checkExistingSession() {
  const raw = localStorage.getItem("absensi_session");
  if (raw) window.location.href = "app.html";
})();

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  hideError();

  const usernameRaw = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  const username = usernameRaw.toLowerCase();
  const btn = document.getElementById("loginBtn");

  if (!username || !password) return;

  btn.disabled = true;
  btn.textContent = "Memeriksa...";

  try {
    // Selalu cek dulu ke tabel users (supaya id yang dipakai adalah UUID asli,
    // sehingga admin bisa ikut chat/pengumuman/absensi seperti peran lain).
    // Jalur cadangan admin.username/password di config.js hanya dipakai
    // sebagai fallback JIKA akun admin belum ada di tabel users.
    const { data, error } = await db
      .from("users")
      .select("*")
      .eq("role", currentRole)
      .eq("username", username)
      .maybeSingle();

    if (error) throw error;

    if (data) {
      if (data.password !== password) {
        showError("Password salah. Silakan coba lagi.");
        return;
      }
      saveSession({
        id: data.id,
        username: data.username,
        nama: data.nama,
        role: data.role,
        nomor_absen: data.nomor_absen
      });
      window.location.href = "app.html";
      return;
    }

    // Jalur cadangan untuk admin (hanya jika belum ada baris admin di tabel users)
    if (currentRole === "admin" &&
        username === ADMIN_FALLBACK.username.toLowerCase() &&
        password === ADMIN_FALLBACK.password) {
      showError("Akun admin belum ada di database. Jalankan supabase/schema.sql (atau tambahkan akun admin lewat SQL Editor) agar admin bisa memakai Chat, Pengumuman, dan fitur lain sepenuhnya.");
      return;
    }

    showError("Akun tidak ditemukan. Periksa kembali username dan peran yang dipilih.");

  } catch (err) {
    console.error(err);
    showError("Gagal terhubung ke server. Pastikan konfigurasi Supabase di js/config.js sudah benar.");
  } finally {
    btn.disabled = false;
    btn.textContent = "Masuk";
  }
});

function saveSession(user) {
  localStorage.setItem("absensi_session", JSON.stringify(user));
}

// ============================================================
// CARI NOMOR ABSEN LEWAT NAMA
// ============================================================

let siswaListCache = null;

document.getElementById("btnFindAbsen").addEventListener("click", openFindAbsenModal);

async function openFindAbsenModal() {
  const root = document.getElementById("findAbsenRoot");
  root.innerHTML = `
    <div class="modal-overlay" id="findAbsenOverlay">
      <div class="modal-box">
        <h3>Cari Nomor Absen</h3>
        <p style="color:var(--ink-600);font-size:13.5px;margin-top:-8px;">Ketik nama siswa untuk menemukan nomor absennya.</p>
        <div class="field">
          <label>Nama Siswa</label>
          <input type="text" id="findAbsenInput" placeholder="Contoh: hadi" autocomplete="off" autofocus>
        </div>
        <div id="findAbsenResults" class="find-absen-results"></div>
        <div class="modal-actions">
          <button class="btn btn-ghost" id="findAbsenCancel">Tutup</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById("findAbsenCancel").addEventListener("click", closeFindAbsenModal);
  document.getElementById("findAbsenOverlay").addEventListener("click", (e) => {
    if (e.target.id === "findAbsenOverlay") closeFindAbsenModal();
  });

  const input = document.getElementById("findAbsenInput");
  input.addEventListener("input", () => renderFindAbsenResults(input.value));

  const resultsEl = document.getElementById("findAbsenResults");
  resultsEl.innerHTML = `<div class="find-absen-empty">Memuat data siswa...</div>`;

  if (!siswaListCache) {
    const { data, error } = await db.from("users").select("nama, nomor_absen").eq("role", "siswa").order("nomor_absen");
    if (error) {
      resultsEl.innerHTML = `<div class="find-absen-empty">Gagal memuat data siswa. Periksa koneksi.</div>`;
      return;
    }
    siswaListCache = data || [];
  }

  renderFindAbsenResults("");
}

function renderFindAbsenResults(query) {
  const resultsEl = document.getElementById("findAbsenResults");
  if (!resultsEl || !siswaListCache) return;

  const q = query.trim().toLowerCase();
  const matches = q
    ? siswaListCache.filter(s => s.nama.toLowerCase().includes(q))
    : siswaListCache;

  if (!matches.length) {
    resultsEl.innerHTML = `<div class="find-absen-empty">Nama tidak ditemukan.</div>`;
    return;
  }

  resultsEl.innerHTML = matches.slice(0, 8).map(s => `
    <div class="find-absen-row">
      <span>${escapeHtmlLogin(s.nama)}</span>
      <b>No. ${s.nomor_absen ?? "-"}</b>
    </div>`).join("");
}

function closeFindAbsenModal() {
  document.getElementById("findAbsenRoot").innerHTML = "";
}

function escapeHtmlLogin(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}
