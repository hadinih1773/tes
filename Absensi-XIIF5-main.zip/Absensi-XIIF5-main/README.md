# Absensi Kelas XII F 5

Website absensi digital dengan 4 peran login: **Admin**, **Wali Kelas**, **Siswa**, **Orang Tua**.
Frontend: HTML/CSS/JS murni (tanpa build tool). Backend & database: **Supabase**.

## 1. Struktur folder

```
kelas-xii-f5/
├─ index.html          -> Halaman login
├─ app.html             -> Aplikasi utama (dashboard, absensi, laporan, dst.)
├─ css/style.css        -> Semua styling (tema biru)
├─ js/
│  ├─ config.js         -> Isi URL & Anon Key Supabase kamu di sini
│  ├─ supabase-client.js
│  ├─ auth.js           -> Logika login
│  ├─ app.js             -> Shell aplikasi (sidebar, navigasi, sesi)
│  ├─ dashboard.js
│  ├─ absensi.js
│  ├─ laporan.js
│  ├─ keterangan.js
│  └─ admin.js
├─ supabase/schema.sql  -> Skema database + data akun awal
└─ package.json
```

## 2. Setup Supabase (5 menit)

1. Buat project baru di [supabase.com](https://supabase.com).
2. Buka **SQL Editor** > **New query**, tempel seluruh isi `supabase/schema.sql`, lalu klik **Run**.
   Ini akan membuat tabel `users`, `attendance`, & `messages` (chat), sekaligus mengisi akun awal (wali kelas, orang tua, admin, dan 23 siswa).
   - **Sudah punya database lama?** Jangan jalankan ulang `schema.sql` (akan menghapus data). Cukup jalankan `supabase/chat_migration.sql` untuk menambahkan fitur chat tanpa kehilangan data yang sudah ada.
3. Buka **Project Settings > API**, salin **Project URL** dan **anon public key**.
4. Tempel keduanya ke `js/config.js`:
   ```js
   const SUPABASE_CONFIG = {
     url: "https://xxxxx.supabase.co",
     anonKey: "isi-anon-key-di-sini"
   };
   ```

## 3. Menjalankan secara lokal

Tidak butuh proses build. Cukup buka `index.html` lewat server lokal (jangan double-click file langsung, karena beberapa browser memblokir `fetch` dari `file://`):

```bash
npm install
npm run dev
```

Atau pakai ekstensi **Live Server** di VS Code.

## 4. Deploy

Karena ini situs statis murni, tinggal upload seluruh folder ke **Netlify**, **Vercel**, **Cloudflare Pages**, atau **GitHub Pages** — tidak perlu langkah build apa pun.

## 5. Akun login default

| Peran | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Wali Kelas | `sury` | `walas` |
| Orang Tua | `orang tua` | `orangtua` |
| Siswa | nama lengkap (bebas besar/kecil), contoh `hadi saputra` | nomor absen, contoh `8` |

Password siswa = **nomor absen masing-masing** (lihat kolom `nomor_absen` di tabel `users`). Contoh: Anayah nomor absen 1 → password `1`; Hadi Saputra nomor absen 8 → password `8`.

## 6. Fitur yang tersedia

- **Login multi-peran** dengan tab pilihan peran di halaman depan.
- **Dashboard**
  - Wali Kelas / Orang Tua / Admin: kartu ringkasan hadir/izin/sakit/alfa hari ini + ranking siswa dengan kehadiran terbanyak, alfa terbanyak, izin terbanyak, sakit terbanyak.
  - Siswa: rekap kehadiran pribadi + 10 catatan terbaru.
- **Absensi** (siswa): check-in harian dengan 4 pilihan status + kolom keterangan opsional, bisa diperbarui dalam hari yang sama.
- **Laporan Absensi**: tabel dengan filter tanggal, siswa, dan status; tombol **Unduh PDF** untuk wali kelas & admin (memakai jsPDF + autoTable).
- **Keterangan**:
  - Wali Kelas / Admin: mengelola & mengedit status + keterangan untuk setiap catatan izin/sakit/alfa.
  - Orang Tua: mengajukan izin/sakit untuk anak + melihat riwayat.
- **Kelola Akun** (Admin): tambah, ubah, hapus akun di semua peran.
- **Admin Panel** (Admin): reset seluruh absensi sekaligus (dengan konfirmasi ketik "RESET"), atau hapus absensi tertentu lewat filter tanggal/siswa/status + pilih baris.
- **Chat Kelas** (semua peran): obrolan langsung antar admin, wali kelas, siswa, dan orang tua. Pesan tersimpan permanen di tabel `messages` dan muncul real-time lewat Supabase Realtime tanpa perlu refresh halaman.
- **Cari Nomor Absen** (halaman login): siswa yang lupa nomor absennya bisa mencarinya lewat nama tanpa perlu login.
- **Social Media**: kanal komunikasi kelas.
- Desain responsif (mobile-friendly), tema biru dengan sidebar navigasi dinamis sesuai peran.

## 7. Catatan Keamanan (penting dibaca)

Sistem login di sini memakai tabel `users` kustom dengan password **teks biasa**, supaya sederhana dan sesuai kebutuhan (username = nama siswa, password = nomor absen siswa). Ini **cukup untuk kebutuhan sekolah/tugas**, tapi bukan standar keamanan produksi:

- Password tidak di-hash. Untuk penggunaan jangka panjang, sebaiknya pindah ke **Supabase Auth** dan hash password (mis. bcrypt) lewat **Edge Function**.
- Row Level Security (RLS) di `schema.sql` dibuka lebar (`using (true)`) supaya anon key browser bisa baca/tulis. Ini berarti siapa pun yang tahu URL & anon key project bisa mengakses API Supabase secara langsung (di luar tampilan web). Jangan gunakan untuk data yang sangat sensitif.
- Anon key **boleh** terlihat di kode frontend (memang begitu cara kerja Supabase), tapi jangan pernah menaruh **service_role key** di frontend.

## 8. Ide pengembangan lanjutan

- Notifikasi WhatsApp/email otomatis ke orang tua saat anak tercatat Alfa.
- Rekap absensi bulanan dalam bentuk grafik (chart.js).
- Export laporan ke Excel selain PDF.
- Riwayat perubahan (log) siapa yang mengubah status keterangan.
