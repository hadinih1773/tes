-- ============================================================
-- SKEMA DATABASE - Absensi Kelas XII F 5
-- Jalankan file ini di Supabase: Dashboard > SQL Editor > New query
-- ============================================================

-- Hapus tabel lama jika ada (hati-hati saat re-run di database yang sudah berisi data)
drop table if exists public.messages cascade;
drop table if exists public.attendance cascade;
drop table if exists public.users cascade;

-- ------------------------------------------------------------
-- TABEL USERS
-- Menyimpan seluruh akun: admin, walas, orangtua, dan siswa
-- ------------------------------------------------------------
create table public.users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique,      -- disimpan huruf kecil semua (lowercase)
  password text not null,             -- lihat catatan keamanan di README
  role text not null check (role in ('admin', 'walas', 'siswa', 'orangtua')),
  nama text not null,
  nomor_absen int,                    -- hanya untuk role = siswa
  created_at timestamptz not null default now()
);

create index idx_users_role on public.users(role);

-- ------------------------------------------------------------
-- TABEL ATTENDANCE (absensi harian per siswa)
-- ------------------------------------------------------------
create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  siswa_id uuid not null references public.users(id) on delete cascade,
  tanggal date not null default current_date,
  status text not null check (status in ('Hadir', 'Izin', 'Sakit', 'Alfa')),
  keterangan text,
  created_by text,                    -- 'siswa', 'walas', atau 'orangtua'
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (siswa_id, tanggal)          -- satu siswa hanya punya 1 catatan per hari
);

create index idx_attendance_tanggal on public.attendance(tanggal);
create index idx_attendance_siswa on public.attendance(siswa_id);

-- Trigger untuk update kolom updated_at otomatis
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_attendance_updated_at
before update on public.attendance
for each row execute function public.set_updated_at();

-- ------------------------------------------------------------
-- TABEL MESSAGES (chat live semua peran)
-- ------------------------------------------------------------
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.users(id) on delete cascade,
  sender_nama text not null,
  sender_role text not null check (sender_role in ('admin', 'walas', 'siswa', 'orangtua')),
  isi text not null,
  created_at timestamptz not null default now()
);

create index idx_messages_created_at on public.messages(created_at);

-- ------------------------------------------------------------
-- ROW LEVEL SECURITY
-- Catatan: Website ini memakai sistem login kustom (bukan Supabase Auth),
-- jadi akses ditentukan oleh logika di frontend, bukan oleh RLS per-user.
-- RLS berikut hanya mengizinkan akses lewat anon key (dipakai di browser).
-- Untuk keamanan produksi yang lebih kuat, pindahkan logika ke Supabase
-- Edge Function + Supabase Auth. Lihat README bagian "Catatan Keamanan".
-- ------------------------------------------------------------
alter table public.users enable row level security;
alter table public.attendance enable row level security;
alter table public.messages enable row level security;

create policy "anon_select_users" on public.users
  for select using (true);

create policy "anon_update_users" on public.users
  for update using (true);

create policy "anon_all_attendance" on public.attendance
  for all using (true) with check (true);

create policy "anon_all_messages" on public.messages
  for all using (true) with check (true);

-- Aktifkan Realtime untuk tabel messages supaya chat live tanpa refresh.
alter publication supabase_realtime add table public.messages;

-- ------------------------------------------------------------
-- SEED DATA - AKUN AWAL
-- ------------------------------------------------------------

-- Wali Kelas
insert into public.users (username, password, role, nama) values
  ('sury', 'walas', 'walas', 'Sury');

-- Orang Tua (akun umum, dipakai bersama oleh semua orang tua)
insert into public.users (username, password, role, nama) values
  ('orang tua', 'orangtua', 'orangtua', 'Orang Tua');

-- Admin (juga dicek lewat js/config.js sebagai cadangan)
insert into public.users (username, password, role, nama) values
  ('admin', 'admin123', 'admin', 'Admin');

-- Siswa Kelas XII F 5 (username = nama, password = nomor absen, tidak case-sensitive)
insert into public.users (username, password, role, nama, nomor_absen) values
  ('anayah', '1', 'siswa', 'ANAYAH', 1),
  ('bintang mandala putera', '2', 'siswa', 'BINTANG MANDALA PUTERA', 2),
  ('diva althafunnisa', '3', 'siswa', 'DIVA ALTHAFUNNISA', 3),
  ('dzaki ramadhan', '4', 'siswa', 'DZAKI RAMADHAN', 4),
  ('ega tri rahayu', '5', 'siswa', 'EGA TRI RAHAYU', 5),
  ('fadlan muzaki', '6', 'siswa', 'FADLAN MUZAKI', 6),
  ('gian rahma gusfian', '7', 'siswa', 'GIAN RAHMA GUSFIAN', 7),
  ('hadi saputra', '8', 'siswa', 'HADI SAPUTRA', 8),
  ('hervina nur farahni', '9', 'siswa', 'HERVINA NUR FARAHNI', 9),
  ('izmi nur aini agustina', '10', 'siswa', 'IZMI NUR AINI AGUSTINA', 10),
  ('khalif gibran muhammad sukma', '11', 'siswa', 'KHALIF GIBRAN MUHAMMAD SUKMA', 11),
  ('latifa sari', '12', 'siswa', 'LATIFA SARI', 12),
  ('mal habib fakhry rabiul', '13', 'siswa', 'MAL HABIB FAKHRY RABIUL', 13),
  ('muhammad rafly', '14', 'siswa', 'MUHAMMAD RAFLY', 14),
  ('mutiara aprilisia fitri', '15', 'siswa', 'MUTIARA APRILISIA FITRI', 15),
  ('nasrul fahri', '16', 'siswa', 'NASRUL FAHRI', 16),
  ('nazwa chairani', '17', 'siswa', 'NAZWA CHAIRANI', 17),
  ('rafi adha syafiq', '18', 'siswa', 'RAFI ADHA SYAFIQ', 18),
  ('razita alya', '19', 'siswa', 'RAZITA ALYA', 19),
  ('reza friska ningsi', '20', 'siswa', 'REZA FRISKA NINGSI', 20),
  ('sabili ilmi', '21', 'siswa', 'SABILI ILMI', 21),
  ('salsabila hasyifa', '22', 'siswa', 'SALSABILA HASYIFA', 22),
  ('syafriati mulliani', '23', 'siswa', 'SYAFRIATI MULLIANI', 23);
