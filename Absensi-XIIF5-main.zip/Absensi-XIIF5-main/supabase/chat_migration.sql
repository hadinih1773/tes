-- ============================================================
-- MIGRASI v4: Chat Wali Murid, Media Chat, Hapus Pesan, Pengumuman
-- Jalankan file ini di Supabase: Dashboard > SQL Editor > New query
-- Aman dijalankan di database yang SUDAH berisi data.
-- Jalankan SETELAH schema.sql / chat_migration.sql.
-- ============================================================

-- ------------------------------------------------------------
-- 1. Tabel MESSAGES: tambah kolom channel + media
-- ------------------------------------------------------------
alter table public.messages add column if not exists channel text not null default 'kelas';
alter table public.messages drop constraint if exists messages_channel_check;
alter table public.messages add constraint messages_channel_check check (channel in ('kelas', 'siswa'));

alter table public.messages add column if not exists media_url text;
alter table public.messages add column if not exists media_path text;
alter table public.messages add column if not exists media_type text; -- 'image' | 'video' | 'file'
alter table public.messages add column if not exists media_name text;

-- isi boleh kosong kalau pesan hanya berupa media
alter table public.messages alter column isi drop not null;
alter table public.messages alter column isi set default '';

create index if not exists idx_messages_channel on public.messages(channel);

-- ------------------------------------------------------------
-- 2. Tabel ANNOUNCEMENTS (Pengumuman)
-- ------------------------------------------------------------
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.users(id) on delete cascade,
  sender_nama text not null,
  sender_role text not null check (sender_role in ('admin', 'walas', 'siswa', 'orangtua')),
  isi text not null,
  image_url text,
  created_at timestamptz not null default now()
);

create index if not exists idx_announcements_created_at on public.announcements(created_at);

alter table public.announcements enable row level security;

drop policy if exists "anon_all_announcements" on public.announcements;
create policy "anon_all_announcements" on public.announcements
  for all using (true) with check (true);

-- ------------------------------------------------------------
-- 3. Realtime: pastikan messages & announcements aktif live
-- (Jika error "already a member", abaikan saja - berarti sudah aktif)
-- ------------------------------------------------------------
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.announcements;

-- ------------------------------------------------------------
-- 4. Storage bucket "lampiran" (untuk foto absensi/keterangan/
--    pengumuman serta media chat: gambar, video, file)
-- ------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit)
values ('lampiran', 'lampiran', true, 26214400) -- 25MB
on conflict (id) do update set public = true, file_size_limit = 26214400;

drop policy if exists "lampiran_public_read" on storage.objects;
create policy "lampiran_public_read" on storage.objects
  for select using (bucket_id = 'lampiran');

drop policy if exists "lampiran_public_insert" on storage.objects;
create policy "lampiran_public_insert" on storage.objects
  for insert with check (bucket_id = 'lampiran');

drop policy if exists "lampiran_public_delete" on storage.objects;
create policy "lampiran_public_delete" on storage.objects
  for delete using (bucket_id = 'lampiran');

-- ============================================================
-- SELESAI. Sekarang jalankan aplikasi seperti biasa.
-- ============================================================
