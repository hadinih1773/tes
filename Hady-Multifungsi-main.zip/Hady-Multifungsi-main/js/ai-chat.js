// ==========================================================
// ai-chat.js
// Widget AI Chat (Hady Assistant) - portable & self-contained.
// Tinggal tambahkan <script src="assets/ai-chat.js"></script>
// (atau "../assets/ai-chat.js" dari folder /html/) di file HTML
// mana pun untuk menambahkan tombol + panel chat AI.
// Butuh Font Awesome sudah di-load di halaman (untuk ikon robot).
// ==========================================================

(function () {

  /* ---------- INJECT CSS ---------- */
  const aiChatStyle = document.createElement("style");
  aiChatStyle.textContent = `
    .ai-btn{
      position:fixed;
      right:20px;
      bottom:20px;
      width:60px;
      height:60px;
      border:none;
      border-radius:50%;
      background:linear-gradient(135deg,var(--accent),var(--accent2));
      color:#fff;
      font-size:24px;
      cursor:pointer;
      z-index:99999;
    }

    .ai-chat{
      position:fixed;
      right:20px;
      bottom:90px;
      width:350px;
      max-width:90%;
      height:500px;
      background:var(--card);
      border:1px solid var(--border);
      border-radius:16px;
      display:none;
      flex-direction:column;
      overflow:hidden;
      z-index:99999;
    }

    .ai-chat.show{
      display:flex;
    }

    .ai-header{
      padding:15px;
      border-bottom:1px solid var(--border);
      font-weight:700;
    }

    .ai-messages{
      flex:1;
      overflow:auto;
      padding:15px;
    }

    .ai-msg{
      margin-bottom:10px;
      padding:10px;
      border-radius:10px;
      background:var(--bg3, #1a1a24);
      word-break:break-word;
    }

    .ai-input{
      display:flex;
      gap:10px;
      padding:15px;
      border-top:1px solid var(--border);
    }

    .ai-input input{
      flex:1;
      background:var(--bg3, #1a1a24);
      border:1px solid var(--border);
      color:var(--text);
      border-radius:10px;
      padding:10px;
    }

    .ai-input button{
      width:auto;
      margin:0;
    }
  `;
  document.head.appendChild(aiChatStyle);

  /* ---------- INJECT HTML ---------- */
  document.body.insertAdjacentHTML("beforeend", `
    <button class="ai-btn" id="aiBtn">
      <i class="fas fa-robot"></i>
    </button>
    <div class="ai-chat" id="aiChat">
      <div class="ai-header">Hady Assistant</div>
      <div class="ai-messages" id="aiMessages"></div>
      <div class="ai-input">
        <input type="text" id="aiInput" placeholder="Tulis pesan...">
        <button id="aiSend">Kirim</button>
      </div>
    </div>
  `);

  /* ---------- LOGIC ---------- */
  const aiBtn = document.getElementById("aiBtn");
  const aiChat = document.getElementById("aiChat");
  const aiSend = document.getElementById("aiSend");
  const aiInput = document.getElementById("aiInput");
  const aiMessages = document.getElementById("aiMessages");

  const ARNARU_AI_API = 'https://arnaru-ai.vercel.app/api/chat';
  const SYSTEM_PROMPT = "Kamu adalah asisten AI super pintar, andal, dan gaul. Wajib gunakan bahasa kasual Indonesia (gw, lu, bro, legit, dll). TAMPILAN VISUAL ADALAH PRIORITAS UTAMA. Ikuti gaya formatting premium ini:\n1. PENGGUNAAN EMOJI: Gunakan emoji secara rapi dan estetis HANYA di luar blok kode markdown (misal untuk mempertegas judul 🏆, status ✅❌, atau reaksi 💀💥).\n2. DATA TERSTRUKTUR: Saat menyajikan info model, konsep dasar, desain sistem, spesifikasi, statistik, probabilitas, atau rincian spesifik, WAJIB bungkus teks tersebut ke dalam blok kode markdown. Di dalam blok kode, buat tata letak yang sejajar/presisi dan rapi. Gunakan simbol peluru sederhana seperti '-', '✓', atau '→'.\n3. KODE SCRIPT: Jika memberikan source code murni, taruh di blok kode dengan nama bahasanya (contoh blok kode lua, pawn, html).\n4. PEMBATAS & HEADER: Gunakan teks tebal (**teks**) untuk judul di luar blok kode. Gunakan garis pembatas Markdown resmi (---) HANYA untuk memisahkan section besar agar elegan. DILARANG KERAS mengetik deretan garis manual panjang seperti ------- atau =======.\n5. Intinya: Buat respons yang visualnya memanjakan mata, perpaduan pas antara obrolan santai ber-emoji di luar, dan blok data yang rapi/teknis di dalam.";

  aiBtn.addEventListener("click", () => {
    aiChat.classList.toggle("show");
  });

  async function askAI(question, userId = 'default_user', model = 'claude-sonnet-5', webSearch = false, onStreamUpdate = null) {
    const conversationId = `${userId}_session_1`;

    try {
      const payload = {
        question: question,
        model: model,
        conversationId: conversationId,
        systemPrompt: SYSTEM_PROMPT,
        webSearch: webSearch
      };

      const response = await fetch(ARNARU_AI_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let fullAnswer = "";
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        let lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const jsonStr = line.substring(6).trim();
            if (jsonStr === '[DONE]') continue;

            try {
              const parsed = JSON.parse(jsonStr);
              if (parsed.answer) {
                fullAnswer += parsed.answer;
                let cleanedText = fullAnswer.replace(/[-=_]{3,}/g, '');
                if (onStreamUpdate) {
                  onStreamUpdate(cleanedText);
                }
              }
            } catch (e) {}
          }
        }
      }

      if (buffer.startsWith('data: ')) {
        try {
          const jsonStr = buffer.substring(6).trim();
          if (jsonStr !== '[DONE]') {
            const parsed = JSON.parse(jsonStr);
            if (parsed.answer) fullAnswer += parsed.answer;
          }
        } catch (e) {}
      }

      let finalCleaned = fullAnswer.replace(/[-=_]{3,}/g, '');
      return finalCleaned || "Sori ngab, server AInya lagi ampas nih ga ngasih jawaban bener.";
    } catch (error) {
      throw new Error(error.message);
    }
  }

  async function sendAI() {
    const text = aiInput.value.trim();
    if (!text) return;

    aiMessages.innerHTML += `
      <div class="ai-msg">
        <b>Kamu:</b><br>${text}
      </div>
    `;

    aiInput.value = "";

    const botMsgId = "ai-msg-" + Date.now();
    aiMessages.innerHTML += `
      <div class="ai-msg" id="${botMsgId}">
        <b>Hady Assistant:</b><br><span class="msg-content">Sedang mengetik...</span>
      </div>
    `;
    aiMessages.scrollTop = aiMessages.scrollHeight;

    const botMsgEl = document.getElementById(botMsgId).querySelector('.msg-content');

    try {
      const answer = await askAI(text, 'default_user', 'claude-sonnet-5', false, (streamText) => {
        botMsgEl.innerText = streamText;
        aiMessages.scrollTop = aiMessages.scrollHeight;
      });

      botMsgEl.innerText = answer;
      aiMessages.scrollTop = aiMessages.scrollHeight;
    } catch (err) {
      botMsgEl.innerText = "Gagal terhubung ke AI.";
    }
  }

  aiSend.addEventListener("click", sendAI);

  aiInput.addEventListener("keypress", e => {
    if (e.key === "Enter") {
      sendAI();
    }
  });

})();
