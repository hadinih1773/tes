// ==========================================================
// config.js
// Konfigurasi password website (biar ga kelihatan di kode HTML)
// File ini WAJIB di-load sebelum script yang memakainya.
// ==========================================================

const SITE_CONFIG = {
  // Password untuk buka kunci website (index.html)
  LOCK_PASSWORD: "hadinih",

  // Password untuk hapus Code Snippet (html/snippet.html)
  SNIPPET_DELETE_PASSWORD: "31012009",

  // Login Admin Panel (html/lock.html) - kelola lock website & changelog
  ADMIN_USERNAME: "hadinih",
  ADMIN_PASSWORD: "hadinih"
};
