-- ==========================================================
-- schema.sql
-- Skema database untuk fitur Changelog
-- Dibuat untuk Supabase / PostgreSQL
--
-- Cara pakai:
-- 1. Buka project Supabase kamu -> SQL Editor
-- 2. Copy-paste seluruh isi file ini -> Run
-- 3. Table "changelogs" siap dipakai oleh api/changelog.js
-- ==========================================================

create extension if not exists "pgcrypto";

create table if not exists changelogs (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,              -- judul changelog, contoh: "Update Fitur Downloader"
  version     text default '',            -- versi rilis, contoh: "v1.2.0" (opsional)
  tag         text default 'update',      -- kategori: 'feature' | 'fix' | 'update' | 'remove'
  changes     jsonb not null default '[]', -- daftar perubahan, contoh: ["Menambahkan fitur X", "Memperbaiki bug Y"]
  entry_date  date not null default current_date, -- tanggal changelog (bisa diedit manual saat input)
  created_at  timestamptz not null default now()
);

-- Index supaya query "ORDER BY entry_date DESC" lebih cepat
create index if not exists idx_changelogs_entry_date on changelogs (entry_date desc);

-- ==========================================================
-- ROW LEVEL SECURITY (opsional tapi disarankan)
-- Karena akses tulis/hapus sudah divalidasi lewat password
-- admin di api/changelog.js (pakai Service Role Key di server),
-- RLS berikut hanya mengizinkan pembacaan publik lewat anon key.
-- ==========================================================

alter table changelogs enable row level security;

drop policy if exists "Public read changelogs" on changelogs;
create policy "Public read changelogs"
  on changelogs
  for select
  using (true);

-- Catatan: insert/update/delete sengaja TIDAK dibuka untuk role "anon".
-- api/changelog.js mengakses tabel ini memakai SUPABASE_SERVICE_ROLE_KEY
-- (lihat api/supabaseClient.js) yang otomatis bypass RLS di server.
