const supabase = require("./supabaseClient");
const { checkBruteForce, recordFailedAttempt, resetAttempts } = require("./_bruteforce");

// Password hapus mod diambil dari environment variable server (BUKAN config.js lagi),
// supaya tidak pernah ikut terkirim ke browser pengunjung.
const MOD_DELETE_PASSWORD = process.env.MOD_DELETE_PASSWORD;

module.exports = async (req, res) => {

    if (req.method === "GET") {
        const { data, error } = await supabase
            .from("mods")
            .select("*")
            .order("created_at", { ascending: true });

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal mengambil data: " + error.message });
        }

        // Mapping supaya field cocok dengan yang dipakai di frontend (createdAt bukan created_at)
        const mapped = data.map(m => ({
            id: m.id,
            fileName: m.file_name,
            author: m.author,
            modType: m.mod_type,
            description: m.description,
            downloadUrl: m.download_url,
            imageUrl: m.image_url,
            views: m.views,
            downloads: m.downloads,
            createdAt: m.created_at
        }));

        return res.status(200).json(mapped);
    }

    if (req.method === "POST") {
        const body = req.body || {};
        const { fileName, author, modType, description, downloadUrl, imageUrl } = body;

        if (!fileName || !downloadUrl) {
            return res.status(400).json({ error: "Nama File/Mod & Url Download wajib diisi!" });
        }

        const { data, error } = await supabase
            .from("mods")
            .insert([{
                file_name: fileName,
                author: author || "Anonim",
                mod_type: modType || "Others",
                description: description || "",
                download_url: downloadUrl,
                image_url: imageUrl || "",
                views: 1,
                downloads: 0
            }])
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menyimpan ke storage: " + error.message });
        }

        return res.status(201).json({
            id: data.id,
            fileName: data.file_name,
            author: data.author,
            modType: data.mod_type,
            description: data.description,
            downloadUrl: data.download_url,
            imageUrl: data.image_url,
            views: data.views,
            downloads: data.downloads,
            createdAt: data.created_at
        });
    }

    if (req.method === "DELETE") {
        const body = req.body || {};
        const { id, password } = body;

        const bf = await checkBruteForce(req, "mod");
        if (bf.blocked) {
            return res.status(429).json({ error: `Terlalu banyak percobaan salah. Coba lagi dalam ${bf.sisaMenit} menit.` });
        }

        if (password !== MOD_DELETE_PASSWORD) {
            await recordFailedAttempt(bf.key, bf.existing);
            return res.status(401).json({ error: "Password salah!" });
        }
        await resetAttempts(bf.key);

        if (!id) {
            return res.status(400).json({ error: "ID mod wajib diisi!" });
        }

        const { error } = await supabase
            .from("mods")
            .delete()
            .eq("id", id);

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menghapus dari storage: " + error.message });
        }

        return res.status(200).json({ success: true });
    }

    if (req.method === "PATCH") {
        const body = req.body || {};
        const { id } = body;

        if (!id) {
            return res.status(400).json({ error: "ID mod wajib diisi!" });
        }

        // Ambil dulu nilai downloads saat ini
        const { data: current, error: fetchError } = await supabase
            .from("mods")
            .select("downloads")
            .eq("id", id)
            .single();

        if (fetchError) {
            console.error(fetchError);
            return res.status(404).json({ error: "Mod tidak ditemukan" });
        }

        const { data, error } = await supabase
            .from("mods")
            .update({ downloads: (current.downloads || 0) + 1 })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal update storage: " + error.message });
        }

        return res.status(200).json({
            id: data.id,
            downloads: data.downloads
        });
    }

    res.setHeader("Allow", ["GET", "POST", "DELETE", "PATCH"]);
    return res.status(405).json({ error: `Method ${req.method} tidak diizinkan` });
};
