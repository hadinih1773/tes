const fs = require("fs");
const path = require("path");
const archiver = require("archiver");

const backupConfigFile = path.resolve(__dirname, "../databasetele/backuptele.json");
const ownerFile = path.resolve(__dirname, "../databasetele/ownertele.json");
const backupDir = path.join(__dirname, "../sampah");

if (!fs.existsSync(path.dirname(backupConfigFile))) fs.mkdirSync(path.dirname(backupConfigFile), { recursive: true });
if (!fs.existsSync(backupConfigFile)) {
    fs.writeFileSync(backupConfigFile, JSON.stringify({ chatIds: [], backupDelay: 300000, active: false }, null, 2));
}
if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

let config = JSON.parse(fs.readFileSync(backupConfigFile, "utf8"));
let backupInterval = null;

const isOwner = (userId) => {
    if (!fs.existsSync(ownerFile)) return false;
    const rawData = fs.readFileSync(ownerFile, "utf8");
    const match = rawData.match(/"(\d+)"/);
    const ownerId = match ? match[1] : null;
    return userId.toString() === ownerId;
};

const handleBackup = async (ctx, bot, targetId) => {
    const date = new Date();
    const folderName = `backup_${date.getTime()}`;
    const folderPath = path.join(backupDir, folderName);
    
    if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });

    const zipFile = path.join(folderPath, "backup.zip");
    const output = fs.createWriteStream(zipFile);
    const archive = archiver("zip", { zlib: { level: 9 } });

    try {
        archive.pipe(output);
        const excluded = [
            "node_modules", ".npm", ".cache", ".git", ".DS_Store", 
            "session", "sampah", ".replit", ".upm", "jadibot-session"
        ];

        const addFiles = (dir, base = "") => {
            const items = fs.readdirSync(dir);
            for (const item of items) {
                const fullPath = path.join(dir, item);
                const relativePath = path.join(base, item);
                if (excluded.includes(item) || excluded.some(ex => item.startsWith(ex))) continue;
                if (fs.statSync(fullPath).isDirectory()) addFiles(fullPath, relativePath);
                else archive.file(fullPath, { name: relativePath });
            }
        };

        addFiles(process.cwd());
        await archive.finalize();

        await new Promise((resolve) => output.on("close", resolve));

        const fileName = `Backup_${date.toISOString().split('T')[0]}.zip`;
        
        if (ctx) {
            await bot.telegram.sendDocument(ctx.from.id, { source: zipFile, filename: fileName }, { caption: "📦 Backup Selesai" });
            if (ctx.chat.type !== 'private') {
                await ctx.reply("✅ Hasil Backup Sudah Dikirim Di Chat Pribadi Bot");
            }
        } else {
            await bot.telegram.sendDocument(targetId, { source: zipFile, filename: fileName }, { caption: "📦 Auto-Backup Selesai" });
        }

        fs.rmSync(folderPath, { recursive: true, force: true });
    } catch (err) {
        console.error("❌ Gagal backup:", err);
        if (ctx) ctx.reply("❌ Gagal melakukan backup.");
    }
};

const startAutoBackup = (bot) => {
    if (backupInterval) clearInterval(backupInterval);
    if (config.active && config.chatIds.length > 0) {
        backupInterval = setInterval(() => {
            config.chatIds.forEach(id => handleBackup(null, bot, id));
        }, config.backupDelay);
    }
};

function initAutoBackup(bot) {
    if (config.active) startAutoBackup(bot);
}

module.exports = {
    initAutoBackup,
    commands: {
        backup: async (ctx, bot) => {
            if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
            await ctx.reply("⏳ Sedang memproses backup...");
            await handleBackup(ctx, bot);
        },
        autobackup: (ctx) => {
            if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
            const args = ctx.message.text.split(" ");
            const action = args[1]?.toLowerCase();

            if (action === "on") {
                config.active = true;
                if (!config.chatIds.includes(ctx.chat.id)) config.chatIds.push(ctx.chat.id);
                fs.writeFileSync(backupConfigFile, JSON.stringify(config, null, 2));
                startAutoBackup(ctx.telegram);
                ctx.reply("✅ Autobackup Aktif untuk chat ini.");
            } else if (action === "off") {
                config.active = false;
                config.chatIds = [];
                fs.writeFileSync(backupConfigFile, JSON.stringify(config, null, 2));
                if (backupInterval) clearInterval(backupInterval);
                ctx.reply("🗑️ Autobackup Dinonaktifkan.");
            } else {
                ctx.reply("❌ Format Salah: /autobackup on/off", { parse_mode: 'Markdown' });
            }
        },
        settimebackup: (ctx) => {
            if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
            const args = ctx.message.text.split(" ");
            const timeArg = args[1];

            if (!timeArg) return ctx.reply("❌ Contoh: /settimebackup time");

            const match = timeArg.match(/^(\d+)([smh])$/);
            if (!match) return ctx.reply("❌ Format tidak valid.");

            const value = parseInt(match[1]);
            const unit = match[2];
            let ms = value * 1000;
            if (unit === "m") ms = value * 60 * 1000;
            if (unit === "h") ms = value * 60 * 60 * 1000;

            config.backupDelay = ms;
            fs.writeFileSync(backupConfigFile, JSON.stringify(config, null, 2));
            if (config.active) startAutoBackup(ctx.telegram);
            ctx.reply(`✅ Interval backup diatur ke ${value}${unit.toUpperCase()}.`);
        }
    }
};