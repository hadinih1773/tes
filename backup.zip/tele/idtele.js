module.exports = {
    commands: {
        id: (ctx) => {
            const user = ctx.from;
            const info = `🆔 *Your Info*

User ID: \`${user.id}\`
Name: ${user.first_name}${user.last_name ? ' ' + user.last_name : ''}
Username: ${user.username ? '@' + user.username : 'Tidak ada'}`;

            ctx.reply(info, { parse_mode: 'Markdown' });
        },
        cekid: async (ctx) => {
            const text = ctx.message.text || '';
            let target;
            if (ctx.message.reply_to_message) {
                target = ctx.message.reply_to_message.from;
            } else if (ctx.message.entities && ctx.message.entities.some(e => e.type === 'mention' || e.type === 'text_mention')) {
                return ctx.reply("❌ Bot hanya bisa cek ID via Reply pesan user tersebut.");
            }

            if (!target) {
                return ctx.reply("❌ Format Salah : /cekid reply pesan");
            }

            const info = `🆔 @${target.username || target.first_name} Info

User ID: \`${target.id}\`
Name: ${target.first_name}${target.last_name ? ' ' + target.last_name : ''}
Username: ${target.username ? '@' + target.username : 'Tidak ada'}`;

            return ctx.reply(info, { parse_mode: 'Markdown' });
        }
    }
};