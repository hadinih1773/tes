const Axios = require("axios");

let family100json = null;
let susunkatajson = null;
let tebakbenderajson = null;
let tebakgambarjson = null;
let tebakkatajson = null;
let tebaktebakanjson = null;
let tekatekijson = null;
let siapakahakujson = null;

const activeGames = new Map();

async function getFamily100() {
    if (!family100json) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json');
            family100json = res.data;
        } catch (error) { return null; }
    }
    return family100json[Math.floor(Math.random() * family100json.length)];
}

async function getSusunKata() {
    if (!susunkatajson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json');
            susunkatajson = res.data;
        } catch (error) { return null; }
    }
    return susunkatajson[Math.floor(Math.random() * susunkatajson.length)];
}

async function getTebakBendera() {
    if (!tebakbenderajson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera2.json');
            tebakbenderajson = res.data;
        } catch (error) { return null; }
    }
    return tebakbenderajson[Math.floor(Math.random() * tebakbenderajson.length)];
}

async function getTebakGambar() {
    if (!tebakgambarjson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json');
            tebakgambarjson = res.data;
        } catch (error) { return null; }
    }
    return tebakgambarjson[Math.floor(Math.random() * tebakgambarjson.length)];
}

async function getTebakKata() {
    if (!tebakkatajson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json');
            tebakkatajson = res.data;
        } catch (error) { return null; }
    }
    return tebakkatajson[Math.floor(Math.random() * tebakkatajson.length)];
}

async function getTebakTebakan() {
    if (!tebaktebakanjson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json');
            tebaktebakanjson = res.data;
        } catch (error) { return null; }
    }
    return tebaktebakanjson[Math.floor(Math.random() * tebaktebakanjson.length)];
}

async function getTekaTeki() {
    if (!tekatekijson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json');
            tekatekijson = res.data;
        } catch (error) { return null; }
    }
    return tekatekijson[Math.floor(Math.random() * tekatekijson.length)];
}

async function getSiapakahAku() {
    if (!siapakahakujson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json');
            siapakahakujson = res.data;
        } catch (error) { return null; }
    }
    return siapakahakujson[Math.floor(Math.random() * siapakahakujson.length)];
}

const handleGame = async (ctx, getSoalFn, type) => {
    const waitMsg = await ctx.reply("⏳ Sedang Proses..");
    try {
        const soalObj = await getSoalFn();
        if (!soalObj) return ctx.reply("❌ Gagal mengambil soal.");

        let sentMsg;
        const chatId = ctx.chat.id;

        if (type === "family100") {
            const caption = `🎮 *Game Family 100*\n\n*Pertanyaan:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab!_`;
            sentMsg = await ctx.reply(caption, { parse_mode: 'Markdown' });
            activeGames.set(`${chatId}:${sentMsg.message_id}`, { type, jawaban: soalObj.jawaban.map(j => j.toLowerCase().trim()), jawabanAsli: soalObj.jawaban });
        } else if (type === "susunkata") {
            const caption = `🎮 *Game Susun Kata*\n\n*Susun Kata Ini:* \`${soalObj.soal}\`\n*Tipe:* ${soalObj.tipe}\n\n_Reply pesan ini untuk menjawab!_`;
            sentMsg = await ctx.reply(caption, { parse_mode: 'Markdown' });
            activeGames.set(`${chatId}:${sentMsg.message_id}`, { type, jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
        } else if (type === "tebakbendera") {
            let imageUrl = soalObj.img.replace("http://", "https://");
            const caption = `🏳 *Tebak Bendera Negara!*\n\n*Bendera Negara Manakah Ini?*\n\n_Reply pesan ini untuk menjawab!_`;
            sentMsg = await ctx.replyWithPhoto({ url: imageUrl }, { caption, parse_mode: 'Markdown' });
            activeGames.set(`${chatId}:${sentMsg.message_id}`, { type, jawaban: soalObj.name.toLowerCase().trim(), jawabanAsli: soalObj.name });
        } else if (type === "tebakgambar") {
            let imageUrl = soalObj.img.replace("http://", "https://");
            const caption = `🖼️ *Tebak Gambar!*\n\n*Coba Tebak Gambar Apakah Ini?*\n\n_Reply pesan ini untuk menjawab!_`;
            sentMsg = await ctx.replyWithPhoto({ url: imageUrl }, { caption, parse_mode: 'Markdown' });
            activeGames.set(`${chatId}:${sentMsg.message_id}`, { type, jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
        } else {
            const caption = `🎮 *Game ${type}*\n\n*Soal:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab!_`;
            sentMsg = await ctx.reply(caption, { parse_mode: 'Markdown' });
            activeGames.set(`${chatId}:${sentMsg.message_id}`, { type, jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
        }
    } catch (e) { console.error(e); }
    finally {
        ctx.deleteMessage(waitMsg.message_id).catch(() => {});
    }
};

async function handleGameReply(ctx, next) {
    if (!ctx.message || !ctx.message.reply_to_message || !ctx.message.text) return next ? next() : null;
    
    const chatId = ctx.chat.id;
    const replyId = ctx.message.reply_to_message.message_id;
    const gameKey = `${chatId}:${replyId}`;

    if (activeGames.has(gameKey)) {
        const gameData = activeGames.get(gameKey);
        const userGuess = ctx.message.text.trim().toLowerCase();
        const sender = ctx.from.username || ctx.from.first_name;

        if (gameData.type === "family100") {
            if (gameData.jawaban.includes(userGuess)) {
                await ctx.reply(`✅ *Jawaban Kamu Benar!*\n\n@${sender} Mantap! Jawaban tersebut ada dalam daftar.\n\n*Semua Jawaban:*\n${gameData.jawabanAsli.join(", ")}`, { parse_mode: 'Markdown' });
                activeGames.delete(gameKey);
            } else {
                await ctx.reply(`❌ *Jawaban Kamu Salah!*\n\nSayang sekali! Jawaban itu tidak ada dalam daftar.\n\n*Jawaban Benar:*\n${gameData.jawabanAsli.join(", ")}`, { parse_mode: 'Markdown' });
                activeGames.delete(gameKey);
            }
        } else {
            if (userGuess === gameData.jawaban) {
                await ctx.reply(`✅ *Jawaban Kamu Benar!*\n\n@${sender} luar biasa! Jawaban kamu tepat.\n\n*Jawaban:* ${gameData.jawabanAsli.toUpperCase()}`, { parse_mode: 'Markdown' });
                activeGames.delete(gameKey);
            } else {
                await ctx.reply(`❌ *Jawaban Kamu Salah!*\n\nSalah tu! Coba lagi lain kali.\n\n*Jawaban Sebenarnya:* ${gameData.jawabanAsli.toUpperCase()}`, { parse_mode: 'Markdown' });
                activeGames.delete(gameKey);
            }
        }
    }
    return next ? next() : null;
}

module.exports = {
    handleGameReply,
    commands: {
        family100: ctx => handleGame(ctx, getFamily100, "family100"),
        susunkata: ctx => handleGame(ctx, getSusunKata, "susunkata"),
        tebakbendera: ctx => handleGame(ctx, getTebakBendera, "tebakbendera"),
        tebakgambar: ctx => handleGame(ctx, getTebakGambar, "tebakgambar"),
        tebakkata: ctx => handleGame(ctx, getTebakKata, "tebakkata"),
        tebaktebakan: ctx => handleGame(ctx, getTebakTebakan, "tebaktebakan"),
        tekateki: ctx => handleGame(ctx, getTekaTeki, "tekateki"),
        siapakahaku: ctx => handleGame(ctx, getSiapakahAku, "siapakahaku")
    }
};