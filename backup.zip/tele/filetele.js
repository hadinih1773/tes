const fs = require("fs");
const path = require("path");

const ownerFile = path.resolve(__dirname, "../databasetele/ownertele.json");

const isOwner = (userId) => {
    if (!fs.existsSync(ownerFile)) return false;
    const rawData = fs.readFileSync(ownerFile, "utf8");
    const match = rawData.match(/"(\d+)"/);
    const ownerId = match ? match[1] : null;
    return userId.toString() === ownerId;
};

const folders = [
    '../wa', '../fitur', '../slashcommands', '../owner', '../scrape',
    '../databasewa', '../database', '../protect', '../databasetele',
    '../tele', '../dc'
];

const sendLongMessage = async (ctx, text) => {
    const maxLength = 4000;
    for (let i = 0; i < text.length; i += maxLength) {
        await ctx.reply(text.substring(i, i + maxLength));
    }
};

async function getFileLogic(ctx) {
    try {
        if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
        const body = ctx.message.text || '';
        const args = body.trim().split(/ +/).slice(1);
        if (args.length === 0) return ctx.reply("❌ Format Salah : /getfile nama file");

        const fileName = args[0];
        let filePath = path.resolve(fileName);

        if (!fs.existsSync(filePath)) {
            for (let folder of folders) {
                let tempPath = path.join(__dirname, folder, fileName);
                if (fs.existsSync(tempPath)) {
                    filePath = tempPath;
                    break;
                }
            }
        }

        if (!fs.existsSync(filePath)) {
            return ctx.reply(`❌ File tidak ditemukan: ${fileName}`);
        }

        const stats = fs.statSync(filePath);
        if (stats.isDirectory()) {
            return ctx.reply(`❌ ${fileName} adalah sebuah folder.`);
        }

        const content = fs.readFileSync(filePath, "utf8");
        await sendLongMessage(ctx, content);
        await ctx.replyWithDocument({
            source: filePath,
            filename: path.basename(filePath)
        });
    } catch (err) {
        console.error(err);
        ctx.reply(`❌ Terjadi Error: ${err.message}`);
    }
}

module.exports = {
    commands: {
        getfile: getFileLogic,
        gf: getFileLogic,
        update: async (ctx) => {
            try {
                if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
                const body = ctx.message.text || '';
                const parts = body.split('|');
                if (parts.length < 3) return ctx.reply("❌ Format Salah : /update|nama file|kode baru");

                const fileName = parts[1].trim();
                const newContent = parts.slice(2).join('|'); 
                let filePath = path.resolve(fileName);

                if (!fs.existsSync(filePath)) {
                    for (let folder of folders) {
                        let tempPath = path.join(__dirname, folder, fileName);
                        if (fs.existsSync(tempPath)) {
                            filePath = tempPath;
                            break;
                        }
                    }
                }

                if (!fs.existsSync(filePath)) {
                    return ctx.reply(`❌ File tidak ditemukan: ${fileName}`);
                }

                fs.writeFileSync(filePath, newContent, "utf8");
                await ctx.reply(`✅ Berhasil update file: ${fileName}`);
            } catch (err) {
                console.error(err);
                ctx.reply(`❌ Terjadi Error: ${err.message}`);
            }
        },
        rnmfile: async (ctx) => {
            try {
                if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
                const body = ctx.message.text || '';
                const parts = body.split('|');
                if (parts.length < 3) return ctx.reply("❌ Format Salah : /rnmfile|nama file|nama baru");

                const oldName = parts[1].trim();
                const newName = parts[2].trim();
                let oldPath = path.resolve(oldName);

                if (!fs.existsSync(oldPath)) {
                    for (let folder of folders) {
                        let tempPath = path.join(__dirname, folder, oldName);
                        if (fs.existsSync(tempPath)) {
                            oldPath = tempPath;
                            break;
                        }
                    }
                }

                if (!fs.existsSync(oldPath)) {
                    return ctx.reply(`❌ File tidak ditemukan: ${oldName}`);
                }

                const newPath = path.join(path.dirname(oldPath), newName);
                fs.renameSync(oldPath, newPath);
                await ctx.reply(`✅ Berhasil rename file dari ${oldName} menjadi ${newName}`);
            } catch (err) {
                console.error(err);
                ctx.reply(`❌ Terjadi Error: ${err.message}`);
            }
        },
        delfile: async (ctx) => {
            try {
                if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
                const body = ctx.message.text || '';
                const args = body.trim().split(/ +/).slice(1);
                if (args.length === 0) return ctx.reply("❌ Format Salah : /delfile nama file");

                const fileName = args[0];
                let filePath = path.resolve(fileName);

                if (!fs.existsSync(filePath)) {
                    for (let folder of folders) {
                        let tempPath = path.join(__dirname, folder, fileName);
                        if (fs.existsSync(tempPath)) {
                            filePath = tempPath;
                            break;
                        }
                    }
                }

                if (!fs.existsSync(filePath)) {
                    return ctx.reply(`❌ File tidak ditemukan: ${fileName}`);
                }

                fs.unlinkSync(filePath);
                await ctx.reply(`✅ Berhasil menghapus file: ${fileName}`);
            } catch (err) {
                console.error(err);
                ctx.reply(`❌ Terjadi Error: ${err.message}`);
            }
        },
        listfile: async (ctx) => {
            try {
                if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
                let files = [];
                const mainDirFiles = fs.readdirSync(path.resolve(__dirname, '..'));
                mainDirFiles.forEach(f => {
                    if (!fs.statSync(path.join(__dirname, '..', f)).isDirectory()) files.push(f);
                });

                for (let folder of folders) {
                    const folderPath = path.resolve(__dirname, folder);
                    if (fs.existsSync(folderPath)) {
                        const items = fs.readdirSync(folderPath);
                        items.forEach(item => {
                            const fullPath = path.join(folderPath, item);
                            if (!fs.statSync(fullPath).isDirectory()) {
                                files.push(`${folder.replace('../', '')}/${item}`);
                            }
                        });
                    }
                }

                let listMsg = "List Nama File Script Bot\n";
                files.forEach(f => {
                    listMsg += `➣ ${f}\n`;
                });

                await sendLongMessage(ctx, listMsg);
            } catch (err) {
                console.error(err);
                ctx.reply(`❌ Terjadi Error: ${err.message}`);
            }
        },
        addfile: async (ctx) => {
            try {
                if (!isOwner(ctx.from.id)) return ctx.reply("❌ Hanya Owner Yang Bisa Gunakan");
                const body = ctx.message.text || '';
                const parts = body.split('|');
                let filePath;
                let fileName;
                let kode;

                if (parts.length === 4) {
                    const folderInput = parts[1].trim();
                    fileName = parts[2].trim();
                    kode = parts.slice(3).join('|');
                    filePath = path.join(__dirname, folderInput, fileName);
                } else if (parts.length === 3) {
                    fileName = parts[1].trim();
                    kode = parts.slice(2).join('|');
                    filePath = path.join(__dirname, '..', fileName);
                } else {
                    return ctx.reply("❌ Format Salah : /addfile|tempat file|nama file|kode\n/addfile|nama file|kode");
                }

                fs.writeFileSync(filePath, kode, "utf8");
                await ctx.reply(`✅ Berhasil menambah file: ${fileName}`);
            } catch (err) {
                console.error(err);
                ctx.reply(`❌ Terjadi Error: ${err.message}`);
            }
        }
    }
};