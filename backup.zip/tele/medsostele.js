const axios = require("axios");
const FormData = require("form-data");
const https = require('https');
const path = require("path");
const yts = require("yt-search");

const agent = new https.Agent({
    rejectUnauthorized: true,
    maxVersion: 'TLSv1.3',
    minVersion: 'TLSv1.2'
});

async function CatBox(url) {
    try {
        const resBuffer = await axios.get(url, { 
            responseType: 'arraybuffer', 
            timeout: 10000,
            headers: {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
            }
        });
        
        const buffer = Buffer.from(resBuffer.data);
        const formData = new FormData();
        formData.append('fileToUpload', buffer, { filename: 'thumbnail.jpg' });
        formData.append('reqtype', 'fileupload');
        formData.append('userhash', '');
        
        const response = await axios.post('https://catbox.moe/user/api.php', formData, {
            headers: { ...formData.getHeaders() },
            timeout: 20000
        });
        
        return response.data;
    } catch (error) {
        console.error("Uploader Error: ", error.message);
        return url;
    }
}

async function tiktokdl(url) {
    const res = await axios.get(`https://velynapi.vercel.app/api/downloader/tiktok?url=${encodeURIComponent(url)}`, { timeout: 15000 });
    return res.data.data;
}

async function pinterestSearch(query) {
    return new Promise(async (resolve, reject) => {
        const baseUrl = 'https://www.pinterest.com/resource/BaseSearchResource/get/';
        const params = {
            source_url: '/search/pins/?q=' + encodeURIComponent(query),
            data: JSON.stringify({
                options: { isPrefetch: false, query, scope: 'pins', no_fetch_context_on_resource: false },
                context: {}
            }),
            _: Date.now()
        };
        const headers = {
            'accept': 'application/json, text/javascript, */*, q=0.01',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',
            'x-requested-with': 'XMLHttpRequest'
        };
        try {
            const { data } = await axios.get(baseUrl, { httpsAgent: agent, headers, params });
            const results = data.resource_response?.data?.results ?? [];
            const result = results.map(item => ({
                images_url: item.images?.['736x']?.url ?? '',
            }));
            resolve(result);
        } catch (e) {
            reject([]);
        }
    });
}

module.exports = {
    commands: {
        yts: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /yts judul');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const resYts = await yts(text);
                const data = resYts.all.filter(v => v.type === "video");
                if (!data || data.length === 0) return;
                for (let i = 0; i < Math.min(data.length, 5); i++) {
                    const v = data[i];
                    const thumbnailUrl = await CatBox(`https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`);
                    try {
                        await ctx.replyWithPhoto({ url: thumbnailUrl }, { 
                            caption: `📺 *YOUTUBE SEARCH*\n\n📝 *Judul:* ${v.title}\n🔗 *Link:* ${v.url}\n\n*Slide:* ${i+1}/${Math.min(data.length, 5)}`,
                            parse_mode: 'Markdown'
                        });
                    } catch (err) {
                        await ctx.replyWithPhoto({ url: thumbnailUrl }, { 
                            caption: `📺 YOUTUBE SEARCH\n\n📝 Judul: ${v.title}\n🔗 Link: ${v.url}`
                        });
                    }
                }
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        ytdl: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /ytdl url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const resMp4 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(text)}`, { timeout: 20000 });
                const resMp3 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp3?url=${encodeURIComponent(text)}`, { timeout: 20000 });
                await ctx.replyWithVideo({ url: resMp4.data.data.url }, { caption: `\`𝗦 𝗢 𝗨 𝗧 𝗨 𝗕 𝗘 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``, parse_mode: 'Markdown' });
                await ctx.replyWithAudio({ url: resMp3.data.output });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        ytmp3: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /ytmp3 url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const resMp3 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp3?url=${encodeURIComponent(text)}`, { timeout: 20000 });
                await ctx.replyWithAudio({ url: resMp3.data.output }, { caption: `\`𝗬 𝗧 𝗠 𝗣 𝟯 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``, parse_mode: 'Markdown' });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        ytmp4: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /ytmp4 url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const resMp4 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(text)}`, { timeout: 20000 });
                await ctx.replyWithVideo({ url: resMp4.data.data.url }, { caption: `\`𝗬 𝗧 𝗠 package - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 Ａ 𝗗 Ｅ 𝗥\``, parse_mode: 'Markdown' });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        tts: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /tts judul');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const res = await axios.get(`https://velynapi.vercel.app/api/search/tiktoksearch?query=${encodeURIComponent(text)}`, { timeout: 15000 });
                const results = res.data.data;
                for (let i = 0; i < Math.min(results.length, 5); i++) {
                    const v = results[i];
                    const thumbnailUrl = await CatBox(v.cover);
                    try {
                        await ctx.replyWithPhoto({ url: thumbnailUrl }, { 
                            caption: `🎵 *TIKTOK SEARCH*\n\n📝 *Judul:* ${v.title}\n👤 *Creator:* ${v.music.author}\n🔗 *Link:* ${v.link}`,
                            parse_mode: 'Markdown'
                        });
                    } catch (err) {
                        await ctx.replyWithPhoto({ url: thumbnailUrl }, { 
                            caption: `🎵 TIKTOK SEARCH\n\n📝 Judul: ${v.title}\n👤 Creator: ${v.music.author}\n🔗 Link: ${v.link}`
                        });
                    }
                }
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        ttdl: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /ttdl url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const data = await tiktokdl(text);
                await ctx.replyWithVideo({ url: data.no_watermark }, { caption: `\`𝗧 𝗜 𝗞 𝗧 𝗢 𝗞 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``, parse_mode: 'Markdown' });
                await ctx.replyWithAudio({ url: data.music });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        ttmp3: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /ttmp3 url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const data = await tiktokdl(text);
                await ctx.replyWithAudio({ url: data.music }, { caption: `\`𝗧 𝗧 𝗠 𝗣 𝟯 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``, parse_mode: 'Markdown' });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        ttmp4: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /ttmp4 url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const data = await tiktokdl(text);
                await ctx.replyWithVideo({ url: data.no_watermark }, { caption: `\`𝗧 𝗧 𝗠 𝗣 𝟰 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``, parse_mode: 'Markdown' });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        igdl: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /igdl url');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const res = await axios.get(`https://velynapi.vercel.app/api/downloader/instagram?url=${encodeURIComponent(text)}`, { timeout: 20000 });
                await ctx.replyWithVideo({ url: res.data.data.url[0] }, { caption: `\`𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``, parse_mode: 'Markdown' });
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        },
        pinterest: async (ctx) => {
            const text = ctx.message.text.split(" ").slice(1).join(" ");
            if (!text) return ctx.reply('❌ Format Salah : /pinterest query`');
            const wait = await ctx.reply('⏳ Sedang Proses..');
            try {
                const results = await pinterestSearch(text);
                const data = results.slice(0, 10);
                if (!data || data.length === 0) return;
                for (let i = 0; i < data.length; i++) {
                    try {
                        await ctx.replyWithPhoto({ url: data[i].images_url });
                    } catch (err) { console.error("Pinterest send error") }
                }
            } catch (e) { console.error(e) }
            finally { ctx.deleteMessage(wait.message_id).catch(() => {}) }
        }
    }
};