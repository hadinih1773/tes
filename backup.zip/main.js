const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    makeCacheableSignalKeyStore, 
    DisconnectReason,
    fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const readline = require("readline");
const fs = require("fs");
const path = require("path");

const menuwa = require("./menuwa");
const listener = require("./lib/listener"); // Import listener

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// Variabel penampung modul agar tidak dibaca berulang kali
let loadedPlugins = [];

function systemLog(type, message) {
    const time = new Date().toLocaleTimeString("id-ID");
    const colors = {
        reset: "\x1b[0m",
        cyan: "\x1b[36m",
        green: "\x1b[32m",
        yellow: "\x1b[33m",
        red: "\x1b[31m",
        magenta: "\x1b[35m"
    };

    let prefix = "";
    switch(type) {
        case "INPUT": prefix = `${colors.cyan}📥 [INPUT]${colors.reset}`; break;
        case "OUTPUT": prefix = `${colors.magenta}📤 [OUTPUT]${colors.reset}`; break;
        case "PROGRESS": prefix = `${colors.yellow}⏳ [PROGRESS]${colors.reset}`; break;
        case "SUCCESS": prefix = `${colors.green}✅ [SUCCESS]${colors.reset}`; break;
        case "ERROR": prefix = `${colors.red}❌ [ERROR]${colors.reset}`; break;
        case "DEBUG": prefix = `${colors.yellow}🐛 [DEBUG]${colors.reset}`; break;
        default: prefix = `[INFO]`;
    }
    console.log(`[${time}] ${prefix} ${message}`);
}

if (!fs.existsSync('./databasewa')) fs.mkdirSync('./databasewa');
if (!fs.existsSync('./databasewa/userwa.json')) fs.writeFileSync('./databasewa/userwa.json', JSON.stringify([], null, 2));

async function setup(discordClient) {
    systemLog("PROGRESS", "Memulai inisialisasi bot...");

    const FALLBACK_VERSION = [2, 3000, 1015901307];
    let waVersion = FALLBACK_VERSION;
    try {
        const { version, isLatest } = await fetchLatestBaileysVersion();
        if (version && Array.isArray(version)) {
            waVersion = version;
            systemLog("SUCCESS", `WA-VERSION: [${version.join(', ')}] ${isLatest ? '(Terbaru)' : '(Bukan Terbaru)'}`);
        }
    } catch (e) {
        systemLog("ERROR", `Gagal fetch versi WA, menggunakan fallback: [${FALLBACK_VERSION.join(', ')}]`);
    }
    
    const { state, saveCreds } = await useMultiFileAuthState('session');
    const sock = makeWASocket({
        version: waVersion,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" })),
        },
        printQRInTerminal: false,
        logger: pino({ level: "fatal" }),
        browser: ["Windows", "Chrome", "122.0.6261.112"],
        generateHighQualityLinkPreview: true,
        shouldIgnoreOldMessages: true 
    });

    const originalSendMessage = sock.sendMessage;
    sock.sendMessage = async (...args) => {
        const jidTarget = args[0];
        try {
            const result = await originalSendMessage.apply(sock, args);
            const time = new Date().toISOString().slice(0, 19).replace("T", " ");
            const yellow = "\x1b[33m";
            const red = "\x1b[31m";
            const reset = "\x1b[0m";

            console.log(`
         [ OUTPUT CHAT LOG ]
────────────────────────────────────
 乂 WAKTU   : ${yellow}${time}${reset}
 乂 TO      : ${red}${jidTarget}${reset}
 乂 STATUS  : ${yellow}Berhasil Terkirim${reset}
────────────────────────────────────
            `);
            return result;
        } catch (error) {
            systemLog("ERROR", `Gagal mengirim pesan ke ${jidTarget} | Alasan: ${error.message}`);
            throw error;
        }
    };

    if (!sock.authState.creds.registered) {
        systemLog("PROGRESS", "Membutuhkan Pairing Code...");
        const phoneNumber = await question('✅ Masukkan nomor WhatsApp (contoh: 62812xxx): ');
        setTimeout(async () => {
            try {
                const code = await sock.requestPairingCode(phoneNumber.trim(), "HELPERMD");
                systemLog("SUCCESS", `Pairing Code WhatsApp: ${code}`);
            } catch (err) {
                systemLog("ERROR", `Gagal meminta Pairing Code: ${err.message}`);
            }
        }, 3000);
    }  

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut;
            systemLog("PROGRESS", `Koneksi terputus. Alasan: ${lastDisconnect.error?.message || "Unknown"}`);
            
            if (shouldReconnect) {
                systemLog("PROGRESS", 'Mencoba menyambungkan kembali (Reconnecting)...');
                sock.ev.removeAllListeners('connection.update');
                sock.ev.removeAllListeners('creds.update');
                sock.ev.removeAllListeners('messages.upsert');
                setup(discordClient);
            } else {
                systemLog("ERROR", 'Bot telah log out. Silakan hapus folder session dan hubungkan ulang.');
            }
        } else if (connection === 'connecting') {
            systemLog("PROGRESS", "Menyambungkan ke server WhatsApp...");
        } else if (connection === 'open') {
            systemLog("SUCCESS", "WhatsApp Bot Berhasil Online!");
            
            loadedPlugins = []; 
            const waFolder = path.join(__dirname, 'wa');
            if (fs.existsSync(waFolder)) {
                const files = fs.readdirSync(waFolder).filter(file => file.endsWith('.js'));
                for (let file of files) {
                    try {
                        const modulePath = path.join(waFolder, file);
                        delete require.cache[require.resolve(modulePath)];
                        const mod = require(modulePath);
                        loadedPlugins.push(mod); 
                        if (typeof mod.setup === 'function') mod.setup(sock);
                    } catch (err) {
                        systemLog("ERROR", `Gagal memuat file ${file}: ${err.message}`);
                    }
                }
            }
            if (typeof menuwa.setup === 'function') menuwa.setup(sock);
            systemLog("SUCCESS", "Semua modul berhasil dimuat!");
        }
    });

    sock.ev.on('messages.upsert', async (chatUpdate) => {
        try {
            // Memanggil listener utama dari ./lib/listener.js
            await listener(sock, chatUpdate);

            // Logika Logging Terminal
            if (chatUpdate.type !== 'notify' && chatUpdate.type !== 'append') return;
            for (const m of chatUpdate.messages) {
                if (!m.message) continue;
                const isGroup = m.key.remoteJid.endsWith('@g.us');
                const sender = m.key.participant || m.key.remoteJid;
                const pushname = m.pushName || "Unknown";
                const messageType = Object.keys(m.message)[0];
                const budy = m.message.conversation || m.message[messageType]?.text || m.message[messageType]?.caption || null;
                const mtype = messageType;
                const time = new Date().toISOString().slice(0, 19).replace("T", " ");

                const yellow = "\x1b[33m";
                const red = "\x1b[31m";
                const reset = "\x1b[0m";

                if (isGroup) {
                    console.log(`\n         [ GROUP CHAT LOG ]\n────────────────────────────────────\n 乂 WAKTU   : ${yellow}${time}${reset}\n 乂 TEXT    : ${yellow}${budy || mtype}${reset}\n 乂 FROM    : ${red}${pushname}${reset} (${yellow}${sender}${reset})\n 乂 GRUB    : ${yellow}${m.key.remoteJid}${reset}\n────────────────────────────────────\n`);
                } else {
                    console.log(`\n         [ PRIVATE CHAT LOG ]\n────────────────────────────────────\n 乂 WAKTU   : ${yellow}${time}${reset}\n 乂 TEXT    : ${yellow}${budy || mtype}${reset}\n 乂 FROM    : ${red}${pushname}${reset} (${yellow}${m.key.remoteJid}${reset})\n────────────────────────────────────\n`);
                }
            }
        } catch (err) {
            systemLog("ERROR", `Terjadi kesalahan saat memproses pesan masuk: ${err.message}`);
        }
    });
}

module.exports = { setup };