const { PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "..", "database", "antikata.json");

function loadData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return [];
  }
}

function saveData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database antikata.json:", err);
  }
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // --- CONFIG COMMAND: !antikata on/off ---
      if (command === "!antikata" || command === "!antiword") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then(msg => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const status = args[1]?.toLowerCase();
        if (status !== "on" && status !== "off") {
          return message.reply(`❌ Format Salah : \`\`${command} on/off\`\``);
        }

        let antiKataChannels = loadData();
        const currentChannelId = message.channel.id;

        if (status === "on") {
          if (!antiKataChannels.includes(currentChannelId)) {
            antiKataChannels.push(currentChannelId);
            saveData(antiKataChannels);
            return message.reply("✅ Fitur anti-kata berhasil diaktifkan di channel ini. Hanya kiriman media yang diizinkan.");
          } else {
            return message.reply("ℹ️ Fitur anti-kata sudah aktif di channel ini.");
          }
        }

        if (status === "off") {
          if (antiKataChannels.includes(currentChannelId)) {
            antiKataChannels = antiKataChannels.filter(id => id !== currentChannelId);
            saveData(antiKataChannels);
            return message.reply("✅ Fitur anti-kata berhasil dinonaktifkan di channel ini.");
          } else {
            return message.reply("❌ Fitur anti-kata belum aktif di channel ini.");
          }
        }
      }

      // --- PROTECTION SYSTEM FILTER ---
      const antiKataChannels = loadData();

      // Jika channel terdaftar di database antikata.json
      if (antiKataChannels.includes(message.channel.id)) {
        // Cek apakah pesan TIDAK memiliki attachment (gambar, video, file, dll) atau link embed media luar
        const hasMedia = message.attachments.size > 0 || message.embeds.length > 0;
        
        // Bersihkan string konten dari spasi kosong untuk validasi teks murni
        const hasText = message.content.trim().length > 0;

        // Jika user mengirim teks tanpa ada komponen media sama sekali
        if (hasText && !hasMedia) {
          // Hapus pesan teks pelanggar secara instan
          await message.delete().catch(() => null);

          // Kirim pesan peringatan terdeteksi
          const warningMessage = await message.channel.send(
            `🔍 <@${message.author.id}> Terdeteksi Pesan Kata Di Channel Ini, Pesan Akan Dihapus. Hanya Bisa Mengirim Media Ke Channel Ini.`
          );

          // Hapus pesan bot peringatan setelah 5 detik
          setTimeout(() => {
            warningMessage.delete().catch(() => null);
          }, 5000);
        }
      }
    });
  }
};
