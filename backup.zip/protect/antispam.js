const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dataPath = path.join(__dirname, "../database/antispam.json");

// Inisialisasi database jika belum ada
if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, JSON.stringify({}));
}

// Memory cache untuk mendeteksi spam (agar proses super cepat)
const userHistory = new Map();

const loadData = () => JSON.parse(fs.readFileSync(dataPath, "utf8"));
const saveData = (data) => fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

function setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
        if (message.author.bot || !message.guild) return;

        const guildId = message.guild.id;
        const data = loadData();

        // === COMMAND PENGATURAN (!antispam on/off) ===
        if (message.content.startsWith("!antispam")) {
            if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return message.reply("❌ Hanya Admin yang bisa menggunakan command ini.");
            }

            const args = message.content.split(" ")[1];
            if (args === "on") {
                data[guildId] = true;
                saveData(data);
                return message.reply("✅ **Anti Spam Aktif!** Bot akan mem-ban user yang spam di banyak channel sekaligus.");
            } else if (args === "off") {
                data[guildId] = false;
                saveData(data);
                return message.reply("✅ **Anti Spam Dinonaktifkan.**");
            } else {
                return message.reply("❌ Format Salah : Gunakan `!antispam on` atau `!antispam off`.");
            }
        }

        // === LOGIKA DETEKSI SPAM PHISHING & NSFW ===
        if (data[guildId] === true) {
            const now = Date.now();
            const userId = message.author.id;

            // Cek apakah pesan mengandung attachment yang ditandai NSFW oleh sistem Discord
            const hasNSFW = message.attachments.some(attachment => attachment.contentType?.startsWith('image/') && attachment.spoiler);

            if (!userHistory.has(userId)) {
                userHistory.set(userId, []);
            }

            let timestamps = userHistory.get(userId);
            // Menyimpan konten pesan untuk mendeteksi kesamaan konten di banyak channel
            timestamps.push({ time: now, channelId: message.channel.id, isNSFW: hasNSFW, content: message.content });

            // Filter pesan hanya dalam 3 detik terakhir
            timestamps = timestamps.filter(m => now - m.time < 3000);
            userHistory.set(userId, timestamps);

            // Cek jika user mengirim pesan di lebih dari 3 channel berbeda ATAU mengirim NSFW spam
            const uniqueChannels = new Set(timestamps.map(m => m.channelId));
            const containsNSFWSpam = timestamps.some(m => m.isNSFW);

            // DETEKSI BARU: Cari pesan dengan konten yang sama di channel yang berbeda
            const contentMap = {};
            let isSameMessageSpam = false;
            
            for (const m of timestamps) {
                if (!contentMap[m.content]) {
                    contentMap[m.content] = new Set();
                }
                contentMap[m.content].add(m.channelId);
                // Jika pesan yang sama dikirim ke lebih dari 5 channel berbeda
                if (contentMap[m.content].size > 5) {
                    isSameMessageSpam = true;
                    break;
                }
            }

            if (uniqueChannels.size >= 3 || (containsNSFWSpam && uniqueChannels.size >= 2) || isSameMessageSpam) {
                try {
                    // 1. Kirim Notifikasi Embed
                    const embed = new EmbedBuilder()
                        .setTitle("🚨 Spam Chat Terdeteksi")
                        .setDescription(`<@${userId}> Kamu telah melakukan spam chat ke beberapa channel sekaligus.\n\n🚮 Anda akan langsung di banned dan spam chat akan segera dihapus. 🗑`)
                        .setColor("Red")
                        .setTimestamp();

                    await message.channel.send({ embeds: [embed] });

                    // 2. Ban User & Hapus History Pesan 7 Hari (604800 detik)
                    if (message.member.bannable) {
                        await message.member.ban({ 
                            deleteMessageSeconds: 604800, 
                            reason: "Auto-Ban: Spam Phishing/Multi-Channel/NSFW Media" 
                        });
                    }

                    // Bersihkan history cache
                    userHistory.delete(userId);

                } catch (err) {
                    console.error("❌ Gagal eksekusi Anti-Spam:", err);
                }
            }
        }
    });
}

module.exports = { setup };