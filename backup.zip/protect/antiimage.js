const { PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "..", "database", "antiimage.json");

function loadData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return [];
  }
}

function saveData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database antiimage.json:", err);
  }
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // --- CONFIG COMMAND: !antiimage on/off ---
      if (command === "!antiimage" || command === "!antivideo") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then(msg => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const status = args[1]?.toLowerCase();
        if (status !== "on" && status !== "off") {
          return message.reply(`❌ Format Salah : \`\`${command} on/off\`\``);
        }

        let antiImageChannels = loadData();
        const currentChannelId = message.channel.id;

        if (status === "on") {
          if (!antiImageChannels.includes(currentChannelId)) {
            antiImageChannels.push(currentChannelId);
            saveData(antiImageChannels);
            return message.reply("✅ Fitur anti-image/video berhasil diaktifkan di channel ini. Hanya kiriman teks yang diizinkan.");
          } else {
            return message.reply("ℹ️ Fitur anti-image/video sudah aktif di channel ini.");
          }
        }

        if (status === "off") {
          if (antiImageChannels.includes(currentChannelId)) {
            antiImageChannels = antiImageChannels.filter(id => id !== currentChannelId);
            saveData(antiImageChannels);
            return message.reply("✅ Fitur anti-image/video berhasil dinonaktifkan di channel ini.");
          } else {
            return message.reply("❌ Fitur anti-image/video belum aktif di channel ini.");
          }
        }
      }

      // --- PROTECTION SYSTEM FILTER ---
      const antiImageChannels = loadData();

      if (antiImageChannels.includes(message.channel.id)) {
        // Deteksi lampiran langsung (file/media)
        const hasAttachments = message.attachments.size > 0;
        
        // Deteksi link gambar/video luar yang memicu embed tipe image atau video
        const hasMediaEmbed = message.embeds.some(embed => embed.image || embed.video);

        if (hasAttachments || hasMediaEmbed) {
          await message.delete().catch(() => null);

          const warningMessage = await message.channel.send(
            `🔍 <@${message.author.id}> Terdeteksi Pesan Gambar/Video Di Channel Ini, Pesan Akan Dihapus. Hanya Bisa Pesan Teks Ke Channel Ini.`
          );

          setTimeout(() => {
            warningMessage.delete().catch(() => null);
          }, 5000);
        }
      }
    });
  }
};
