const { PermissionsBitField } = require("discord.js");

const fs = require("fs");

const path = require("path");

const dbPath = path.join(__dirname, "../database/antikasar.json");

// Inisialisasi Database

if (!fs.existsSync(dbPath)) {

    fs.writeFileSync(dbPath, JSON.stringify({}));

}

// Tambahkan kata kasar di dalam array ini

const daftarKataKasar = ["anjing", "babi", "bangsat", "goblok", "kontol", "memek", "ngentot", "ngentod", "anj", "jembut", "peler", "pler", "pantek", "ngentid", "puki", "pepek", "ppk", "lonte"];

module.exports = {

  setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

      if (message.author.bot || !message.guild) return;

      const args = message.content.split(/\s+/);

      const command = args[0].toLowerCase();

      // Load database setiap ada pesan untuk sinkronisasi

      let db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      // ================= COMMAND SETTING (ADMIN ONLY) =================

      if (command === "!antikasar") {

        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

          return message.reply("❌ Hanya Admin yang dapat menggunakan command ini.");

        }

        const status = args[1]?.toLowerCase();

        if (status === "on") {

          db[message.guild.id] = true;

          fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

          return message.reply("✅ Fitur Anti-Kasar telah diaktifkan.");

        } else if (status === "off") {

          db[message.guild.id] = false;

          fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

          return message.reply("✅ Fitur Anti-Kasar telah dimatikan.");

        } else {

          return message.reply("❓ Gunakan: `!antikasar on` atau `!antikasar off`.");

        }

      }

      // ================= FILTER KATA KASAR =================

      if (db[message.guild.id] === true) {

        // Memisahkan pesan menjadi array kata-kata untuk pengecekan presisi (Exact Match)

        const words = message.content.toLowerCase().split(/\s+/);

        

        const containsKasar = words.some(word => 

          daftarKataKasar.includes(word.trim())

        );

        if (containsKasar) {

          try {

            await message.delete();

            const warning = await message.channel.send(`<@${message.author.id}> Jangan Terlalu Kasar Anj🤬`);

            setTimeout(() => warning.delete().catch(() => {}), 5000);

          } catch (err) {

            console.error("❌ Gagal menghapus pesan kasar:", err);

          }

        }

      }

    });

  },

};