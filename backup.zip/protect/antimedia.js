const { PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "..", "database", "antimedia.json");

function loadData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return [];
  }
}

function saveData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database antimedia.json:", err);
  }
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // --- CONFIG COMMAND: !antimedia on/off ---
      if (command === "!antimedia") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then(msg => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const status = args[1]?.toLowerCase();
        if (status !== "on" && status !== "off") {
          return message.reply(`❌ Format Salah : \`\`${command} on/off\`\``);
        }

        let antiMediaChannels = loadData();
        const currentChannelId = message.channel.id;

        if (status === "on") {
          if (!antiMediaChannels.includes(currentChannelId)) {
            antiMediaChannels.push(currentChannelId);
            saveData(antiMediaChannels);
            return message.reply("✅ Fitur anti-media berhasil diaktifkan di channel ini. Hanya kiriman teks murni yang diizinkan.");
          } else {
            return message.reply("ℹ️ Fitur anti-media sudah aktif di channel ini.");
          }
        }

        if (status === "off") {
          if (antiMediaChannels.includes(currentChannelId)) {
            antiMediaChannels = antiMediaChannels.filter(id => id !== currentChannelId);
            saveData(antiMediaChannels);
            return message.reply("✅ Fitur anti-media berhasil dinonaktifkan di channel ini.");
          } else {
            return message.reply("❌ Fitur anti-media belum aktif di channel ini.");
          }
        }
      }

      // --- PROTECTION SYSTEM FILTER ---
      const antiMediaChannels = loadData();

      if (antiMediaChannels.includes(message.channel.id)) {
        // Deteksi lampiran file, gambar, video, suara, dokumen, stiker, dll
        const hasAttachments = message.attachments.size > 0;
        
        // Deteksi tautan url luar yang memicu render preview media (image, video, gif, dll)
        const hasMediaEmbed = message.embeds.some(embed => embed.image || embed.video || embed.thumbnail);

        if (hasAttachments || hasMediaEmbed) {
          await message.delete().catch(() => null);

          const warningMessage = await message.channel.send(
            `🔍 <@${message.author.id}> Terdeteksi Pesan Media Di Channel Ini, Pesan Akan Dihapus. Hanya Bisa Pesan Teks Ke Channel Ini.`
          );

          setTimeout(() => {
            warningMessage.delete().catch(() => null);
          }, 5000);
        }
      }
    });
  }
};