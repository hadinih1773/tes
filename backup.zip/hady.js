const express = require("express");
const fs = require("fs");
const path = require("path");
const https = require("https");

let cachedUrl = ""; 

module.exports = {
    getUrl: () => cachedUrl, 
    setup: (client, app) => {
        const dbFolder = path.join(__dirname, "./database");
        const dbPath = path.join(dbFolder, "website.json");
        const htmlPath = path.join(__dirname, "hady.html");

        const loadData = () => {
            if (!fs.existsSync(dbFolder)) fs.mkdirSync(dbFolder, { recursive: true });
            if (!fs.existsSync(dbPath)) {
                const initialData = { profil: "Halo, saya Hady.", catatan: [], images: [] };
                fs.writeFileSync(dbPath, JSON.stringify(initialData, null, 2));
                return initialData;
            }
            return JSON.parse(fs.readFileSync(dbPath, "utf-8"));
        };

        const saveData = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

        app.use(express.json());
        app.use(express.urlencoded({ extended: true }));

        app.get("/hady", (req, res) => {
            const data = loadData();
            if (!fs.existsSync(htmlPath)) return res.send("File hady.html tidak ditemukan!");
            
            let html = fs.readFileSync(htmlPath, "utf-8");

            const catatanHtml = data.catatan.map((n, index) => `
                <div class="note-item">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div onclick="viewNote(${index})" style="cursor:pointer; flex-grow:1;">
                            <b>${n.title}</b>
                            <small style="color:#64748b;">${n.date}</small>
                        </div>
                        <div style="display:flex; gap:5px;">
                            <button onclick="editNote(${index})" style="padding: 5px 10px; font-size: 12px; background: #fbbf24; color: black;"><i class="fas fa-edit"></i></button>
                            <button onclick="deleteNote(${index})" style="padding: 5px 10px; font-size: 12px; background: #ef4444; color: white;"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                    <div id="note-content-${index}" style="display:none; margin-top:10px; padding-top:10px; border-top:1px solid #ddd; color:#444;">
                        ${n.content}
                    </div>
                </div>
            `).join('');

            const imagesHtml = data.images.map((img, index) => `
                <div class="img-card" style="position:relative;">
                    <a href="${img}" target="_blank">
                        <img src="${img}">
                    </a>
                    <button onclick="deleteImage(${index})" style="position:absolute; top:5px; right:5px; background:rgba(239, 68, 68, 0.8); color:white; padding:5px; border-radius:5px; width:30px; height:30px;"><i class="fas fa-trash"></i></button>
                </div>
            `).join('');

            html = html.replace("\${profil}", data.profil)
                       .replace("\${catatan}", catatanHtml)
                       .replace("\${images}", imagesHtml);
            
            res.send(html);
        });

        // API Endpoints
        app.post("/hady/edit-profil", (req, res) => { const data = loadData(); data.profil = req.body.profil; saveData(data); res.sendStatus(200); });
        app.post("/hady/add-note", (req, res) => { const data = loadData(); const now = new Date(); data.catatan.push({ title: req.body.title, content: req.body.content, date: now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) }); saveData(data); res.sendStatus(200); });
        app.post("/hady/edit-note", (req, res) => { const data = loadData(); const index = req.body.index; if(data.catatan[index]) { data.catatan[index].title = req.body.title; data.catatan[index].content = req.body.content; saveData(data); } res.sendStatus(200); });
        app.post("/hady/delete-note", (req, res) => { const data = loadData(); data.catatan.splice(req.body.index, 1); saveData(data); res.sendStatus(200); });
        app.post("/hady/add-image", (req, res) => { const data = loadData(); data.images.push(req.body.url); saveData(data); res.sendStatus(200); });
        app.post("/hady/delete-image", (req, res) => { const data = loadData(); data.images.splice(req.body.index, 1); saveData(data); res.sendStatus(200); });

        // --- IMPLEMENTASI AMBIL PORT DARI PANEL ---
        // Menggunakan PORT dari process.env secara langsung seperti kode referensi kamu
        const PORT = process.env.PORT || process.env.SERVER_PORT;

        app.listen(PORT, () => {
            https.get('https://api.ipify.org', (res) => {
                res.on('data', (ip) => {
                    const cleanIp = ip.toString().trim();
                    // Gabungkan IP Publik dengan PORT dari panel
                    cachedUrl = `http://${cleanIp}:${PORT}/hady`;
                    
                    console.log("✅ Module Hady.js Aktif");
                    console.log(`🚀 App listened on port: ${PORT}`);
                    console.log(`🔗 Link Website: ${cachedUrl}`);
                });
            }).on('error', () => {
                console.log(`✅ Module Hady.js Aktif di port ${PORT}`);
            });
        });
    }
};