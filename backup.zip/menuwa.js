const os = require('os');
const fs = require('fs');
const path = require('path');
const axios = require('axios'); // Ditambahkan untuk mengambil audio dari URL
const { spawn } = require('child_process');
const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

/**
 * Konfigurasi Menu Bot & Sinkronisasi Database
 */
const dbDir = path.join(__dirname, './databasewa');
const menuDbPath = path.join(dbDir, 'menuwa.json');

if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir);
}

// Fungsi Konversi Buffer ke Audio WhatsApp (Sama persis dengan file referensi)
function toPTT(buffer) {
    return new Promise((resolve, reject) => {
        let ffmpeg = spawn('ffmpeg', [
            '-i', 'pipe:0',
            '-vn',
            '-c:a', 'libopus',
            '-b:a', '128k',
            '-vbr', 'on',
            '-f', 'ogg',
            'pipe:1'
        ]);
        let buffers = [];
        ffmpeg.stdout.on('data', (chunk) => buffers.push(chunk));
        ffmpeg.stderr.on('data', (err) => {}); // Silent error ffmpeg
        ffmpeg.on('close', () => resolve(Buffer.concat(buffers)));
        ffmpeg.on('error', (err) => reject(err));
        ffmpeg.stdin.write(buffer);
        ffmpeg.stdin.end();
    });
}

const fields = [
    {
        name: "👑 𝐎𝐰𝐧𝐞𝐫 𝐌𝐞𝐧𝐮",
        id: "ownermenu",
        value: [
".addadmin", 
".deladmin", 
".backup",
".autobackup [on/off]", 
".settimebackup [time]", 
".self",
".public", 
".onlygc [on/off]", 
".sewa", 
".listsewa",
".delsewa",
".unsewa",
".setnamebot", 
".setppbot",
".setswbot", 
".autoai",  
".delppbot", 
".setbiobot", 
".join", 
".leavegc", 
".restart",
".spamwa|[628xx]|[pesan]|[jumlah]",
".linkgc",
".swgc [teks/reply video/foto]",
".bc [teks/reply teks]",
".bc [blacklist]",
".bctagsw [teks/reply video foto]",
".bctagsw [blacklist]",
".bcchat [teks]",
".jadibot",
".statusjadibot",
".deletejadibot",
".listjadibot [628xx]",
".setwelcome [teks]",
".setleft [teks]",
".wl [on/off]",
".get [url]",
".getfile",
".getplugin",
".gp", 
" get [url]",
".addfile", 
".addplugin",
".ap",
".update",
".updateplugin", 
".up",
".rnmfile", 
".renameplugin",
".rp",
".delfile",
".deleteplugin",
".dp",
".del",
".listfile",
".swgc [kirim teks/reply video, foto]",
".swgcall [teks/reply video, foto]",
".$"
    ]
    },
    {
        name: "🏢 𝐆𝐫𝐨𝐮𝐩 𝐌𝐞𝐧𝐮",
        id: "groupmenu",
        value: [
".setppgc", 
".setnamegc [name]", 
".setgc [open/close]",
".setdescgc [desc]",
".pinchat [teks/reply pesan]", 
".unpinchat", 
".kick [@tag/reply pesan]",
".add [628xx]", 
".ban [@tag/reply pesan]", 
".unban [@tag/reply pesan]",
".cekid [@tag/628xx]", 
".cekidgc",
".myid",
".tagall [pesan]",
".ar|[kata]|[response]", 
".dar|[kata]", 
".listar",
".setopen [on/off]",
".setclose [on/off]",
".settimeopen [time]",
".settimeclose [time]",
".setteksopen [teks]",
".setteksclose [teks]",
".welcome [test]",
".left [test]",
".ans [jawaban]",
".promote [@tag/reply pesan]",
".demote [@tag/reply pesan]",
".listadmin",
".warn [@tag/reply pesan]",
".unwarn [@tag/reply pesan]",
".setmaxwarnings [jumlah]",
".clearwarn [@tag/reply pesan]",
".cekwarn [@tag/reply pesan]",
".listban",
".listdaftar"
    ]
    },
    {
        name: "🚨 𝐀𝐧𝐭𝐢 𝐌𝐞𝐧𝐮",
        id: "antimenu",
        value: [
".antitagsw [on/off]", 
".antilink [on/off]",
".antikasar [on/off]",
".autotyping [on/off]",
".settings"
    ]
    },
    {
        name: "📣 𝐈𝐧𝐟𝐨 𝐌𝐞𝐧𝐮",
        id: "infomenu",
        value: [
".menu",
".hadymenu",
".allmenu",
".daftar [nama][.umur]",
".undaftar",
".owner",
".report [laporan]",
".ask [pertanyaan]",
".maxwarnings",
".mywarn",
".mylimit",
".chess menu",
".tutorial",
".totalfitur",
".chat|[628xx]|[pesan]",
".donasi",
".runtime",
".sc",
".info",
".monitor",
".server"
    ]
    },
    {
        name: "📟 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝𝐞𝐫 𝐌𝐞𝐧𝐮",
        id: "downloadermenu",
        value: [
".yt [url]",
".ytdl [url]",
".ytmp3 [url]",
".ytmp4 [url]",
".tt [url]",
".ttdl [url]",
".ttmp3 [url]",
".ttmp4 [url]",
".ig [url]",
".igdl [url]",
".aiodl [url]",
".fb [url]",
".fbdl [url]",
".x [url]",
".xdl [url]",
".twdl [url]",
".mfdl [url]",
".mediafire [url]",
".git [url]",
".gitdl [url]",
".github [url]"
    ]
    },
    {
        name: "🔍 𝐒𝐞𝐚𝐫𝐜𝐡 𝐌𝐞𝐧𝐮",
        id: "searchmenu",
        value: [
".yts [judul]",
".ytsearch [judul]",
".tts [judul]",
".pin [query]",
".pinterest [query]",
".play [query]",
".npms [query]"
    ]
    },
    {
        name: "👀 𝐒𝐭𝐚𝐥𝐤𝐞 𝐌𝐞𝐧𝐮",
        id: "stalkermenu",
        value: [
".wastalk [628xx]",
".igstalk [username]"
    ]
    },
    {
        name: "🕌 𝐈𝐬𝐥𝐚𝐦𝐢 𝐌𝐞𝐧𝐮",
        id: "islamimenu",
        value: [
".asmaulhusna [nomor/all]"
    ]
    },
   {
        name: "🤖 𝐀𝐈 𝐌𝐞𝐧𝐮",
        id: "aimenu",
        value: [
".autoai [on/off]",
".ai [query]",
".gemini [query]" 
    ]
    },
    {
        name: "💸 𝐄𝐜𝐨𝐧𝐨𝐦𝐲 𝐌𝐞𝐧𝐮",
        id: "economymenu",
        value: [
".work", 
".daily",
".weekly",
".mine",
".hunt",
".fish",
".deposite [jumlah]",
".depoall",
".depositeall",
".withdraw [jumlah]",
".withall",
".withdrawall",
".mystats",
".balance",
".bal",
".inventory",
".inv",
".sell|[item]|[jumlah]",
".buy [item]|[jumlah]",
".leaderboard",
".lb"
    ]
    },
    {
        name: "🎯 𝐅𝐮𝐧 𝐌𝐞𝐧𝐮",
        id: "funmenu",
        value: [
".family100", 
".siapakahaku", 
".susunkata",
".tebakbendera",
".tebakgambar",
".tebakkata",
".tebaktebakan",
".tekateki",
".artinama [nama]",
".chess [create, join, delete, computer]",
".kerangajaib [pertanyaan]"                     
    ]
    },
    {
        name: "📡 𝐂𝐡𝐞𝐤𝐢𝐧𝐠 𝐌𝐞𝐧𝐮",
        id: "chekingmenu",
        value: [
".cekip",
".ping",
".cekidch [url]",
".idch [url]"
    ]
    },
    {
        name: "🔍 𝐒𝐞𝐚𝐫𝐜𝐡 𝐌𝐞𝐧𝐮",
        id: "searchmenu",
        value: [
".yts [judul]",
".ytsearch [judul]",
".tts [judul]",
".pin [query]",
".pinterest [query]",
".bbsearch [query]",
".bbs [query]"
    ]
    },
   {
        name: "🏟 𝐌𝐨𝐛𝐢𝐥𝐞 𝐋𝐞𝐠𝐞𝐧𝐝",
        id: "mobilelegend",
        value: [
".buildml [nama hero]"
    ]
    },
    {
        name: "🎮 𝐒𝐚𝐦𝐩 𝐓𝐨𝐨𝐥𝐬",
        id: "samptools",
        value: [
".bb [query/url]", 
".bbplaylist",
".cekfile [kirim/reply file]", 
".listserver",
".cs|[nama ic]|[tanggal lahir]|[tempat tinggal]",
".spamwebhook|[url]|[pesan]|[jumlah]",
".cekwebhook|[url]"
    ]
    },
    {
        name: "🎐 𝐂𝐚𝐧𝐯𝐚𝐬 𝐓𝐨𝐨𝐥𝐬",
        id: "canvastools",
        value: [
".fakecall|[nama]|[durasi]",
".fakeff [nama]",
".fakeml [nama]"
    ]
    },
    {
        name: "🖼 𝐈𝐦𝐚𝐠𝐞 𝐓𝐨𝐨𝐥𝐬",
        id: "imagetools",
        value: [
".removebg [kirim/reply gambar]", 
".tofigure [kirim/reply gambar]",
".hd [kirim/reply gambar]", 
".editimage [prompt] [kirim/reply gambar]",
".iqc|[teks]|[jam]|[batre]"
    ]
    },
    {
        name: "🎨 𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐌𝐞𝐧𝐮",
        id: "stickermenu",
        value: [
".brat [teks]", 
".bratvid [teks]", 
".s [kirim/reply gambar]", 
".toimg [reply sticker]",
".smeme [teks atas]|[teks bawah]",
".swm [nama]|[nama]",
".sticker [kirim/reply gambar]"
    ]
    },
    {
        name: "🧰 𝐓𝐨𝐨𝐥𝐬 𝐌𝐞𝐧𝐮",
        id: "toolsmenu",
        value: [
".skip [url]", 
".tourl [kirim/reply gambar]", 
".rvo [reply pesan]",
".getpp [@tag/reply pesan]", 
".tovn [kirim/reply video]", 
".tomp3 [kirim/reply video]",
".obf [kirim/reply file]",
".deobf [kirim/reply file]"
    ]
    }
];

// Proses sinkronisasi ke menuwa.json
const cleanFields = fields.map(category => ({
    ...category,
    value: category.value.map(cmd => {
        let cleanCmd = cmd.split(' ')[0].split('|')[0];
        return cleanCmd;
    })
}));

fs.writeFileSync(menuDbPath, JSON.stringify(cleanFields, null, 2));

function runtime(seconds) {
    seconds = Number(seconds);
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return `${d > 0 ? d + "d " : ""}${h > 0 ? h + "h " : ""}${m > 0 ? m + "m " : ""}${s}s`;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        const body = (
            m.message.conversation || 
            m.message.extendedTextMessage?.text || 
            m.message.buttonsResponseMessage?.selectedButtonId || 
            m.message.listResponseMessage?.singleSelectReply?.selectedRowId || 
            m.message.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson && JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id || 
            m.message.templateButtonReplyMessage?.selectedId ||
            m.message.interactiveResponseMessage?.body?.text ||
            ''
        );

        if (body === 'ownerhc') {
            const vcardHady = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:Hady\n' + 'ORG:Hady Community;\n' + 'TEL;type=CELL;type=VOICE;waid=6282311544652:+6282311544652\n' + 'END:VCARD';
            const vcardAka = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:Aka\n' + 'ORG:Hady Community;\n' + 'TEL;type=CELL;type=VOICE;waid=6281266950382:+6281266950382\n' + 'END:VCARD';
            const vcardHelper = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:HC Helper MD\n' + 'ORG:Hady Community;\n' + 'TEL;type=CELL;type=VOICE;waid=6285165754930:+6285165754930\n' + 'END:VCARD';

            return await sock.sendMessage(from, {
                contacts: {
                    displayName: 'Owner List',
                    contacts: [{ vcard: vcardHady }, { vcard: vcardAka }, { vcard: vcardHelper }]
                }
            }, { quoted: m });
        }

        const dbUserPath = path.join(__dirname, './databasewa/userwa.json');
        if (fs.existsSync(dbUserPath)) {
            const userDb = JSON.parse(fs.readFileSync(dbUserPath));
            if (!userDb.includes(sender)) return; 
        } else {
            return; 
        }

        const isSpecificMenu = fields.some(f => body === `.${f.id}`);
        
        if (body.startsWith('.menu') || body.startsWith('.allmenu') || body === 'categoryhc' || isSpecificMenu) {
            let categoryArg = body.split(' ')[1];
            
            if (isSpecificMenu) {
                categoryArg = body.replace('.', '');
            } else if (!categoryArg && body.includes('menu') && body !== '.menu' && body !== '.allmenu') {
                categoryArg = body.replace('.', '');
            }
            
            if (body === 'categoryhc') {
                categoryArg = 'categoryhc';
            }

            await tampilkanMenu(sock, from, m, categoryArg, body);
        }
    } catch (err) {
        console.error(err);
    }
};

async function tampilkanMenu(sock, from, m, categoryArg, fullBody) {
    const pushname = m.pushName || "User";
    const speed = Date.now() - (m.messageTimestamp * 1000);
    const run = runtime(process.uptime());
    const platform = os.platform();

    await sock.sendMessage(from, { react: { text: "🤫", key: m.key } });

    const imagePath = path.join(__dirname, './src/media/menuwa.png');

    const headerBotText = `ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴍᴇɴᴜ ᴄᴏᴍᴍᴀɴᴅs ʜᴇʟᴘᴇʀ - ᴍᴅ 👋✨

sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ᴅᴀʟᴀᴍ ᴍᴇɴᴜ ᴄᴏᴍᴍᴀɴᴅ ʜᴇʟᴘᴇʀ - ᴍᴅ,
ʙᴏᴛ ᴡʜᴀᴛsᴀᴘᴘ sᴇʀʙᴀɢᴜɴᴀ ʏᴀɴɢ ᴅɪʀᴀɴᴄᴀɴɢ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜᴅᴀʜᴋᴀɴ ᴀᴋᴛɪᴠɪᴛᴀs ᴠɪʀᴛᴜᴀʟᴍᴜ 💫

🎯 ꜰɪᴛᴜʀ ᴜɴɢɢᴜʟᴀɴ:
🔹 ᴄʜᴇᴋɪɴɢ ғɪʟᴇ 🔍
🔹 ᴜʀʟ ᴛᴏᴘ𝟺ᴛᴏᴘ ɢᴇɴᴇʀᴀᴛᴏʀ 🎶
🔹 ɪᴍᴀɢᴇ ᴇᴅɪᴛ 🖼
🔹 ᴄʀᴇᴀᴛᴇ ғɪɢᴜʀᴇ 🦸‍♂️
🔹 ʙᴇʀᴍᴀɪɴ ɢᴀᴍᴇ 🎮
🔹 ᴅᴏᴡɴʟᴏᴀᴅᴇʀ ɪɢ, ʏᴛ, ᴛᴛ ᴅʟʟ 📟

📂 ꜱᴇᴍᴜᴀ ꜰɪᴛᴜʀ ᴛᴇʀᴛᴀᴛᴀ ʀᴀᴘɪ ᴅᴀʟᴀᴍ ᴍᴇɴᴜ ʏᴀɴɢ ᴍᴜᴅᴀʜ ᴅɪᴀᴋꜱᴇꜱ 🧠✨

━━━━━━━━━━━━━━━━━━━
🚫 ᴛᴏʟᴏɴɢ ᴊᴀɴɢᴀɴ sᴘᴀᴍ ᴄᴏᴍᴍᴀɴᴅ, ᴅᴀɴ  ᴊɪᴋᴀ ᴄᴏᴍᴍᴀɴᴅ ɢᴀɢᴀʟ ᴜʟᴀɴɢ ᴋᴇᴍʙᴀʟɪ
━━━━━━━━━━━━━━━━━━━

⚠️ ʙᴏᴛ ɪɴɪ ꜱᴇᴅᴀɴɢ ᴅɪᴋᴇᴍʙᴀɴɢᴋᴀɴ.
ᴊɪᴋᴀ ᴛᴇʀᴊᴀᴅɪ ʙᴜɢ ᴀᴛᴀᴜ ᴋᴇꜱᴀʟᴀʜᴀɴ, ᴍᴏʜᴏɴ ᴘᴇɴɢᴇʀᴛɪᴀɴ 🙏
ᴅᴜᴋᴜɴɢᴀɴᴍᴜ ꜱᴀɴɢᴀᴛ ʙᴇʀᴀʀᴛɪ ʙᴀɢɪ ᴋᴀᴍɪ ❤️

📩 ᴊɪᴋᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ, ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ʙᴏᴛ 🤝

━━━━━━━━━━━━━━━━━━━
📚 ᴘᴀɴᴅᴜᴀɴ sɪɴɢᴋᴀᴛ :
🔹 ɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ \`.ᴏᴡɴᴇʀ\` ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ɴᴏᴍᴏʀ ᴏᴡɴᴇʀ
🔹 ɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ \`.ᴅᴏɴᴀsɪ\` ᴊɪᴋᴀ ɪɴɢɪɴ ʙᴇʀᴅᴏɴᴀsɪ
🔹 ɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ \`.ᴛᴜᴛᴏʀɪᴀʟ\` ᴀᴛᴀᴜ ʙɪsᴀ ʟᴀɴɢsᴜɴɢ ᴛᴀɴʏᴀ ᴋᴇ ᴀᴅᴍɪɴ \`.ᴀsᴋ\` /  \`.ʀᴇᴘᴏʀᴛ\`
━━━━━━━━━━━━━━━━━━━
\`ꜱᴇʟᴀᴍᴀᴛ ᴍᴇɴɪᴋᴍᴀᴛɪ ʜᴇʟᴘᴇʀ - ᴍᴅ!\``;

    const infoHeader = `◤───「 \`INFO USER\` 」──✦
> ⎆  [ ɴᴀᴍᴀ: ${pushname}
> ⎆  [ ᴍᴏᴅᴇ : ᴘᴜʙʟɪᴄ
> ⎆  [ ᴀᴜᴛʜᴏʀ : @6282311544652
◣──────────❈

◤───「 \`INFO BOT\` 」──✦
> ⎆ ɴᴀᴍᴀ : Helper MD
> ⎆ ʀᴜɴᴛɪᴍᴇ : ${run}
> ⎆ sᴘᴇᴇᴅ : ${speed} ᴍs
> ⎆ ᴘʟᴀᴛғᴏʀᴍ : ${platform}
◣─────────────✦

◤───「 \`SOCIAL MEDIA\` 」──✦
> ⎆ ᴡʜᴀᴛsᴀᴘᴘ : wa.me/6282311544652
> ⎆ ᴅɪsᴄᴏʀᴅ : https://discord.gg/4uzdM25KYv
> ⎆ ᴛᴇʟᴇɢʀᴀᴍ : t.me/hadinihh
> ⎆ ᴛɪᴋᴛᴏᴋ : www.tiktok.com/@hadinih_
> ⎆ ɪɴsᴛᴀɢʀᴀᴍ : https://www.instagram.com/hadinih_
> ⎆ ʏᴏᴜᴛᴜʙᴇ : www.youtube.com/@hadinih
> ⎆ ᴡᴇʙsɪᴛᴇ :
> https://hadytools.vercel.app/ 
> https://hadyofficial.vercel.app/
◣─────────────✦

⚠️ ʙᴏᴛ ɪɴɪ ᴍᴀsɪʜ ʙᴀɴʏᴀᴋ ʙᴜɢ ᴅᴀɴ ᴇʀᴏʀ, ᴊᴀᴅɪ ᴍᴏʜᴏɴ ᴍᴀᴀғ ᴋᴀʟᴀᴜ ᴛɪᴅᴀᴋ ʙᴇᴋᴇʀᴊᴀ 🙏.

📩 ᴊɪᴋᴀ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ ᴀᴛᴀᴜ ᴇʀᴏʀ sɪʟᴀʜᴋᴀɴ, ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ʙᴏᴛ ɢᴜɴᴀᴋᴀɴ .ᴏᴡɴᴇʀ👊🏻.
━━━━━━━━━━━━━━━━━━━
sᴇʟᴀᴍᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʜᴇʟᴘᴇʀ - ᴍᴅ\n\n*_Jangan Di Spam Ya Agar Botnya Bisa Aktif 24 Jam Dan Tidak Terkena Blokir Spam🍁_*`;

    let menuContent = "";
    let isSubMenu = false;

    if (categoryArg === 'categoryhc') {
        isSubMenu = true;
        menuContent = `📑 𝐂𝐚𝐭𝐞𝐠𝐨𝐫𝐲 𝐌𝐞𝐧𝐮 𝐇𝐞𝐥𝐩𝐞𝐫 𝐌𝐃\n\n`;
        fields.forEach(f => {
            menuContent += `📌 .${f.id}\n`;
        });
    } else if (fullBody === '.allmenu') {
        isSubMenu = true;
        menuContent = infoHeader + "\n\n";
        fields.forEach((menu) => {
            menuContent += `◣──────────❈\n◤─「 \`${menu.name}\` 」─✦\n`;
            menu.value.forEach((cmd) => { menuContent += `│⦿ ${cmd}\n`; });
            menuContent += `◣──────────❈\n\n`;
        });
    } else if (categoryArg) {
        isSubMenu = true;
        const selectedFields = fields.filter(f => f.id === categoryArg);
        if (selectedFields.length > 0) {
            menuContent = infoHeader + "\n\n";
            selectedFields.forEach((menu) => {
                menuContent += `◣──────────❈\n◤─「 \`${menu.name}\` 」─✦\n`;
                menu.value.forEach((cmd) => { menuContent += `│⦿ ${cmd}\n`; });
                menuContent += `◣──────────❈\n\n`;
            });
        } else {
            menuContent = headerBotText;
            isSubMenu = false;
        }
    } else {
        menuContent = headerBotText;
    }

    const rows = [
        {
            title: "🛡 𝐀𝐥𝐥 𝐌𝐞𝐧𝐮",
            description: "Menampilkan semua daftar perintah",
            id: ".allmenu"
        },
        ...fields.map(f => ({
            title: f.name,
            description: `Klik untuk perintah ${f.name}`,
            id: `.${f.id}`
        }))
    ];

    const buttonParamsJson = JSON.stringify({
        title: "📋 List Menu",
        sections: [{ title: "Pilih Kategori Menu", rows }]
    });

    let buttons = [];
    if (isSubMenu) {
        buttons = [
            {
                name: "single_select",
                buttonParamsJson: buttonParamsJson
            }
        ];
    } else {
        buttons = [
            {
                name: "single_select",
                buttonParamsJson: buttonParamsJson
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "👑 Owner",
                    id: "ownerhc"
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "📌 Category",
                    id: "categoryhc"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "#⃣ Saluran",
                    url: "https://whatsapp.com/channel/0029Vb6TwQ84tRrw2345Ut1z",
                    merchant_url: "https://whatsapp.com/channel/0029Vb6TwQ84tRrw2345Ut1z"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "🧿 Discord",
                    url: "https://discord.gg/4uzdM25KYv",
                    merchant_url: "https://discord.gg/4uzdM25KYv"
                })
            }
        ];
    }

    let mediaHeader = {};
    if (fs.existsSync(imagePath)) {
        const preparedMedia = await prepareWAMessageMedia({ image: fs.readFileSync(imagePath) }, { upload: sock.waUploadToServer });
        mediaHeader = { 
            title: isSubMenu ? "𝐒𝐮𝐛 𝐌𝐞𝐧𝐮" : "𝐌𝐚𝐢𝐧 𝐌𝐞𝐧𝐮", 
            hasMediaAttachment: true, 
            imageMessage: preparedMedia.imageMessage 
        };
    } else {
        mediaHeader = { title: isSubMenu ? "𝐒𝐮bp 𝐌𝐞𝐧𝐮" : "𝐌𝐚𝐢𝐧 𝐌𝐞𝐧𝐮", hasMediaAttachment: false };
    }

    const msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({ text: menuContent }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "©Created By Hady" }),
                    header: proto.Message.InteractiveMessage.Header.fromObject(mediaHeader),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: buttons
                    })
                })
            }
        }
    }, { quoted: m });

    // Kirim pesan menu utama / sub-menu
    await sock.relayMessage(from, msg.message, { messageId: msg.key.id });

    // Mengirimkan audio HANYA saat perintah adalah .menu
    if (fullBody === '.menu') {
        try {
            const audioUrl = 'http://l.top4top.io/m_3840rwdg70.mp3';
            const response = await axios.get(audioUrl, { responseType: 'arraybuffer' });
            const rawBuffer = Buffer.from(response.data, 'binary');
            const convertedBuffer = await toPTT(rawBuffer);
            
            await sock.sendMessage(from, { 
                audio: convertedBuffer, 
                mimetype: 'audio/mp4', 
                ptt: true
            }, { quoted: m });
        } catch (audioErr) {
            // Silent error jika terjadi kendala pada pengambilan URL atau konversi audio
        }
    }
}