const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');
const menutele = require("./menutele");

/**
 * Setup Telegram Bot 
 * Dipanggil di index.js via telegram.setup(discordClient)
 */
const setup = (discordClient) => {
    const token = process.env.TELEGRAM_TOKEN;

    if (!token) {
        console.error("❌ [Telegram] Token tidak ditemukan di .env");
        return;
    }

    const bot = new Telegraf(token);
    const loadedCommands = new Map();
    const messageHandlers = [];

    // --- Error Handler Global ---
    bot.catch((err, ctx) => {
        console.error(`❌ [Telegram Error] ${ctx.updateType}:`, err);
        const errorMessage = `❌ *Terjadi Kesalahan!*\n\n` +
                             `*Tipe:* ${ctx.updateType}\n` +
                             `*Pesan:* \`${err.message}\``;
        ctx.reply(errorMessage, { parse_mode: 'Markdown' }).catch(console.error);
    });

    // --- MANUAL REQUIRE MENU ---
    menutele.setup(bot);

    // --- AUTO LOAD & REGISTER COMMANDS/LISTENERS ---
    const teleFolder = path.join(__dirname, 'tele');
    if (fs.existsSync(teleFolder)) {
        const files = fs.readdirSync(teleFolder).filter(file => file.endsWith('.js') && file !== 'menutele.js');
        
        for (const file of files) {
            try {
                const module = require(`./tele/${file}`);
                
                // Jika modul memiliki objek commands, masukkan ke Map command global
                if (module.commands && typeof module.commands === 'object') {
                    for (const [cmdName, handlerFn] of Object.entries(module.commands)) {
                        loadedCommands.set(cmdName.toLowerCase(), handlerFn);
                    }
                }

                // Jika modul memiliki handler message non-command (seperti game reply atau auto-backup)
                if (typeof module.handleGameReply === 'function') {
                    messageHandlers.push(module.handleGameReply);
                }
                if (typeof module.initAutoBackup === 'function') {
                    module.initAutoBackup(bot);
                }
            } catch (err) {
                console.error(`❌ [ Telegram Bot ] Gagal memuat modul ${file}:`, err);
            }
        }
        console.log(`✅ [ Telegram Bot ] Sukses Loaded Semua File Di Folder /tele`);
    }

    // --- Handler Bawaan ---
    bot.start((ctx) => {
        const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
        const welcomeMessage = `✨ Welcome To Helper Bot ✨\n\n` +
                               `Hai ${username} 👋!!\n` +
                               `Perkenalkan aku adalah Helper Bot versi telegram, yang dibuat oleh king @hadinihh\n\n` +
                               `Silahkan untuk mencoba semua fitur saya. Tapi, ingat!! Jangan dispam yaa takut eror wok 🗿🤭\n\n` +
                               `Gunakan /menu untuk melihat isi command 🚀\n` +
                               `Selamat menikmati 😁🤭`;
        
        ctx.reply(welcomeMessage);
    });

    bot.command('status', (ctx) => {
        const discordStatus = discordClient.ws.status === 0 ? "Online ✅" : "Offline ❌";
        ctx.reply(`Status Bot Discord & WhatsApp: ${discordStatus}`);
    });

    // =====================================================
    //      SATELLITE LISTENER (1 Listener Utama untuk Semua)
    // =====================================================
    bot.on('message', async (ctx, next) => {
        const text = ctx.message.text || '';
        
        // 1. Cek apakah ini sebuah command (dimulai dengan /)
        if (text.startsWith('/')) {
            const commandName = text.split(' ')[0].substring(1).split('@')[0].toLowerCase();
            
            // Cari eksekusi fungsi dari map commands yang sudah di-load otomatis
            if (loadedCommands.has(commandName)) {
                const handler = loadedCommands.get(commandName);
                if (commandName === 'backup') {
                    return handler(ctx, bot); // Khusus backup butuh instance bot
                }
                return handler(ctx);
            }
        }

        // 2. Jika bukan command, oper ke handlers non-command (seperti deteksi jawaban game)
        for (const handler of messageHandlers) {
            await handler(ctx, () => {});
        }

        return next();
    });

    // --- Launch Bot ---
    bot.launch()
        .then(() => console.log("🚀 Telegram Bot is running..."))
        .catch((err) => console.error("❌ Telegram Launch Error:", err));

    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));

    return bot;
};

module.exports = { setup };