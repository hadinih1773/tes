const { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionsBitField, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbFolder = path.join(__dirname, "../database");
const backupFile = path.join(dbFolder, "serverbackup.json");
const ownerFile = path.join(dbFolder, "owner.json");

// Pastikan database siap
if (!fs.existsSync(dbFolder)) fs.mkdirSync(dbFolder);
if (!fs.existsSync(backupFile)) fs.writeFileSync(backupFile, JSON.stringify({}, null, 2));

const getOwnerId = () => {
  try {
    if (fs.existsSync(ownerFile)) {
      const data = JSON.parse(fs.readFileSync(ownerFile, "utf8"));
      return data.owner;
    }
  } catch (err) {
    console.error("Gagal membaca file owner.json:", err);
  }
  return null;
};

const loadBackups = () => JSON.parse(fs.readFileSync(backupFile, "utf8"));
const saveBackups = (data) => fs.writeFileSync(backupFile, JSON.stringify(data, null, 2));

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("backupserver")
      .setDescription("Backing Up The Entire Server Structure ")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("restoreserver")
      .setDescription("Restore Server Backup Position ")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("server")
          .setDescription("Nama atau ID Server yang telah di-backup")
          .setRequired(true)
          .setAutocomplete(true)
      )
      .toJSON()
  ],

  setup(client) {
    
    // === FUNGSI INTI BACKUP ===
    async function runBackup(guild) {
      const roles = guild.roles.cache
        .filter(r => !r.managed)
        .sort((a, b) => b.position - a.position)
        .map(r => ({
          name: r.name,
          color: r.color,
          hoist: r.hoist,
          permissions: r.permissions.bitfield.toString(),
          mentionable: r.mentionable,
          isEveryone: r.name === "@everyone"
        }));

      const channels = guild.channels.cache
        .filter(c => c.type === ChannelType.GuildCategory || c.type === ChannelType.GuildText || c.type === ChannelType.GuildVoice)
        .map(c => {
          const permissionOverwrites = c.permissionOverwrites.cache.map(o => ({
            id: o.id,
            type: o.type,
            allow: o.allow.bitfield.toString(),
            deny: o.deny.bitfield.toString()
          }));

          return {
            id: c.id,
            name: c.name,
            type: c.type,
            position: c.position,
            parentId: c.parentId,
            nsfw: c.nsfw || false,
            rateLimitPerUser: c.rateLimitPerUser || 0,
            topic: c.topic || null,
            userLimit: c.userLimit || 0,
            permissionOverwrites
          };
        });

      const backups = loadBackups();
      backups[guild.id] = {
        serverName: guild.name,
        backupTime: Date.now(),
        roles,
        channels
      };
      saveBackups(backups);
    }

    // === FUNGSI INTI RESTORE ===
    async function runRestore(guild, backupData) {
      // 1. Hapus semua channel lama yang bisa dihapus
      const currentChannels = await guild.channels.fetch();
      for (const [_, channel] of currentChannels) {
        await channel.delete().catch(() => {});
      }

      // 2. Hapus semua role lama yang bisa dihapus (kecuali @everyone dan managed)
      const currentRoles = await guild.roles.fetch();
      for (const [_, role] of currentRoles) {
        if (role.name !== "@everyone" && !role.managed) {
          await role.delete().catch(() => {});
        }
      }

      // Map untuk menyimpan relasi ID role lama dengan objek role baru
      const roleMap = new Map();

      // 3. Konfigurasi Ulang Role
      for (const rData of backupData.roles) {
        if (rData.isEveryone) {
          // Edit role @everyone bawaan server jika ada datanya
          await guild.roles.everyone.setPermissions(BigInt(rData.permissions)).catch(() => {});
          roleMap.set(guild.id, guild.roles.everyone.id);
        } else {
          const newRole = await guild.roles.create({
            name: rData.name,
            color: rData.color,
            hoist: rData.hoist,
            permissions: BigInt(rData.permissions),
            mentionable: rData.mentionable
          }).catch(() => null);

          if (newRole) {
            const oldRole = guild.roles.cache.find(r => r.name === rData.name);
            if (oldRole) roleMap.set(oldRole.id, newRole.id);
          }
        }
      }

      const categoryMap = new Map();
      const textAndVoiceChannels = [];

      // 4. Urutkan susunan channel berdasarkan posisi
      const sortedChannels = backupData.channels.sort((a, b) => a.position - b.position);

      // 5. Buat Kategori Terlebih Dahulu
      for (const cData of sortedChannels) {
        if (cData.type === ChannelType.GuildCategory) {
          const overwrites = cData.permissionOverwrites.map(o => ({
            id: roleMap.get(o.id) || (o.id === guild.id ? guild.roles.everyone.id : o.id),
            type: o.type,
            allow: BigInt(o.allow),
            deny: BigInt(o.deny)
          }));

          const newCategory = await guild.channels.create({
            name: cData.name,
            type: ChannelType.GuildCategory,
            permissionOverwrites: overwrites
          }).catch(() => null);

          if (newCategory) categoryMap.set(cData.id, newCategory.id);
        } else {
          textAndVoiceChannels.push(cData);
        }
      }

      // 6. Buat Channel Teks dan Voice
      for (const cData of textAndVoiceChannels) {
        const overwrites = cData.permissionOverwrites.map(o => ({
          id: roleMap.get(o.id) || (o.id === guild.id ? guild.roles.everyone.id : o.id),
          type: o.type,
          allow: BigInt(o.allow),
          deny: BigInt(o.deny)
        }));

        await guild.channels.create({
          name: cData.name,
          type: cData.type,
          parent: categoryMap.get(cData.parentId) || null,
          nsfw: cData.nsfw,
          topic: cData.topic,
          rateLimitPerUser: cData.rateLimitPerUser,
          userLimit: cData.userLimit,
          permissionOverwrites: overwrites
        }).catch(() => null);
      }
    }

    // === HANDLE INTERACTION (SLASH COMMAND & AUTOCOMPLETE) ===
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      const ownerId = getOwnerId();

      // HANDLE AUTOCOMPLETE UNTUK RESTORESERVER
      if (interaction.isAutocomplete()) {
        if (interaction.commandName !== "restoreserver") return;
        if (interaction.user.id !== ownerId) return await interaction.respond([]);

        const focusedValue = interaction.options.getFocused().toLowerCase();
        const backups = loadBackups();
        
        const choices = Object.keys(backups).map(id => ({
          name: backups[id].serverName,
          value: id
        }));

        const filtered = choices.filter(choice =>
          choice.name.toLowerCase().includes(focusedValue) || choice.value.includes(focusedValue)
        ).slice(0, 25); // Maksimal 25 opsi pilihan di Discord

        return await interaction.respond(filtered);
      }

      // HANDLE SLASH COMMANDS EXECUTION
      if (!interaction.isChatInputCommand()) return;
      
      const { commandName, options, guild, user } = interaction;

      if (commandName === "backupserver" || commandName === "restoreserver") {
        if (user.id !== ownerId) {
          return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
        }
      }

      if (commandName === "backupserver") {
        await interaction.deferReply({ ephemeral: true });
        try {
          await runBackup(guild);
          await interaction.editReply({ content: `✅ Struktur server **${guild.name}** berhasil dicadangkan ke database.` });
        } catch (err) {
          console.error(err);
          await interaction.editReply({ content: "❌ Terjadi kesalahan saat melakukan backup." });
        }
      }

      if (commandName === "restoreserver") {
        await interaction.deferReply({ ephemeral: true });
        const backupKey = options.getString("server");
        const backups = loadBackups();

        if (!backups[backupKey]) {
          return interaction.editReply({ content: "❌ Data cadangan server tidak ditemukan." });
        }

        try {
          await runRestore(guild, backups[backupKey]);
          await interaction.editReply({ content: "✅ Pemulihan struktur server selesai dilakukan sesuai data cadangan!" });
        } catch (err) {
          console.error(err);
          await interaction.editReply({ content: "❌ Terjadi kesalahan saat memulihan struktur server." });
        }
      }
    });

  }
};