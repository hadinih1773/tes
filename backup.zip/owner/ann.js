const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("ann")
      .setDescription("Announcement Message With Using Bot")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("deskripsi")
          .setDescription("Isi deskripsi pengumuman")
          .setRequired(true))
      .addStringOption(option => 
        option.setName("topic")
          .setDescription("Nama pengirim/topik pengumuman (opsional)")
          .setRequired(false))
      .addChannelOption(option => 
        option.setName("channel")
          .setDescription("Pilih channel tujuan (opsional)")
          .setRequired(false))
      .addBooleanOption(option => 
        option.setName("embed")
          .setDescription("Gunakan format embed? (True = Embed + @everyone)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("tittle")
          .setDescription("Judul pengumuman (opsional)")
          .setRequired(false))
      .addAttachmentOption(option => 
        option.setName("image")
          .setDescription("Upload gambar utama (opsional)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("image_url")
          .setDescription("Link gambar utama (opsional)")
          .setRequired(false))
      .addAttachmentOption(option => 
        option.setName("thumbnail")
          .setDescription("Upload gambar thumbnail (opsional)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("thumbnail_url")
          .setDescription("Link gambar thumbnail (opsional)")
          .setRequired(false))
      .toJSON()
  ],

  async setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      const { commandName, options, channel } = interaction;

      // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
      const validCommands = ["ann"];
      if (!validCommands.includes(commandName)) return;

      // Proteksi Owner dari database/owner.json
      try {
        const ownerDataPath = path.join(__dirname, "../database/owner.json");
        const ownerData = JSON.parse(fs.readFileSync(ownerDataPath, "utf8"));
        
        if (interaction.user.id !== ownerData.owner) {
          return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
        }
      } catch (err) {
        console.error("Gagal membaca file owner.json:", err);
        return interaction.reply({ content: "❌ Terjadi kesalahan saat memvalidasi status Owner.", ephemeral: true });
      }

      if (commandName === "ann") {
        const deskripsi = options.getString("deskripsi");
        const topic = options.getString("topic");
        const targetChannel = options.getChannel("channel") || channel;
        const useEmbed = options.getBoolean("embed") || false;
        const title = options.getString("tittle");
        
        const imageFile = options.getAttachment("image");
        const imageUrlInput = options.getString("image_url");
        const image = imageFile ? imageFile.url : imageUrlInput;

        const thumbnailFile = options.getAttachment("thumbnail");
        const thumbnailUrlInput = options.getString("thumbnail_url");
        const thumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

        await interaction.deferReply({ ephemeral: true });

        try {
          const webhooks = await targetChannel.fetchWebhooks();
          let webhook = webhooks.find(wh => wh.name === "Hady Announcement WH");

          if (!webhook) {
            webhook = await targetChannel.createWebhook({
              name: "Hady Announcement WH",
              avatar: client.user.displayAvatarURL(),
            });
          }

          // Jika topic diisi maka pakai topic, jika tidak pakai nama default
          const webhookName = topic ? topic : "📢 Hady Community Daily Announcement";

          const payload = {
            username: webhookName,
            avatarURL: client.user.displayAvatarURL(),
          };

          if (useEmbed) {
            const embed = new EmbedBuilder()
              .setDescription(deskripsi)
              .setColor("#0099ff")
              .setTimestamp();

            if (title) embed.setTitle(title);
            if (image) embed.setImage(image);
            if (thumbnail) embed.setThumbnail(thumbnail);

            payload.content = "@everyone";
            payload.embeds = [embed];
          } else {
            payload.content = deskripsi;
            payload.embeds = [];
            
            // Jika tidak embed tapi ada image, kirim sebagai attachment pesan biasa
            if (image) {
              payload.files = [image];
            }
          }

          await webhook.send(payload);
          await interaction.editReply({ content: `✅ Pengumuman berhasil dikirim ke ${targetChannel}!` });
        } catch (error) {
          console.error(error);
          await interaction.editReply({ content: "❌ Gagal mengirim pengumuman." });
        }
      }
    });
  }
};