const os = require("os");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const {
  EmbedBuilder,
  SlashCommandBuilder,
  REST,
  Routes,
  PermissionFlagsBits
} = require("discord.js");

const ownerData = require("../database/owner.json");
const OWNER_ID = ownerData.owner;
const FILE_PATH = __filename;

module.exports = {
  data: new SlashCommandBuilder()
    .setName("restart")
    .setDescription("Restart Hosting Your Bot ")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .toJSON(),

  async setup(client) {
    /* ================= FILE WATCHER (RINGAN) ================= */
    fs.watchFile(FILE_PATH, { interval: 5000 }, (curr) => {
      if (curr.nlink === 0) {
        console.log("⚠️ monitor.js terhapus, slash command akan hilang setelah restart");
      }
    });

    /* ================= SLASH COMMAND HANDLER ================= */
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== "restart") return;

      if (interaction.user.id !== OWNER_ID) {
        return interaction.reply({
          content: "❌ Hanya Owner Yang Bisa Gunakan",
          ephemeral: true
        });
      }

      await interaction.reply({
        content: "♻️ Bot sedang restart...",
        ephemeral: true
      });
      setTimeout(() => process.exit(0), 1000);
    });

    /* ================= MESSAGE COMMAND ================= */
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;

      const prefix = "!";
      if (!message.content.startsWith(prefix)) return;

      const args = message.content.slice(prefix.length).trim().split(/ +/);
      const cmd = args.shift().toLowerCase();

      /* ================= RESTART (Message Command) ================= */
      if (cmd === "restart") {
        if (message.author.id !== OWNER_ID) {
          return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
        }

        await message.reply("♻️ Bot sedang restart...");
        setTimeout(() => process.exit(0), 1000);
      }

      /* ================= PING (Embed Potong) ================= */
      if (cmd === "ping") {
        const start = Date.now();
        await new Promise(r => setTimeout(r, 10)); 
        const pingValue = Date.now() - start; // Diubah ke milidetik (ms)

        let osDistro = "Ubuntu 25.04";
        try {
          osDistro = execSync('lsb_release -ds').toString().replace(/"/g, "").trim();
        } catch (e) {
          osDistro = `${os.type()} ${os.release()}`;
        }

        const totalRam = (os.totalmem() / (1024 ** 3)).toFixed(0);
        const usedRam = (process.memoryUsage().rss / (1024 ** 2)).toFixed(2);

        let diskTotal = "0", diskUsed = "0", diskFree = "0", diskPercent = "0";
        try {
          const df = execSync('df -h / --output=size,used,avail,pcent').toString().split('\n')[1].split(/\s+/);
          diskTotal = df[1]; diskUsed = df[2]; diskFree = df[3]; diskPercent = df[4];
        } catch (e) { diskPercent = "0%"; }

        const uptimeMin = Math.floor(process.uptime() / 60);
        const cpus = os.cpus();
        const times = cpus[0].times;
        const totalTicks = Object.values(times).reduce((acc, tv) => acc + tv, 0);
        const getPerc = (tick) => ((tick / totalTicks) * 100).toFixed(2);
        
        const usedP = parseInt(diskPercent);
        const freeP = 100 - usedP;

        // Embed: Info (Format Baru Tanpa RAM & Penyimpanan)
        const embed2 = new EmbedBuilder()
          .setColor("Blue")
          .setDescription(
`📡 **JARINGAN SERVER**
- Ping: ${pingValue} ms

📢 **INFO SERVER**
- OS: ${osDistro}
- Type OS: ${os.type()}

⏰ **RUNTIME SERVER**
Aktif:
${uptimeMin}m

🖨 **CPU USAGE (${cpus.length} CORE CPU)**
${cpus[0].model} (${cpus[0].speed} MHZ)
- *user* : ${getPerc(times.user)}%
- *nice* : ${getPerc(times.nice)}%
- *sys* : ${getPerc(times.sys)}%
- *idle* : ${getPerc(times.idle)}%
- *irq* : ${getPerc(times.irq)}%`
          );

        return message.reply({ 
          embeds: [embed2]
        });
      }

      /* ================= MONITOR ================= */
      if (cmd === "monitor") {
        if (message.author.id !== OWNER_ID) {
          return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
        }

        const startLoop = process.hrtime.bigint();
        await new Promise(r => setImmediate(r));
        const endLoop = process.hrtime.bigint();
        const eventLoopDelay = Number(endLoop - startLoop) / 1e6;
        const speedBot = (eventLoopDelay + client.ws.ping).toFixed(2);

        let fsStatus = "✅ Normal";
        let wsStatus = "✅ Normal";
        try {
          fs.accessSync(process.cwd());
        } catch {
          fsStatus = "❌ FileSystem Error";
        }
        if (client.ws.ping < 0) wsStatus = "❌ WebSocket Error";

        const mem = process.memoryUsage();
        const cpu = os.cpus()[0];
        const uptime = process.uptime();

        const embed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle("🖥️ BOT SYSTEM MONITOR")
          .addFields(
            { name: "🧠 Platform", value: os.platform(), inline: true },
            { name: "⚙️ Node.js", value: process.version, inline: true },
            { name: "📦 Architecture", value: os.arch(), inline: true },
            { name: "⏱️ Uptime", value: `${Math.floor(uptime)} detik`, inline: true },
            { name: "📡 WS Ping", value: `${client.ws.ping} ms`, inline: true },
            { name: "⚡ Speed Bot", value: `${speedBot} ms`, inline: true },
            { name: "🧠 CPU Model", value: cpu.model, inline: false },
            { name: "⚡ CPU Speed", value: `${cpu.speed} MHz`, inline: true },
            { name: "📊 CPU Core", value: `${os.cpus().length}`, inline: true },
            { name: "💾 RAM Used", value: `${(mem.rss / 1024 / 1024).toFixed(2)} MB`, inline: true },
            { name: "💾 RAM Heap", value: `${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
            { name: "💾 RAM Total", value: `${(os.totalmem() / 1024 / 1024).toFixed(0)} MB`, inline: true },
            { name: "📁 File System", value: fsStatus, inline: true },
            { name: "🔗 WebSocket", value: wsStatus, inline: true },
            {
              name: "🚨 ERROR SUMMARY",
              value: wsStatus.includes("❌") || fsStatus.includes("❌") ? "❌ ADA KOMPONEN ERROR" : "✅ SEMUA NORMAL",
              inline: false
            }
          )
          .setFooter({ text: "Full Bot Health Monitor" });

        return message.reply({ embeds: [embed] });
      }
    });
  }
};