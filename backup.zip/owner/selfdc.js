const fs = require("fs");
const path = require("path");

const ownerPath = path.join(__dirname, "../database/owner.json");
const selfPath = path.join(__dirname, "../database/self.json");

function getOwnerId() {
    try {
        const data = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
        return data.owner;
    } catch (err) {
        return null;
    }
}

function getSelfData() {
    try {
        if (!fs.existsSync(selfPath)) return {};
        const data = JSON.parse(fs.readFileSync(selfPath, "utf8"));
        return (data && typeof data === "object" && !Array.isArray(data)) ? data : {};
    } catch (err) {
        return {};
    }
}

function saveSelfData(data) {
    fs.writeFileSync(selfPath, JSON.stringify(data, null, 2));
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const prefix = "!";
      if (!message.content.startsWith(prefix)) return;

      const args = message.content.slice(prefix.length).trim().split(/\s+/);
      const command = args.shift().toLowerCase();

      if (!["self", "public", "selfall", "publicall"].includes(command)) return;

      const ownerId = getOwnerId();
      if (!ownerId || message.author.id !== ownerId) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }

      let selfData = getSelfData();

      if (command === "self") {
        selfData[message.guild.id] = true;
        saveSelfData(selfData);
        return message.reply("✅ Bot Telah Di Self Semua Fitur Hanya Bisa Diakses Oleh Owner");
      }

      if (command === "public") {
        selfData[message.guild.id] = false;
        saveSelfData(selfData);
        return message.reply("✅ Semua Fitur Telah Bisa Diakses");
      }

      if (command === "selfall") {
        client.guilds.cache.forEach(guild => {
          selfData[guild.id] = true;
        });
        saveSelfData(selfData);
        return message.reply("✅ Semua Guild ID Di Self Hanya Owner Yang Bisa Akses");
      }

      if (command === "publicall") {
        client.guilds.cache.forEach(guild => {
          selfData[guild.id] = false;
        });
        saveSelfData(selfData);
        return message.reply("✅ Semua Guild ID Bisa Akses Fitur");
      }
    });
  }
};
