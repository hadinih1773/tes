// owner.js

const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

const fs = require("fs");

const path = require("path");

const ownerFile = path.join(__dirname, "..", "database", "owner.json");

const sambutanFile = path.join(__dirname, "..", "database", "sambutan.json");

// ambil owner

const OWNER_ID = JSON.parse(fs.readFileSync(ownerFile, "utf8")).owner;

// ambil sambutan on/off dari file sambutan.json

let sambutanAktif = true;

if (fs.existsSync(sambutanFile)) {

  try {

    const data = JSON.parse(fs.readFileSync(sambutanFile, "utf8"));

    sambutanAktif = data.status;

  } catch (err) {

    sambutanAktif = true;

  }

}

let lastOwnerMessage = 0;

const OWNER_TIMEOUT = 15 * 60 * 1000; // 15 menit

module.exports = {

setup(client) {

  // ============================

  // INTERACTION BUTTON SOCIAL

  // ============================

  (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {  

    if (!interaction.isButton()) return;  

    

    const links = {

      "btn_yt": "https://www.youtube.com/@hadinih",

      "btn_tt": "https://www.tiktok.com/@hadinih_?_t=ZS-90TZ3PGNoiy&_r=1",

      "btn_tx": "https://x.com/hadinih_?t=_wqwZxUhvYUAMOpSsElwRw&s=08",

      "btn_wa": "https://whatsapp.com/channel/0029Vb6TwQ84tRrw2345Ut1z",

      "btn_ig": "https://www.instagram.com/hadinih_?igsh=MWl4NjY3cWEyNXEwMg=="

    };

    if (links[interaction.customId]) {

      return interaction.reply({

        content: links[interaction.customId],

        flags: 64

      });

    }

  });  

  // ============================

  // MESSAGE EVENT

  // ============================

  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {  

    if (message.author.bot) return;  

    const msg = message.content.toLowerCase();  

    // =====================================================

    //                COMMAND !owner

    // =====================================================

    if (msg === "!owner") {  

      if (!OWNER_ID)

        return message.reply("❌ Owner belum diset.");  

      await message.channel.sendTyping();

      const user = await client.users.fetch(OWNER_ID).catch(() => null);  

      const avatar = user ? user.displayAvatarURL({ size: 1024 }) : null;  

      const embed = new EmbedBuilder()  

        .setColor("Blue")  

        .setTitle("🤴 Owner Community")  

        .setDescription(`Inilah orang yang dibalik berdirinya Hady Community jangan ragu untuk bertanya atau mengobrol langsung saja tag\n\nOwner: <@${OWNER_ID}>`)

        .setThumbnail(avatar)  

        .setTimestamp();  

      const row1 = new ActionRowBuilder().addComponents(

        new ButtonBuilder().setCustomId("btn_yt").setLabel("YouTube").setStyle(ButtonStyle.Danger),

        new ButtonBuilder().setCustomId("btn_tt").setLabel("Tiktok").setStyle(ButtonStyle.Secondary),

        new ButtonBuilder().setCustomId("btn_tx").setLabel("Twitter/X").setStyle(ButtonStyle.Secondary),

        new ButtonBuilder().setCustomId("btn_wa").setLabel("Saluran WhatsApp").setStyle(ButtonStyle.Success),

        new ButtonBuilder().setCustomId("btn_ig").setLabel("Instagram").setStyle(ButtonStyle.Primary)

      );

      const row2 = new ActionRowBuilder().addComponents(

        new ButtonBuilder().setLabel("Website Linktree").setURL("https://linktr.ee/hadinih_").setStyle(ButtonStyle.Link),

        new ButtonBuilder().setLabel("Website Lynk.id").setURL("https://lynk.id/hadinih").setStyle(ButtonStyle.Link)

      );

      return message.channel.send({  

        embeds: [embed],  

        components: [row1, row2]  

      });  

    }  

    // =====================================================

    //       COMMAND !sambutan on / off (KHUSUS OWNER)

    // =====================================================

    if (msg === "!sambutan on") {

      if (message.author.id !== OWNER_ID)

        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");

      sambutanAktif = true;

      fs.writeFileSync(sambutanFile, JSON.stringify({ status: true }, null, 2));

      return message.reply("✅ Sambutan owner berhasil **diaktifkan**.");

    }

    if (msg === "!sambutan off") {

      if (message.author.id !== OWNER_ID)

        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");

      sambutanAktif = false;

      fs.writeFileSync(sambutanFile, JSON.stringify({ status: false }, null, 2));

      return message.reply("❌ Sambutan owner berhasil **dimatikan**.");

    }

    // =====================================================

    //              FITUR SAMBUTAN OWNER

    // =====================================================

    if (message.author.id === OWNER_ID) {  

      if (!sambutanAktif) return;  

      const now = Date.now();  

      const sudahLebih = (now - lastOwnerMessage) >= OWNER_TIMEOUT;  

      lastOwnerMessage = now;  

      if (!sudahLebih) return;  

      const avatar = message.author.displayAvatarURL({ size: 1024 });  

      const welcomeOwner = new EmbedBuilder()  

        .setColor("Blue")  

        .setTitle("[ 📢 DINGG ]")  

        .setDescription(`Ownerku telah tiba sambutlah dia. Jika kalian ada yang mau ditanyakan silahkan /ask saja atau langsung tag dia. \nOwner Joined The Chat <@${OWNER_ID}>`)

        .setImage(avatar)  

        .setTimestamp();  

      await message.reply({ embeds: [welcomeOwner] });  

    }  

  });

}

};