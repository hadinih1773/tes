const fs = require("fs");
const path = require("path");
const {
  EmbedBuilder,
  SlashCommandBuilder,
  Events,
  PermissionFlagsBits
} = require("discord.js");

const ownerPath = path.join(__dirname, "../database/owner.json");
const filePath = __filename;

/* ===== LOAD OWNER ===== */
function loadOwner() {
  try {
    const raw = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
    return String(raw.owner);
  } catch {
    return null;
  }
}

/* ===== FILE WATCHER (AMAN, RINGAN) ===== */
fs.watch(path.dirname(filePath), (event, filename) => {
  if (filename === path.basename(filePath)) {
    if (!fs.existsSync(filePath)) {
      console.log("⚠️ changelogs.js dihapus, slash command akan terhapus setelah restart");
    }
  }
});

module.exports = {
  data: new SlashCommandBuilder()
    .setName("changelogs")
    .setDescription("Updates And Changelogs Message Bot")
    .addStringOption(o =>
      o.setName("tittle").setDescription("Judul embed").setRequired(true)
    )
    .addStringOption(o =>
      o.setName("deskripsi").setDescription("Isi deskripsi").setRequired(true)
    )
    .addChannelOption(o =>
      o.setName("channel").setDescription("Channel tujuan")
    )
    .addBooleanOption(o =>
      o.setName("embed").setDescription("Gunakan embed atau tidak")
    )
    .addStringOption(o =>
      o.setName("color").setDescription("Hex color embed")
    )
    .addAttachmentOption(o =>
      o.setName("image").setDescription("Gambar embed")
    )
    .addStringOption(o =>
      o.setName("image_url").setDescription("Link gambar embed")
    )
    .addAttachmentOption(o =>
      o.setName("thumbnail").setDescription("Thumbnail embed")
    )
    .addStringOption(o =>
      o.setName("thumbnail_url").setDescription("Link thumbnail embed")
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .toJSON(),

  setup(client) {
    /* ================= HELPER WEBHOOK ================= */
    async function sendChangelogWebhook(channel, payload) {
      try {
        const webhooks = await channel.fetchWebhooks();
        let webhook = webhooks.find(wh => wh.name === "Hady Changelog WH");

        if (!webhook) {
          webhook = await channel.createWebhook({
            name: "Hady Changelog WH",
            avatar: client.user.displayAvatarURL(),
          });
        }

        await webhook.send({
          username: "🛠 Changelogs HC Helper",
          avatarURL: client.user.displayAvatarURL(),
          ...payload
        });
        return true;
      } catch (error) {
        console.error("Webhook Error:", error);
        await channel.send(payload);
        return false;
      }
    }

    /* ================= SLASH HANDLER ================= */
    client.on(Events.InteractionCreate, async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== "changelogs") return;

      const OWNER_ID = loadOwner();
      if (!OWNER_ID || interaction.user.id !== OWNER_ID) {
        return interaction.reply({
          content: "❌ Hanya Owner Yang Bisa Gunakan",
          ephemeral: true
        });
      }

      const title = interaction.options.getString("tittle");
      const desc = interaction.options.getString("deskripsi");
      const targetChannel =
        interaction.options.getChannel("channel") || interaction.channel;
      const useEmbed = interaction.options.getBoolean("embed") ?? true;
      const colorHex = interaction.options.getString("color") || "#3498db";
      
      const imageFile = interaction.options.getAttachment("image");
      const imageUrlInput = interaction.options.getString("image_url");
      const image = imageFile ? imageFile.url : imageUrlInput;

      const thumbFile = interaction.options.getAttachment("thumbnail");
      const thumbUrlInput = interaction.options.getString("thumbnail_url");
      const thumb = thumbFile ? thumbFile.url : thumbUrlInput;

      const payload = { content: "@everyone" };

      if (!useEmbed) {
        payload.content += "\n" + desc;
      } else {
        const embed = new EmbedBuilder()
          .setTitle(title)
          .setDescription(desc)
          .setColor(colorHex)
          .setFooter({
            text: `Changelogs By ${interaction.user.username} • ${new Date().toLocaleDateString()}`
          });

        if (image) embed.setImage(image);
        if (thumb) embed.setThumbnail(thumb);
        payload.embeds = [embed];
      }

      await sendChangelogWebhook(targetChannel, payload);
      await interaction.reply({
        content: "✅ Changelogs terkirim",
        ephemeral: true
      });
    });

    /* ================= MESSAGE COMMAND ================= */
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;
      if (!message.content.startsWith("!changelogs")) return;

      const OWNER_ID = loadOwner();
      if (!OWNER_ID || message.author.id !== OWNER_ID) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }

      const raw = message.content.slice("!changelogs".length).trim();
      const parts = raw.split("|");
      if (parts.length < 3) {
        return message.reply("❌ Format Salah : `!changelogs|tittle|deskripsi`");
      }

      const title = parts[1];
      const desc = parts.slice(2).join("|");
        
      await message.delete().catch(() => {});    

      const embed = new EmbedBuilder()
        .setColor("Blue")
        .setTitle(title)
        .setDescription(desc)
        .setFooter({
          text: `Changelogs By ${message.author.username} • ${new Date().toLocaleDateString()}`
        });

      await sendChangelogWebhook(message.channel, {
        content: "@everyone",
        embeds: [embed]
      });
    });
  }
};