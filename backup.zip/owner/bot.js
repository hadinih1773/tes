// bot.js

const fs = require("fs");

const path = require("path");

const ownerFile = path.join(__dirname, "..", "database", "owner.json");

/* ===== LOAD OWNER ===== */

function loadOwner() {

  try {

    const raw = JSON.parse(fs.readFileSync(ownerFile, "utf8"));

    return String(raw.owner);

  } catch {

    return null;

  }

}

module.exports = {

  setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

      if (message.author.bot) return;

      const args = message.content.split(" ");

      const command = args[0].toLowerCase();

      const content = message.content.slice(command.length).trim();

      // Cek list command yang butuh akses owner
      const ownerCommands = ["!setnamebot", "!setbiobot", "!setppbot", "!setbannerbot"];

      if (ownerCommands.includes(command)) {
        const OWNER_ID = loadOwner();
        if (message.author.id !== OWNER_ID) {
          return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
        }
      } else {
        return;
      }

      // =====================================================

      //                COMMAND !setnamebot

      // =====================================================

      if (command === "!setnamebot") {

        if (!content) return message.reply("❌ Format Salah : ``!setnamebot name``");

        try {

          await client.user.setUsername(content);

          return message.reply(`✅ Nama bot berhasil diubah menjadi: **${content}**`);

        } catch (err) {

          return message.reply("❌ Gagal mengubah nama.");

        }

      }

      // =====================================================

      //                COMMAND !setbiobot

      // =====================================================

      if (command === "!setbiobot") {

        if (!content) return message.reply("❌ Format Salah : ``!setdeskbot text``");

        try {

          await client.user.setAboutMe(content);

          return message.reply("✅ Deskripsi bot berhasil diubah.");

        } catch (err) {

          return message.reply("❌ Gagal mengubah deskripsi.");

        }

      }

      // =====================================================

      //                COMMAND !setppbot

      // =====================================================

      if (command === "!setppbot") {

        let image = message.attachments.first();

        

        if (!image && message.reference) {

          const repliedMsg = await message.channel.messages.fetch(message.reference.messageId);

          image = repliedMsg.attachments.first();

        }

        if (!image) return message.reply("Kirim gambar atau reply gambar dengan command ini.");

        try {

          await client.user.setAvatar(image.url);

          return message.reply("✅ Foto profil bot berhasil diubah.");

        } catch (err) {

          return message.reply("❌ Gagal mengubah foto profil.");

        }

      }

      // =====================================================

      //                COMMAND !setbannerbot

      // =====================================================

      if (command === "!setbannerbot") {

        let image = message.attachments.first();

        

        if (!image && message.reference) {

          const repliedMsg = await message.channel.messages.fetch(message.reference.messageId);

          image = repliedMsg.attachments.first();

        }

        if (!image) return message.reply("Kirim gambar atau reply gambar dengan command ini.");

        try {

          await client.user.setBanner(image.url);

          return message.reply("✅ Banner bot berhasil diubah.");

        } catch (err) {

          return message.reply("❌ Gagal mengubah banner.");

        }

      }

    });

  }

};