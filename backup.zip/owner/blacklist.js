const fs = require("fs");
const path = require("path");

const ownerPath = path.join(__dirname, "../database/owner.json");
const blacklistPath = path.join(__dirname, "../database/blacklist.json");

function getOwnerId() {
    try {
        const data = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
        return data.owner;
    } catch (err) {
        return null;
    }
}

function getBlacklist() {
    try {
        if (!fs.existsSync(blacklistPath)) return [];
        const data = JSON.parse(fs.readFileSync(blacklistPath, "utf8"));
        return Array.isArray(data) ? data : [];
    } catch (err) {
        return [];
    }
}

function saveBlacklist(list) {
    fs.writeFileSync(blacklistPath, JSON.stringify(list, null, 2));
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const prefix = "!";
      if (!message.content.startsWith(prefix)) return;

      const args = message.content.slice(prefix.length).trim().split(/\s+/);
      const command = args.shift().toLowerCase();

      if (!["blacklist", "bl", "unblacklist", "unbl"].includes(command)) return;

      const ownerId = getOwnerId();
      if (!ownerId || message.author.id !== ownerId) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }

      const mentioned = message.mentions.users.first();
      const targetId = mentioned ? mentioned.id : args[0];

      if (!targetId) {
        return message.reply(`❌ Format Salah : \`\`!${command} @user/id\`\``);
      }

      const tag = `<@${targetId}>`;
      let blacklist = getBlacklist();

      if (command === "blacklist" || command === "bl") {
        if (!blacklist.includes(targetId)) {
          blacklist.push(targetId);
          saveBlacklist(blacklist);
        }
        return message.reply(`✅ ${tag} Berhasil Di Blacklist. Tidak Akan Bisa Menggunakan Bot`);
      }

      if (command === "unblacklist" || command === "unbl") {
        blacklist = blacklist.filter(id => id !== targetId);
        saveBlacklist(blacklist);
        return message.reply(`✅ ${tag} Berhasil Dihapus Dari Blacklist. Sudah Bisa Menggunakan Bot Kembali`);
      }
    });
  }
};
