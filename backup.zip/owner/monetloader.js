const fs = require("fs");
const path = require("path");
const {
  EmbedBuilder,
  SlashCommandBuilder,
  Events,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits
} = require("discord.js");

const ownerPath = path.join(__dirname, "../database/owner.json");
const filePath = __filename;

/* ===== LOAD OWNER ===== */
function loadOwner() {
  try {
    const raw = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
    return String(raw.owner);
  } catch {
    return null;
  }
}

/* ===== FILE WATCHER (AMAN, RINGAN) ===== */
fs.watch(path.dirname(filePath), (event, filename) => {
  if (filename === path.basename(filePath)) {
    if (!fs.existsSync(filePath)) {
      console.log("⚠️ MonetLoader.js dihapus, slash command akan terhapus setelah restart");
    }
  }
});

module.exports = {
  data: new SlashCommandBuilder()
    .setName("monetloader")
    .setDescription("Send Your Monetloader To Server")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(o =>
      o.setName("tittle").setDescription("Judul embed").setRequired(true)
    )
    .addStringOption(o =>
      o.setName("deskripsi").setDescription("Isi deskripsi").setRequired(true)
    )
    .addChannelOption(o =>
      o.setName("channel").setDescription("Channel tujuan")
    )
    .addStringOption(o =>
      o.setName("link_download").setDescription("Link Download")
    )
    .addBooleanOption(o =>
      o.setName("embed").setDescription("Gunakan embed atau tidak")
    )
    .addStringOption(o =>
      o.setName("color").setDescription("Hex color embed")
    )
    .addAttachmentOption(o =>
      o.setName("image").setDescription("Gambar embed")
    )
    .addStringOption(o =>
      o.setName("image_url").setDescription("Link gambar embed")
    )
    .addAttachmentOption(o =>
      o.setName("thumbnail").setDescription("Thumbnail embed")
    )
    .addStringOption(o =>
      o.setName("thumbnail_url").setDescription("Link thumbnail embed")
    )
    .toJSON(),

  setup(client) {
    /* ================= SLASH HANDLER ================= */
    client.on(Events.InteractionCreate, async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== "monetloader") return;

      const OWNER_ID = loadOwner();
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator) && interaction.user.id !== OWNER_ID) {
        return interaction.reply({
          content: "❌ Hanya Admin Yang Bisa Gunakan",
          ephemeral: true
        });
      }

      const title = interaction.options.getString("tittle");
      const desc = interaction.options.getString("deskripsi");
      const channel = interaction.options.getChannel("channel") || interaction.channel;
      const downloadLink = interaction.options.getString("link_download");
      const useEmbed = interaction.options.getBoolean("embed") ?? true;
      const colorHex = interaction.options.getString("color") || "#50c878";
      
      const imageFile = interaction.options.getAttachment("image");
      const imageUrlInput = interaction.options.getString("image_url");
      const image = imageFile ? imageFile.url : imageUrlInput;

      const thumbFile = interaction.options.getAttachment("thumbnail");
      const thumbUrlInput = interaction.options.getString("thumbnail_url");
      const thumb = thumbFile ? thumbFile.url : thumbUrlInput;

      const row = new ActionRowBuilder();
      if (downloadLink) {
        row.addComponents(
          new ButtonBuilder()
            .setLabel("Download")
            .setURL(downloadLink)
            .setStyle(ButtonStyle.Link)
        );
      }

      if (!useEmbed) {
        await channel.send({
          content: "@everyone\n" + desc,
          components: downloadLink ? [row] : []
        });
        return interaction.reply({
          content: "✅ MonetLoader terkirim",
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(desc)
        .setColor(colorHex)
        .setFooter({
          text: `Share By ${interaction.user.username} • ${new Date().toLocaleDateString()}`
        });

      if (image) embed.setImage(image);
      if (thumb) embed.setThumbnail(thumb);

      await channel.send({
        content: "@everyone",
        embeds: [embed],
        components: downloadLink ? [row] : []
      });

      await interaction.reply({
        content: "✅ MonetLoader terkirim",
        ephemeral: true
      });
    });

    /* ================= MESSAGE COMMAND ================= */
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;
      if (!message.content.startsWith("!monetloader")) return;

      const OWNER_ID = loadOwner();
      if (!message.member.permissions.has(PermissionFlagsBits.Administrator) && message.author.id !== OWNER_ID) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      const raw = message.content.slice("!monetloader".length).trim();
      const parts = raw.split("|");
      if (parts.length < 3) {
        return message.reply("❌ Format Salah : `!monetloader|tittle|deskripsi`");
      }

      const title = parts[1];
      const desc = parts.slice(2).join("|");
        
      await message.delete().catch(() => {});    
      const embed = new EmbedBuilder()
        .setColor("#50c878")
        .setTitle(title)
        .setDescription(desc)
        .setFooter({
          text: `Share By ${message.author.username} • ${new Date().toLocaleDateString()}`
        });

      await message.channel.send({
        content: "@everyone",
        embeds: [embed]
      });
    });
  }
};