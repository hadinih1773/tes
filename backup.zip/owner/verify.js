const { 
  SlashCommandBuilder, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle,
  PermissionFlagsBits
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../database/verify.json");
const ownerPath = path.join(__dirname, "../database/owner.json");

if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true });
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));

// --- HELPER FUNCTIONS ---
function getOwner() {
  try {
    const data = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
    return data.owner;
  } catch { return null; }
}

function saveVerifyData(guildId, roleId, messageId, channelId) {
  const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
  if (!data[guildId]) data[guildId] = [];
  data[guildId].push({ roleId, messageId, channelId });
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function getVerifyData(guildId) {
  const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
  return data[guildId];
}

function generateCaptcha(length = 6) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

const captchaCache = new Map();
const cooldowns = new Map();

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("handleverify")
      .setDescription("Setup Verification Panel To Add Role For You")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addRoleOption(option => option.setName("role").setDescription("Role yang akan diberikan").setRequired(true))
      .addStringOption(option => option.setName("tittle").setDescription("Judul embed").setRequired(false))
      .addStringOption(option => option.setName("deskripsi").setDescription("Deskripsi embed").setRequired(false))
      .addAttachmentOption(option => option.setName("image").setDescription("Gambar besar embed").setRequired(false))
      .addStringOption(option => option.setName("image_url").setDescription("Link gambar besar embed").setRequired(false))
      .addAttachmentOption(option => option.setName("thumbnail").setDescription("Thumbnail embed").setRequired(false))
      .addStringOption(option => option.setName("thumbnail_url").setDescription("Link thumbnail embed").setRequired(false))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("delverify")
      .setDescription("Delete Panel Verification Of People")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addChannelOption(option => option.setName("channel").setDescription("Channel yang ingin dibersihkan").setRequired(false))
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      const ownerId = getOwner();
      if (interaction.isChatInputCommand()) {
        // --- HANDLER: HANDLEVERIFY ---
        if (interaction.commandName === "handleverify") {
          if (interaction.user.id !== ownerId) {
            return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
          }
          
          await interaction.deferReply({ ephemeral: true });
          
          const role = interaction.options.getRole("role");
          const title = interaction.options.getString("tittle") || "Verification System";
          const deskripsi = interaction.options.getString("deskripsi") || "Klik tombol di bawah untuk verifikasi.";
          
          const imageAttachment = interaction.options.getAttachment("image");
          const imageUrlInput = interaction.options.getString("image_url");
          const image = imageAttachment ? imageAttachment.url : imageUrlInput;

          const thumbAttachment = interaction.options.getAttachment("thumbnail");
          const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
          const thumbnail = thumbAttachment ? thumbAttachment.url : thumbnailUrlInput;

          const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(deskripsi)
            .setColor("Blue")
            .setTimestamp();
          
          if (image) {
            embed.setImage(image);
          }
          if (thumbnail) {
            embed.setThumbnail(thumbnail);
          }
          
          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("start_verify").setLabel("Verification").setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId("sewa_bot").setLabel("Sewa Bot").setStyle(ButtonStyle.Secondary)
          );
          const msg = await interaction.channel.send({ embeds: [embed], components: [row] });
          saveVerifyData(interaction.guildId, role.id, msg.id, interaction.channelId);
          
          return interaction.editReply({ content: "✅ Panel verifikasi berhasil dikirim." });
        }
        // --- HANDLER: DELVERIFY ---
        if (interaction.commandName === "delverify") {
          if (interaction.user.id !== ownerId) {
            return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
          }
          const targetChannel = interaction.options.getChannel("channel") || interaction.channel;
          const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
          
          if (!data[interaction.guildId]) return interaction.reply({ content: "❌ Tidak ada data verifikasi di server ini.", ephemeral: true });
          const guildData = data[interaction.guildId];
          const filteredData = guildData.filter(item => item.channelId === targetChannel.id);
          for (const item of filteredData) {
            try {
              const ch = await interaction.guild.channels.fetch(item.channelId);
              const msg = await ch.messages.fetch(item.messageId);
              await msg.delete();
            } catch (e) {}
          }
          data[interaction.guildId] = guildData.filter(item => item.channelId !== targetChannel.id);
          fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
          return interaction.reply({ content: `✅ Berhasil menghapus semua panel verifikasi di <#${targetChannel.id}>.`, ephemeral: true });
        }
      }
      if (interaction.isButton()) {
        if (interaction.customId === "start_verify" || interaction.customId === "sewa_bot") {
          const now = Date.now();
          const cooldownAmount = 5000;
          if (cooldowns.has(interaction.user.id)) {
            const expirationTime = cooldowns.get(interaction.user.id) + cooldownAmount;
            if (now < expirationTime) return interaction.reply({ content: "❌ Tunggu 5 Detik Untuk Kembali Digunakan", ephemeral: true });
          }
          cooldowns.set(interaction.user.id, now);
          setTimeout(() => cooldowns.delete(interaction.user.id), cooldownAmount);
        }
        if (interaction.customId === "start_verify") {
          const captcha = generateCaptcha();
          captchaCache.set(interaction.user.id, captcha);
          const modal = new ModalBuilder().setCustomId("modal_verify").setTitle("Verification Security");
          const infoInput = new TextInputBuilder().setCustomId("captcha_code").setLabel(`Kode Passwordmu : ${captcha}`).setStyle(TextInputStyle.Short).setValue(captcha).setRequired(false);
          const userInput = new TextInputBuilder().setCustomId("user_answer").setLabel("Tulis Kodemu").setPlaceholder("Tulis disini").setStyle(TextInputStyle.Short).setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(infoInput), new ActionRowBuilder().addComponents(userInput));
          return interaction.showModal(modal);
        }
        if (interaction.customId === "sewa_bot") {
          return interaction.reply({ content: "Halo, jika kamu ingin menyewa bot ini. Silahkan PM ke owner dari Community Kami yaitu <@1341007595288268880>.\nJika ingin tahu lebih banyak tentang owner. Silahkan gunakan command ``!owner``. Terima Kasih", ephemeral: true });
        }
      }
      if (interaction.isModalSubmit() && interaction.customId === "modal_verify") {
        const userAnswer = interaction.fields.getTextInputValue("user_answer").toUpperCase();
        const correctCaptcha = captchaCache.get(interaction.user.id);
        if (userAnswer !== correctCaptcha) return interaction.reply({ content: "❌ Kode password salah!", ephemeral: true });
        
        const guildData = getVerifyData(interaction.guildId);
        const vData = guildData ? guildData[guildData.length - 1] : null; 
        
        if (!vData) return interaction.reply({ content: "❌ Data verifikasi tidak ditemukan.", ephemeral: true });
        const role = interaction.guild.roles.cache.get(vData.roleId);
        if (!role) return interaction.reply({ content: "❌ Role tidak ditemukan.", ephemeral: true });
        
        try {
          await interaction.member.roles.add(role);
          captchaCache.delete(interaction.user.id);
          return interaction.reply({ content: "✅ Verifikasi berhasil!", ephemeral: true });
        } catch (err) {
          return interaction.reply({ content: "❌ Gagal memberikan role.", ephemeral: true });
        }
      }
    });
  }
};