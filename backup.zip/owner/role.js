// role.js

const fs = require("fs");
const path = require("path");
const { PermissionsBitField } = require("discord.js");

// Load owner ID dari ../database/owner.json
const ownerPath = path.join(__dirname, "../database/owner.json");
const owner = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
const ownerId = owner.owner; // ambil field "owner"

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    // ===== GIVERROLE =====
    if (message.content.startsWith("!giverole ")) {
      // Hanya owner ID yang boleh pakai command
      if (message.author.id !== ownerId) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }

      const args = message.content.split(" ").filter(a => a.trim() !== "");
      if (args.length < 3) {
        return message.reply("❌ Format salah!\nGunakan: `!giverole @user @role`");
      }

      const targetMember = message.mentions.members.first();
      const role = message.mentions.roles.first();

      if (!targetMember) {
        return message.reply("❌ Member tidak ditemukan!");
      }

      if (!role) {
        return message.reply("❌ Role tidak ditemukan!");
      }

      try {
        await targetMember.roles.add(role);
        await message.reply(
          `✅ Role **${role.name}** berhasil diberikan ke **${targetMember.user.tag}**`
        );
      } catch (error) {
        console.error("Gagal memberikan role:", error);
        await message.reply(
          "❌ Gagal memberikan role. Pastikan bot punya izin Manage Roles dan role bot lebih tinggi dari role target."
        );
      }
    }

    // ===== TAKERROLE =====
    if (message.content.startsWith("!takerole ")) {
      // Hanya owner ID yang boleh pakai command
      if (message.author.id !== ownerId) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }

      const args = message.content.split(" ").filter(a => a.trim() !== "");
      if (args.length < 3) {
        return message.reply("❌ Format salah!\nGunakan: `!takerole @user @role`");
      }

      const targetMember = message.mentions.members.first();
      const role = message.mentions.roles.first();

      if (!targetMember) {
        return message.reply("❌ Member tidak ditemukan!");
      }

      if (!role) {
        return message.reply("❌ Role tidak ditemukan!");
      }

      try {
        await targetMember.roles.remove(role);
        await message.reply(
          `✅ Role **${role.name}** berhasil diambil dari **${targetMember.user.tag}**`
        );
      } catch (error) {
        console.error("Gagal mengambil role:", error);
        await message.reply(
          "❌ Gagal mengambil role. Pastikan bot punya izin Manage Roles dan role bot lebih tinggi dari role target."
        );
      }
    }

    // ===== GIVEROLEALL =====
    if (message.content.startsWith("!giveroleall")) {
      if (message.author.id !== ownerId) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }
      const role = message.mentions.roles.first();
      if (!role) return message.reply("❌ Sebutkan role yang ingin diberikan ke semua member!");
      
      const members = await message.guild.members.fetch();
      let count = 0;
      message.reply(`⏳ Memproses pemberian role **${role.name}** ke ${members.size} member...`);
      
      for (const member of members.values()) {
        if (!member.roles.cache.has(role.id) && !member.user.bot) {
          await member.roles.add(role).catch(() => {});
          count++;
        }
      }
      message.channel.send(`✅ Berhasil memberikan role **${role.name}** kepada ${count} member.`);
    }

    // ===== TAKEROLEALL =====
    if (message.content.startsWith("!takeroleall")) {
      if (message.author.id !== ownerId) {
        return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }
      const role = message.mentions.roles.first();
      if (!role) return message.reply("❌ Sebutkan role yang ingin diambil dari semua member!");

      const members = await message.guild.members.fetch();
      let count = 0;
      message.reply(`⏳ Memproses pengambilan role **${role.name}** dari semua member...`);

      for (const member of members.values()) {
        if (member.roles.cache.has(role.id) && !member.user.bot) {
          await member.roles.remove(role).catch(() => {});
          count++;
        }
      }
      message.channel.send(`✅ Berhasil mengambil role **${role.name}** dari ${count} member.`);
    }
  });
}

module.exports = { setup };