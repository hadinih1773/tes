const { PermissionsBitField } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../database/lock.json");
const ownerPath = path.join(__dirname, "../database/owner.json");

// Tentukan ID channel yang ingin di-lock di sini (pisahkan dengan tanda koma)
const targetChannels = [
  "1455010333738533019",
  "1455010223764017265",
  "1455016183643504783",
  "1455010588932702248",
  "1438772534295400448",
  "1446593000624095363",
  "1458482356854984846",
  "1458516093571170405",
  "1440517187273228429",
  "1467106460931461142",
  "1465912361545105559"
];

// ID channel khusus untuk command !bblock dan !bbopen
const targetChannelsBB = [
  "1455010333738533019",
  "1455010223764017265",
  "1455016183643504783",
  "1455010588932702248"
];

// Inisialisasi Database
if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}));
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // Pengelompokan Command dan Alias
      const lockFiturCmds = ["!kuncichfitur", "!kuncifitur", "!kuncichannelfitur"];
      const unlockFiturCmds = ["!bukachfitur", "!bukafitur", "!bukachannelfitur"];
      const lockBBCmds = ["!bblock"];
      const unlockBBCmds = ["!bbopen"];

      // Cek apakah command termasuk dalam fitur lock
      const lockCommands = [...lockFiturCmds, ...unlockFiturCmds, ...lockBBCmds, ...unlockBBCmds];
      if (!lockCommands.includes(command)) return;

      // Cek Owner ID
      if (!fs.existsSync(ownerPath)) return;

      const ownerData = JSON.parse(fs.readFileSync(ownerPath, "utf8"));

      if (message.author.id !== ownerData.owner) {
          return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
      }

      // ================= COMMAND LOCK FITUR =================
      if (lockFiturCmds.includes(command)) {
        const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

        // Cek jika sudah pernah di-lock/tersimpan di database
        const isAlreadyLocked = targetChannels.some(id => db[id]);
        if (isAlreadyLocked) {
          return message.reply("❌ Channel Sudah Di Kunci Dan Tersimpan Di Database. Silahkan Buka Terlebih Dahulu.");
        }

        for (const channelId of targetChannels) {
          const channel = message.guild.channels.cache.get(channelId);
          if (!channel) continue;

          const currentOverwrites = {};
          channel.permissionOverwrites.cache.forEach((overwrite) => {
              currentOverwrites[overwrite.id] = {
                  allow: overwrite.allow.bitfield.toString(),
                  deny: overwrite.deny.bitfield.toString(),
                  type: overwrite.type
              };
          });

          db[channelId] = currentOverwrites;

          try {
              await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                  SendMessages: false
              });

              const rolesInChannel = channel.permissionOverwrites.cache.filter(o => o.type === 0);
              for (const [roleId] of rolesInChannel) {
                  await channel.permissionOverwrites.edit(roleId, {
                      SendMessages: false
                  });
              }
          } catch (err) {
              console.error(`Gagal mengunci channel ${channelId}:`, err);
          }
        }

        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        return message.channel.send(`🔒 Berhasil mengunci ${targetChannels.length} channel yang ditentukan di dalam kode.`);
      }

      // ================= COMMAND UNLOCK FITUR =================
      if (unlockFiturCmds.includes(command)) {
        const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

        for (const channelId of targetChannels) {
          const channel = message.guild.channels.cache.get(channelId);
          if (!channel || !db[channelId]) continue;

          const savedOverwrites = db[channelId];

          try {
              const finalOverwrites = Object.keys(savedOverwrites).map(id => ({
                  id: id,
                  allow: BigInt(savedOverwrites[id].allow),
                  deny: BigInt(savedOverwrites[id].deny),
                  type: savedOverwrites[id].type
              }));

              await channel.permissionOverwrites.set(finalOverwrites);
              delete db[channelId];
          } catch (err) {
              console.error(`Gagal membuka channel ${channelId}:`, err);
          }
        }

        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        return message.channel.send(`🔓 Berhasil mengembalikan permission ${targetChannels.length} channel ke semula.`);
      }

      // ================= COMMAND !bblock =================
      if (lockBBCmds.includes(command)) {
        const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

        // Cek jika sudah pernah di-lock/tersimpan di database
        const isAlreadyLocked = targetChannelsBB.some(id => db[id]);
        if (isAlreadyLocked) {
          return message.reply("❌ Channel Sudah Di Kunci Dan Tersimpan Di Database. Silahkan Buka Terlebih Dahulu.");
        }

        for (const channelId of targetChannelsBB) {
          const channel = message.guild.channels.cache.get(channelId);
          if (!channel) continue;

          const currentOverwrites = {};
          channel.permissionOverwrites.cache.forEach((overwrite) => {
              currentOverwrites[overwrite.id] = {
                  allow: overwrite.allow.bitfield.toString(),
                  deny: overwrite.deny.bitfield.toString(),
                  type: overwrite.type
              };
          });

          db[channelId] = currentOverwrites;

          try {
              await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                  SendMessages: false
              });

              const rolesInChannel = channel.permissionOverwrites.cache.filter(o => o.type === 0);
              for (const [roleId] of rolesInChannel) {
                  await channel.permissionOverwrites.edit(roleId, {
                      SendMessages: false
                  });
              }
          } catch (err) {
              console.error(`Gagal mengunci channel BB ${channelId}:`, err);
          }
        }

        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        return message.channel.send(`🔒 Berhasil mengunci ${targetChannelsBB.length} channel Boombox yang ditentukan.`);
      }

      // ================= COMMAND !bbopen =================
      if (unlockBBCmds.includes(command)) {
        const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

        for (const channelId of targetChannelsBB) {
          const channel = message.guild.channels.cache.get(channelId);
          if (!channel || !db[channelId]) continue;

          const savedOverwrites = db[channelId];

          try {
              const finalOverwrites = Object.keys(savedOverwrites).map(id => ({
                  id: id,
                  allow: BigInt(savedOverwrites[id].allow),
                  deny: BigInt(savedOverwrites[id].deny),
                  type: savedOverwrites[id].type
              }));

              await channel.permissionOverwrites.set(finalOverwrites);
              delete db[channelId];
          } catch (err) {
              console.error(`Gagal membuka channel BB ${channelId}:`, err);
          }
        }

        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        return message.channel.send(`🔓 Berhasil mengembalikan permission ${targetChannelsBB.length} channel Boombox ke semula.`);
      }
    });
  },
};