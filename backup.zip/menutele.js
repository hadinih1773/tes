const { Markup } = require('telegraf');

module.exports = {
    setup: async (bot) => {
        const categories = {
            owner: {
                name: "👑 Owner",
                commands: [
                    "/status - Cek Status Bot Discord Dan WhatsApp",
                    "/backup - Backup Database",
                    "/autobackup - Auto Backup",
                    "/settimebackup - Atur Jam Backup",
                    "/getfile - Mengambil File Dari Hosting",
                    "/update - Memperbarui Isi Dalam File",
                    "/rnmfile - Mengubah Nama File",
                    "/addfile - Menambahkan File Baru",
                    "/delfile - Menghapus File"
                ]
            },
            downloader: {
                name: "📟 Downloader",
                commands: [
                    "/ytdl - Download MP3 dan MP4 YouTube",
                    "/ytmp3 - Download MP3 YouTube",
                    "/ytmp4 - Download MP4 YouTube",
                    "/igdl - Download MP4 Instagram",
                    "/ttdl - Download MP3 dan MP4 TikTok",
                    "/ttmp3 - Download MP3 TikTok",
                    "/ttmp4 - Download MP4 TikTok"
                ]
            },
            help: {
                name: "⚠️ Help",
                commands: [
                    "/menu - Show List Menu",
                    "/start - Start Bot",
                    "/status - Status Bot",
                    "/id - Check Your ID",
                    "/ping - Show Latency Bot"
                ]
            },
            search: {
                name: "🔎 Search",
                commands: [
                    "/yts - YouTube Search",
                    "/tts - TikTok Search",
                    "/pinterest - Pinterest Image Search"
                ]
            },
            game: {
                name: "🎮 Game",
                commands: [
                    "/tebakgambar",
                    "/tebakbendera",
                    "/tebakkata",
                    "/tebaktebakan",
                    "/family100",
                    "/siapakahaku",
                    "/susunkata",
                    "/tekateki"
                ]
            }
        };

        // Fungsi pembantu untuk membuat Menu Utama secara otomatis
        const getMainMenu = (ctx) => {
            const firstName = ctx.from.first_name;
            const text = `✨ Selamat Datang Di Menu List Helper Bot ✨\n\nHai @${ctx.from.username || firstName} !! 👋\nSilahkan tekan salah satu tombol dibawah untuk melihat semua isi command dari kategorinya. \n\n🎯 Fitur Unggulan :\n🔹 Url Top4Top Generator 🎶\n🔹 Image Edit 🖼\n🔹 Figure Edit 🦸‍♂️\n🔹 Play Game 🎮\n🔹 Downloader 📟\n\n🚫 Tolong jangan spam command nanti bisa-bisa eror dia \n\nSemua fitur bot masih dikembangkan jadi jika terjadi bug atau eror maklum saja 🤭🤭.`;
            
            // Generate tombol otomatis dari objek categories (2 kolom)
            const keys = Object.keys(categories);
            const buttons = [];
            for (let i = 0; i < keys.length; i += 2) {
                const row = [];
                row.push(Markup.button.callback(categories[keys[i]].name, `show_menu_${keys[i]}`));
                if (keys[i + 1]) {
                    row.push(Markup.button.callback(categories[keys[i + 1]].name, `show_menu_${keys[i + 1]}`));
                }
                buttons.push(row);
            }
            
            // Tombol Close di paling bawah
            buttons.push([Markup.button.callback('❌ Close', 'close_menu')]);
            
            return { text, extra: Markup.inlineKeyboard(buttons) };
        };

        // Command /menu
        bot.command('menu', async (ctx) => {
            const menu = getMainMenu(ctx);
            await ctx.reply(menu.text, menu.extra);
        });

        // Handler Tombol Kategori (Mengedit pesan yang ada)
        bot.action(/^show_menu_(.+)$/, async (ctx) => {
            const categoryKey = ctx.match[1];
            const menu = categories[categoryKey];

            if (menu) {
                let menuContent = `◣──────────❈\n◤─「 \`${menu.name}\` 」─✦\n`;
                menu.commands.forEach((cmd) => { 
                    menuContent += `│⦿ ${cmd}\n`; 
                });
                menuContent += `◣──────────❈\n\n`;

                const buttons = [
                    [Markup.button.callback('⬅️ Back', 'back_to_main'), Markup.button.callback('❌ Close', 'close_menu')]
                ];

                await ctx.answerCbQuery();
                await ctx.editMessageText(menuContent, { 
                    parse_mode: 'Markdown', 
                    ...Markup.inlineKeyboard(buttons) 
                });
            }
        });

        // Handler Tombol Kembali
        bot.action('back_to_main', async (ctx) => {
            const menu = getMainMenu(ctx);
            await ctx.answerCbQuery();
            await ctx.editMessageText(menu.text, { 
                parse_mode: 'Markdown', 
                ...menu.extra 
            });
        });

        // Handler Tombol Close
        bot.action('close_menu', async (ctx) => {
            await ctx.answerCbQuery("Menu ditutup");
            await ctx.deleteMessage();
        });
    }
};
