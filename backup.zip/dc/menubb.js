const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    SlashCommandBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const tampilkanMenu = async (interaction) => {
    const user = interaction.user;
    const clientUser = interaction.client.user;

    const judulUtama = `🎵 ${clientUser.username} || List Command Help`;
    const deskripsiUtama = `🙋 **Selamat Datang ${user} Di Menu List Command**\n\nSaya ${clientUser.username} Adalah Bot Yang Dirancang Untuk Memudahkan Dalam Mengkonversi Url TikTok, YouTube dan Spotify Menjadi Url Top4Top\n\n**🤖 Informasi Bot**\n> Nama Bot : ${clientUser} (\`${clientUser.id}\`)\n> Owner Bot : [hadinih_](https://discord.com/users/1341007595288268880) (\`1341007595288268880\`)\n> Link Server : [Hady Community](https://discord.gg/4uzdM25KYv)\n\n** 📣 Ketentuan**\n> 1. Jangan Spam Drop Url, Tunggu Bot Proses Baru Kirim Lagi.\n> 2. Gunakan Bot Dengan Bijak\n> 3. Jika Ada Eror Atau Bug, Mohon Dimaklumi Botnya Sedang Tahap Pengembangan \n> 4. Jika Ada Saran Dan Yang Lainnya Silahkan Hubungi Owner. \n> 5. Jika Kamu Ingin Berdonasi Supaya Bot Terus Online 24/7 Silahkan Tekan Button Donasi Dibawah`;
    
    const fields = [
        {
            name: "🎧 Boombox Command",
            value: [
                "`!setchannelbb [#channel]` - Setting Channel Drop Url Convert",
                "`!delchannelbb [#channel]` - Hapus Channel Drop Url Convert",
                "`!bb [url/query]` - Mencari dan Konversi Url Ke Top4Top",
                "`!bbowner [url/query]` - Khusus Owner Konversi Ke Top4Top",
                "`!bbsearch [query]` - Mencari Judul Lagu Yang Sudah Di Konversi"
            ].join('\n')
        },
        {
            name: "🌐 Slash Command",
            value: [
                "`/boombox setup` - Setting Channel Auto Convert",
                "`/boombox delete` - Delete Channel Auto Convert",
                "`/bbfav` - Melihat Url Yang Disukai",
                "`/bbplaylist` - Melihat Playlist Url Top4Top Yang Sudah Di Convert",
                "`/broadcast` - Broadcast Message",
                "`/leavebot` - Mengeluarkan Bot Dari Server",
                "`/locbot` - Melihat List Server Bot",
                "`/setbannerbot` - Mengubah Banner Bot",
                "`/setnamebot` - Mengubah Nama Bot",
                "`/setppbot` - Mengubah Avatar Bot",
                "`/setbiobot` - Mengubah Bio Bot"
            ].join('\n')
        }
    ];

    // Membagi otomatis jika isi kategori melebihi batas 1500 karakter agar rapi
    const daftarHalaman = [
        { tipe: 'utama', judul: judulUtama, isi: deskripsiUtama, referensiKategori: "all_menu" }
    ];

    for (const f of fields) {
        const baris = f.value.split('\n');
        let teksHalaman = "";
        let counterBagian = 1;

        for (const b of baris) {
            if ((teksHalaman + b).length > 1500) {
                daftarHalaman.push({
                    tipe: 'kategori',
                    judul: `${f.name} (Bagian ${counterBagian})`,
                    isi: teksHalaman.trim(),
                    referensiKategori: f.name
                });
                teksHalaman = "";
                counterBagian++;
            }
            teksHalaman += b + "\n";
        }
        if (teksHalaman.trim().length > 0) {
            daftarHalaman.push({
                tipe: 'kategori',
                judul: counterBagian > 1 ? `${f.name} (Bagian ${counterBagian})` : f.name,
                isi: teksHalaman.trim(),
                referensiKategori: f.name
            });
        }
    }

    let halamanSekarang = 0;

    const buatEmbed = (indeks) => {
        const dataHalaman = daftarHalaman[indeks];
        const embed = new EmbedBuilder()
            .setTitle(dataHalaman.judul)
            .setDescription(dataHalaman.isi)
            .setColor("Blue")
            .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: `Halaman ${indeks + 1}/${daftarHalaman.length} | By ${interaction.client.user.tag} -_-` });

        if (dataHalaman.tipe === 'utama' || dataHalaman.tipe === 'kategori') {
            embed.setImage("https://api.kabox.my.id/file/6e09ea1245f60bda.gif");
        }
        return embed;
    };

    const buatKomponen = (indeks) => {
        const tombolPrev = new ButtonBuilder()
            .setCustomId('prev_menu')
            .setLabel('⬅️ Prev')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(indeks === 0);

        const tombolAll = new ButtonBuilder()
            .setCustomId('all_menu')
            .setLabel('🌀 All Menu')
            .setStyle(ButtonStyle.Primary);

        const tombolNext = new ButtonBuilder()
            .setCustomId('next_menu')
            .setLabel('Next ➡️')
            .setStyle(ButtonStyle.Success)
            .setDisabled(indeks === daftarHalaman.length - 1);

        const tombolDonasi = new ButtonBuilder()
            .setLabel('💸 Donasi')
            .setStyle(ButtonStyle.Link)
            .setURL("https://cdn.discordapp.com/attachments/1382265549706236035/1511279044870672424/IMG_20260411_194210.png?ex=6a83690a&is=6a82178a&hm=3cc06d9c110b6d5c5f0ab7a5d6348dfe7a874816467b7f1b064f89055e2ebf27&");

        const rowButton = new ActionRowBuilder().addComponents(tombolPrev, tombolAll, tombolNext, tombolDonasi);

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('pilih_menu')
            .setPlaceholder('👉 Pilih Kategori Menu')
            .addOptions(
                new StringSelectMenuOptionBuilder().setLabel('🌀 All Menu').setValue('all_menu'),
                ...fields.map(f => new StringSelectMenuOptionBuilder().setLabel(f.name).setValue(f.name))
            );
            
        const dataHalaman = daftarHalaman[indeks];
        if (dataHalaman.referensiKategori) {
            const opsiCocok = selectMenu.options.find(opt => opt.data.value === dataHalaman.referensiKategori);
            if (opsiCocok) opsiCocok.setDefault(true);
        }

        const rowSelect = new ActionRowBuilder().addComponents(selectMenu);

        return [rowSelect, rowButton];
    };

    const response = await interaction.reply({
        embeds: [buatEmbed(halamanSekarang)],
        components: buatKomponen(halamanSekarang),
        fetchReply: true
    });

    try {
        const audioPath = path.join(__dirname, '../vn/menu.mp3');
        if (fs.existsSync(audioPath)) {
            await interaction.channel.send({
                files: [{
                    attachment: audioPath,
                    name: 'HC Assistant.mp3'
                }]
            });
        }
    } catch (audioErr) {
        // Silent error jika terjadi kendala pada pembacaan file audio
    }

    // Kolektor tanpa parameter 'time' agar selalu aktif selamanya
    const collector = response.createMessageComponentCollector();

    collector.on('collect', async (i) => {
        const targetId = user.id;
        if (i.user.id !== targetId) {
            return i.reply({ content: "❌ Kamu tidak bisa menggunakan menu ini.", ephemeral: true });
        }

        // Handle aksi dari Select Menu
        if (i.isStringSelectMenu() && i.customId === 'pilih_menu') {
            const selectedValue = i.values[0];
            
            if (selectedValue === 'all_menu') {
                halamanSekarang = 0;
                await i.update({
                    embeds: [buatEmbed(halamanSekarang)],
                    components: buatKomponen(halamanSekarang)
                }).catch(() => {});
                
                // Mengirimkan semua menu terpisah ke channel
                for (const field of fields) {
                    const embed = new EmbedBuilder()
                        .setTitle(field.name)
                        .setDescription(field.value)
                        .setColor("Blue")
                        .setFooter({ text: `By ${interaction.client.user.tag} -_-` });
                    await interaction.channel.send({ embeds: [embed] });
                }
                return;
            } else {
                const indeksCocok = daftarHalaman.findIndex(h => h.referensiKategori === selectedValue);
                if (indeksCocok !== -1) {
                    halamanSekarang = indeksCocok;
                }
            }
        } 
        // Handle aksi dari Buttons
        else if (i.isButton()) {
            if (i.customId === 'all_menu') {
                await i.reply({ content: "Mengirimkan seluruh menu...", ephemeral: true });
                for (const field of fields) {
                    const embed = new EmbedBuilder()
                        .setTitle(field.name)
                        .setDescription(field.value)
                        .setColor("Blue")
                        .setFooter({ text: `By ${interaction.client.user.tag} -_-` });
                    await interaction.channel.send({ embeds: [embed] });
                }
                return;
            }

            if (i.customId === 'next_menu') {
                if (halamanSekarang < daftarHalaman.length - 1) halamanSekarang++;
            } else if (i.customId === 'prev_menu') {
                if (halamanSekarang > 0) halamanSekarang--;
            }
        }

        await i.update({
            embeds: [buatEmbed(halamanSekarang)],
            components: buatKomponen(halamanSekarang)
        }).catch(() => {});
    });
};

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("help")
            .setDescription("Menampilkan menu bantuan dan daftar command bot")
    ],
    setup: (client) => {
        if (!client._interactionHandlers) client._interactionHandlers = [];
        client._interactionHandlers.push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            if (interaction.commandName === "help") {
                await tampilkanMenu(interaction);
            }
        });
    },
    tampilkanMenu
};