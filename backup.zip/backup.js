const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const { EmbedBuilder } = require("discord.js");

function setup(client) {

  // =============== LOAD OWNER JSON ===============
  const ownerFile = path.join(__dirname, "database", "owner.json");
  const OWNER_ID = JSON.parse(fs.readFileSync(ownerFile, "utf8")).owner;
  // ===============================================

  const backupDir = path.join(__dirname, "sampah");
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);

  // FILE CONFIG WAKTU BACKUP
  const configFile = path.join(__dirname, "database", "backup_config.json");

  // FILE LIST CHANNEL BACKUP
  const channelFile = path.join(__dirname, "database", "backup_channels.json");

  // BIKIN FILE CHANNEL JIKA BELUM ADA
  if (!fs.existsSync(channelFile)) {
    fs.writeFileSync(
      channelFile,
      JSON.stringify({
        channels: ["1377564963367026688"],
        active: true
      }, null, 2)
    );
  }

  let backupData = JSON.parse(fs.readFileSync(channelFile, "utf8"));
  let backupChannels = backupData.channels;
  let backupActive = backupData.active !== undefined ? backupData.active : true;

  let isBackingUp = false;
  let lastBackupPath = null;
  let backupInterval = null;
  let backupDelay = 5 * 60 * 1000;

  // LOAD CONFIG WAKTU
  if (fs.existsSync(configFile)) {
    try {
      const savedConfig = JSON.parse(fs.readFileSync(configFile, "utf8"));
      if (savedConfig.backupDelay && typeof savedConfig.backupDelay === "number") {
        backupDelay = savedConfig.backupDelay;
        console.log(`⚙️ Interval backup sebelumnya dimuat: ${backupDelay / 1000}s`);

        backupInterval = setInterval(() => {
          if (!backupActive) return;
          console.log(`🕒 Melakukan backup otomatis (load config)...`);
          handleBackup();
        }, backupDelay);
      }
    } catch (err) {
      console.error("⚠️ Gagal membaca konfigurasi backup:", err);
    }
  }

  // Helper untuk format ukuran file
  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // ================= FUNGSI BACKUP =================
  const handleBackup = async (targetChannel = null, isDM = false, messageRef = null) => {
    if (isBackingUp) {
      console.log("⚠️ Backup masih berjalan, tunggu...");
      return;
    }

    isBackingUp = true;

    try {
      // --- HAPUS ISI FOLDER SAMPAH SEBELUM MULAI ---
      if (fs.existsSync(backupDir)) {
        fs.rmSync(backupDir, { recursive: true, force: true });
      }
      fs.mkdirSync(backupDir, { recursive: true });
      // ---------------------------------------------

      const date = new Date();
      const folderName = `${date.getFullYear()}-${String(
        date.getMonth() + 1
      ).padStart(2, "0")}-${String(date.getDate()).padStart(
        2,
        "0"
      )}_${String(date.getHours()).padStart(2, "0")}-${String(
        date.getMinutes()
      ).padStart(2, "0")}`;

      const folderPath = path.join(backupDir, folderName);
      fs.mkdirSync(folderPath, { recursive: true });

      const zipFile = path.join(folderPath, "backup.zip");
      const output = fs.createWriteStream(zipFile);
      const archive = archiver("zip", { zlib: { level: 9 } });

      archive.pipe(output);

      const excluded = [
        "node_modules",
        ".npm",
        ".cache",
        ".git",
        ".DS_Store",
        "thumbs.db",
        "desktop.ini",
        ".upm",
        "session",
        "assets",
        "sampah",
        "jadibot-session",
        ".replit"
      ];

      let fileCount = 0;

      const addFiles = (dir, base = "") => {
        const items = fs.readdirSync(dir);

        for (const item of items) {
          const fullPath = path.join(dir, item);
          const relativePath = path.join(base, item);

          if (excluded.includes(item)) continue;
          if (excluded.some((ex) => item.startsWith(ex))) continue;

          const stats = fs.statSync(fullPath);

          if (stats.isDirectory()) {
            addFiles(fullPath, relativePath);
          } else {
            archive.file(fullPath, { name: relativePath });
            fileCount++;
          }
        }
      };

      addFiles(__dirname);

      await archive.finalize();

      await new Promise((resolve, reject) => {
        output.on("close", resolve);
        output.on("error", reject);
      });

      console.log(`✅ Backup selesai (${archive.pointer()} bytes)`);
      lastBackupPath = zipFile;

      // KIRIM KE DM OWNER JIKA DIPICU COMMAND !backup
      if (isDM) {
        const owner = await client.users.fetch(OWNER_ID).catch(() => null);
        if (owner) {
          await owner.send({
            content: `📦 **Backup selesai! (${folderName})**`,
            files: [zipFile],
          }).catch(() => null);
        }

        // Kirim Embed Balasan di Channel jika pemicunya adalah pesan command !backup
        if (messageRef) {
          const embed = new EmbedBuilder()
            .setColor("#2ECC71") // Emerald Green
            .setTitle("✅ Backup Script Successful")
            .setDescription(
              `📦 **Backup File**\n\`\`\`backup.zip\`\`\`\n` +
              `📂 **Total Files**\n\`\`\`${fileCount}\`\`\`\n` +
              `🏷 **File Size**\n\`\`\`${formatBytes(archive.pointer())}\`\`\`\n` +
              `📌 **Status Backup**\n\`\`\`File Backup Berhasil Dikirim Ke DM Owner\`\`\``
            )
            .setFooter({
              text: `By ${messageRef.author.username}`,
              iconURL: messageRef.author.displayAvatarURL({ dynamic: true })
            })
            .setTimestamp();

          await messageRef.reply({ embeds: [embed] });
        }
      }

      // KIRIM KE SEMUA CHANNEL YANG DI SET DI JSON
      for (const ch of backupChannels) {
        const channel = await client.channels.fetch(ch).catch(() => null);
        if (channel) {
          await channel.send({
            content: `📦 **Backup selesai! (${folderName})**`,
            files: [zipFile],
          });
        }
      }

      // HAPUS FOLDER BACKUP SPESIFIK SETELAH KIRIM
      try {
        fs.rmSync(folderPath, { recursive: true, force: true });
        console.log(`🗑️ Backup dihapus: ${folderName}`);
      } catch (err) {
        console.error("⚠️ Gagal menghapus folder backup:", err);
      }

    } catch (err) {
      console.error("❌ Gagal backup:", err);
    } finally {
      isBackingUp = false;
    }
  };

  // ==================================================
  // COMMAND !backup (ONLY OWNER)
  // ==================================================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (!message.content.startsWith("!backup")) return;

    if (message.author.id !== OWNER_ID) {
      return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
    }

    handleBackup(null, true, message);
  });

  // ==================================================
  // COMMAND !setbackup on/off (ONLY OWNER)
  // ==================================================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (!message.content.startsWith("!setbackup ")) return;

    if (message.author.id !== OWNER_ID) {
      return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
    }

    const args = message.content.split(" ")[1];

    if (args === "on") {
      backupActive = true;
      backupData.active = true;
      fs.writeFileSync(channelFile, JSON.stringify(backupData, null, 2), "utf8");
      message.reply("✅ Autobackup telah diaktifkan.");
    } else if (args === "off") {
      backupActive = false;
      backupData.active = false;
      fs.writeFileSync(channelFile, JSON.stringify(backupData, null, 2), "utf8");
      message.reply("❌ Autobackup telah dinonaktifkan.");
    } else {
      message.reply("⚠️ Format: `!setbackup on/off`");
    }
  });

  // ==================================================
  // COMMAND !settimebackup (ONLY OWNER)
  // ==================================================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (!message.content.startsWith("!settimebackup")) return;

    if (message.author.id !== OWNER_ID) {
      return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
    }

    const args = message.content.split(" ")[1];
    if (!args) return message.reply("⚠️ Format: `!settimebackup 5m / 2h / 30s`");

    const match = args.match(/^(\d+)([smh])$/);
    if (!match) return message.reply("⚠️ Format salah! Contoh: `!settimebackup 5m`");

    const value = parseInt(match[1]);
    const unit = match[2];

    if (unit === "s") backupDelay = value * 1000;
    else if (unit === "m") backupDelay = value * 60 * 1000;
    else if (unit === "h") backupDelay = value * 60 * 60 * 1000;

    if (backupInterval) clearInterval(backupInterval);

    fs.writeFileSync(configFile, JSON.stringify({ backupDelay }), "utf8");

    backupInterval = setInterval(() => {
      if (!backupActive) return;
      console.log(`🕒 Melakukan backup otomatis (${args})...`);
      handleBackup();
    }, backupDelay);

    message.reply(`✅ Interval backup diatur menjadi setiap ${value}${unit.toUpperCase()}`);
  });

  // ==================================================
  // COMMAND !setchannelbackup (ONLY OWNER)
  // ==================================================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (!message.content.startsWith("!setchannelbackup")) return;

    if (message.author.id !== OWNER_ID) {
      return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
    }

    let target = message.channel.id;

    if (!backupChannels.includes(target)) {
      backupChannels.push(target);
      backupData.channels = backupChannels;

      fs.writeFileSync(
        channelFile,
        JSON.stringify(backupData, null, 2),
        "utf8"
      );
      
      message.reply(`✅ Channel ini ditambah ke daftar backup. Memulai proses backup...`);
      handleBackup();
    } else {
      message.reply(`⚠️ Channel ini sudah terdaftar.`);
    }
  });

  // ==================================================
  // COMMAND !delchannelbackup (ONLY OWNER)
  // ==================================================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (!message.content.startsWith("!delchannelbackup")) return;

    if (message.author.id !== OWNER_ID) {
      return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
    }

    const target = message.channel.id;

    if (!backupChannels.includes(target)) {
      return message.reply("⚠️ Channel ini tidak ada dalam daftar backup.");
    }

    backupChannels = backupChannels.filter((id) => id !== target);
    backupData.channels = backupChannels;

    fs.writeFileSync(
      channelFile,
      JSON.stringify(backupData, null, 2),
      "utf8"
    );

    message.reply(`🗑️ Channel ini dihapus dari daftar backup.`);
  });

  // EXIT HANDLER
  const safeExit = async (signal) => {
    console.log(`⚠️ Menerima sinyal ${signal}, melakukan backup sebelum keluar...`);
    await handleBackup();
    setTimeout(() => process.exit(0), 5000);
  };

  process.on("SIGINT", safeExit);
  process.on("SIGTERM", safeExit);
  process.on("beforeExit", handleBackup);
  process.on("uncaughtException", async (err) => {
    console.error("❌ Error tidak tertangkap:", err);
    await handleBackup();
    process.exit(1);
  });

}

module.exports = { setup };