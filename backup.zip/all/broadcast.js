const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, PermissionFlagsBits, ChannelType } = require("discord.js");
const fs = require("fs");
const path = require("path");

// Load owner ID
const ownerPath = path.join(__dirname, "../database/owner.json");
const ownerData = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
const ownerId = ownerData.owner;

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("broadcast")
      .setDescription("Send Broadcast Message To All Members")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => option.setName("deskripsi").setDescription("Isi pesan broadcast").setRequired(true))
      .addStringOption(option => 
        option.setName("action")
          .setDescription("Tujuan pengiriman broadcast")
          .setRequired(false)
          .addChoices(
            { name: "Owner Server", value: "owner_server" },
            { name: "Members Global", value: "members_global" },
            { name: "Members Server", value: "members_server" },
            { name: "Channel Server", value: "channel_server" }
          )
      )
      .addBooleanOption(option => 
        option.setName("embed")
          .setDescription("Kirim sebagai embed (true) atau teks biasa (false)")
          .setRequired(false)
      )
      .addStringOption(option => option.setName("title").setDescription("Judul embed").setRequired(false))
      .addStringOption(option => option.setName("color").setDescription("Warna hex (contoh: #00ff00)").setRequired(false))
      .addAttachmentOption(option => option.setName("image").setDescription("Upload gambar utama").setRequired(false))
      .addStringOption(option => option.setName("image_url").setDescription("Link gambar utama").setRequired(false))
      .addAttachmentOption(option => option.setName("thumbnail").setDescription("Upload thumbnail kecil").setRequired(false))
      .addStringOption(option => option.setName("thumbnail_url").setDescription("Link thumbnail kecil").setRequired(false))
      .toJSON()
  ],

  setup(client) {
    // === PREFIX COMMAND !broadcast ===
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;
      if (!message.content.startsWith("!broadcast")) return;
      if (message.author.id !== ownerId) return;

      const args = message.content.slice(11).trim();
      if (!args) return message.reply("❌ Format Salah : ``!broadcast text``");

      const embed = new EmbedBuilder()
        .setTitle("📢 Broadcast Message")
        .setDescription(args)
        .setColor("Blue")
        .setTimestamp();

      try {
        const members = await message.guild.members.fetch();
        let success = 0;
        let failed = 0;
        const statusMsg = await message.channel.send(`🚀 Mengirim DM ke ${members.size} member...`);

        for (const [id, member] of members) {
          if (member.user.bot) continue;
          try {
            await member.send({ embeds: [embed] });
            success++;
          } catch (err) {
            failed++;
          }
        }

        await statusMsg.edit(`✅ **Broadcast Selesai!**\n Berhasil: ${success}\n Gagal: ${failed} (DM tertutup/block)`);
      } catch (error) {
        console.error("Error Broadcast:", error);
        message.reply("❌ Terjadi kesalahan saat mengambil data member.");
      }
    });

    // === SLASH COMMAND /broadcast ===
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== "broadcast") return;

      if (interaction.user.id !== ownerId) {
        return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
      }

      const deskripsi = interaction.options.getString("deskripsi");
      const action = interaction.options.getString("action") || "members_server";
      const isEmbed = interaction.options.getBoolean("embed") || false;
      const title = interaction.options.getString("title") || "📢 Broadcast Message";
      const color = interaction.options.getString("color") || "Blue";
      
      const imageFile = interaction.options.getAttachment("image");
      const imageUrlInput = interaction.options.getString("image_url");
      const image = imageFile ? imageFile.url : imageUrlInput;

      const thumbnailFile = interaction.options.getAttachment("thumbnail");
      const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
      const thumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

      let embed = null;
      if (isEmbed) {
        embed = new EmbedBuilder()
          .setTitle(title)
          .setDescription(deskripsi)
          .setColor(color)
          .setTimestamp();

        if (image) embed.setImage(image);
        if (thumbnail) embed.setThumbnail(thumbnail);
      }

      // Helper function untuk mengirim pesan berdasarkan pilihan embed dan tag
      const sendMessage = async (target, mentionText) => {
        if (isEmbed) {
          return await target.send({ content: mentionText, embeds: [embed] });
        } else {
          return await target.send({ content: `${mentionText}\n${deskripsi}` });
        }
      };

      await interaction.reply({ content: "🚀 Proses broadcast dimulai...", ephemeral: true });

      try {
        let success = 0;

        // 1. Target: Owner Server
        if (action === "owner_server") {
          const processedOwners = new Set();
          for (const guild of client.guilds.cache.values()) {
            try {
              const guildOwner = await guild.fetchOwner();
              if (guildOwner && !guildOwner.user.bot && !processedOwners.has(guildOwner.id)) {
                processedOwners.add(guildOwner.id);
                await sendMessage(guildOwner, `<@${guildOwner.id}>`);
                success++;
              }
            } catch (err) {
              continue;
            }
          }
        }
        // 2. Target: Members Global
        else if (action === "members_global") {
          const processedMembers = new Set();
          for (const guild of client.guilds.cache.values()) {
            try {
              const members = await guild.members.fetch();
              for (const [id, member] of members) {
                if (member.user.bot || processedMembers.has(member.id)) continue;
                processedMembers.add(member.id);
                try {
                  await sendMessage(member, `<@${member.id}>`);
                  success++;
                } catch (err) {
                  continue;
                }
              }
            } catch (err) {
              continue;
            }
          }
        }
        // 3. Target: Channel Server
        else if (action === "channel_server") {
          for (const guild of client.guilds.cache.values()) {
            try {
              const targetChannel = guild.channels.cache.find(
                ch => ch.type === ChannelType.GuildText && 
                      ch.permissionsFor(guild.members.me).has(PermissionsBitField.Flags.SendMessages)
              );
              if (targetChannel) {
                await sendMessage(targetChannel, "@everyone");
                success++;
              }
            } catch (err) {
              continue;
            }
          }
        }
        // 4. Target: Members Server (Default tempat command dipanggil)
        else {
          const members = await interaction.guild.members.fetch();
          for (const [id, member] of members) {
            if (member.user.bot) continue;
            try {
              await sendMessage(member, `<@${member.id}>`);
              success++;
            } catch (err) {
              continue;
            }
          }
        }

        await interaction.followUp({ content: `✅ Broadcast selesai! Terkirim ke ${success} target.`, ephemeral: true });
      } catch (error) {
        console.error("Error Slash Broadcast:", error);
      }
    });
  }
};