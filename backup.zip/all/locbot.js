const { 
  EmbedBuilder, 
  SlashCommandBuilder, 
  PermissionFlagsBits, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ComponentType 
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const ownerFile = path.join(__dirname, "../database/owner.json");

const getOwnerId = () => {
  try {
    if (fs.existsSync(ownerFile)) {
      const data = JSON.parse(fs.readFileSync(ownerFile, "utf8"));
      return data.owner;
    }
  } catch (err) {
    console.error("Gagal membaca file owner.json:", err);
  }
  return null;
};

// Fungsi pembantu untuk membuat Embed & Buttons berdasarkan index server
async function generateGuildPage(guildsArray, index) {
  const guild = guildsArray[index];

  // Fetch Owner untuk mendapatkan data username terbaru
  let ownerUser = null;
  try {
    const owner = await guild.fetchOwner();
    ownerUser = owner.user;
  } catch (err) {
    console.error(`Gagal fetch owner untuk guild ${guild.id}:`, err);
  }

  // Logika pembuatan invite link
  let inviteUrl = null;
  try {
    const defaultChannel = guild.channels.cache
      .filter(c => c.type === 0 && c.permissionsFor(guild.members.me)?.has("CreateInstantInvite"))
      .first();

    if (defaultChannel) {
      const invite = await defaultChannel.createInvite({ maxAge: 0, maxUses: 0 });
      inviteUrl = invite.url;
    }
  } catch (err) {
    console.error(`Gagal membuat invite link untuk guild ${guild.id}:`, err);
  }

  const ownerName = ownerUser ? ownerUser.username : "Tidak dapat memuat username";
  const ownerId = ownerUser ? ownerUser.id : "N/A";
  const inviteText = inviteUrl ? `[Click To Join](${inviteUrl})` : "Tidak ada izin invite";

  const embed = new EmbedBuilder()
    .setColor("#50C878")
    .setTitle(`🌏 ${guild.name}`)
    .setDescription(
      `🌐 Nama Server : ${guild.name}\n` +
      `🆔 ID Server : \`\`${guild.id}\`\`\n` +
      `👑 Owner : ${ownerName} \`\`${ownerId}\`\`\n` +
      `👥 Jumlah Members : ${guild.memberCount}\n` +
      `🔗 Invite Link : ${inviteText}`
    )
    .setFooter({ text: `Page ${index + 1} of ${guildsArray.length}` });

  // Membuat Tombol Navigasi Prev & Next
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("prev_guild")
      .setLabel("Prev")
      .setStyle(ButtonStyle.Primary)
      .setDisabled(index === 0),
    new ButtonBuilder()
      .setCustomId("next_guild")
      .setLabel("Next")
      .setStyle(ButtonStyle.Primary)
      .setDisabled(index === guildsArray.length - 1)
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("locbot")
      .setDescription("See Server Entered By Bot")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON()
  ],

  setup(client) {
    // HANDLE SLASH COMMAND
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      
      // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
      if (interaction.commandName !== "locbot") return;

      const ownerId = getOwnerId();
      if (interaction.user.id !== ownerId) {
        return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
      }

      const guildsArray = Array.from(client.guilds.cache.values());
      if (guildsArray.length === 0) {
        return interaction.reply({ content: "Bot tidak berada di server manapun.", ephemeral: true });
      }

      let currentIndex = 0;
      const initialPage = await generateGuildPage(guildsArray, currentIndex);

      // Kirim pesan awal secara ephemeral
      const response = await interaction.reply({
        ...initialPage,
        ephemeral: true,
        fetchReply: true
      });

      // Collector untuk mendengarkan klik tombol
      const collector = response.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 120000 // Aktif selama 2 menit (120000ms)
      });

      collector.on("collect", async (i) => {
        if (i.user.id !== ownerId) {
          return i.reply({ content: "❌ Kamu tidak memiliki akses ke tombol ini.", ephemeral: true });
        }

        if (i.customId === "prev_guild") {
          currentIndex--;
        } else if (i.customId === "next_guild") {
          currentIndex++;
        }

        const updatedPage = await generateGuildPage(guildsArray, currentIndex);
        await i.update(updatedPage);
      });

      collector.on("end", async () => {
        // Menonaktifkan tombol setelah waktu collector habis
        const disabledRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("prev_guild").setLabel("Prev").setStyle(ButtonStyle.Primary).setDisabled(true),
          new ButtonBuilder().setCustomId("next_guild").setLabel("Next").setStyle(ButtonStyle.Primary).setDisabled(true)
        );
        await interaction.editReply({ components: [disabledRow] }).catch(() => {});
      });
    });

    // HANDLE MESSAGE COMMAND
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      try {
        if (message.author.bot) return;

        const content = message.content.trim().toLowerCase();
        if (content !== "!locbot") return;

        const ownerId = getOwnerId();
        if (message.author.id !== ownerId) {
          return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
        }

        // Mengambil data server dan fetch owner untuk mendapatkan username terbaru
        const guildPromises = message.client.guilds.cache.map(async (guild) => {
          try {
            const owner = await guild.fetchOwner();
            return `* Nama Server : ${guild.name}\n* ID Server : ${guild.id}\n* Owner Server : ${owner.user.username}`;
          } catch (err) {
            return `* Nama Server : ${guild.name}\n* ID Server : ${guild.id}\n* Owner Server : Tidak dapat memuat username`;
          }
        });

        const guildArray = await Promise.all(guildPromises);
        const guilds = guildArray.join("\n");

        const embed = new EmbedBuilder()
          .setColor("#50C878")
          .setTitle("🆘 List Server Location Bot")
          .setDescription(guilds || "Bot tidak berada di server manapun.");

        await message.reply({ embeds: [embed] });
      } catch (err) {
        console.error("ERR locbot messageCreate:", err);
      }
    });
  }
};