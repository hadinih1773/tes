const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const ownerFile = path.join(__dirname, "../database/owner.json");

const getOwnerId = () => {
  try {
    if (fs.existsSync(ownerFile)) {
      const data = JSON.parse(fs.readFileSync(ownerFile, "utf8"));
      return data.owner;
    }
  } catch (err) {
    console.error("Gagal membaca file owner.json:", err);
  }
  return null;
};

// Fungsi helper parsing waktu string (s, h, d, m) ke milidetik
const parseTimeToMs = (timeStr) => {
  const match = timeStr.match(/^(\d+)([shdm])$/i);
  if (!match) return null;

  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();

  switch (unit) {
    case "s": return value * 1000;
    case "h": return value * 60 * 60 * 1000;
    case "d": return value * 24 * 60 * 60 * 1000;
    case "m": return value * 30 * 24 * 60 * 60 * 1000; // 1 Bulan diasumsikan 30 hari
    default: return null;
  }
};

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("leavebot")
      .setDescription("Commanding the Bot to Leave the Server")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option =>
        option.setName("server")
          .setDescription("Pilih server tempat bot berada (opsional)")
          .setRequired(false)
          .setAutocomplete(true)
      )
      .addStringOption(option =>
        option.setName("serverid")
          .setDescription("Masukkan ID Server secara manual (opsional)")
          .setRequired(false)
      )
      .addStringOption(option =>
        option.setName("time")
          .setDescription("Waktu tunda keluar. Contoh: 10s, 2h, 5d, 3m (opsional)")
          .setRequired(false)
      )
      .toJSON()
  ],

  setup(client) {

    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      const ownerId = getOwnerId();

      // === HANDLE AUTOCOMPLETE UNTUK SERVER LIST ===
      if (interaction.isAutocomplete()) {
        // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
        if (interaction.commandName !== "leavebot") return;
        if (interaction.user.id !== ownerId) return await interaction.respond([]);

        const focusedValue = interaction.options.getFocused().toLowerCase();
        
        const choices = client.guilds.cache.map(guild => ({
          name: guild.name,
          value: guild.id
        }));

        const filtered = choices.filter(choice =>
          choice.name.toLowerCase().includes(focusedValue) || choice.value.includes(focusedValue)
        ).slice(0, 25);

        return await interaction.respond(filtered);
      }

      // === HANDLE SLASH COMMAND EXECUTION ===
      if (!interaction.isChatInputCommand()) return;
      
      // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
      if (interaction.commandName !== "leavebot") return;

      if (interaction.user.id !== ownerId) {
        return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
      }

      const serverId = interaction.options.getString("serverid") || interaction.options.getString("server") || interaction.guild?.id;
      const timeStr = interaction.options.getString("time");

      if (!serverId) {
        return interaction.reply({ content: "❌ ID Server tidak terdeteksi. Silakan pilih server melalui opsi input.", ephemeral: true });
      }

      const targetGuild = client.guilds.cache.get(serverId);
      if (!targetGuild) {
        return interaction.reply({ content: "❌ Bot tidak ditemukan di server tersebut.", ephemeral: true });
      }

      // Jika ada opsi waktu tunda diisi
      if (timeStr) {
        const delayMs = parseTimeToMs(timeStr);
        if (!delayMs) {
          return interaction.reply({ content: "❌ Format waktu salah! Gunakan angka diikuti huruf satuan (s/h/d/m). Contoh: `30s`, `2h`, `5d`, `3m`", ephemeral: true });
        }

        await interaction.reply({ content: `⏱️ Bot dijadwalkan akan keluar dari server **${targetGuild.name}** dalam waktu **${timeStr}**.`, ephemeral: true });

        setTimeout(async () => {
          try {
            const currentGuild = client.guilds.cache.get(serverId);
            if (currentGuild) {
              await currentGuild.leave();
              console.log(`[LEAVE] Bot berhasil keluar dari server: ${currentGuild.name} setelah penundaan ${timeStr}`);
            }
          } catch (err) {
            console.error(`Gagal keluar dari server ${serverId} setelah delay:`, err);
          }
        }, delayMs);

      } else {
        // Jika tidak ada opsi waktu, langsung keluar detik itu juga
        await interaction.reply({ content: `🚀 Mengeluarkan bot dari server **${targetGuild.name}**...`, ephemeral: true });
        try {
          await targetGuild.leave();
        } catch (err) {
          console.error(`Gagal mengeluarkan bot dari server ${serverId}:`, err);
          if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: "❌ Gagal memproses perintah untuk meninggalkan server tersebut.", ephemeral: true });
          } else {
            await interaction.reply({ content: "❌ Gagal memproses perintah untuk meninggalkan server tersebut.", ephemeral: true });
          }
        }
      }
    });

  }
};