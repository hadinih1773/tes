const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

// Jalur ke file owner.json
const ownerPath = path.join(__dirname, "..", "database", "owner.json");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("linkinvite")
            .setDescription("Dapatkan link invite server yang dimasuki bot (Hanya Owner).")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(option =>
                option
                    .setName("server")
                    .setDescription("Pilih server")
                    .setRequired(true)
                    .setAutocomplete(true)
            )
            .toJSON()
    ],
    setup: function(client) {
        // Handler untuk autocomplete (pilihan server)
        client.on("interactionCreate", async (interaction) => {
            if (interaction.isAutocomplete() && interaction.commandName === "linkinvite") {
                const focusedValue = interaction.options.getFocused().toLowerCase();
                const guilds = client.guilds.cache
                    .filter(g => g.name.toLowerCase().includes(focusedValue))
                    .map(g => ({ name: g.name, value: g.id }))
                    .slice(0, 25); // Limit maksimum choice dari Discord API
                
                await interaction.respond(guilds);
            }
        });

        // Handler untuk eksekusi perintah
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            if (interaction.commandName === "linkinvite") {
                // Load data owner
                let ownerData = { owner: "" };
                try {
                    if (fs.existsSync(ownerPath)) {
                        ownerData = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
                    }
                } catch (e) {
                    console.error("Gagal membaca owner.json:", e);
                }

                // Proteksi Owner
                if (interaction.user.id !== ownerData.owner) {
                    return interaction.reply({ 
                        content: "❌ Hanya Owner Yang Bisa Gunakan", 
                        ephemeral: true 
                    });
                }

                const guildId = interaction.options.getString("server");
                const guild = client.guilds.cache.get(guildId);

                if (!guild) {
                    return interaction.reply({
                        content: "Server tidak ditemukan atau bot sudah tidak ada di server tersebut.",
                        ephemeral: true
                    });
                }

                try {
                    const defaultChannel = guild.channels.cache
                        .filter(c => c.type === 0 && c.permissionsFor(guild.members.me).has("CreateInstantInvite"))
                        .first();
                    
                    if (defaultChannel) {
                        const invite = await defaultChannel.createInvite({ maxAge: 0, maxUses: 0 });
                        return interaction.reply({
                            content: `Berikut adalah link invite server ini: ${invite.url}`,
                            ephemeral: true
                        });
                    } else {
                        return interaction.reply({
                            content: "Saya tidak memiliki izin untuk membuat link invite di server ini.",
                            ephemeral: true
                        });
                    }
                } catch (err) {
                    return interaction.reply({
                        content: "Gagal membuat link invite.",
                        ephemeral: true
                    });
                }
            }
        });
    }
};
