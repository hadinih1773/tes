const { EmbedBuilder } = require("discord.js");
const Axios = require("axios");

let tebaktebakanjson = null;

/**
 * Fungsi untuk mengambil soal tebak-tebakan dari database
 */
async function getSoal() {
    if (!tebaktebakanjson) {
        const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json');
        tebaktebakanjson = res.data;
    }
    return tebaktebakanjson[Math.floor(Math.random() * tebaktebakanjson.length)];
}

module.exports = {
    setup(client) {
        // Map untuk menyimpan sesi permainan yang aktif (Key: messageId bot)
        const activeGames = new Map();

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            if (message.author.bot) return;

            const content = message.content.trim().toLowerCase();

            // =================== COMMAND MULAI GAME ===================
            if (content === "!tebaktebakan") {
                try {
                    const soalObj = await getSoal();
                    
                    const embedSoal = new EmbedBuilder()
                        .setColor("Blue")
                        .setTitle("🎮 Game Tebak-Tebakan")
                        .setDescription(`**Soal:**\n"${soalObj.soal}"`)
                        .setFooter({ text: "Reply pesan ini untuk menjawab!" });

                    const sentMsg = await message.reply({ embeds: [embedSoal] });

                    // Simpan data jawaban
                    activeGames.set(sentMsg.id, {
                        jawaban: soalObj.jawaban.toLowerCase().trim(),
                        userId: message.author.id
                    });

                } catch (err) {
                    console.error("Error TebakTebakan:", err);
                    message.reply("Gagal mengambil soal, silakan coba lagi nanti.");
                }
                return;
            }

            // =================== LOGIKA PENGECEKAN JAWABAN ===================
            // Memeriksa apakah pesan adalah reply ke soal yang dikirim bot
            if (message.reference && activeGames.has(message.reference.messageId)) {
                const gameData = activeGames.get(message.reference.messageId);
                const userGuess = content.trim();

                if (userGuess === gameData.jawaban) {
                    // JAWABAN BENAR
                    const embedBenar = new EmbedBuilder()
                        .setColor("Green")
                        .setTitle("✅ Jawaban Kamu Benar!")
                        .setDescription(`${message.author} luar biasa! Jawaban kamu tepat.\n\n**Jawaban:** ${gameData.jawaban.toUpperCase()}`);
                    
                    await message.reply({ embeds: [embedBenar] });
                    activeGames.delete(message.reference.messageId); // Hapus sesi
                } else {
                    // JAWABAN SALAH
                    const embedSalah = new EmbedBuilder()
                        .setColor("Red")
                        .setTitle("❌ Jawaban Kamu Salah!")
                        .setDescription(`Bukan itu jawabannya! Coba lagi kalau bisa.\n\n**Jawaban Benar:** ${gameData.jawaban.toUpperCase()}`);
                    
                    await message.reply({ embeds: [embedSalah] });
                    activeGames.delete(message.reference.messageId); // Hapus sesi
                }
            }
        });
    }
};