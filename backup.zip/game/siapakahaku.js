const { EmbedBuilder } = require("discord.js");

const Axios = require("axios");

let siapakahakujson = null;

/**

 * Fungsi untuk mengambil soal dari database

 */

async function getSoal() {

    if (!siapakahakujson) {

        const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json');

        siapakahakujson = res.data;

    }

    return siapakahakujson[Math.floor(Math.random() * siapakahakujson.length)];

}

module.exports = {

    setup(client) {

        // Map untuk menyimpan sesi permainan yang sedang aktif

        const activeGames = new Map();

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot) return;

            const content = message.content.trim().toLowerCase();

            // =================== COMMAND MULAI GAME ===================

            if (content === "!siapakahaku") {

                try {

                    const soalObj = await getSoal();

                    

                    const embedSoal = new EmbedBuilder()

                        .setColor("Blue")

                        .setTitle("🎮 Game Siapakah Aku")

                        .setDescription(`**Soal:**\n"${soalObj.soal}"`)

                        .setFooter({ text: "Reply pesan ini untuk menjawab!" });

                    const sentMsg = await message.reply({ embeds: [embedSoal] });

                    // Simpan ID pesan bot sebagai kunci untuk mengecek jawaban nanti

                    activeGames.set(sentMsg.id, {

                        jawaban: soalObj.jawaban.toLowerCase().trim(),

                        userId: message.author.id

                    });

                } catch (err) {

                    console.error(err);

                    message.reply("Gagal mengambil soal, coba lagi nanti.");

                }

                return;

            }

            // =================== LOGIKA PENGECEKAN JAWABAN ===================

            // Cek apakah pesan ini adalah reply ke pesan bot yang berisi soal

            if (message.reference && activeGames.has(message.reference.messageId)) {

                const gameData = activeGames.get(message.reference.messageId);

                // Opsional: Hanya orang yang memulai yang bisa menjawab

                // if (message.author.id !== gameData.userId) return;

                const userAnsw = content.trim();

                if (userAnsw === gameData.jawaban) {

                    // JAWABAN BENAR

                    const embedBenar = new EmbedBuilder()

                        .setColor("Green")

                        .setTitle("✅ Jawaban Kamu Benar!")

                        .setDescription(`Selamat ${message.author}! Jawaban kamu tepat.\n\n**Jawaban:** ${gameData.jawaban.toUpperCase()}`);

                    

                    await message.reply({ embeds: [embedBenar] });

                    activeGames.delete(message.reference.messageId); // Hapus sesi setelah terjawab

                } else {

                    // JAWABAN SALAH

                    const embedSalah = new EmbedBuilder()

                        .setColor("Red")

                        .setTitle("❌ Jawaban Kamu Salah!")

                        .setDescription(`Bukan itu jawabannya, coba lagi!\n\n **Jawaban yang benar adalah **${gameData.jawaban.toUpperCase()}`);

                    

                    await message.reply({ embeds: [embedSalah] });

                    // Sesi tetap aktif jika ingin memberikan kesempatan menjawab lagi (atau hapus jika sekali salah langsung selesai)

                    activeGames.delete(message.reference.messageId); 

                }

            }

        });

    }

};