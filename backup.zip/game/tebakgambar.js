// tebakgambar.js
const got = require("got").default;
const { EmbedBuilder } = require("discord.js");

let tebakgambarjson = null;

async function getSoal() {
  if (!tebakgambarjson) {
    tebakgambarjson = await got(
      "https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json"
    ).json();
  }
  return tebakgambarjson[Math.floor(Math.random() * tebakgambarjson.length)];
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;

      if (message.content.toLowerCase() === "!tebakgambar") {
        const soal = await getSoal();

        let imageUrl = soal.img;
        if (imageUrl.startsWith("http://")) {
          imageUrl = imageUrl.replace("http://", "https://");
        }

        const embed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle("🖼️ Tebak Gambar!")
          .setDescription("Coba Tebak Gambar Apakah Ini?")
          .setImage(imageUrl)
          .setFooter({ text: "Reply pesan ini untuk menjawab" });

        const soalMsg = await message.reply({ embeds: [embed] });

        const filter = (m) =>
          !m.author.bot &&
          m.reference &&
          m.reference.messageId === soalMsg.id;

        const collector = message.channel.createMessageCollector({
          filter,
          max: 1,
          time: 30000
        });

        collector.on("collect", (jawabanMsg) => {
          const jawabanUser = jawabanMsg.content.toLowerCase().trim();
          const jawabanBenar = soal.jawaban.toLowerCase().trim();

          if (jawabanUser === jawabanBenar) {
            const benarEmbed = new EmbedBuilder()
              .setColor("Green")
              .setTitle("✅ Jawaban Kamu Benar!")
              .setDescription(`Jawaban: **${soal.jawaban}**`);
              
            message.channel.send({ embeds: [benarEmbed] });
          } else {
            const salahEmbed = new EmbedBuilder()
              .setColor("Red")
              .setTitle("❌ Jawaban Kamu Salah!")
              .setDescription(
                `Jawaban kamu: **${jawabanMsg.content}**\nJawaban benar: **${soal.jawaban}**`
              );
           message.channel.send({ embeds: [salahEmbed] });
          }
        });

        collector.on("end", (collected) => {
          if (collected.size === 0) {
            const timeoutEmbed = new EmbedBuilder()
              .setColor("Red")
              .setTitle("⏰ Waktu Kamu Habis!")
              .setDescription(`Jawaban yang benar: **${soal.jawaban}**`);
              
            message.channel.send({ embeds: [timeoutEmbed] });
          }
        });
      }
    });
  }
};