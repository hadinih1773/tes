const got = require("got").default;

const { EmbedBuilder, AttachmentBuilder } = require("discord.js");

let tebakbenderajson = null;

async function getSoal() {

  if (!tebakbenderajson) {

    tebakbenderajson = await got(

      "https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera2.json"

    ).json();

  }

  return tebakbenderajson[Math.floor(Math.random() * tebakbenderajson.length)];

}

module.exports = {

  setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

      if (message.author.bot) return;

      if (message.content.toLowerCase() === "!tebakbendera") {

        const soal = await getSoal();

        let imageUrl = soal.img;

        if (imageUrl.startsWith("http://")) {

          imageUrl = imageUrl.replace("http://", "https://");

        }

        // ===== FIX UTAMA: PAKSA ZOOM DENGAN ATTACHMENT =====

        const imgBuffer = await got(imageUrl).buffer();

        const attachment = new AttachmentBuilder(imgBuffer, {

          name: "bendera.png"

        });

        const embed = new EmbedBuilder()

          .setColor("Blue")

          .setTitle("🏳 Tebak Bendera Negara!")

          .setDescription("**Bendera Negara Manakah Ini**?")

          .setImage("attachment://bendera.png")   // image embed besar (zoom)

          .setFooter({ text: "Reply pesan ini untuk menjawab" });

        const soalMsg = await message.reply({

          embeds: [embed],

          files: [attachment]

        });

        const filter = (m) =>

          !m.author.bot &&

          m.reference &&

          m.reference.messageId === soalMsg.id;

        const collector = message.channel.createMessageCollector({

          filter,

          max: 1,

          time: 30000

        });

        collector.on("collect", (jawabanMsg) => {

          const jawabanUser = jawabanMsg.content.toLowerCase().trim();

          const jawabanBenar = soal.name.toLowerCase().trim();

          if (jawabanUser === jawabanBenar) {

            const benarEmbed = new EmbedBuilder()

              .setColor("Green")

              .setTitle("✅ Jawaban Kamu Benar!")

              .setDescription(`Jawaban: **${soal.name}**`);

            message.channel.send({ embeds: [benarEmbed] });

          } else {

            const salahEmbed = new EmbedBuilder()

              .setColor("Red")

              .setTitle("❌ Jawaban Kamu Salah!")

              .setDescription(

                `Jawaban kamu: **${jawabanMsg.content}**\nJawaban benar: **${soal.name}**`

              );

            message.channel.send({ embeds: [salahEmbed] });

          }

        });

        collector.on("end", (collected) => {

          if (collected.size === 0) {

            const timeoutEmbed = new EmbedBuilder()

              .setColor("Red")

              .setTitle("⏰ Waktu Kamu Habis!")

              .setDescription(`Jawaban yang benar: **${soal.name}**`);

            message.channel.send({ embeds: [timeoutEmbed] });

          }

        });

      }

    });

  }

};