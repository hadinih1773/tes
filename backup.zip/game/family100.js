const { EmbedBuilder } = require("discord.js");

const Axios = require("axios");

let family100json = null;

/**

 * Fungsi untuk mengambil soal Family 100 dari database

 */

async function getSoal() {

    if (!family100json) {

        try {

            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json');

            family100json = res.data;

        } catch (error) {

            console.error("Error fetching family100 database:", error);

            return null;

        }

    }

    return family100json[Math.floor(Math.random() * family100json.length)];

}

module.exports = {

    setup(client) {

        // Map untuk menyimpan sesi permainan yang aktif (Key: messageId bot)

        const activeGames = new Map();

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot || !message.guild) return;

            const content = message.content.trim().toLowerCase();

            // =================== COMMAND MULAI GAME ===================

            if (content === "!family100") {

                try {

                    const soalObj = await getSoal();

                    if (!soalObj) return message.reply("Gagal mengambil soal, silakan coba lagi nanti.");

                    const listJawaban = soalObj.jawaban.map(j => j.toLowerCase().trim());

                    

                    const embedSoal = new EmbedBuilder()

                        .setColor("Blue")

                        .setTitle("🎮 Game Family 100")

                        .setDescription(`**Pertanyaan:**\n"${soalObj.soal}"`)

                        .setFooter({ text: "Reply pesan ini untuk menjawab salah satu jawabannya!" });

                    const sentMsg = await message.reply({ embeds: [embedSoal] });

                    // Simpan data jawaban

                    activeGames.set(sentMsg.id, {

                        jawaban: listJawaban,

                        jawabanAsli: soalObj.jawaban,

                        userId: message.author.id

                    });

                } catch (err) {

                    console.error("Error Family100:", err);

                    message.reply("Gagal mengambil soal, silakan coba lagi nanti.");

                }

                return;

            }

            // =================== LOGIKA PENGECEKAN JAWABAN ===================

            if (message.reference && message.reference.messageId) {

                const refId = message.reference.messageId;

                

                if (activeGames.has(refId)) {

                    const gameData = activeGames.get(refId);

                    const userGuess = content.trim();

                    if (gameData.jawaban.includes(userGuess)) {

                        // JAWABAN BENAR

                        const embedBenar = new EmbedBuilder()

                            .setColor("Green")

                            .setTitle("✅ Jawaban Kamu Benar!")

                            .setDescription(`${message.author} Mantap! Jawaban tersebut ada dalam daftar.\n\n**Semua Jawaban:**\n${gameData.jawabanAsli.join(", ")}`);

                        

                        await message.reply({ embeds: [embedBenar] });

                        activeGames.delete(refId);

                    } else {

                        // JAWABAN SALAH

                        const embedSalah = new EmbedBuilder()

                            .setColor("Red")

                            .setTitle("❌ Jawaban Kamu Salah!")

                            .setDescription(`Sayang sekali! Jawaban itu tidak ada dalam daftar.\n\n**Jawaban Benar:**\n${gameData.jawabanAsli.join(", ")}`);

                        

                        await message.reply({ embeds: [embedSalah] });

                        activeGames.delete(refId);

                    }

                }

            }

        });

    }

};