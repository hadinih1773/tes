const { EmbedBuilder } = require("discord.js");

const Axios = require("axios");

let susunkatajson = null;

/**

 * Fungsi untuk mengambil soalan susun kata daripada pangkalan data

 */

async function getSoal() {

    if (!susunkatajson) {

        const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json');

        susunkatajson = res.data;

    }

    return susunkatajson[Math.floor(Math.random() * susunkatajson.length)];

}

module.exports = {

    setup(client) {

        // Map untuk menyimpan sesi permainan yang aktif (Key: messageId bot)

        const activeGames = new Map();

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot) return;

            const content = message.content.trim().toLowerCase();

            // =================== COMMAND MULA GAME ===================

            if (content === "!susunkata") {

                try {

                    const soalObj = await getSoal();

                    

                    const embedSoal = new EmbedBuilder()

                        .setColor("Blue")

                        .setTitle("🎮 Game Susun Kata")

                        .setDescription(`**Susun Kata Ini:**\n\n\`${soalObj.soal}\`\n\n**Tipe:** ${soalObj.tipe}`)

                        .setFooter({ text: "Reply pesan ini untuk menjawab!" });

                    const sentMsg = await message.reply({ embeds: [embedSoal] });

                    // Simpan data jawapan

                    activeGames.set(sentMsg.id, {

                        jawaban: soalObj.jawaban.toLowerCase().trim(),

                        userId: message.author.id

                    });

                } catch (err) {

                    console.error("Error SusunKata:", err);

                    message.reply("Gagal mengambil soalan, sila cuba sebentar lagi.");

                }

                return;

            }

            // =================== LOGIK SEMAKAN JAWAPAN ===================

            // Memeriksa jika mesej adalah reply kepada soalan yang dihantar bot

            if (message.reference && activeGames.has(message.reference.messageId)) {

                const gameData = activeGames.get(message.reference.messageId);

                const userGuess = content.trim();

                if (userGuess === gameData.jawaban) {

                    // JAWAPAN BETUL

                    const embedBenar = new EmbedBuilder()

                        .setColor("Green")

                        .setTitle("✅ Jawaban Kamu Benar!")

                        .setDescription(`${message.author} hebat! Susunan kata kamu tepat.\n\n**Jawaban:** ${gameData.jawaban.toUpperCase()}`);

                    

                    await message.reply({ embeds: [embedBenar] });

                    activeGames.delete(message.reference.messageId); // Buang sesi

                } else {

                    // JAWAPAN SALAH

                    const embedSalah = new EmbedBuilder()

                        .setColor("Red")

                        .setTitle("❌ Jawaban Kamu Salah!")

                        .setDescription(`Salah tu! Coba lagi lain kali.\n\n**Jawaban Sebenarnya:** ${gameData.jawaban.toUpperCase()}`);

                    

                    await message.reply({ embeds: [embedSalah] });

                    activeGames.delete(message.reference.messageId); // Buang sesi

                }

            }

        });

    }

};