const { PermissionsBitField, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const ownerPath = path.join(__dirname, "../database/owner.json");

function getOwner() {
    if (!fs.existsSync(ownerPath)) return null;
    try {
        const data = JSON.parse(fs.readFileSync(ownerPath, "utf-8"));
        return data.owner;
    } catch (e) {
        return null;
    }
}

module.exports = {
  data: [
    // COMMAND /CLEAR (KHUSUS OWNER)
    new SlashCommandBuilder()
      .setName("clear")
      .setDescription("Clear Chat In Channels Only Owner")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("jumlah")
          .setDescription("Jumlah pesan (1-100) atau ketik 'all' untuk menghapus semua")
          .setRequired(true)
      )
      .addUserOption(option => 
        option.setName("user")
          .setDescription("Pilih user tertentu yang pesannya ingin dihapus (opsional)")
          .setRequired(false)
      )
      .toJSON(),

    // COMMAND /PURGE (UNTUK ADMIN)
    new SlashCommandBuilder()
      .setName("purge")
      .setDescription("Clear Chat In Channels Only Administrator")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addIntegerOption(option => 
        option.setName("jumlah")
          .setDescription("Jumlah pesan yang ingin dihapus (1-100)")
          .setRequired(true)
      )
      .addUserOption(option => 
        option.setName("user")
          .setDescription("Pilih user tertentu yang pesannya ingin dihapus (opsional)")
          .setRequired(false)
      )
      .toJSON()
  ],

  setup: function(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      // VALIDASI COMMAND AGAR TIDAK BENTROK DAN MENGHINDARI ERROR READING ID
      if (interaction.commandName !== "clear" && interaction.commandName !== "purge") return;
      if (!interaction.guild) return;

      const ownerId = getOwner();

      // ==========================================
      // LENGKAPIN LOGIKA UNTUK COMMAND /CLEAR
      // ==========================================
      if (interaction.commandName === "clear") {
        if (interaction.user.id !== ownerId) {
          return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
        }

        const param = interaction.options.getString("jumlah").toLowerCase();
        const targetUser = interaction.options.getUser("user");

        if (param === "all") {
          if (interaction.channel.isThread()) return interaction.reply({ content: "Tidak bisa digunakan di thread!", ephemeral: true });

          await interaction.reply({ content: "**PERINGATAN:** Semua pesan di channel ini akan dihapus. Mohon tunggu...", ephemeral: false });

          try {
            const oldChannel = interaction.channel;
            const position = oldChannel.position;
            const parent = oldChannel.parent;
            const name = oldChannel.name;
            const topic = oldChannel.topic;
            const nsfw = oldChannel.nsfw;
            const rateLimit = oldChannel.rateLimitPerUser;
            const permissionOverwrites = oldChannel.permissionOverwrites.cache.map(po => ({
              id: po.id,
              allow: po.allow.bitfield,
              deny: po.deny.bitfield,
              type: po.type
            }));

            const newChannel = await oldChannel.guild.channels.create({
              name: name,
              type: oldChannel.type,
              topic: topic,
              nsfw: nsfw,
              parent: parent,
              rateLimitPerUser: rateLimit,
              permissionOverwrites: permissionOverwrites
            });

            await newChannel.setPosition(position).catch(() => {});
            await oldChannel.delete().catch(() => {});

            const msg = await newChannel.send("Channel berhasil dibersihkan.");
            setTimeout(() => msg.delete().catch(() => {}), 5000);
          } catch (error) {
            console.error("Gagal menghapus semua pesan (cc all via slash):", error);
          }
          return;
        }

        // Jika memasukkan jumlah angka di /clear
        const amount = parseInt(param);
        if (isNaN(amount) || amount < 1 || amount > 100) {
          return interaction.reply({ content: "Masukkan jumlah angka antara 1 - 100 atau ketik 'all'!", ephemeral: true });
        }

        try {
          await interaction.deferReply({ ephemeral: true });
          let messages = await interaction.channel.messages.fetch({ limit: amount });

          if (targetUser) {
            messages = messages.filter(m => m.author.id === targetUser.id);
          }

          if (messages.size === 0) {
            return interaction.editReply({ content: "Tidak ditemukan pesan yang cocok untuk dihapus." });
          }

          const deleted = await interaction.channel.bulkDelete(messages, true);
          return interaction.editReply({ content: `Berhasil menghapus **${deleted.size}** pesan!` });
        } catch (error) {
          console.error("Gagal menghapus pesan di /clear:", error);
          return interaction.editReply({ content: "Gagal menghapus pesan." });
        }
      }

      // ==========================================
      // LENGKAPIN LOGIKA UNTUK COMMAND /PURGE
      // ==========================================
      if (interaction.commandName === "purge") {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }

        const amount = interaction.options.getInteger("jumlah");
        const targetUser = interaction.options.getUser("user");

        if (amount < 1 || amount > 100) {
          return interaction.reply({ content: "Jumlah pesan harus di antara 1 - 100!", ephemeral: true });
        }

        try {
          await interaction.deferReply({ ephemeral: true });
          let messages = await interaction.channel.messages.fetch({ limit: amount });

          if (targetUser) {
            messages = messages.filter(m => m.author.id === targetUser.id);
          }

          if (messages.size === 0) {
            return interaction.editReply({ content: "Tidak ditemukan pesan yang cocok untuk dihapus." });
          }

          const deleted = await interaction.channel.bulkDelete(messages, true);
          return interaction.editReply({ content: `Berhasil menghapus **${deleted.size}** pesan!` });
        } catch (error) {
          console.error("Gagal menghapus pesan di /purge:", error);
          return interaction.editReply({ content: "Gagal menghapus pesan." });
        }
      }
    });
  }
};