const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
    
  data: [
    new SlashCommandBuilder()
      .setName('chat')
      .setDescription('Send Message With Using Bot')
      .addStringOption(option =>
        option.setName('pesan')
          .setDescription('Teks atau isi pesan yang mau dikirim')
          .setRequired(true)
      )
      .addBooleanOption(option =>
        option.setName('embed')
          .setDescription('Kirim dalam bentuk embed hitam? (true/false)')
          .setRequired(false)
      )
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== 'chat') return;
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({
          content: '❌ Hanya Admin Yang Bisa Gunakan',
          ephemeral: true,
        });
      }
      const pesan = interaction.options.getString('pesan');
      const isEmbed = interaction.options.getBoolean('embed') || false;

      try {
        const webhooks = await interaction.channel.fetchWebhooks();
        let webhook = webhooks.find(wh => wh.name === 'ChatWebhook');
        if (!webhook) {
          webhook = await interaction.channel.createWebhook({
            name: 'ChatWebhook',
            avatar: client.user.displayAvatarURL(),
          });
        }
        const username = interaction.member.displayName || interaction.user.username;
        const avatar = interaction.user.displayAvatarURL();

        if (isEmbed) {
          const embed = new EmbedBuilder()
            .setDescription(pesan)
            .setColor('#000000')
            .setTimestamp();
          await webhook.send({
            username,
            avatarURL: avatar,
            embeds: [embed],
          });
        } else {
          await webhook.send({
            content: pesan,
            username,
            avatarURL: avatar,
          });
        }
        await interaction.reply({
          content: `✔️ Pesan udah dikirim ${isEmbed ? 'dalam embed hitam' : 'sebagai teks biasa'}!`,
          ephemeral: true,
        });
        console.log(`💬 /chat dari ${interaction.user.tag}: "${pesan}"`);
      } catch (err) {
        console.error('❌ Gagal kirim webhook:', err);
        await interaction.reply({
          content: '❌ Gagal kirim pesan webhook.',
          ephemeral: true,
        });
      }
    });

    (client._msgHandlers = client._msgHandlers || []).push(async (msg) => {
      if (!msg.guild) return;
      if (msg.author.bot) return;
      if (msg.content.startsWith("!chatembed")) return;
      if (!msg.content.startsWith("!chat")) return;
      if (!msg.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return msg.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }
      const pesan = msg.content.replace("!chat", "").trim();
      if (!pesan) {
        return msg.reply("❌ Format salah! Gunakan: `!chat isi pesan`");
      }
      try {
        const webhooks = await msg.channel.fetchWebhooks();
        let webhook = webhooks.find(wh => wh.name === 'ChatWebhook');
        if (!webhook) {
          webhook = await msg.channel.createWebhook({
            name: 'ChatWebhook',
            avatar: client.user.displayAvatarURL(),
          });
        }
        const username = msg.member.displayName || msg.author.username;
        const avatar = msg.author.displayAvatarURL();
        await webhook.send({
          content: pesan,
          username,
          avatarURL: avatar,
        });
        console.log(`💬 !chat dari ${msg.author.tag}: "${pesan}"`);
        msg.delete().catch(() => {});
      } catch (err) {
        console.error("❌ Error command !chat :", err);
        msg.reply("❌ Gagal menjalankan command !chat");
      }
    });

    (client._msgHandlers = client._msgHandlers || []).push(async (msg) => {
      if (!msg.guild) return;
      if (msg.author.bot) return;
      if (!msg.content.startsWith("!chatembed")) return;
      if (!msg.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return msg.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }
      const pesan = msg.content.replace("!chatembed", "").trim();
      if (!pesan) {
        return msg.reply("❌ Format salah! Gunakan: `!chatembed isi pesan`");
      }
      try {
        const webhooks = await msg.channel.fetchWebhooks();
        let webhook = webhooks.find(wh => wh.name === 'ChatWebhook');
        if (!webhook) {
          webhook = await msg.channel.createWebhook({
            name: 'ChatWebhook',
            avatar: client.user.displayAvatarURL(),
          });
        }
        const username = msg.member.displayName || msg.author.username;
        const avatar = msg.author.displayAvatarURL();
        const embed = new EmbedBuilder()
          .setDescription(pesan)
          .setColor('#000000')
          .setTimestamp();
        await webhook.send({
          username,
          avatarURL: avatar,
          embeds: [embed],
        });
        console.log(`🖤 !chatembed dari ${msg.author.tag}: "${pesan}"`);
        msg.delete().catch(() => {});
      } catch (err) {
        console.error("❌ Error command !chatembed :", err);
        msg.reply("❌ Gagal menjalankan command !chatembed");
      }
    });
  },
};