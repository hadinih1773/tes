const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

// Load owner ID dari ../database/owner.json
const ownerPath = path.join(__dirname, "../database/owner.json");
const owner = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
const ownerId = owner.owner;

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("giveroleall")
      .setDescription("Berikan role ke semua member (Hanya Owner).")
      .addRoleOption(option => option.setName("role").setDescription("Pilih role yang ingin diberikan").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("takeroleall")
      .setDescription("Ambil role dari semua member (Hanya Owner).")
      .addRoleOption(option => option.setName("role").setDescription("Pilih role yang ingin diambil").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand() || !interaction.guild) return;

      const { commandName, options, guild, user: author } = interaction;

      // Proteksi murni khusus Owner ID saja
      if (commandName === "giveroleall" || commandName === "takeroleall") {
        if (author.id !== ownerId) {
          return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: false });
        }
      }

      // ===== SLASH GIVEROLEALL =====
      if (commandName === "giveroleall") {
        await interaction.deferReply({ ephemeral: false });
        const role = options.getRole("role");

        if (!role) {
          return interaction.editReply("❌ Role tidak ditemukan!");
        }

        const members = await guild.members.fetch();
        let count = 0;
        await interaction.editReply(`⏳ Memproses pemberian role **${role.name}** ke ${members.size} member...`);

        for (const member of members.values()) {
          if (!member.roles.cache.has(role.id) && !member.user.bot) {
            await member.roles.add(role).catch(() => {});
            count++;
          }
        }
        return interaction.followUp(`✅ Berhasil memberikan role **${role.name}** kepada ${count} member.`);
      }

      // ===== SLASH TAKEROLEALL =====
      if (commandName === "takeroleall") {
        await interaction.deferReply({ ephemeral: false });
        const role = options.getRole("role");

        if (!role) {
          return interaction.editReply("❌ Role tidak ditemukan!");
        }

        const members = await guild.members.fetch();
        let count = 0;
        await interaction.editReply(`⏳ Memproses pengambilan role **${role.name}** dari semua member...`);

        for (const member of members.values()) {
          if (member.roles.cache.has(role.id) && !member.user.bot) {
            await member.roles.remove(role).catch(() => {});
            count++;
          }
        }
        return interaction.followUp(`✅ Berhasil mengambil role **${role.name}** dari ${count} member.`);
      }
    });
  }
};