const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

module.exports = {
  // 1. Registrasi Slash Command (Masuk ke register.js)
  data: [
    new SlashCommandBuilder()
      .setName("createwebhook")
      .setDescription("Membuat webhook baru (Hanya Admin).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("nama")
          .setDescription("Nama untuk webhook baru")
          .setRequired(true)
      )
      .addChannelOption(option => 
        option.setName("channel")
          .setDescription("Pilih channel tujuan (opsional, default channel saat ini)")
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
          .setRequired(false)
      )
      .toJSON(),

    new SlashCommandBuilder()
      .setName("deletewebhook")
      .setDescription("Menghapus webhook berdasarkan URL atau menghapus semua webhook di channel (Hanya Admin).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("url")
          .setDescription("URL webhook yang ingin dihapus")
          .setRequired(false)
      )
      .addChannelOption(option => 
        option.setName("channel")
          .setDescription("Pilih channel untuk menghapus semua webhook di dalamnya")
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
          .setRequired(false)
      )
      .toJSON()
  ],

  // 2. Logika Penanganan Fitur (Auto-load oleh index.js)
  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      // Memastikan hanya memproses Slash Command
      if (!interaction.isChatInputCommand()) return;

      // Memastikan hanya memproses command milik file ini agar tidak mengganggu fitur lain
      if (interaction.commandName !== "createwebhook" && interaction.commandName !== "deletewebhook") return;

      // Proteksi Tambahan: Cek izin Administrator
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({
          content: "❌ Hanya Admin Yang Bisa Gunakan",
          ephemeral: true
        });
      }

      // ==========================================
      // LOGIKA /CREATEWEBHOOK
      // ==========================================
      if (interaction.commandName === "createwebhook") {
        await interaction.deferReply({ ephemeral: true });

        const nama = interaction.options.getString("nama");
        const targetChannel = interaction.options.getChannel("channel") || interaction.channel;

        // Validasi tipe channel agar aman dari error 'id' atau ketidakcocokan tipe data
        if (!targetChannel || (targetChannel.type !== ChannelType.GuildText && targetChannel.type !== ChannelType.GuildAnnouncement)) {
          return interaction.editReply({
            content: "❌ Webhook hanya bisa dibuat di channel teks atau announcement."
          });
        }

        try {
          const webhook = await targetChannel.createWebhook({
            name: nama,
            reason: `Dibuat oleh ${interaction.user.tag} melalui command /createwebhook`
          });

          return interaction.editReply({
            content: `✅ Webhook berhasil dibuat!\n\n**Nama:** ${webhook.name}\n**Channel:** <#${targetChannel.id}>\n**URL:** \`${webhook.url}\``
          });
        } catch (error) {
          console.error("Error saat membuat webhook:", error);
          return interaction.editReply({
            content: "❌ Gagal membuat webhook. Pastikan bot memiliki izin `Manage Webhooks`."
          });
        }
      }

      // ==========================================
      // LOGIKA /DELETEWEBHOOK
      // ==========================================
      if (interaction.commandName === "deletewebhook") {
        await interaction.deferReply({ ephemeral: true });

        const urlInput = interaction.options.getString("url");
        const targetChannel = interaction.options.getChannel("channel");

        if (!urlInput && !targetChannel) {
          return interaction.editReply({
            content: "❌ Masukkan URL webhook atau pilih channel yang ingin dihapus seluruh webhook-nya!"
          });
        }

        // Opsi A: Menghapus semua webhook di channel tertentu
        if (targetChannel) {
          if (targetChannel.type !== ChannelType.GuildText && targetChannel.type !== ChannelType.GuildAnnouncement) {
            return interaction.editReply({
              content: "❌ Channel yang dipilih harus berupa channel teks atau announcement."
            });
          }

          try {
            const webhooks = await targetChannel.fetchWebhooks();
            if (webhooks.size === 0) {
              return interaction.editReply({
                content: `ℹ️ Tidak ada webhook yang ditemukan di channel <#${targetChannel.id}>.`
              });
            }

            for (const webhook of webhooks.values()) {
              await webhook.delete(`Dihapus oleh ${interaction.user.tag} menggunakan /deletewebhook`);
            }

            return interaction.editReply({
              content: `✅ Berhasil menghapus semua webhook (${webhooks.size}) di channel <#${targetChannel.id}>.`
            });
          } catch (error) {
            console.error("Error saat menghapus semua webhook di channel:", error);
            return interaction.editReply({
              content: "❌ Gagal mengambil atau menghapus webhook. Periksa izin bot."
            });
          }
        }

        // Opsi B: Menghapus webhook spesifik berdasarkan URL
        if (urlInput) {
          try {
            // Membaca ID webhook langsung dari string URL untuk menghindari error pembacaan properti
            const match = urlInput.match(/discord\.com\/api\/webhooks\/(\d+)\//);
            if (!match) {
              return interaction.editReply({
                content: "❌ URL Webhook tidak valid! Pastikan formatnya benar."
              });
            }

            const webhookId = match[1];
            const fetchedWebhook = await client.fetchWebhook(webhookId).catch(() => null);

            if (!fetchedWebhook) {
              return interaction.editReply({
                content: "❌ Webhook tidak ditemukan atau sudah dihapus."
              });
            }

            await fetchedWebhook.delete(`Dihapus oleh ${interaction.user.tag} menggunakan /deletewebhook`);
            return interaction.editReply({
              content: `✅ Webhook berhasil dihapus!`
            });
          } catch (error) {
            console.error("Error saat menghapus webhook berdasarkan URL:", error);
            return interaction.editReply({
              content: "❌ Gagal menghapus webhook. Pastikan bot memiliki akses atau URL benar."
            });
          }
        }
      }
    });
  }
};