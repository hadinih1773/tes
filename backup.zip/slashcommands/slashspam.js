const axios = require("axios");
const FormData = require("form-data");
const {
  Events,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
  PermissionFlagsBits,
} = require("discord.js");

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  data: [],

  setup(client) {
    client.on(Events.MessageCreate, async message => {
      if (message.author.bot) return;
      if (message.content === "!setupspam") {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return message.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }

        const setupEmbed = new EmbedBuilder()
          .setTitle("🛡 Spam & Check Webhook")
          .setDescription(`Jika Kalian Menemukan File .lua atau yang Berhubungan dengan Keylogger!! Sini Spam Menggunakan Fitur Bot HC Helper\n\n**Langkah-Langkahnya** :\n1. Klik Button Merah Bernama **🛡 Spam Webhook**\n2. Masukkan Link Discord Webhooknya, Pesannya, dan Jumlah Pesannya\n3. Saran Saya Jangan Terlalu Banyak Spamnya Bisa" Gagal 🗿🗿\n\nTerima Kasih Telah Menyepam Keylogger Puk*. Gunakan Hastag\n#BantaiKeylogger`)
          .setColor("#FF0000");

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("btn_check_webhook")
            .setLabel("🔎 Check Webhook")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId("btn_spam_webhook")
            .setLabel("🛡 Spam Webhook")
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId("btn_delete_webhook")
            .setLabel("🗑 Delete Webhook")
            .setStyle(ButtonStyle.Secondary)
        );

        await message.channel.send({ embeds: [setupEmbed], components: [row] });
        return message.reply({ content: `✅ Panel berhasil dikirim ke ${message.channel}`, ephemeral: true });
      }
    });

    client.on(Events.InteractionCreate, async i => {
      try {
        const validIds = [
          "btn_check_webhook",
          "btn_spam_webhook",
          "btn_delete_webhook",
          "modal_check",
          "modal_spam",
          "modal_delete"
        ];

        if (i.isButton() && !validIds.includes(i.customId)) return;
        if (i.isModalSubmit() && !validIds.includes(i.customId)) return;

        // --- BUTTON ---
        if (i.isButton()) {
          if (i.customId === "btn_check_webhook") {
            const modal = new ModalBuilder()
              .setCustomId("modal_check")
              .setTitle("Cek Webhook Status");

            const linkInput = new TextInputBuilder()
              .setCustomId("check_url")
              .setLabel("Link Webhook")
              .setPlaceholder("https://discord.com/api/webhooks/xxxxx")
              .setStyle(TextInputStyle.Short)
              .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(linkInput));
            return i.showModal(modal);
          }

          if (i.customId === "btn_spam_webhook") {
            const modal = new ModalBuilder()
              .setCustomId("modal_spam")
              .setTitle("Spam Webhook Panel");

            const urlInput = new TextInputBuilder()
              .setCustomId("spam_url")
              .setLabel("Tempat Kirim Url Webhook Disini")
              .setStyle(TextInputStyle.Short)
              .setRequired(true);

            const msgInput = new TextInputBuilder()
              .setCustomId("spam_msg")
              .setLabel("Tempat Pesan Spam")
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(true);

            const countInput = new TextInputBuilder()
              .setCustomId("spam_count")
              .setLabel("Jumlah pesan")
              .setPlaceholder("Contoh: 5")
              .setStyle(TextInputStyle.Short)
              .setRequired(true);

            modal.addComponents(
              new ActionRowBuilder().addComponents(urlInput),
              new ActionRowBuilder().addComponents(msgInput),
              new ActionRowBuilder().addComponents(countInput)
            );

            return i.showModal(modal);
          }

          if (i.customId === "btn_delete_webhook") {
            const modal = new ModalBuilder()
              .setCustomId("modal_delete")
              .setTitle("Delete Webhook");

            const linkInput = new TextInputBuilder()
              .setCustomId("delete_url")
              .setLabel("Link Webhook")
              .setPlaceholder("https://discord.com/api/webhooks/")
              .setStyle(TextInputStyle.Short)
              .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(linkInput));
            return i.showModal(modal);
          }
        }

        // --- MODAL ---
        if (i.isModalSubmit()) {
          if (i.customId === "modal_check") {
            await i.deferReply({ ephemeral: true });
            const url = i.fields.getTextInputValue("check_url").trim();
            return handleCheckWebhook(i, url);
          }

          if (i.customId === "modal_spam") {
            await i.deferReply({ ephemeral: true });
            const options = {
              url: i.fields.getTextInputValue("spam_url").trim(),
              message: i.fields.getTextInputValue("spam_msg"),
              amount: parseInt(i.fields.getTextInputValue("spam_count")) || 1,
              embedEnabled: false,
              colorHex: "#ff0000"
            };
            return handleSpamWebhook(i, options);
          }

          if (i.customId === "modal_delete") {
            await i.deferReply({ ephemeral: true });
            const url = i.fields.getTextInputValue("delete_url").trim();
            return handleDeleteWebhook(i, url);
          }
        }

      } catch (err) {
        console.error("GLOBAL ERROR:", err);
      }
    });
  }
};

async function handleCheckWebhook(i, webhookUrl) {
  try {
    const { data } = await axios.get(webhookUrl);
    const embed = new EmbedBuilder()
      .setTitle("🛡 Cheking Webhook Successful")
      .setDescription(`🚨 **Status** : \nAktif ✅\n\n👤 **Name** :\n${data.name || "N/A"}\n\n#⃣ **Channel ID** : \n${data.channel_id || "N/A"}\n\n🌐 **Guild ID** :\n${data.guild_id || "N/A"}\n\n🆔 **ID** :\n${data.id || "N/A"}`)
      .setColor("#50C878");
    return i.editReply({ embeds: [embed] });
  } catch {
    const embed = new EmbedBuilder()
      .setTitle("🛡 Cheking Webhook Successful")
      .setDescription(`🚨 **Status** : \nTidak Aktif ❌\n\n📋 **Note** :\nSepertinya Webhook Sudah Dihapus`)
      .setColor("#FF0000");
    return i.editReply({ embeds: [embed] });
  }
}

async function handleSpamWebhook(i, opt) {
  try {
    await axios.get(opt.url);
  } catch {
    const embed = new EmbedBuilder()
      .setTitle("🛡 Cheking Webhook Successful")
      .setDescription(`🚨 **Status** : \nTidak Aktif ❌\n\n📋 **Note** :\nWebhook tidak valid atau sudah dihapus`)
      .setColor("#FF0000");
    return i.editReply({ embeds: [embed] }).catch(() => {});
  }

  await i.editReply({ content: `🚀 Pesan Spam Akan Dikirim Ke Targer Sebanyak ${opt.amount}` }).catch(() => {});

  let successCount = 0;
  for (let x = 0; x < opt.amount; x++) {
    try {
      await axios.post(opt.url, { content: opt.message, username: "Captcha Hook" });
      successCount++;
      await sleep(1100);
    } catch (err) {
      if (err.response?.status === 429) {
        const retryAfter = (err.response.data.retry_after || 5) * 1000;
        await sleep(retryAfter);
      }
    }
  }

  return i.editReply({ content: `✅ Pesan Telah Berhasil Terkirim Sebanyak ${successCount}` }).catch(() => {});
}

async function handleDeleteWebhook(i, webhookUrl) {
  try {
    await axios.delete(webhookUrl);
    const embed = new EmbedBuilder()
      .setTitle("🛡 Delete Webhook")
      .setDescription("✅ Webhook berhasil dihapus.")
      .setColor("#50C878");
    return i.editReply({ embeds: [embed] });
  } catch (err) {
    const embed = new EmbedBuilder()
      .setTitle("🛡 Delete Webhook")
      .setDescription("❌ Gagal menghapus webhook. Pastikan URL benar atau webhook sudah tidak ada.")
      .setColor("#FF0000");
    return i.editReply({ embeds: [embed] });
  }
}