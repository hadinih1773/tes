const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  PermissionsBitField,
  SlashCommandBuilder,
  PermissionFlagsBits,
} = require("discord.js");

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("giveaway")
      .setDescription("Create Giveaway Panel In Server")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => option.setName("durasi").setDescription("Durasi (contoh: 30s, 1h, 1d)").setRequired(true))
      .addIntegerOption(option => option.setName("pemenang").setDescription("Jumlah pemenang").setRequired(true))
      .addStringOption(option => option.setName("hadiah").setDescription("Hadiah giveaway").setRequired(true))
      .toJSON()
  ],

  setup(client) {
    // HANDLE SLASH COMMAND
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== "giveaway") return;

      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
      }

      const waktuRaw = interaction.options.getString("durasi");
      const jumlahPemenang = interaction.options.getInteger("pemenang");
      const hadiah = interaction.options.getString("hadiah");

      let durasiMs;
      if (waktuRaw.endsWith("s")) durasiMs = parseInt(waktuRaw) * 1000;
      else if (waktuRaw.endsWith("h")) durasiMs = parseInt(waktuRaw) * 60 * 60 * 1000;
      else if (waktuRaw.endsWith("d")) durasiMs = parseInt(waktuRaw) * 24 * 60 * 60 * 1000;
      else return interaction.reply({ content: "Gunakan `s` (detik), `h` (jam), atau `d` (hari).", ephemeral: true });

      const endTime = Math.floor((Date.now() + durasiMs) / 1000);

      const embed = new EmbedBuilder()
        .setColor("#50C878")
        .setTitle(`🎉 Giveaway ${hadiah} 🎉`)
        .setDescription(`**Hadiah :** ${hadiah}\n**Jumlah Pemenang:** ${jumlahPemenang}\n**Durasi :** ${waktuRaw}\n**End** : <t:${endTime}:F>\n**Participants** : 0\n\nKlik tombol **🎉 Ikut Giveaway** untuk bergabung!`)
        .setFooter({ text: `Dibuat oleh ${interaction.user.tag}` })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("join_giveaway").setLabel("🎉 Ikut Giveaway").setStyle(ButtonStyle.Success)
      );

      const giveawayMsg = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
      handleGiveawayLogic(giveawayMsg, durasiMs, jumlahPemenang, hadiah, interaction.user, embed, endTime);
    });

    // LOGIKA INTI GIVEAWAY
    function handleGiveawayLogic(messageObj, durasiMs, jumlahPemenang, hadiah, creator, originalEmbed, endTime) {
      const peserta = new Set();
      let isEnded = false;

      // Collector tanpa batasan waktu untuk menangani interaksi setelah giveaway selesai
      const collector = messageObj.createMessageComponentCollector();

      // Menghentikan collector utama saat durasi habis
      setTimeout(() => {
        isEnded = true;
        collector.stop();
      }, durasiMs);

      collector.on("collect", async (i) => {
        if (i.customId === "join_giveaway") {
          if (isEnded) {
            return i.reply({
              content: "❌ Giveaway Telah Selesai Silahkan Tunggu Giveaway Yang Baru",
              ephemeral: true
            });
          }

          if (peserta.has(i.user.id)) {
            await i.reply({ content: "Kamu sudah ikut giveaway ini!", ephemeral: true });
          } else {
            peserta.add(i.user.id);
            
            // Update jumlah partisipan pada embed secara realtime
            const updatedEmbed = EmbedBuilder.from(originalEmbed).setDescription(
              `**Hadiah :** ${hadiah}\n**Jumlah Pemenang:** ${jumlahPemenang}\n**Durasi :** ${messageObj.embeds[0].description.split("\n")[2].split(": ")[1]}\n**End** : <t:${endTime}:F>\n**Participants** : ${peserta.size}\n\nKlik tombol **🎉 Ikut Giveaway** untuk bergabung!`
            );
            
            await messageObj.edit({ embeds: [updatedEmbed] }).catch(() => {});
            await i.reply({ content: "Berhasil ikut giveaway!", ephemeral: true });
          }
        }
      });

      collector.on("end", async () => {
        const channel = messageObj.channel;
        
        // Nonaktifkan tombol setelah selesai
        const disabledRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("join_giveaway").setLabel("🎉 Ikut Giveaway").setStyle(ButtonStyle.Success).setDisabled(true)
        );
        await messageObj.edit({ components: [disabledRow] }).catch(() => {});

        if (peserta.size === 0) return channel.send("Tidak ada yang ikut giveaway 😢");

        const pesertaArray = Array.from(peserta);
        const winners = [];

        if (pesertaArray.length < jumlahPemenang) {
          return channel.send(`Peserta kurang. Hanya ${pesertaArray.length} peserta.`);
        }

        for (let i = 0; i < jumlahPemenang; i++) {
          const rand = Math.floor(Math.random() * pesertaArray.length);
          winners.push(pesertaArray[rand]);
          pesertaArray.splice(rand, 1);
        }

        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("Green")
              .setTitle("🎉 GIVEAWAY SELESAI 🎉")
              .setDescription(`**Hadiah:** ${hadiah}\n**Pemenang:** ${winners.map((id) => `<@${id}>`).join(", ")}`)
              .setFooter({ text: "Giveaway telah berakhir" })
              .setTimestamp(),
          ],
        });
      });
    }
  }
};