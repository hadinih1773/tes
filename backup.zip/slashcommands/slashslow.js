const { PermissionsBitField, SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require("discord.js");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("slowmode")
            .setDescription("Set Chat Time On Channel ")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(option => 
                option.setName("durasi")
                    .setDescription("Durasi slowmode (contoh: 5s, 10m, 1h) atau 'off' untuk mematikan")
                    .setRequired(true))
            .addChannelOption(option => 
                option.setName("channel")
                    .setDescription("Pilih channel (opsional, default channel saat ini)")
                    .addChannelTypes(ChannelType.GuildText)
                    .setRequired(false))
            .toJSON()
    ],

    setup: function(client) {
        // HANDLE SLASH COMMAND
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            
            // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
            if (interaction.commandName !== "slowmode") return;

            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
            }

            const durasiInput = interaction.options.getString("durasi").toLowerCase();
            const targetChannel = interaction.options.getChannel("channel") || interaction.channel;

            if (durasiInput === "off") {
                await targetChannel.setRateLimitPerUser(0);
                return interaction.reply(`✅ Slowmode di ${targetChannel} Berhasil Dimatikan.`);
            }

            const time = parseInt(durasiInput);
            const unit = durasiInput.charAt(durasiInput.length - 1);
            let seconds = 0;

            if (unit === "s") seconds = time;
            else if (unit === "m") seconds = time * 60;
            else if (unit === "h") seconds = time * 3600;
            else return interaction.reply({ content: "❌ Format waktu salah! Gunakan s, m, atau h.", ephemeral: true });

            if (seconds > 21600) return interaction.reply({ content: "Maksimal slowmod adalah 6 jam (21600s).", ephemeral: true });

            try {
                await targetChannel.setRateLimitPerUser(seconds);
                return interaction.reply(`✅ Slowmod di ${targetChannel} Berhasil Diaktifkan Selama ${durasiInput}.`);
            } catch (err) {
                return interaction.reply({ content: "Gagal mengatur slowmod.", ephemeral: true });
            }
        });
    }
};