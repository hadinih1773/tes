const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("calc")
            .setDescription("Calculator Fitur To Help Your Math")
            .addStringOption(option => 
                option.setName("operasi")
                    .setDescription("Contoh: 1+2*5/2")
                    .setRequired(true))
            .toJSON()
    ],

    async setup(client) {
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            if (interaction.commandName !== "calc") return;

            const operasi = interaction.options.getString("operasi");

            try {
                // Membersihkan input agar hanya angka dan operator matematika yang diperbolehkan
                const cleanInput = operasi.replace(/[^-+*/().0-9]/g, '');
                
                if (!cleanInput) {
                    return interaction.reply({ content: "⚠️ Input tidak valid!", ephemeral: true });
                }

                // Mengevaluasi operasi matematika
                // Menggunakan Function sebagai alternatif safe-eval sederhana
                const hasil = new Function(`return ${cleanInput}`)();

                if (isNaN(hasil) || !isFinite(hasil)) {
                    return interaction.reply({ content: "❌ Hasil tidak valid atau tidak terhingga.", ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor("#50C878")
                    .setTitle("🔢 Calculator Result")
                    .setDescription(`\`\`\`\n${cleanInput} = ${hasil}\n\`\`\``)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });

            } catch (error) {
                await interaction.reply({ 
                    content: "❌ Gagal menghitung. Pastikan format operasi benar (Contoh: 1+2*3).", 
                    ephemeral: true 
                });
            }
        });
    }
};
