const fs = require("fs");
const path = require("path");
const {
  SlashCommandBuilder,
  PermissionsBitField,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");

const dataPath = path.join(__dirname, "..", "database", "welcome.json");
const dbDir = path.dirname(dataPath);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, "{}");

const loadData = () => JSON.parse(fs.readFileSync(dataPath, "utf8"));
const saveData = (data) => fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("welcome")
      .setDescription("Setup Welcome Message In Community")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(o => o.setName("deskripsi").setDescription("Isi pesan welcome. Gunakan {user} dan {server}").setRequired(true))
      .addBooleanOption(o => o.setName("dm_user").setDescription("Kirim pesan ke DM user"))
      .addChannelOption(o => o.setName("channel").setDescription("Channel tujuan"))
      .addBooleanOption(o => o.setName("embed").setDescription("Gunakan embed"))
      .addStringOption(o => o.setName("color").setDescription("Warna embed (hex)"))
      .addAttachmentOption(o => o.setName("image").setDescription("Gambar utama (upload)"))
      .addStringOption(o => o.setName("image_url").setDescription("Gambar utama (link)"))
      .addAttachmentOption(o => o.setName("thumbnail").setDescription("Thumbnail (upload)"))
      .addStringOption(o => o.setName("thumbnail_url").setDescription("Thumbnail (link)"))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("leave")
      .setDescription("Setup Leave Message In Community")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(o => o.setName("deskripsi").setDescription("Isi pesan leave. Gunakan {user} dan {server}").setRequired(true))
      .addBooleanOption(o => o.setName("dm_user").setDescription("Kirim pesan ke DM user"))
      .addChannelOption(o => o.setName("channel").setDescription("Channel tujuan"))
      .addBooleanOption(o => o.setName("embed").setDescription("Gunakan embed"))
      .addStringOption(o => o.setName("color").setDescription("Warna embed (hex)"))
      .addAttachmentOption(o => o.setName("image").setDescription("Gambar utama (upload)"))
      .addStringOption(o => o.setName("image_url").setDescription("Gambar utama (link)"))
      .addAttachmentOption(o => o.setName("thumbnail").setDescription("Thumbnail (upload)"))
      .addStringOption(o => o.setName("thumbnail_url").setDescription("Thumbnail (link)"))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("deletewelcome")
      .setDescription("Delete Welcome Message")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addChannelOption(o => o.setName("channel").setDescription("Channel target"))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("deleteleave")
      .setDescription("Delete Leave Message")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addChannelOption(o => o.setName("channel").setDescription("Channel target"))
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async interaction => {
      if (!interaction.isChatInputCommand()) return;
      const welcomeCommands = ["welcome", "leave", "deletewelcome", "deleteleave"];
      if (welcomeCommands.includes(interaction.commandName)) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }
        const data = loadData();
        const channel = interaction.options.getChannel("channel") || interaction.channel;
        if (interaction.commandName === "welcome" || interaction.commandName === "leave") {
          await interaction.deferReply({ ephemeral: true });
          
          if (!data[channel.id]) data[channel.id] = {};
          
          const type = interaction.commandName;
          
          const imgAttach = interaction.options.getAttachment("image");
          const imageUrlInput = interaction.options.getString("image_url");
          let imageUrl = imgAttach ? imgAttach.url : (imageUrlInput || data[channel.id][type]?.image || null);

          const thumbAttach = interaction.options.getAttachment("thumbnail");
          const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
          let thumbUrl = thumbAttach ? thumbAttach.url : (thumbnailUrlInput || data[channel.id][type]?.thumbnail || null);
          
          const defaultColor = type === "leave" ? "#FF0000" : "#0000FF";
          
          data[channel.id][type] = {
            desc: interaction.options.getString("deskripsi"),
            dmUser: interaction.options.getBoolean("dm_user") ?? false,
            embed: interaction.options.getBoolean("embed") ?? false,
            color: interaction.options.getString("color") || defaultColor,
            image: imageUrl,
            thumbnail: thumbUrl,
            guildId: interaction.guild.id
          };
          
          saveData(data);
          return interaction.editReply({ content: `✅ Pesan ${type} berhasil diperbarui di <#${channel.id}>.` });
        }
        if (interaction.commandName === "deletewelcome") {
          if (data[channel.id]?.welcome) {
            delete data[channel.id].welcome;
            if (Object.keys(data[channel.id]).length === 0) delete data[channel.id];
            saveData(data);
          }
          return interaction.reply({ content: "🗑️ Data welcome pada channel tersebut dihapus.", ephemeral: true });
        }
        if (interaction.commandName === "deleteleave") {
          if (data[channel.id]?.leave) {
            delete data[channel.id].leave;
            if (Object.keys(data[channel.id]).length === 0) delete data[channel.id];
            saveData(data);
          }
          return interaction.reply({ content: "🗑️ Data leave pada channel tersebut dihapus.", ephemeral: true });
        }
      }
    });

    (client._msgHandlers = client._msgHandlers || []).push(async message => {
      if (message.author.bot || !message.guild) return;
      const content = message.content.toLowerCase();
      
      if (content === "hady welcome" || content === "hady leave") {
        const type = content.includes("welcome") ? "welcome" : "leave";
        const data = loadData();
        let cfg = null;
        for (const id in data) {
          if (!data[id][type]) continue;
          const config = data[id][type];
          if (config && (message.guild.channels.cache.has(id) || config.guildId === message.guild.id)) {
            cfg = config;
            break;
          }
        }
        if (!cfg) return message.reply(`❌ Data ${type} belum diset.`);
        const text = cfg.desc.replace(/{user}/g, `<@${message.author.id}>`).replace(/{server}/g, `**${message.guild.name}**`);
        
        const embed = cfg.embed ? new EmbedBuilder().setDescription(text).setColor(cfg.color) : null;
        if (embed) {
          if (cfg.image) embed.setImage(cfg.image);
          embed.setThumbnail(cfg.thumbnail || message.author.displayAvatarURL({ forceStatic: false }));
        }
        const payload = cfg.embed ? { embeds: [embed] } : text;
        message.channel.send(payload);
      }
    });

    client.on("guildMemberAdd", async member => {
      const data = loadData();
      for (const id in data) {
        const cfg = data[id]?.welcome;
        if (!cfg || cfg.guildId !== member.guild.id) continue;
        
        const ch = member.guild.channels.cache.get(id) || await member.guild.channels.fetch(id).catch(() => null);
        if (!ch) continue;
        const text = cfg.desc.replace(/{user}/g, `<@${member.id}>`).replace(/{server}/g, `**${member.guild.name}**`);
        const embed = cfg.embed ? new EmbedBuilder().setDescription(text).setColor(cfg.color) : null;
        if (embed) {
          if (cfg.image) embed.setImage(cfg.image);
          embed.setThumbnail(cfg.thumbnail || member.user.displayAvatarURL({ forceStatic: false }));
        }
        const payload = cfg.embed ? { embeds: [embed] } : text;
        ch.send(payload).catch(() => null);
        if (cfg.dmUser) await member.send(payload).catch(() => null);
      }
    });

    client.on("guildMemberRemove", async member => {
      const data = loadData();
      for (const id in data) {
        const cfg = data[id]?.leave;
        if (!cfg || cfg.guildId !== member.guild.id) continue;
        
        const ch = member.guild.channels.cache.get(id) || await member.guild.channels.fetch(id).catch(() => null);
        if (!ch) continue;
        const text = cfg.desc.replace(/{user}/g, `<@${member.id}>`).replace(/{server}/g, `**${member.guild.name}**`);
        const embed = cfg.embed ? new EmbedBuilder().setDescription(text).setColor(cfg.color) : null;
        if (embed) {
          if (cfg.image) embed.setImage(cfg.image);
          embed.setThumbnail(cfg.thumbnail || member.user.displayAvatarURL({ forceStatic: false }));
        }
        const payload = cfg.embed ? { embeds: [embed] } : text;
        ch.send(payload).catch(() => null);
        if (cfg.dmUser) await member.send(payload).catch(() => null);
      }
    });
  },
};