const { 
  SlashCommandBuilder, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle, 
  PermissionFlagsBits 
} = require("discord.js");

const fs = require("fs");
const path = require("path");
const dbPath = path.join(__dirname, "../database/report.json");

const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([], null, 2));

function getDB() {
  try { return JSON.parse(fs.readFileSync(dbPath, "utf8")); } catch { return []; }
}

function saveDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("ask")
      .setDescription("Asking To Staff Administrator")
      .addStringOption(o => o.setName("pertanyaan").setDescription("Tulis pertanyaanmu").setRequired(true))
      .addStringOption(o => o.setName("note").setDescription("Catatan kecil").setRequired(false))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("report")
      .setDescription("Reporting To Staff Administrator")
      .addStringOption(o => o.setName("laporan").setDescription("Tulis laporannya").setRequired(true))
      .addAttachmentOption(o => o.setName("image").setDescription("Kirim gambar bukti").setRequired(false))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("listask")
      .setDescription("Check Ask Form Your Member")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("listreport")
      .setDescription("Check Report Form Your Member")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      
      // === SLASH COMMANDS ===
      if (interaction.isChatInputCommand()) {
        const { commandName, options, user, member, guildId } = interaction;
        
        if (!["ask", "report", "listask", "listreport"].includes(commandName)) return;

        if (commandName === "ask" || commandName === "report") {
          const content = options.getString("pertanyaan") || options.getString("laporan");
          const note = options.getString("note") || "Tidak ada catatan.";
          const img = options.getAttachment("image")?.url || null;
          const type = commandName === "ask" ? "Asking" : "Report";

          const db = getDB();
          
          const isDuplicate = db.some(x => x.userId === user.id && x.content === content && x.guildId === guildId);
          if (isDuplicate) {
            return interaction.reply({ content: `⚠️ Kamu sudah mengirim ${type} ini sebelumnya, harap tunggu balasan staff.`, ephemeral: true }).catch(() => {});
          }

          db.push({
            id: Date.now().toString(),
            guildId: guildId,
            type,
            userId: user.id,
            userTag: user.tag,
            content,
            extra: type === "Asking" ? note : img,
            timestamp: new Date().toLocaleString()
          });
          saveDB(db);

          return interaction.reply({ content: `✅ ${type} Berhasil Dikirim Silahkan Tunggu Jawaban Dari Staff!`, ephemeral: true }).catch(() => {});
        }

        if (commandName === "listask" || commandName === "listreport") {
          if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: "❌ Hanya admin yang bisa menggunakan ini.", ephemeral: true }).catch(() => {});
          }

          const type = commandName === "listask" ? "Asking" : "Report";
          const db = getDB().filter(x => x.type === type && x.guildId === guildId);
          
          if (db.length === 0) return interaction.reply({ content: `❌ Belum Ada Asking Atau Report Di Discord Ini.`, ephemeral: true }).catch(() => {});

          const embed = new EmbedBuilder()
            .setTitle(type === "Asking" ? "📜 List Asking" : "⛔ List Report")
            .setColor(type === "Asking" ? "Blue" : "Red")
            .setTimestamp();

          const row = new ActionRowBuilder();
          db.slice(0, 5).forEach((item, i) => {
            embed.addFields({ 
              name: `${i + 1}. ${item.type} From @${item.userTag}`, 
              value: `**Isi:** ${item.content}` 
            });
            row.addComponents(new ButtonBuilder().setCustomId(`ars_ans_${item.id}`).setLabel(`Answer #${i+1}`).setStyle(ButtonStyle.Primary));
          });

          const clearBtn = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`ars_clear_${type.toLowerCase()}`).setLabel(`Clear ${type}`).setStyle(ButtonStyle.Danger)
          );

          return interaction.reply({ embeds: [embed], components: row.components.length > 0 ? [row, clearBtn] : [clearBtn], ephemeral: true }).catch(() => {});
        }
      }

      // === BUTTONS ===
      if (interaction.isButton()) {
        if (!interaction.customId.startsWith("ars_")) return;

        if (interaction.customId.startsWith("ars_ans_")) {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return;
          const id = interaction.customId.split("_")[2];
          const db = getDB();
          const data = db.find(x => x.id === id);
          if (!data) return interaction.reply({ content: "Data hilang atau sudah dijawab.", ephemeral: true }).catch(() => {});

          const modal = new ModalBuilder().setCustomId(`ars_modal_${id}`).setTitle("Answer Member");
          modal.addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("original").setLabel(data.type).setStyle(TextInputStyle.Paragraph).setValue(data.content).setRequired(false)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("reply").setLabel("Jawab Disini").setStyle(TextInputStyle.Paragraph).setRequired(true))
          );
          return interaction.showModal(modal).catch(() => {});
        }

        if (interaction.customId.startsWith("ars_clear_")) {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return;
          const type = interaction.customId.split("_")[2] === "asking" ? "Asking" : "Report";
          const guildId = interaction.guildId;
          
          const db = getDB();
          const filtered = db.filter(x => !(x.type === type && x.guildId === guildId));
          saveDB(filtered);
          
          return interaction.reply({ content: `✅ List ${type} di server ini dibersihkan.`, ephemeral: true }).catch(() => {});
        }
      }

      // === MODAL SUBMIT ===
      if (interaction.isModalSubmit()) {
        if (!interaction.customId.startsWith("ars_modal_")) return;

        const id = interaction.customId.split("_")[2];
        const replyText = interaction.fields.getTextInputValue("reply");
        
        // Ambil data terbaru untuk pengecekan
        let db = getDB();
        const index = db.findIndex(x => x.id === id);
        const data = db[index];

        if (data) {
          // Segera hapus data dari database agar tidak bisa diproses dua kali (mencegah double DM)
          db.splice(index, 1);
          saveDB(db);

          const target = await client.users.fetch(data.userId).catch(() => null);
          if (target) {
            const dmEmbed = new EmbedBuilder()
              .setTitle("👑 Answer Staff Administrator")
              .setColor("#50C878")
              .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
              .addFields(
                { name: "👤 Nama Staff", value: `<@${interaction.user.id}>`, inline: true },
                { name: "📜 Type", value: data.type, inline: true },
                { name: "📅 Date", value: new Date().toLocaleString(), inline: true },
                { name: data.type === "Asking" ? "❓ Question" : "⛔ Report", value: data.content },
                { name: "📋 Answer", value: replyText }
              );
            if (data.type === "Report" && data.extra) dmEmbed.setImage(data.extra);
            
            // Kirim DM
            await target.send({ embeds: [dmEmbed] }).catch(() => {});
          }
          
          return interaction.reply({ content: "✅ Jawaban Sudah Terkirim Melalui DM!", ephemeral: true }).catch(() => {});
        } else {
          // Jika data sudah tidak ada (berarti sudah dijawab oleh listener lain/sebelumnya)
          return; 
        }
      }
    });
  }
};