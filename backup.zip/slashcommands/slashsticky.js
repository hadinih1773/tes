const fs = require("fs");
const path = require("path");
const {
  SlashCommandBuilder,
  PermissionsBitField,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");

const dataPath = path.join(__dirname, "..", "database", "sticky.json");
if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, "{}");

const loadData = () => JSON.parse(fs.readFileSync(dataPath, "utf8"));
const saveData = (data) => fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

const processingChannels = new Set();

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("sticky")
      .setDescription("Create Sticky Message With Chat Or Embed Message")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption((opt) => opt.setName("deskripsi").setDescription("Isi sticky message").setRequired(true))
      .addChannelOption((opt) => opt.setName("channel").setDescription("Channel sticky (opsional)"))
      .addBooleanOption((opt) => opt.setName("embed").setDescription("Kirim sebagai embed"))
      .addStringOption((opt) => opt.setName("color").setDescription("Warna embed (hex)"))
      .addAttachmentOption((opt) => opt.setName("image").setDescription("Gambar utama (upload)"))
      .addStringOption((opt) => opt.setName("image_url").setDescription("Gambar utama (link)"))
      .addAttachmentOption((opt) => opt.setName("thumbnail").setDescription("Thumbnail (upload)"))
      .addStringOption((opt) => opt.setName("thumbnail_url").setDescription("Thumbnail (link)"))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("deletesticky")
      .setDescription("Delete Sticky Message From Channel")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addChannelOption((opt) => opt.setName("channel").setDescription("Channel sticky (opsional)"))
      .toJSON()
  ],

  setup(client) {
    const refreshSticky = async (channelId) => {
      if (processingChannels.has(channelId)) return;
      processingChannels.add(channelId);
      const data = loadData();
      const sticky = data[channelId];
      if (!sticky || !sticky.desc) {
        processingChannels.delete(channelId);
        return;
      }
      try {
        const channel = await client.channels.fetch(channelId).catch(() => null);
        if (!channel) return;
        if (sticky.messageId) {
          const oldMsg = await channel.messages.fetch(sticky.messageId).catch(() => null);
          if (oldMsg) await oldMsg.delete().catch(() => {});
        }
        let payload = {};
        if (sticky.embed) {
          const embed = new EmbedBuilder()
            .setDescription(sticky.desc.toString())
            .setColor(sticky.color && sticky.color.startsWith("#") ? sticky.color : "#000000");
          if (sticky.image) embed.setImage(sticky.image);
          if (sticky.thumbnail) embed.setThumbnail(sticky.thumbnail);
          payload = { embeds: [embed] };
        } else {
          payload = { content: sticky.desc.toString() };
        }
        const newMsg = await channel.send(payload);
        data[channelId].messageId = newMsg.id;
        saveData(data);
      } catch (e) {
        console.error("Error refresh sticky:", e);
      } finally {
        setTimeout(() => processingChannels.delete(channelId), 1500);
      }
    };
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      
      if (interaction.commandName === "sticky" || interaction.commandName === "deletesticky") {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }
        const data = loadData();
        if (interaction.commandName === "sticky") {
          await interaction.deferReply({ ephemeral: true });
          const desc = interaction.options.getString("deskripsi");
          const channel = interaction.options.getChannel("channel") || interaction.channel;
          const isEmbed = interaction.options.getBoolean("embed") || false;
          const colorHex = interaction.options.getString("color") || "#000000";
          
          const imageFile = interaction.options.getAttachment("image");
          const imageUrlInput = interaction.options.getString("image_url");
          const finalImage = imageFile ? imageFile.url : imageUrlInput;

          const thumbnailFile = interaction.options.getAttachment("thumbnail");
          const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
          const finalThumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;
          
          data[channel.id] = {
            messageId: null,
            embed: isEmbed,
            desc: desc,
            color: colorHex,
            image: finalImage,
            thumbnail: finalThumbnail,
          };
          saveData(data);
          
          await refreshSticky(channel.id);
          return interaction.editReply({ content: `✅ Sticky berhasil dibuat di ${channel}` });
        }
        if (interaction.commandName === "deletesticky") {
          const channel = interaction.options.getChannel("channel") || interaction.channel;
          if (!data[channel.id]) return interaction.reply({ content: "⚠️ Tidak ada sticky di channel ini.", ephemeral: true });
          
          const oldMsg = await channel.messages.fetch(data[channel.id].messageId).catch(() => null);
          if (oldMsg) await oldMsg.delete().catch(() => {});
          
          delete data[channel.id];
          saveData(data);
          return interaction.reply({ content: `🗑️ Sticky di ${channel} berhasil dihapus.`, ephemeral: true });
        }
      }
    });
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      const data = loadData();
      const sticky = data[message.channel.id];
      if (sticky) {
        if (message.id === sticky.messageId) return;
        await refreshSticky(message.channel.id);
      }
    });
    fs.watch(__filename, async (eventType) => {
      if (eventType === "rename" && !fs.existsSync(__filename)) {
        try {
          const commands = await client.application.commands.fetch();
          for (const cmd of commands.values()) {
            if (cmd.name === "sticky" || cmd.name === "deletesticky") {
              await client.application.commands.delete(cmd.id);
            }
          }
        } catch (err) {}
      }
    });
  },
};