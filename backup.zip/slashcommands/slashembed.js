const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("embed")
      .setDescription("Create Embed Message With Using Bot")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => option.setName("title").setDescription("Judul embed").setRequired(true))
      .addStringOption(option => option.setName("deskripsi").setDescription("Deskripsi embed").setRequired(true))
      .addChannelOption(option => option.setName("channel").setDescription("Pilih channel tujuan embed (opsional)").setRequired(false))
      .addStringOption(option => option.setName("color").setDescription("Warna embed (contoh: #ff0000, #0000ff dll").setRequired(false))
      .addAttachmentOption(option => option.setName("image").setDescription("Upload gambar utama (opsional)").setRequired(false))
      .addStringOption(option => option.setName("image_url").setDescription("Masukkan Link Gambar utama (opsional)").setRequired(false))
      .addStringOption(option => option.setName("footer").setDescription("Teks footer embed (opsional)").setRequired(false))
      .addAttachmentOption(option => option.setName("thumbnail").setDescription("Upload gambar thumbnail kecil (opsional)").setRequired(false))
      .addStringOption(option => option.setName("thumbnail_url").setDescription("Masukkan Link Thumbnail kecil (opsional)").setRequired(false))
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand() || interaction.commandName !== "embed") return;

      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
      }

      await interaction.deferReply({ ephemeral: true });

      const channel = interaction.options.getChannel("channel") || interaction.channel;
      const color = interaction.options.getString("color");
      const title = interaction.options.getString("title");
      const deskripsi = interaction.options.getString("deskripsi");
      const footerText = interaction.options.getString("footer");
      
      const imageFile = interaction.options.getAttachment("image");
      const imageUrlInput = interaction.options.getString("image_url");
      const image = imageFile ? imageFile.url : imageUrlInput;

      const thumbnailFile = interaction.options.getAttachment("thumbnail");
      const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
      const thumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

      try {
        const embed = new EmbedBuilder()
          .setTitle(title)
          .setDescription(deskripsi)
          .setColor(color || "#000000")
          .setTimestamp();

        if (footerText) embed.setFooter({ text: footerText });

        if (image) {
          embed.setImage(image);
        }

        if (thumbnail) {
          embed.setThumbnail(thumbnail);
        }

        await channel.send({ embeds: [embed] });
        await interaction.editReply({ content: `✅ Embed berhasil dikirim ke ${channel}` });

      } catch (err) {
        console.error(err);
        await interaction.editReply({ content: "❌ Gagal membuat embed." });
      }
    });
  }
};