const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    PermissionFlagsBits, 
    ChannelType,
    AttachmentBuilder 
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../database/invitetracker.json");

if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true });
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({ configs: {}, counts: {}, history: {} }));

const inviteCache = new Map();

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("invitetracker")
            .setDescription("Setup Invite Tracker System")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(o => o.setName("title").setDescription("Judul pesan").setRequired(true))
            .addStringOption(o => o.setName("deskripsi").setDescription("Gunakan {user}, {userinvite}, {totalinvite}, {memberdc}").setRequired(true))
            .addChannelOption(o => o.setName("channel").setDescription("Channel tujuan").addChannelTypes(ChannelType.GuildText))
            .addBooleanOption(o => o.setName("embed").setDescription("Kirim dalam bentuk embed? (True/False)"))
            .addStringOption(o => o.setName("color").setDescription("Warna Hex (Contoh: #50c878)"))
            .addAttachmentOption(o => o.setName("image").setDescription("Upload gambar utama"))
            .addStringOption(o => o.setName("image_url").setDescription("Link URL gambar utama"))
            .addAttachmentOption(o => o.setName("thumbnail").setDescription("Upload thumbnail"))
            .addStringOption(o => o.setName("thumbnail_url").setDescription("Link URL thumbnail"))
            .toJSON(),

        new SlashCommandBuilder()
            .setName("deleteinvitetracker")
            .setDescription("Delete Invite Tracker System")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addChannelOption(o => o.setName("channel").setDescription("Channel yang ingin dihapus (opsional)"))
            .toJSON()
    ],

    async setup(client) {
        client.on("ready", async () => {
            for (const [id, guild] of client.guilds.cache) {
                try {
                    const invites = await guild.invites.fetch();
                    inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses])));
                } catch (e) { console.log(`Gagal cache invite di ${guild.name}`); }
            }
        });

        client.on("inviteCreate", inv => inviteCache.get(inv.guild.id)?.set(inv.code, inv.uses));
        client.on("inviteDelete", inv => inviteCache.get(inv.guild.id)?.delete(inv.code));

        client.on("guildMemberAdd", async (member) => {
            const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));
            const config = db.configs[member.guild.id];
            if (!config) return;

            const newInvites = await member.guild.invites.fetch();
            const oldInvites = inviteCache.get(member.guild.id);
            
            let inviter = null;
            let usedInvite = newInvites.find(i => i.uses > (oldInvites?.get(i.code) || 0));
            
            inviteCache.set(member.guild.id, new Map(newInvites.map(i => [i.code, i.uses])));

            if (usedInvite) {
                inviter = usedInvite.inviter;
                if (inviter) {
                    db.counts[member.guild.id] = db.counts[member.guild.id] || {};
                    db.counts[member.guild.id][inviter.id] = (db.counts[member.guild.id][inviter.id] || 0) + 1;
                    db.history[member.id] = inviter.id;
                    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
                }
            }

            const totalInvite = inviter ? (db.counts[member.guild.id][inviter.id] || 0) : 0;
            const channel = member.guild.channels.cache.get(config.channelId);
            if (!channel) return;

            const format = (str) => str
                .replace(/{user}/g, `<@${member.id}>`)
                .replace(/{userinvite}/g, inviter ? `<@${inviter.id}>` : "Unknown/Vanity")
                .replace(/{totalinvite}/g, totalInvite)
                .replace(/{memberdc}/g, member.guild.memberCount);

            const deskripsiFinal = format(config.deskripsi);
            const titleFinal = format(config.title);

            if (config.isEmbed) {
                const embed = new EmbedBuilder()
                    .setTitle(titleFinal)
                    .setDescription(deskripsiFinal)
                    .setColor(config.color || "#50c878")
                    .setTimestamp();
                
                if (config.image) embed.setImage(config.image);
                
                const thumbURL = config.thumbnail || member.user.displayAvatarURL({ dynamic: true, size: 512 });
                embed.setThumbnail(thumbURL);
                
                channel.send({ embeds: [embed] });
            } else {
                channel.send({ content: `**${titleFinal}**\n${deskripsiFinal}` });
            }
        });

        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;

            if (interaction.commandName === "invitetracker") {
                if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return interaction.reply({ content: "❌ Anda butuh izin Administrator.", ephemeral: true });
                }

                const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));
                const title = interaction.options.getString("title");
                const deskripsi = interaction.options.getString("deskripsi");
                const channel = interaction.options.getChannel("channel") || interaction.channel;
                const isEmbed = interaction.options.getBoolean("embed") ?? false;
                const color = interaction.options.getString("color");
                
                const imageFile = interaction.options.getAttachment("image");
                const imageUrlInput = interaction.options.getString("image_url");
                const finalImage = imageFile ? imageFile.url : imageUrlInput;

                const thumbnailFile = interaction.options.getAttachment("thumbnail");
                const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
                const finalThumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

                db.configs[interaction.guild.id] = {
                    title,
                    deskripsi,
                    channelId: channel.id,
                    isEmbed,
                    color,
                    image: finalImage || null,
                    thumbnail: finalThumbnail || null
                };

                fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
                await interaction.reply({ content: `✅ Invite Tracker berhasil diset di channel ${channel}`, ephemeral: true });
            }

            if (interaction.commandName === "deleteinvitetracker") {
                if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return interaction.reply({ content: "❌ Anda butuh izin Administrator.", ephemeral: true });
                }

                const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));
                if (db.configs[interaction.guild.id]) {
                    delete db.configs[interaction.guild.id];
                    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
                    await interaction.reply({ content: "✅ Konfigurasi Invite Tracker dihapus.", ephemeral: true });
                } else {
                    await interaction.reply({ content: "❌ Tidak ada konfigurasi ditemukan untuk server ini.", ephemeral: true });
                }
            }
        });
    }
};