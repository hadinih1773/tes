const { 
    PermissionsBitField, 
    EmbedBuilder, 
    SlashCommandBuilder,
    PermissionFlagsBits
} = require('discord.js');
const fs = require('fs');
const path = require('path');

// === AUTO CREATE FOLDER & FILE ===
const dbFolder = path.join(__dirname, '../database');
const warnFile = path.join(dbFolder, 'warn.json');

if (!fs.existsSync(dbFolder)) fs.mkdirSync(dbFolder);
if (!fs.existsSync(warnFile)) fs.writeFileSync(warnFile, JSON.stringify({}, null, 2));

const loadWarn = () => JSON.parse(fs.readFileSync(warnFile));
const saveWarn = (data) => fs.writeFileSync(warnFile, JSON.stringify(data, null, 2));

let warns = loadWarn();

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("ban")
            .setDescription("Ban User From The Server")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di ban").setRequired(true))
            .addStringOption(o => o.setName("alasan").setDescription("Alasan ban").setRequired(false))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("unban")
            .setDescription("Unban User From The Server")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(o => o.setName("id").setDescription("ID User yang akan di unban").setRequired(true))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("timeout")
            .setDescription("Give Timeout To User From The Server")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di timeout").setRequired(true))
            .addStringOption(o => o.setName("waktu").setDescription("Contoh: 10s, 5m, 2h, 1d").setRequired(true))
            .addStringOption(o => o.setName("alasan").setDescription("Alasan timeout").setRequired(false))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("untimeout")
            .setDescription("Remove Timeout From User In The Server")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di untimeout").setRequired(true))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("warn")
            .setDescription("Give Warning To User")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di warn").setRequired(true))
            .addStringOption(o => o.setName("alasan").setDescription("Alasan warn").setRequired(false))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("unwarn")
            .setDescription("Remove One Warning From User")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di unwarn").setRequired(true))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("clearwarn")
            .setDescription("Clear All Warnings From User")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di clearwarn").setRequired(true))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("kick")
            .setDescription("Kick User From The Server")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di kick").setRequired(true))
            .addStringOption(o => o.setName("alasan").setDescription("Alasan kick").setRequired(false))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("cekwarn")
            .setDescription("Check Warning User In Server")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(o => o.setName("user").setDescription("User yang akan di cek").setRequired(true))
            .toJSON(),
        new SlashCommandBuilder()
            .setName("mywarn")
            .setDescription("Check Your Warning In Server")
            .toJSON()
    ],

    setup(client) {
        const prefix = '!';

        // HANDLE SLASH COMMANDS
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;

            const { commandName, options, member, guild, user: author } = interaction;

            // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
            const modCmds = ["ban", "unban", "timeout", "untimeout", "warn", "unwarn", "clearwarn", "kick", "cekwarn", "mywarn"];
            if (!modCmds.includes(commandName)) return;

            const isAdmin = member.permissions.has(PermissionsBitField.Flags.Administrator) ||
                            member.permissions.has(PermissionsBitField.Flags.BanMembers) ||
                            member.permissions.has(PermissionsBitField.Flags.KickMembers) ||
                            member.permissions.has(PermissionsBitField.Flags.ModerateMembers);

            // Cek Izin Admin (Kecuali mywarn)
            if (commandName !== "mywarn" && !isAdmin) {
                return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
            }

            try {
                if (commandName === "ban") {
                    const target = options.getMember("user");
                    const reason = options.getString("alasan") || "Tidak ada alasan";
                    if (!target || !target.bannable) return interaction.reply({ content: "⚠️ Tidak bisa ban user ini.", ephemeral: true });
                    await target.ban({ reason, deleteMessageSeconds: 604800 });
                    await interaction.reply(`✅ ${target.user.tag} diban & chat 7 hari terakhir dihapus. Alasan: **${reason}**`);
                }

                if (commandName === "unban") {
                    const userId = options.getString("id");
                    try {
                        await guild.members.unban(userId);
                        await interaction.reply(`✅ User ${userId} di-unban.`);
                    } catch {
                        await interaction.reply({ content: "⚠️ Gagal unban. Pastikan ID benar.", ephemeral: true });
                    }
                }

                if (commandName === "timeout") {
                    const target = options.getMember("user");
                    const timeArg = options.getString("waktu");
                    const reason = options.getString("alasan") || "Tidak ada alasan";
                    if (!target) return interaction.reply({ content: "⚠️ User tidak ditemukan.", ephemeral: true });

                    let ms = 0;
                    if (timeArg.endsWith("s")) ms = parseInt(timeArg) * 1000;
                    else if (timeArg.endsWith("m")) ms = parseInt(timeArg) * 60000;
                    else if (timeArg.endsWith("h")) ms = parseInt(timeArg) * 3600000;
                    else if (timeArg.endsWith("d")) ms = parseInt(timeArg) * 86400000;
                    else return interaction.reply({ content: "Format waktu salah (s/m/h/d).", ephemeral: true });

                    await target.timeout(ms, reason);
                    await interaction.reply(`⏳ ${target.user.tag} timeout selama ${timeArg}. Alasan: ${reason}`);
                }

                if (commandName === "untimeout") {
                    const target = options.getMember("user");
                    if (!target) return interaction.reply({ content: "⚠️ User tidak ditemukan.", ephemeral: true });
                    await target.timeout(null);
                    await interaction.reply(`✅ Timeout ${target.user.tag} dihapus.`);
                }

                if (commandName === "kick") {
                    const target = options.getMember("user");
                    const reason = options.getString("alasan") || "Tidak ada alasan";
                    if (!target || !target.kickable) return interaction.reply({ content: "⚠️ Tidak bisa kick user ini.", ephemeral: true });
                    await target.kick(reason);
                    await interaction.reply(`👢 ${target.user.tag} berhasil di kick. Alasan: ${reason}`);
                }

                if (commandName === "warn") {
                    const target = options.getUser("user");
                    const reason = options.getString("alasan") || "Tidak ada alasan";
                    if (!warns[target.id]) warns[target.id] = [];
                    warns[target.id].push({ reason, admin: author.id, date: Date.now() });
                    saveWarn(warns);
                    await interaction.reply(`⚠️ Warn diberikan ke ${target}. Alasan: ${reason}`);
                }

                if (commandName === "unwarn") {
                    const target = options.getUser("user");
                    if (!warns[target.id] || warns[target.id].length === 0) {
                        return interaction.reply({ content: "⚠️ User tidak punya warn.", ephemeral: true });
                    }
                    warns[target.id].shift();
                    saveWarn(warns);
                    await interaction.reply(`☑️ 1 warn ${target} dihapus.`);
                }

                if (commandName === "clearwarn") {
                    const target = options.getUser("user");
                    delete warns[target.id];
                    saveWarn(warns);
                    await interaction.reply(`🗑️ Semua warn ${target} dihapus.`);
                }

                if (commandName === "cekwarn") {
                    const target = options.getUser("user");
                    const data = warns[target.id] || [];
                    const embed = new EmbedBuilder()
                        .setTitle(`📄 Daftar Warn: ${target.tag}`)
                        .setColor("#ff0000")
                        .setDescription(data.length === 0 ? "User ini tidak punya warn." : data.map((w, i) => `**${i + 1}.** Reason: **${w.reason}**\nAdmin: <@${w.admin}>`).join("\n\n"));
                    await interaction.reply({ embeds: [embed] });
                }

                if (commandName === "mywarn") {
                    const data = warns[author.id] || [];
                    const embed = new EmbedBuilder()
                        .setTitle("📄 Warn Kamu")
                        .setColor("#ff0000")
                        .setDescription(data.length === 0 ? "Kamu tidak punya warn." : data.map((w, i) => `**${i + 1}.** Reason: **${w.reason}**\nAdmin: <@${w.admin}>`).join("\n\n"));
                    await interaction.reply({ embeds: [embed] });
                }

            } catch (err) {
                console.log(err);
                if (!interaction.replied) await interaction.reply({ content: "❌ Terjadi kesalahan.", ephemeral: true });
            }
        });

        // HANDLE PREFIX COMMANDS
        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            try {
                if (!message.content.startsWith(prefix) || message.author.bot) return;
                if (!message.guild) return;

                const full = message.content.slice(prefix.length).trim();
                const args = full.split(/ +/);
                const command = args.shift().toLowerCase();

                const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator) ||
                                message.member.permissions.has(PermissionsBitField.Flags.BanMembers) ||
                                message.member.permissions.has(PermissionsBitField.Flags.KickMembers) ||
                                message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers);

                if (['x', 'ban', '+', 'unban', 't', 'timeout', 'k', 'kick', 'w', 'warn', 'uw', 'unwarn', 'cw', 'clearwarn', 'ut', 'untimeout', 'cekwarn', 'cwk'].includes(command)) {
                    if (!isAdmin) {
                        return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then(m => {
                            setTimeout(() => m.delete().catch(() => { }), 5000);
                        });
                    }

                    if (command === "x" || command === "ban") {
                        const userArg = args.shift();
                        const reason = args.join(" ") || "Tidak ada alasan";
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id reason\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        const member = await message.guild.members.fetch(uid).catch(() => null);
                        if (!member || !member.bannable) return message.reply("⚠️ Ga bisa di ban.");
                        await member.ban({ reason, deleteMessageSeconds: 604800 });
                        return message.reply(`✅ ${member.user.tag} diban & chat 7 hari terakhir dihapus.`);
                    }

                    if (command === "+" || command === "unban") {
                        const userArg = args.shift();
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        await message.guild.members.unban(uid).catch(() => message.reply("⚠️ Gagal unban."));
                        return message.reply(`✅ User ${uid} di-unban.`);
                    }

                    if (command === "t" || command === "timeout") {
                        const userArg = args.shift();
                        const timeArg = args.shift();
                        const reason = args.join(" ") || "Tidak ada alasan";
                        if (!userArg || !timeArg) return message.reply(`❌ Format Salah : \`!${command} user/id 10s/2h/3d reason\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        const member = await message.guild.members.fetch(uid).catch(() => null);
                        if (!member) return message.reply("⚠️ User tidak ditemukan.");
                        let ms = 0;
                        if (timeArg.endsWith("s")) ms = parseInt(timeArg) * 1000;
                        else if (timeArg.endsWith("m")) ms = parseInt(timeArg) * 60000;
                        else if (timeArg.endsWith("h")) ms = parseInt(timeArg) * 3600000;
                        else if (timeArg.endsWith("d")) ms = parseInt(timeArg) * 86400000;
                        await member.timeout(ms, reason);
                        return message.reply(`⏳ ${member.user.tag} timeout selama ${timeArg}`);
                    }

                    if (command === "ut" || command === "untimeout") {
                        const userArg = args.shift();
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        const member = await message.guild.members.fetch(uid).catch(() => null);
                        if (member) await member.timeout(null);
                        return message.reply(`✅ Timeout dihapus.`);
                    }

                    if (command === "k" || command === "kick") {
                        const userArg = args.shift();
                        const reason = args.join(" ") || "Tidak ada alasan";
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id reason\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        const member = await message.guild.members.fetch(uid).catch(() => null);
                        if (member && member.kickable) await member.kick(reason);
                        return message.reply(`👢 Member berhasil di kick.`);
                    }

                    if (command === "w" || command === "warn") {
                        const userArg = args.shift();
                        const reason = args.join(" ") || "Tidak ada alasan";
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id reason\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        if (!warns[uid]) warns[uid] = [];
                        warns[uid].push({ reason, admin: message.author.id, date: Date.now() });
                        saveWarn(warns);
                        return message.reply(`⚠️ Warn diberikan ke <@${uid}>`);
                    }

                    if (command === "uw" || command === "unwarn") {
                        const userArg = args.shift();
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        if (warns[uid]) warns[uid].shift();
                        saveWarn(warns);
                        return message.reply(`☑️ 1 warn <@${uid}> dihapus.`);
                    }

                    if (command === "cw" || command === "clearwarn") {
                        const userArg = args.shift();
                        if (!userArg) return message.reply(`❌ Format Salah : \`!${command} user/id\``);
                        const uid = userArg.replace(/[<@!>]/g, "");
                        delete warns[uid];
                        saveWarn(warns);
                        return message.reply(`🗑️ Semua warn <@${uid}> dihapus.`);
                    }

                    if (command === "cekwarn" || command === "cwk") {
                        let uid;
                        if (message.reference) {
                            const repliedMessage = await message.channel.messages.fetch(message.reference.messageId).catch(() => null);
                            if (repliedMessage) uid = repliedMessage.author.id;
                        }
                        if (!uid) {
                            const userArg = args.shift();
                            if (userArg) uid = userArg.replace(/[<@!>]/g, "");
                        }
                        if (!uid) return message.reply(`❌ Format Salah : \`!${command} @user/reply pesan\``);

                        const targetUser = await client.users.fetch(uid).catch(() => null);
                        const data = warns[uid] || [];
                        const embed = new EmbedBuilder()
                            .setTitle(`📄 Daftar Warn: ${targetUser ? targetUser.tag : uid}`)
                            .setColor("#ff0000")
                            .setDescription(data.length === 0 ? "User ini tidak punya warn." : data.map((w, i) => `**${i + 1}.** Reason: **${w.reason}**\nAdmin: <@${w.admin}>`).join("\n\n"));
                        return message.reply({ embeds: [embed] });
                    }
                }

                if (command === "myw" || command === "mywarn") {
                    const uid = message.author.id;
                    const data = warns[uid] || [];
                    const embed = new EmbedBuilder()
                        .setTitle("📄 Warn Kamu")
                        .setColor("#ff0000")
                        .setDescription(data.length === 0 ? "Kamu tidak punya warn." : data.map((w, i) => `**${i + 1}.** Reason: **${w.reason}**\nAdmin: <@${w.admin}>`).join("\n\n"));
                    return message.reply({ embeds: [embed] });
                }

            } catch (err) {
                console.log("ERR moderation:", err);
            }
        });
    }
};