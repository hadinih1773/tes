const { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits 
} = require("discord.js");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("takerole")
            .setDescription("Takerole With Bot Fitur")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(option => 
                option.setName("title")
                    .setDescription("Judul embed")
                    .setRequired(true))
            .addStringOption(option => 
                option.setName("deskripsi")
                    .setDescription("Deskripsi embed")
                    .setRequired(true))
            .addStringOption(option => 
                option.setName("role")
                    .setDescription("Format: NamaButton, @role, NamaButton2, @role2")
                    .setRequired(true))
            .toJSON()
    ],

    async setup(client) {
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            // Handle Slash Command
            if (interaction.isChatInputCommand() && interaction.commandName === "takerole") {
                if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan.", ephemeral: true });
                }

                const title = interaction.options.getString("title");
                const deskripsi = interaction.options.getString("deskripsi");
                const roleInput = interaction.options.getString("role");

                // Pecah input role menjadi array
                const items = roleInput.split(",").map(i => i.trim());
                const rows = [];
                let currentRow = new ActionRowBuilder();

                for (let i = 0; i < items.length; i += 2) {
                    const label = items[i];
                    const roleId = items[i + 1]?.replace(/[<@&>]/g, "");

                    if (!label || !roleId) continue;

                    const button = new ButtonBuilder()
                        .setCustomId(`tr_${roleId}`)
                        .setLabel(label)
                        .setStyle(ButtonStyle.Primary);

                    if (currentRow.components.length < 5) {
                        currentRow.addComponents(button);
                    } else {
                        rows.push(currentRow);
                        currentRow = new ActionRowBuilder().addComponents(button);
                    }
                }
                if (currentRow.components.length > 0) rows.push(currentRow);

                const embed = new EmbedBuilder()
                    .setTitle(title)
                    .setDescription(deskripsi)
                    .setColor("#50c878")
                    .setTimestamp();

                await interaction.reply({ content: "✅ Berhasil membuat takerole.", ephemeral: true });
                await interaction.channel.send({ embeds: [embed], components: rows });
            }

            // Handle Button Click
            if (interaction.isButton() && interaction.customId.startsWith("tr_")) {
                const roleId = interaction.customId.replace("tr_", "");
                const role = interaction.guild.roles.cache.get(roleId);

                if (!role) {
                    return interaction.reply({ content: "❌ Role tidak ditemukan di server ini.", ephemeral: true });
                }

                try {
                    if (interaction.member.roles.cache.has(roleId)) {
                        await interaction.member.roles.remove(roleId);
                        return interaction.reply({ content: `✅ Berhasil Mengambil Kembali Role <@&${roleId}>`, ephemeral: true });
                    } else {
                        await interaction.member.roles.add(roleId);
                        return interaction.reply({ content: `✅ Berhasil Menambah Role <@&${roleId}>`, ephemeral: true });
                    }
                } catch (err) {
                    console.error(err);
                    return interaction.reply({ content: "❌ Gagal mengelola role. Pastikan posisi role bot lebih tinggi dari role tersebut.", ephemeral: true });
                }
            }
        });
    }
};