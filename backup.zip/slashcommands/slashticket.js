const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  PermissionFlagsBits,
} = require("discord.js");

const cooldowns = new Map();

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("ticketsetup")
      .setDescription("Setup Panel Ticket System")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption((option) =>
        option.setName("title").setDescription("Judul embed ticket").setRequired(true)
      )
      .addStringOption((option) =>
        option.setName("deskripsi").setDescription("Deskripsi embed ticket").setRequired(true)
      )
      .addStringOption((option) =>
        option.setName("button1").setDescription("Nama button 1").setRequired(true)
      )
      .addChannelOption((option) =>
        option.setName("channel").setDescription("Channel tempat embed ticket").setRequired(false)
      )
      .addStringOption((option) =>
        option.setName("color").setDescription("Warna hex (contoh: #00ff00)").setRequired(false)
      )
      .addStringOption((option) =>
        option.setName("button2").setDescription("Nama button 2 (opsional)").setRequired(false)
      )
      .addStringOption((option) =>
        option.setName("button3").setDescription("Nama button 3 (opsional)").setRequired(false)
      )
      .addAttachmentOption((option) =>
        option.setName("image").setDescription("Upload gambar utama").setRequired(false)
      )
      .addStringOption((option) =>
        option.setName("image_url").setDescription("Link gambar utama").setRequired(false)
      )
      .addAttachmentOption((option) =>
        option.setName("thumbnail").setDescription("Upload thumbnail").setRequired(false)
      )
      .addStringOption((option) =>
        option.setName("thumbnail_url").setDescription("Link thumbnail").setRequired(false)
      )
      .toJSON()
  ],

  setup(client) {
    const LOG_CHANNEL_NAME = "ticket-logs";

    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (interaction.isChatInputCommand()) {
        if (interaction.commandName === "ticketsetup") {
          if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: "❌ Hanya admin yang bisa gunakan!", ephemeral: true });
          }

          const title = interaction.options.getString("title");
          const desc = interaction.options.getString("deskripsi");
          const targetChannel = interaction.options.getChannel("channel") || interaction.channel;
          const color = interaction.options.getString("color") || "#3498db";
          const btn1 = interaction.options.getString("button1");
          const btn2 = interaction.options.getString("button2");
          const btn3 = interaction.options.getString("button3");
          
          const imageFile = interaction.options.getAttachment("image");
          const imageUrlInput = interaction.options.getString("image_url");
          const img = imageFile ? imageFile.url : imageUrlInput;

          const thumbnailFile = interaction.options.getAttachment("thumbnail");
          const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
          const thumb = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

          const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(desc)
            .setColor(color)
            .setFooter({ text: "Gunakan tombol di bawah untuk membuka ticket" })
            .setTimestamp();

          if (img) embed.setImage(img);
          if (thumb) embed.setThumbnail(thumb);

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("ticket_create_0").setLabel(btn1).setStyle(ButtonStyle.Primary)
          );

          if (btn2) {
            row.addComponents(
              new ButtonBuilder().setCustomId("ticket_create_1").setLabel(btn2).setStyle(ButtonStyle.Primary)
            );
          }

          if (btn3) {
            row.addComponents(
              new ButtonBuilder().setCustomId("ticket_create_2").setLabel(btn3).setStyle(ButtonStyle.Primary)
            );
          }

          await targetChannel.send({ embeds: [embed], components: [row] });

          return interaction.reply({ content: "✅ Ticket Setup Berhasil!", ephemeral: true });
        }
      }

      if (!interaction.isButton()) return;

      const now = Date.now();
      const cooldownAmount = 5000; 

      if (cooldowns.has(interaction.user.id)) {
        const expirationTime = cooldowns.get(interaction.user.id) + cooldownAmount;
        if (now < expirationTime) {
          return interaction.reply({ 
            content: "❌ Tunggu Beberapa Saat Lagi.. Supaya tidak Eror", 
            ephemeral: true 
          }).catch(() => {});
        }
      }

      if (interaction.customId.startsWith("ticket_create_")) {
        cooldowns.set(interaction.user.id, now);
        setTimeout(() => cooldowns.delete(interaction.user.id), cooldownAmount);

        await interaction.deferReply({ ephemeral: true });

        const user = interaction.user;
        const uniqueId = Math.floor(1000 + Math.random() * 9000);
        const channelName = `ticket-${user.username.toLowerCase()}-${uniqueId}`;

        try {
          const ticketChannel = await interaction.guild.channels.create({
            name: channelName,
            type: 0,
            parent: interaction.channel.parent?.id || null,
            permissionOverwrites: [
              {
                id: interaction.guild.roles.everyone.id,
                deny: [PermissionsBitField.Flags.ViewChannel],
              },
              {
                id: user.id,
                allow: [
                  PermissionsBitField.Flags.ViewChannel,
                  PermissionsBitField.Flags.SendMessages,
                  PermissionsBitField.Flags.ReadMessageHistory,
                ],
              },
            ],
          });

          const ticketEmbed = new EmbedBuilder()
            .setTitle("Selamat Datang Di Dalam Ticket Gunakan Sebaik-baiknya")
            .setColor("#3498db")
            .setTimestamp();

          const controlRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("ticket_delete").setLabel("Delete Ticket").setStyle(ButtonStyle.Danger)
          );

          await ticketChannel.send({
            content: `<@${user.id}>`,
            embeds: [ticketEmbed],
            components: [controlRow],
          });

          await interaction.editReply({ content: `Ticket kamu sudah dibuat di ${ticketChannel}` });

          const logChannel = interaction.guild.channels.cache.find((ch) => ch.name === LOG_CHANNEL_NAME);
          if (logChannel) {
            logChannel.send(`Ticket "${channelName}" dibuat oleh ${user.tag} di ${ticketChannel}`);
          }
        } catch (error) {
          console.error(error);
          await interaction.editReply({ content: "❌ Gagal membuat channel ticket." });
        }
      }

      if (interaction.customId === "ticket_delete") {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: "❌ Hanya admin yang bisa hapus ticket ini.", ephemeral: true });
        }

        await interaction.deferUpdate().catch(() => {});

        const logChannel = interaction.guild.channels.cache.find((ch) => ch.name === LOG_CHANNEL_NAME);
        if (logChannel) logChannel.send(`Ticket ${interaction.channel.name} dihapus oleh ${interaction.user.tag}`);

        try {
          await interaction.channel.delete();
        } catch (err) {
          console.log("Channel gagal dihapus.");
        }
      }
    });
  },
};