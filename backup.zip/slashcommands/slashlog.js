const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../database/logsserver.json");

// Memastikan database otomatis kebikin
function initializeDB() {
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));
  }
}
initializeDB();

function getDB() {
  try {
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return {};
  }
}

function saveDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function getRandomColor() {
  return Math.floor(Math.random() * 16777215);
}

function getLogChannel(guildId) {
  const db = getDB();
  return db[guildId] || null;
}

function formatCustomTimestamp() {
  const now = new Date();
  const unix = Math.floor(now.getTime() / 1000);
  return `<t:${unix}:F> (<t:${unix}:R>)`;
}

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("logsserver")
      .setDescription("Mengatur log aktivitas server.")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option =>
        option
          .setName("option")
          .setDescription("Pilih opsi add atau delete")
          .setRequired(true)
          .setAutocomplete(true)
      )
      .addChannelOption(option =>
        option
          .setName("channel")
          .setDescription("Pilih channel tujuan log")
          .setRequired(false)
          .addChannelTypes(ChannelType.GuildText)
      )
      .toJSON()
  ],

  setup(client) {
    // Handle Interaction (Slash Command & Autocomplete)
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (interaction.commandName !== "logsserver") return;

      // Handle Autocomplete untuk add dan delete
      if (interaction.isAutocomplete()) {
        const focusedValue = interaction.options.getFocused().toLowerCase();
        const choices = ["add", "delete"];
        const filtered = choices.filter(choice => choice.startsWith(focusedValue));
        return interaction.respond(
          filtered.map(choice => ({ name: choice, value: choice }))
        ).catch(() => {});
      }

      if (!interaction.isChatInputCommand()) return;

      // Cek Izin Admin
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        if (interaction.isRepliable()) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }
        return;
      }

      const option = interaction.options.getString("option");
      const guildId = interaction.guild.id;

      if (option === "add") {
        const channel = interaction.options.getChannel("channel");
        if (!channel) {
          return interaction.reply({ content: "❌ Silakan pilih channel tujuan log untuk opsi add.", ephemeral: true });
        }
        const db = getDB();
        db[guildId] = channel.id;
        saveDB(db);
        return interaction.reply({ content: `✅ Berhasil menambahkan channel log ke <#${channel.id}>`, ephemeral: true });
      }

      if (option === "delete") {
        const db = getDB();
        if (!db[guildId]) {
          return interaction.reply({ content: "❌ Server ini belum mengonfigurasi channel log.", ephemeral: true });
        }
        delete db[guildId];
        saveDB(db);
        return interaction.reply({ content: "✅ Berhasil menghapus konfigurasi channel log.", ephemeral: true });
      }
    });

    // Event: Create Channel
    client.on("channelCreate", async (channel) => {
      if (!channel.guild) return;
      const channelId = getLogChannel(channel.guild.id);
      if (!channelId) return;
      const logChannel = channel.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("📁 Channel Created")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${channel.id}> (${channel.id})\n**Name :** ${channel.name}\n**Type :** ${channel.type}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Delete Channel
    client.on("channelDelete", async (channel) => {
      if (!channel.guild) return;
      const channelId = getLogChannel(channel.guild.id);
      if (!channelId) return;
      const logChannel = channel.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Channel Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${channel.name}\n**ID :** ${channel.id}\n**Type :** ${channel.type}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Update Channel
    client.on("channelUpdate", async (oldChannel, newChannel) => {
      if (!oldChannel.guild) return;
      const channelId = getLogChannel(oldChannel.guild.id);
      if (!channelId) return;
      const logChannel = oldChannel.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldChannel.name === newChannel.name) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Channel Updated")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${newChannel.id}> (${newChannel.id})\n**Old Name :** ${oldChannel.name}\n**New Name :** ${newChannel.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Edit Chat (Message Update)
    client.on("messageUpdate", async (oldMessage, newMessage) => {
      if (!oldMessage.guild || oldMessage.author?.bot) return;
      if (oldMessage.content === newMessage.content) return;
      const channelId = getLogChannel(oldMessage.guild.id);
      if (!channelId) return;
      const logChannel = oldMessage.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const authorId = oldMessage.author?.id || "Unknown";
      const channelIdMsg = oldMessage.channel?.id || "Unknown";

      const embed = new EmbedBuilder()
        .setTitle("📝 Message Edited")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${authorId}> (${authorId})\n**Channel :** <#${channelIdMsg}> (${channelIdMsg})\n**Time :** ${formatCustomTimestamp()}`)
        .addFields(
          { name: "Old Message", value: oldMessage.content || "*No text (embed/media)*" },
          { name: "New Message", value: newMessage.content || "*No text (embed/media)*" }
        );

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Hapus Chat (Message Delete)
    client.on("messageDelete", async (message) => {
      if (!message.guild || message.author?.bot) return;
      const channelId = getLogChannel(message.guild.id);
      if (!channelId) return;
      const logChannel = message.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const authorId = message.author?.id || "Unknown";
      const channelIdMsg = message.channel?.id || "Unknown";

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Message Deleted")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${authorId}> (${authorId})\n**Channel :** <#${channelIdMsg}> (${channelIdMsg})\n**Time :** ${formatCustomTimestamp()}`)
        .addFields({ name: "Content", value: message.content || "*No text (embed/media)*" });

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Bulk Message Delete
    client.on("messageDeleteBulk", async (messages) => {
      const firstMessage = messages.first();
      if (!firstMessage || !firstMessage.guild) return;
      const channelId = getLogChannel(firstMessage.guild.id);
      if (!channelId) return;
      const logChannel = firstMessage.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🧹 Bulk Message Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Amount :** ${messages.size} messages\n**Channel :** <#${firstMessage.channel.id}> (${firstMessage.channel.id})\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Message Pin Update
    client.on("channelPinsUpdate", async (channel) => {
      if (!channel.guild) return;
      const channelId = getLogChannel(channel.guild.id);
      if (!channelId) return;
      const logChannel = channel.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("📌 Message Pins Updated")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${channel.id}> (${channel.id})\n**Info :** Message pin status changed in this channel.\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Create Role
    client.on("roleCreate", async (role) => {
      const channelId = getLogChannel(role.guild.id);
      if (!channelId) return;
      const logChannel = role.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🛡️ Role Created")
        .setColor(getRandomColor())
        .setDescription(`**Role :** <@&${role.id}> (${role.id})\n**Name :** ${role.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Delete Role
    client.on("roleDelete", async (role) => {
      const channelId = getLogChannel(role.guild.id);
      if (!channelId) return;
      const logChannel = role.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Role Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${role.name}\n**ID :** ${role.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Update Role
    client.on("roleUpdate", async (oldRole, newRole) => {
      const channelId = getLogChannel(oldRole.guild.id);
      if (!channelId) return;
      const logChannel = oldRole.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldRole.name === newRole.name) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Role Updated")
        .setColor(getRandomColor())
        .setDescription(`**Role :** <@&${newRole.id}> (${newRole.id})\n**Old Name :** ${oldRole.name}\n**New Name :** ${newRole.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Update Member (Kasih/Ambil Role, Timeout, Nickname)
    client.on("guildMemberUpdate", async (oldMember, newMember) => {
      const channelId = oldMember.guild.id ? getLogChannel(oldMember.guild.id) : null;
      if (!channelId) return;
      const logChannel = oldMember.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      // Handle Kasih/Ambil Role
      const oldRoles = oldMember.roles.cache;
      const newRoles = newMember.roles.cache;
      const addedRoles = newRoles.filter(role => !oldRoles.has(role.id));
      const removedRoles = oldRoles.filter(role => !newRoles.has(role.id));

      if (addedRoles.size > 0) {
        addedRoles.forEach(role => {
          const embed = new EmbedBuilder()
            .setTitle("➕ Role Added")
            .setColor(getRandomColor())
            .setDescription(`**User :** <@${newMember.user.id}> (${newMember.user.id})\n**Role Added :** <@&${role.id}> (${role.id})\n**Time :** ${formatCustomTimestamp()}`);
          logChannel.send({ embeds: [embed] }).catch(() => {});
        });
      }

      if (removedRoles.size > 0) {
        removedRoles.forEach(role => {
          const embed = new EmbedBuilder()
            .setTitle("➖ Role Removed")
            .setColor(getRandomColor())
            .setDescription(`**User :** <@${newMember.user.id}> (${newMember.user.id})\n**Role Removed :** <@&${role.id}> (${role.id})\n**Time :** ${formatCustomTimestamp()}`);
          logChannel.send({ embeds: [embed] }).catch(() => {});
        });
      }

      // Handle Nickname Update
      if (oldMember.nickname !== newMember.nickname) {
        const embed = new EmbedBuilder()
          .setTitle("👤 Nickname Changed")
          .setColor(getRandomColor())
          .setDescription(`**User :** <@${newMember.user.id}> (${newMember.user.id})\n**Old Nickname :** ${oldMember.nickname || "None"}\n**New Nickname :** ${newMember.nickname || "None"}\n**Time :** ${formatCustomTimestamp()}`);
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }

      // Handle Timeout / Un-timeout
      if (oldMember.communicationDisabledUntilTimestamp !== newMember.communicationDisabledUntilTimestamp) {
        if (newMember.communicationDisabledUntilTimestamp && newMember.communicationDisabledUntilTimestamp > Date.now()) {
          const embed = new EmbedBuilder()
            .setTitle("⏳ User Muted (Timeout)")
            .setColor(getRandomColor())
            .setDescription(`**User :** <@${newMember.user.id}> (${newMember.user.id})\n**Until :** <t:${Math.floor(newMember.communicationDisabledUntilTimestamp / 1000)}:F>\n**Time :** ${formatCustomTimestamp()}`);
          logChannel.send({ embeds: [embed] }).catch(() => {});
        } else if (oldMember.communicationDisabledUntilTimestamp && (!newMember.communicationDisabledUntilTimestamp || newMember.communicationDisabledUntilTimestamp <= Date.now())) {
          const embed = new EmbedBuilder()
            .setTitle("🔊 User Unmuted (Timeout Ended)")
            .setColor(getRandomColor())
            .setDescription(`**User :** <@${newMember.user.id}> (${newMember.user.id})\n**Time :** ${formatCustomTimestamp()}`);
          logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }
    });

    // Event: User Joined (Member Add)
    client.on("guildMemberAdd", async (member) => {
      const channelId = getLogChannel(member.guild.id);
      if (!channelId) return;
      const logChannel = member.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("📥 Member Joined")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${member.user.id}> (${member.user.id})\n**Name :** ${member.user.tag}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: User Kick / Keluar (Guild Member Remove)
    client.on("guildMemberRemove", async (member) => {
      const channelId = getLogChannel(member.guild.id);
      if (!channelId) return;
      const logChannel = member.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🚪 Member Left / Kicked")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${member.user.id}> (${member.user.id})\n**Name :** ${member.user.tag}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: User Ban
    client.on("guildBanAdd", async (ban) => {
      const channelId = getLogChannel(ban.guild.id);
      if (!channelId) return;
      const logChannel = ban.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🔨 User Banned")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${ban.user.id}> (${ban.user.id})\n**Name :** ${ban.user.tag}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: User Unban
    client.on("guildBanRemove", async (ban) => {
      const channelId = getLogChannel(ban.guild.id);
      if (!channelId) return;
      const logChannel = ban.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🔓 User Unbanned")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${ban.user.id}> (${ban.user.id})\n**Name :** ${ban.user.tag}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Guild Update (Server Updated)
    client.on("guildUpdate", async (oldGuild, newGuild) => {
      const channelId = getLogChannel(newGuild.id);
      if (!channelId) return;
      const logChannel = newGuild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldGuild.name === newGuild.name) return;

      const embed = new EmbedBuilder()
        .setTitle("🌐 Server Updated")
        .setColor(getRandomColor())
        .setDescription(`**Old Name :** ${oldGuild.name}\n**New Name :** ${newGuild.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Emoji Create
    client.on("emojiCreate", async (emoji) => {
      const channelId = getLogChannel(emoji.guild.id);
      if (!channelId) return;
      const logChannel = emoji.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("😀 Emoji Created")
        .setColor(getRandomColor())
        .setDescription(`**Emoji :** ${emoji} (${emoji.id})\n**Name :** ${emoji.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Emoji Delete
    client.on("emojiDelete", async (emoji) => {
      const channelId = getLogChannel(emoji.guild.id);
      if (!channelId) return;
      const logChannel = emoji.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Emoji Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${emoji.name}\n**ID :** ${emoji.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Emoji Update
    client.on("emojiUpdate", async (oldEmoji, newEmoji) => {
      const channelId = getLogChannel(oldEmoji.guild.id);
      if (!channelId) return;
      const logChannel = oldEmoji.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldEmoji.name === newEmoji.name) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Emoji Updated")
        .setColor(getRandomColor())
        .setDescription(`**Emoji :** ${newEmoji}\n**Old Name :** ${oldEmoji.name}\n**New Name :** ${newEmoji.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Sticker Create
    client.on("stickerCreate", async (sticker) => {
      if (!sticker.guild) return;
      const channelId = getLogChannel(sticker.guild.id);
      if (!channelId) return;
      const logChannel = sticker.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🖼️ Sticker Created")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${sticker.name}\n**ID :** ${sticker.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Sticker Delete
    client.on("stickerDelete", async (sticker) => {
      if (!sticker.guild) return;
      const channelId = getLogChannel(sticker.guild.id);
      if (!channelId) return;
      const logChannel = sticker.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Sticker Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${sticker.name}\n**ID :** ${sticker.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Sticker Update
    client.on("stickerUpdate", async (oldSticker, newSticker) => {
      if (!oldSticker.guild) return;
      const channelId = getLogChannel(oldSticker.guild.id);
      if (!channelId) return;
      const logChannel = oldSticker.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldSticker.name === newSticker.name) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Sticker Updated")
        .setColor(getRandomColor())
        .setDescription(`**Old Name :** ${oldSticker.name}\n**New Name :** ${newSticker.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Voice State Update (Saluran Suara)
    client.on("voiceStateUpdate", async (oldState, newState) => {
      const channelId = oldState.guild.id ? getLogChannel(oldState.guild.id) : null;
      if (!channelId) return;
      const logChannel = oldState.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      // Join Voice
      if (!oldState.channelId && newState.channelId) {
        const embed = new EmbedBuilder()
          .setTitle("🔊 Voice Channel Joined")
          .setColor(getRandomColor())
          .setDescription(`**User :** <@${newState.member.user.id}> (${newState.member.user.id})\n**Channel :** <#${newState.channelId}>\n**Time :** ${formatCustomTimestamp()}`);
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
      // Leave Voice
      else if (oldState.channelId && !newState.channelId) {
        const embed = new EmbedBuilder()
          .setTitle("🔇 Voice Channel Left")
          .setColor(getRandomColor())
          .setDescription(`**User :** <@${oldState.member.user.id}> (${oldState.member.user.id})\n**Channel :** <#${oldState.channelId}>\n**Time :** ${formatCustomTimestamp()}`);
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
      // Move Voice Channel
      else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
        const embed = new EmbedBuilder()
          .setTitle("🔄 Voice Channel Changed")
          .setColor(getRandomColor())
          .setDescription(`**User :** <@${newState.member.user.id}> (${newState.member.user.id})\n**Old Channel :** <#${oldState.channelId}>\n**New Channel :** <#${newState.channelId}>\n**Time :** ${formatCustomTimestamp()}`);
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }

      // Server Mute / Deafen Updates
      if (oldState.serverMute !== newState.serverMute) {
        const embed = new EmbedBuilder()
          .setTitle(newState.serverMute ? "🎙️ Member Server Muted" : "🎙️ Member Server Unmuted")
          .setColor(getRandomColor())
          .setDescription(`**User :** <@${newState.member.user.id}> (${newState.member.user.id})\n**Time :** ${formatCustomTimestamp()}`);
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
      if (oldState.serverDeaf !== newState.serverDeaf) {
        const embed = new EmbedBuilder()
          .setTitle(newState.serverDeaf ? "🎧 Member Server Deafened" : "🎧 Member Server Undeafened")
          .setColor(getRandomColor())
          .setDescription(`**User :** <@${newState.member.user.id}> (${newState.member.user.id})\n**Time :** ${formatCustomTimestamp()}`);
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    });

    // Event: Thread Create
    client.on("threadCreate", async (thread) => {
      const channelId = getLogChannel(thread.guild.id);
      if (!channelId) return;
      const logChannel = thread.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🧵 Thread Created")
        .setColor(getRandomColor())
        .setDescription(`**Thread :** <#${thread.id}> (${thread.id})\n**Name :** ${thread.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Thread Delete
    client.on("threadDelete", async (thread) => {
      const channelId = getLogChannel(thread.guild.id);
      if (!channelId) return;
      const logChannel = thread.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Thread Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${thread.name}\n**ID :** ${thread.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Thread Update
    client.on("threadUpdate", async (oldThread, newThread) => {
      const channelId = getLogChannel(oldThread.guild.id);
      if (!channelId) return;
      const logChannel = oldThread.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldThread.name === newThread.name) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Thread Updated")
        .setColor(getRandomColor())
        .setDescription(`**Thread :** <#${newThread.id}>\n**Old Name :** ${oldThread.name}\n**New Name :** ${newThread.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Webhook Update
    client.on("webhookUpdate", async (channel) => {
      if (!channel.guild) return;
      const channelId = getLogChannel(channel.guild.id);
      if (!channelId) return;
      const logChannel = channel.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🌐 Webhooks Updated")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${channel.id}> (${channel.id})\n**Info :** Webhook configuration changed in this channel.\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Invite Create
    client.on("inviteCreate", async (invite) => {
      if (!invite.guild) return;
      const channelId = getLogChannel(invite.guild.id);
      if (!channelId) return;
      const logChannel = invite.guild.channels.cache.get(invite.guild.id);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("📩 Invite Created")
        .setColor(getRandomColor())
        .setDescription(`**Code :** ${invite.code}\n**Channel :** <#${invite.channelId}>\n**Creator :** <@${invite.inviterId}>\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Invite Delete
    client.on("inviteDelete", async (invite) => {
      if (!invite.guild) return;
      const channelId = getLogChannel(invite.guild.id);
      if (!channelId) return;
      const logChannel = invite.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Invite Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Code :** ${invite.code}\n**Channel :** <#${invite.channelId}>\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Stage Instance Create
    client.on("stageInstanceCreate", async (stageInstance) => {
      const channelId = getLogChannel(stageInstance.guildId);
      if (!channelId) return;
      const logChannel = stageInstance.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🎭 Stage Created")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${stageInstance.channelId}>\n**Topic :** ${stageInstance.topic}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Stage Instance Delete
    client.on("stageInstanceDelete", async (stageInstance) => {
      const channelId = getLogChannel(stageInstance.guildId);
      if (!channelId) return;
      const logChannel = stageInstance.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Stage Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${stageInstance.channelId}>\n**Topic :** ${stageInstance.topic}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Stage Instance Update
    client.on("stageInstanceUpdate", async (oldStage, newStage) => {
      const channelId = getLogChannel(oldStage.guildId);
      if (!channelId) return;
      const logChannel = oldStage.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldStage.topic === newStage.topic) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Stage Updated")
        .setColor(getRandomColor())
        .setDescription(`**Channel :** <#${newStage.channelId}>\n**Old Topic :** ${oldStage.topic}\n**New Topic :** ${newStage.topic}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Guild Scheduled Event Create
    client.on("guildScheduledEventCreate", async (event) => {
      const channelId = getLogChannel(event.guildId);
      if (!channelId) return;
      const logChannel = event.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("📅 Scheduled Event Created")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${event.name}\n**Description :** ${event.description || "No description"}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Guild Scheduled Event Delete
    client.on("guildScheduledEventDelete", async (event) => {
      const channelId = getLogChannel(event.guildId);
      if (!channelId) return;
      const logChannel = event.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ Scheduled Event Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Name :** ${event.name}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: Guild Scheduled Event Update
    client.on("guildScheduledEventUpdate", async (oldEvent, newEvent) => {
      const channelId = getLogChannel(oldEvent.guildId);
      if (!channelId) return;
      const logChannel = oldEvent.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldEvent.name === newEvent.name && oldEvent.status === newEvent.status) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Scheduled Event Updated")
        .setColor(getRandomColor())
        .setDescription(`**Old Name :** ${oldEvent.name}\n**New Name :** ${newEvent.name}\n**Status :** ${newEvent.status}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: AutoMod Rule Create
    client.on("autoModerationRuleCreate", async (rule) => {
      const channelId = getLogChannel(rule.guildId);
      if (!channelId) return;
      const logChannel = rule.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🤖 AutoMod Rule Created")
        .setColor(getRandomColor())
        .setDescription(`**Rule Name :** ${rule.name}\n**ID :** ${rule.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: AutoMod Rule Delete
    client.on("autoModerationRuleDelete", async (rule) => {
      const channelId = getLogChannel(rule.guildId);
      if (!channelId) return;
      const logChannel = rule.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🗑️ AutoMod Rule Deleted")
        .setColor(getRandomColor())
        .setDescription(`**Rule Name :** ${rule.name}\n**ID :** ${rule.id}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: AutoMod Rule Update
    client.on("autoModerationRuleUpdate", async (oldRule, newRule) => {
      const channelId = getLogChannel(oldRule.guildId);
      if (!channelId) return;
      const logChannel = oldRule.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      if (oldRule.name === newRule.name && oldRule.enabled === newRule.enabled) return;

      const embed = new EmbedBuilder()
        .setTitle("⚙️ AutoMod Rule Updated")
        .setColor(getRandomColor())
        .setDescription(`**Old Name :** ${oldRule.name}\n**New Name :** ${newRule.name}\n**Enabled :** ${newRule.enabled}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });

    // Event: AutoMod Action Execution
    client.on("autoModerationActionExecution", async (actionExecution) => {
      const channelId = getLogChannel(actionExecution.guildId);
      if (!channelId) return;
      const logChannel = actionExecution.guild.channels.cache.get(channelId);
      if (!logChannel) return;

      const embed = new EmbedBuilder()
        .setTitle("🚨 AutoMod Action Executed")
        .setColor(getRandomColor())
        .setDescription(`**User :** <@${actionExecution.userId}> (${actionExecution.userId})\n**Rule Name :** ${actionExecution.ruleName}\n**Channel :** <#${actionExecution.channelId}>\n**Blocked Content :** ${actionExecution.content || "*No content*"}\n**Time :** ${formatCustomTimestamp()}`);

      logChannel.send({ embeds: [embed] }).catch(() => {});
    });
  }
};