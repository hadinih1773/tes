const axios = require("axios");
const {
  SlashCommandBuilder,
  Events,
  EmbedBuilder
} = require("discord.js");

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("spamwebhook")
      .setDescription("Send Spamming Message To Scam People")
      .addStringOption(o => o.setName("link").setDescription("Link webhook").setRequired(true))
      .addStringOption(o => o.setName("pesan").setDescription("Pesan yang dikirim").setRequired(true))
      .addIntegerOption(o => o.setName("jumlah").setDescription("Jumlah pesan").setRequired(false))
      .addBooleanOption(o => o.setName("embed").setDescription("Kirim sebagai embed").setRequired(false))
      .addStringOption(o => o.setName("color").setDescription("Hex color embed").setRequired(false))
      .addAttachmentOption(o => o.setName("image").setDescription("Gambar (upload)").setRequired(false))
      .addStringOption(o => o.setName("image_url").setDescription("Gambar (link)").setRequired(false))
      .addAttachmentOption(o => o.setName("thumbnail").setDescription("Thumbnail (upload)").setRequired(false))
      .addStringOption(o => o.setName("thumbnail_url").setDescription("Thumbnail (link)").setRequired(false))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("cekwebhook")
      .setDescription("Checking Url Webhook Scam")
      .addStringOption(o => o.setName("link").setDescription("Link webhook").setRequired(true))
      .toJSON()
  ],

  setup(client) {
    client.on(Events.InteractionCreate, async i => {
      if (!i.isChatInputCommand()) return;

      if (i.commandName === "cekwebhook") {
        const webhookUrl = i.options.getString("link").trim();
        
        try {
          const response = await axios.get(webhookUrl);
          const data = response.data;
          
          const successEmbed = new EmbedBuilder()
            .setTitle("🛡 Cheking Webhook Successful")
            .setDescription(`🚨 **Status** : \nAktif ✅\n\n👤 **Name** :\n${data.name || "N/A"}\n\n#⃣ **Channel ID** : \n${data.channel_id || "N/A"}\n\n🌐 **Guild ID** :\n${data.guild_id || "N/A"}\n\n🆔 **ID** :\n${data.id || "N/A"}`)
            .setColor("#50C878");
            
          return await i.reply({ embeds: [successEmbed], ephemeral: true });
        } catch (err) {
          const failEmbed = new EmbedBuilder()
            .setTitle("🛡 Cheking Webhook Successful")
            .setDescription(`🚨 **Status** : \nTidak Aktif ❌\n\n📋 **Note** :\nSepertinya Webhook Sudah Dihapus`)
            .setColor("#FF0000");
            
          return await i.reply({ embeds: [failEmbed], ephemeral: true });
        }
      }

      if (i.commandName === "spamwebhook") {
        const webhookUrl = i.options.getString("link").trim();
        const message = i.options.getString("pesan");
        const amount = i.options.getInteger("jumlah") || 1;
        const embedEnabled = i.options.getBoolean("embed") ?? false;
        const colorHex = i.options.getString("color") || "#ff0000";
        
        const imageFile = i.options.getAttachment("image");
        const imageUrlInput = i.options.getString("image_url");
        const image = imageFile ? imageFile.url : imageUrlInput;

        const thumbnailFile = i.options.getAttachment("thumbnail");
        const thumbnailUrlInput = i.options.getString("thumbnail_url");
        const thumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

        try {
          await axios.get(webhookUrl);
        } catch (err) {
          const failEmbed = new EmbedBuilder()
            .setTitle("🛡 Cheking Webhook Successful")
            .setDescription(`🚨 **Status** : \nTidak Aktif ❌\n\n📋 **Note** :\nSepertinya Webhook Sudah Dihapus`)
            .setColor("#FF0000");
          return await i.reply({ embeds: [failEmbed], ephemeral: true });
        }

        await i.deferReply({ ephemeral: true }).catch(() => {});
        await i.editReply({ content: "⏳ Mengirim pesan ke webhook..." });

        for (let x = 0; x < amount; x++) {
          try {
            const payload = embedEnabled ? {
              embeds: [{
                description: message,
                color: parseInt(colorHex.replace("#", ""), 16),
                image: image ? { url: image } : undefined,
                thumbnail: thumbnail ? { url: thumbnail } : undefined,
              }],
              username: "Captcha Hook",
            } : { 
              content: message, 
              username: "Captcha Hook" 
            };

            await axios.post(webhookUrl, payload);
            await sleep(1000); 

          } catch (err) {
            console.error("Webhook Error:", err.message);
            if (err.response && err.response.status === 429) {
                await sleep(5000);
            }
          }
        }

        return await i.followUp({ content: `✅ Berhasil mengirim pesan ke webhook`, ephemeral: true });
      }
    });
  }
};