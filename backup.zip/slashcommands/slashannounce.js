const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("announce")
      .setDescription("Announcement Message With Using Bot")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("deskripsi")
          .setDescription("Isi deskripsi pengumuman")
          .setRequired(true))
      .addBooleanOption(option => 
        option.setName("embed")
          .setDescription("Gunakan format embed? (True = Embed + @everyone)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("title")
          .setDescription("Judul pengumuman (opsional)")
          .setRequired(false))
      .addChannelOption(option => 
        option.setName("channel")
          .setDescription("Pilih channel tujuan (opsional)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("color")
          .setDescription("Warna hex (contoh: #ff0000). Default: Biru")
          .setRequired(false))
      .addAttachmentOption(option => 
        option.setName("image")
          .setDescription("Upload gambar/video utama langsung (opsional)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("image_url")
          .setDescription("Masukkan link url gambar/video utama (opsional)")
          .setRequired(false))
      .addAttachmentOption(option => 
        option.setName("thumbnail")
          .setDescription("Upload gambar/video thumbnail langsung (opsional)")
          .setRequired(false))
      .addStringOption(option => 
        option.setName("thumbnail_url")
          .setDescription("Masukkan link url thumbnail (opsional)")
          .setRequired(false))
      .toJSON()
  ],

  async setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      const { commandName, options, channel } = interaction;

      const validCommands = ["announce"];
      if (!validCommands.includes(commandName)) return;

      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: "❌ Hanya Admin yang bisa menggunakan perintah ini", ephemeral: true });
      }

      if (commandName === "announce") {
        const deskripsi = options.getString("deskripsi");
        const useEmbed = options.getBoolean("embed") || false;
        const title = options.getString("title");
        const targetChannel = options.getChannel("channel") || channel;
        const colorInput = options.getString("color") || "#0099ff";
        
        // Cek file upload dulu, kalau kosong pakai input link url
        const imageFile = options.getAttachment("image");
        const imageUrlInput = options.getString("image_url");
        const image = imageFile ? imageFile.url : imageUrlInput;

        const thumbnailFile = options.getAttachment("thumbnail");
        const thumbnailUrlInput = options.getString("thumbnail_url");
        const thumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

        await interaction.deferReply({ ephemeral: true });

        try {
          const webhooks = await targetChannel.fetchWebhooks();
          let webhook = webhooks.find(wh => wh.name === "Hady Announcement WH");

          if (!webhook) {
            webhook = await targetChannel.createWebhook({
              name: "Hady Announcement WH",
              avatar: client.user.displayAvatarURL(),
            });
          }

          const payload = {
            username: "📢 Hady Community Daily Announcement",
            avatarURL: client.user.displayAvatarURL(),
          };

          if (useEmbed) {
            const embed = new EmbedBuilder()
              .setDescription(deskripsi)
              .setColor(colorInput.startsWith("#") ? colorInput : `#${colorInput}`)
              .setTimestamp();

            if (title) embed.setTitle(title);
            if (image) embed.setImage(image);
            if (thumbnail) embed.setThumbnail(thumbnail);

            payload.content = "@everyone";
            payload.embeds = [embed];
          } else {
            payload.content = deskripsi;
            payload.embeds = [];
          }

          await webhook.send(payload);
          await interaction.editReply({ content: `✅ Pengumuman berhasil dikirim ke ${targetChannel}!` });
        } catch (error) {
          console.error(error);
          await interaction.editReply({ content: "❌ Gagal mengirim pengumuman." });
        }
      }
    });
  }
};