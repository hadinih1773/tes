const { PermissionsBitField, SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("say")
      .setDescription("Bot Repeats Message In Channel")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => option.setName("pesan").setDescription("Pesan yang ingin dikirim").setRequired(true))
      .addChannelOption(option => option.setName("channel").setDescription("Pilih channel tujuan (opsional)").addChannelTypes(ChannelType.GuildText).setRequired(false))
      .toJSON()
  ],

  setup: function(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      
      // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN DAN CEK ERROR READING ID
      if (interaction.commandName !== "say") return;

      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
      }

      const deskripsi = interaction.options.getString("pesan");
      const targetChannel = interaction.options.getChannel("channel") || interaction.channel;

      try {
        await targetChannel.send(deskripsi);
        return interaction.reply({ content: "✅ Pesan berhasil dikirim!", ephemeral: true });
      } catch (err) {
        console.error("Error di command /say:", err);
        return interaction.reply({ content: "Gagal mengirim pesan.", ephemeral: true });
      }
    });
  }
};