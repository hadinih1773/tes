const { 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    ChannelType, 
    EmbedBuilder 
} = require("discord.js");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("createchannel")
            .setDescription("Create New Channel In Discord")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(o => o.setName("type")
                .setDescription("Tipe channel")
                .setRequired(true)
                .addChoices(
                    { name: "Text", value: "text" },
                    { name: "Forum", value: "forum" },
                    { name: "Voice", value: "voice" },
                    { name: "Stage", value: "stage" },
                    { name: "Announcement", value: "news" }
                ))
            .addStringOption(o => o.setName("nama").setDescription("Nama channel").setRequired(true))
            .toJSON(),

        new SlashCommandBuilder()
            .setName("deletechannel")
            .setDescription("Delete Your Channel")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addChannelOption(o => o.setName("channel").setDescription("Channel yang akan dihapus").setRequired(true))
            .toJSON(),

        new SlashCommandBuilder()
            .setName("renamechannel")
            .setDescription("Rename Your Channel")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addChannelOption(o => o.setName("channel").setDescription("Channel yang diubah").setRequired(true))
            .addStringOption(o => o.setName("nama").setDescription("Nama baru").setRequired(true))
            .toJSON(),

        new SlashCommandBuilder()
            .setName("createcategory")
            .setDescription("Create New Category In Discord")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addStringOption(o => o.setName("nama").setDescription("Nama kategori").setRequired(true))
            .toJSON()
    ],

    async setup(client) {
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;

            const { commandName, options, guild, member } = interaction;
            
            // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
            const channelCmds = ["createchannel", "deletechannel", "renamechannel", "createcategory"];
            if (!channelCmds.includes(commandName)) return;

            // Pengecekan Izin Administrator
            if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
            }

            try {
                if (commandName === "createchannel") {
                    const typeStr = options.getString("type");
                    const name = options.getString("nama");
                    
                    let type;
                    if (typeStr === "text") type = ChannelType.GuildText;
                    else if (typeStr === "forum") type = ChannelType.GuildForum;
                    else if (typeStr === "voice") type = ChannelType.GuildVoice;
                    else if (typeStr === "stage") type = ChannelType.GuildStageVoice;
                    else if (typeStr === "news") type = ChannelType.GuildAnnouncement;

                    const created = await guild.channels.create({ name, type });
                    await interaction.reply({ content: `✅ Berhasil membuat channel ${created}`, ephemeral: true });
                }

                if (commandName === "deletechannel") {
                    const channel = options.getChannel("channel");
                    await channel.delete();
                    await interaction.reply({ content: `✅ Berhasil menghapus channel **${channel.name}**`, ephemeral: true });
                }

                if (commandName === "renamechannel") {
                    const channel = options.getChannel("channel");
                    const newName = options.getString("nama");
                    const oldName = channel.name;
                    await channel.setName(newName);
                    await interaction.reply({ content: `✅ Berhasil mengubah nama channel **${oldName}** menjadi **${newName}**`, ephemeral: true });
                }

                if (commandName === "createcategory") {
                    const name = options.getString("nama");
                    const category = await guild.channels.create({ name, type: ChannelType.GuildCategory });
                    await interaction.reply({ content: `✅ Berhasil membuat kategori **${category.name}**`, ephemeral: true });
                }
            } catch (error) {
                console.error(error);
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ content: `❌ Terjadi kesalahan: ${error.message}`, ephemeral: true });
                } else {
                    await interaction.reply({ content: `❌ Terjadi kesalahan: ${error.message}`, ephemeral: true });
                }
            }
        });
    }
};