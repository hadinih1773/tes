const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require("discord.js");

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("userinfo")
      .setDescription("Melihat informasi akun pengguna.")
      .addUserOption((option) =>
        option
          .setName("user")
          .setDescription("Pilih user yang ingin dilihat (opsional)")
          .setRequired(false)
      )
      .toJSON(),
    new SlashCommandBuilder()
      .setName("serverinfo")
      .setDescription("Melihat informasi server ini.")
      .toJSON(),
    new SlashCommandBuilder()
      .setName("avatar")
      .setDescription("Melihat avatar user.")
      .addUserOption((option) =>
        option
          .setName("user")
          .setDescription("Pilih user yang ingin dilihat (opsional)")
          .setRequired(false)
      )
      .toJSON()
  ],

  setup: function (client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      // ============================
      //     SLASH: /userinfo
      // ============================
      if (interaction.commandName === "userinfo") {
        await interaction.deferReply();
        
        const targetUser = interaction.options.getUser("user") || interaction.user;
        const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        
        if (!member) {
          return interaction.editReply({ content: "Gagal mengambil data member." });
        }

        // Ambil semua role kecuali @everyone, urutkan berdasarkan posisi tertinggi
        const roles = member.roles.cache
          .filter((r) => r.id !== interaction.guild.id)
          .sort((a, b) => b.position - a.position);
          
        const totalRolesCount = roles.size;
        
        // Ambil maksimal 10 role teratas
        const topRolesMapped = roles
          .map((r) => r.toString())
          .slice(0, 10)
          .join(", ");
          
        const rolesDisplay = totalRolesCount > 0 ? topRolesMapped : "Tidak ada role";

        const embed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle(`👤 User Information | ${targetUser.username}`)
          .setThumbnail(targetUser.displayAvatarURL({ size: 1024 }))
          .addFields(
            {
              name: "🗣️ User Tag",
              value: `<@${targetUser.id}>`,
              inline: true
            },
            {
              name: "🆔 User ID",
              value: `${targetUser.id}`,
              inline: true
            },
            {
              name: "👥 Nickname",
              value: `${member.nickname ? member.nickname : "Tidak ada"}`,
              inline: true
            },
            {
              name: "📅 Join Date",
              value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`,
              inline: true
            },
            {
              name: `🎗 Roles [${totalRolesCount}]`,
              value: rolesDisplay,
              inline: false
            }
          )
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      }

      // ============================
      //    SLASH: /serverinfo
      // ============================
      if (interaction.commandName === "serverinfo") {
        await interaction.deferReply();
        
        const guild = interaction.guild;
        const owner = await guild.fetchOwner();
        
        const onlineCount = guild.members.cache.filter(
          (m) => m.presence && m.presence.status !== "offline"
        ).size;
        
        const rolesCount = guild.roles.cache.size;
        
        // Perhitungan jumlah channel berdasarkan tipenya masing-masing
        const allChannels = guild.channels.cache;
        const textCount = allChannels.filter((c) => c.type === ChannelType.GuildText).size;
        const voiceCount = allChannels.filter((c) => c.type === ChannelType.GuildVoice).size;
        const forumCount = allChannels.filter((c) => c.type === ChannelType.GuildForum).size;
        const announcementCount = allChannels.filter((c) => c.type === ChannelType.GuildAnnouncement).size;
        const stageCount = allChannels.filter((c) => c.type === ChannelType.GuildStageVoice).size;
        const channelsCount = allChannels.size;

        const embed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle(`🌐 Server Information | ${guild.name}`)
          .setThumbnail(guild.iconURL({ size: 1024 }))
          .addFields(
            {
              name: "🖥 Server Name",
              value: `${guild.name}`,
              inline: true
            },
            {
              name: "👑 Server Owner",
              value: `<@${owner.id}>`,
              inline: true
            },
            {
              name: "🆔 Server ID",
              value: `${guild.id}`,
              inline: true
            },
            {
              name: "📖 Server Description",
              value: guild.description || "Tidak ada deskripsi.",
              inline: false
            },
            {
              name: "👥 Members",
              value: `${guild.memberCount}`,
              inline: true
            },
            {
              name: "🟢 Online Members",
              value: `${onlineCount}`,
              inline: true
            },
            {
              name: "🎗 Roles",
              value: `${rolesCount}`,
              inline: true
            },
            {
              name: "#⃣ Channels",
              value: `Total: ${channelsCount}\nText : ${textCount}\nVoice : ${voiceCount}\nForum : ${forumCount}\nAnnouncement : ${announcementCount}\nStage : ${stageCount}`,
              inline: false
            },
            {
              name: "📅 Created Date",
              value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`,
              inline: false
            }
          )
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      }

      // ============================
      //      SLASH: /avatar
      // ============================
      if (interaction.commandName === "avatar") {
        const targetUser = interaction.options.getUser("user") || interaction.user;
        const avatarURL = targetUser.displayAvatarURL({ size: 1024, dynamic: true });
        
        return interaction.reply({ content: avatarURL });
      }
    });
  }
};