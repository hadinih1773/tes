const fs = require("fs");
const path = require("path");
const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionsBitField,
  PermissionFlagsBits,
} = require("discord.js");

const dataPath = path.join(__dirname, "../database/autoresponse.json");
if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, "{}");

const loadData = () => JSON.parse(fs.readFileSync(dataPath, "utf8"));
const saveData = (data) =>
  fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("autoresponse")
      .setDescription("Auto Response Word Form Bot")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption((opt) =>
        opt
          .setName("action")
          .setDescription("add/delete/list")
          .setRequired(true)
          .addChoices(
            { name: "add", value: "add" },
            { name: "delete", value: "delete" },
            { name: "list", value: "list" }
          )
      )
      .addStringOption((opt) =>
        opt.setName("kata").setDescription("Kata yang ingin diatur/dihapus")
      )
      .addStringOption((opt) =>
        opt.setName("response").setDescription("Respon yang ingin diberikan")
      )
      .addBooleanOption((opt) =>
        opt.setName("embed").setDescription("Kirim sebagai embed?")
      )
      .addStringOption((opt) =>
        opt
          .setName("color")
          .setDescription("Warna embed (hex, contoh: #000000)")
      )
      .addAttachmentOption((opt) =>
        opt
          .setName("thumbnail")
          .setDescription("Thumbnail embed (upload gambar)")
      )
      .addStringOption((opt) =>
        opt
          .setName("thumbnail_url")
          .setDescription("Link URL untuk thumbnail")
      )
      .addAttachmentOption((opt) =>
        opt
          .setName("image")
          .setDescription("Gambar utama embed (upload gambar)")
      )
      .addStringOption((opt) =>
        opt
          .setName("image_url")
          .setDescription("Link URL untuk gambar utama")
      )
      .toJSON()
  ],
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const guildId = message.guild.id;
      const content = message.content.toLowerCase().trim();
      const data = loadData();

      if (message.content.startsWith("!ar") || message.content.startsWith("!dar") || message.content.startsWith("!listar")) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        if (!data[guildId]) data[guildId] = {};
        if (message.content === "!ar") return message.reply("❌ Format Salah :\n`!ar|kata|response`\nContoh: `!ar|halo|Hai juga!`");
        if (message.content === "!dar") return message.reply("❌ Format Salah :\n`!dar|kata`\nContoh: `!dar|halo`");

        if (message.content.startsWith("!ar|")) {
          const args = message.content.split("|");
          const kata = args[1]?.trim();
          const response = args.slice(2).join("|").trim();
          if (!kata || !response) return message.reply("❌ Format salah!\nContoh: `!ar|halo|Hai juga!`");
          data[guildId][kata.toLowerCase()] = { type: "text", response };
          saveData(data);
          return message.reply(`✅ AutoResponse ditambahkan:\n**${kata}** → ${response}`);
        }

        if (message.content.startsWith("!dar|")) {
          const kata = message.content.split("|")[1]?.trim();
          if (!kata) return message.reply("❌ Format salah!\nContoh: `!dar|halo`");
          if (!data[guildId][kata.toLowerCase()]) return message.reply(`⚠️ Kata **${kata}** gak ditemukan.`);
          delete data[guildId][kata.toLowerCase()];
          saveData(data);
          return message.reply(`🗑️ AutoResponse untuk **${kata}** udah dihapus.`);
        }

        if (message.content.startsWith("!listar")) {
          const entries = Object.entries(data[guildId]);
          if (entries.length === 0) return message.reply("📃 Belum ada autoresponse di server ini.");
          const embed = new EmbedBuilder()
            .setTitle(`📘 AutoResponse List — ${message.guild.name}`)
            .setColor("Green")
            .setDescription(entries.map(([k, v], i) => `**${i + 1}.** ${k} → ${v.response}`).join("\n"))
            .setFooter({ text: "Gunakan !dar|kata untuk hapus." });
          return message.reply({ embeds: [embed] });
        }
        return;
      }

      if (!data[guildId]) return;

      for (const trigger of Object.keys(data[guildId])) {
        const words = content.split(/\s+/); 
        
        if (words.includes(trigger.toLowerCase())) {
          const entry = data[guildId][trigger];
          if (entry.type === "embed") {
            const embed = new EmbedBuilder().setColor(entry.color || 0x000000).setDescription(entry.response);
            if (entry.thumbnail) embed.setThumbnail(entry.thumbnail);
            if (entry.image) embed.setImage(entry.image);
            return message.channel.send({ embeds: [embed] });
          } else {
            return message.channel.send(entry.response);
          }
        }
      }
    });

    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand() || interaction.commandName !== "autoresponse") return;
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
      }
      
      const data = loadData();
      const guildId = interaction.guild.id;
      const action = interaction.options.getString("action");
      const kata = interaction.options.getString("kata");
      const response = interaction.options.getString("response");
      const isEmbed = interaction.options.getBoolean("embed") || false;
      const colorInput = interaction.options.getString("color");
      
      const thumbnailFile = interaction.options.getAttachment("thumbnail");
      const thumbnailUrlInput = interaction.options.getString("thumbnail_url");
      const finalThumbnail = thumbnailFile ? thumbnailFile.url : thumbnailUrlInput;

      const imageFile = interaction.options.getAttachment("image");
      const imageUrlInput = interaction.options.getString("image_url");
      const finalImage = imageFile ? imageFile.url : imageUrlInput;
      
      if (!data[guildId]) data[guildId] = {};
      const color = colorInput && /^#?[0-9A-Fa-f]{6}$/.test(colorInput) ? parseInt(colorInput.replace("#", ""), 16) : null;

      if (action === "add") {
        if (!kata || !response) return interaction.reply({ content: "❌ Format salah.", ephemeral: true });
        
        await interaction.deferReply();
        try {
            data[guildId][kata.toLowerCase()] = { 
                type: isEmbed ? "embed" : "text", 
                response, 
                thumbnail: finalThumbnail, 
                image: finalImage,
                color 
            };
            saveData(data);
            return interaction.editReply(`✅ AutoResponse ditambahkan:\n**${kata}** → ${response}${isEmbed ? " *(embed)*" : ""}`);
        } catch (err) {
            return interaction.editReply(`❌ Gagal menambahkan autoresponse: ${err.message}`);
        }
      }
      if (action === "delete") {
        if (!kata) return interaction.reply({ content: "❌ Masukkan kata.", ephemeral: true });
        if (!data[guildId][kata.toLowerCase()]) return interaction.reply(`⚠️ Kata **${kata}** gak ditemukan.`);
        delete data[guildId][kata.toLowerCase()];
        saveData(data);
        return interaction.reply(`🗑️ AutoResponse untuk **${kata}** berhasil dihapus.`);
      }
      if (action === "list") {
        const entries = Object.entries(data[guildId]);
        if (entries.length === 0) return interaction.reply("📃 Belum ada autoresponse.");
        const embed = new EmbedBuilder().setTitle(`📘 AutoResponse List — ${interaction.guild.name}`).setColor("Green")
          .setDescription(entries.map(([key, val], i) => `**${i + 1}.** ${key} → ${val.response}${val.type === "embed" ? " *(embed)*" : ""}`).join("\n"));
        return interaction.reply({ embeds: [embed] });
      }
    });
  }
};