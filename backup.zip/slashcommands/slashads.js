const { 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  PermissionFlagsBits, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle, 
  ChannelType 
} = require("discord.js");

module.exports = {
  setup(client) {
    // 1. HANDLING MESSAGE COMMAND (!setupiklan)
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;
      if (!message.content.startsWith("!setupiklan")) return;

      if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      const args = message.content.split(" ").slice(1);
      const channel = message.mentions.channels.first() || message.channel;

      const embedSetup = new EmbedBuilder()
        .setTitle("📦 Iklan Produk")
        .setDescription("Bagi kalian yang ingin mencari dan menjual sesuatu barang silahkan buat iklan")
        .setColor("Green");

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("buat_iklan")
          .setLabel("📰 Buat Iklan")
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId("buat_ticket_info")
          .setLabel("🎟 Buat Ticket")
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId("hapus_iklan_main")
          .setLabel("🗑 Hapus Iklan")
          .setStyle(ButtonStyle.Danger)
      );

      await channel.send({ embeds: [embedSetup], components: [row] });
      return message.reply("✅ Setup iklan berhasil dikirim.");
    });

    // 2. HANDLING INTERACTIONS (BUTTONS & MODALS)
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      
      // --- MODAL POPUP ---
      if (interaction.isButton() && interaction.customId === "buat_iklan") {
        const modal = new ModalBuilder()
          .setCustomId("modal_iklan_input")
          .setTitle("Buat Iklan Baru");

        const nameInput = new TextInputBuilder()
          .setCustomId("nama_produk")
          .setLabel("Nama Produk")
          .setPlaceholder("Masukkan nama produk di sini")
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        const descInput = new TextInputBuilder()
          .setCustomId("desk_produk")
          .setLabel("Deskripsi Produk")
          .setPlaceholder("Masukkan deskripsi produk di sini")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true);

        const imageInput = new TextInputBuilder()
          .setCustomId("image_produk")
          .setLabel("Image URL (Opsional)")
          .setPlaceholder("Masukkan link gambar di sini (http/https)")
          .setStyle(TextInputStyle.Short)
          .setRequired(false);

        modal.addComponents(
          new ActionRowBuilder().addComponents(nameInput),
          new ActionRowBuilder().addComponents(descInput),
          new ActionRowBuilder().addComponents(imageInput)
        );

        return interaction.showModal(modal);
      }

      // --- SUBMIT MODAL ---
      if (interaction.isModalSubmit() && interaction.customId === "modal_iklan_input") {
        const nama = interaction.fields.getTextInputValue("nama_produk");
        const desk = interaction.fields.getTextInputValue("desk_produk");
        const imgUrl = interaction.fields.getTextInputValue("image_produk");

        const embedBaru = new EmbedBuilder()
          .setTitle(`📦 ${nama}`)
          .setDescription(desk)
          .setColor("Green")
          .setFooter({ text: `Pembuat: ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() }); 

        if (imgUrl && imgUrl.startsWith("http")) {
          embedBaru.setImage(imgUrl);
        }

        const rowBaru = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("buat_iklan")
            .setLabel("📰 Buat Iklan")
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId("proses_ticket_iklan")
            .setLabel("🎟 Buat Ticket")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId("hapus_iklan_item")
            .setLabel("🗑 Hapus Iklan")
            .setStyle(ButtonStyle.Danger)
        );

        await interaction.channel.send({ embeds: [embedBaru], components: [rowBaru] });
        return interaction.reply({ content: "✅ Iklan berhasil dibuat!", ephemeral: true });
      }

      // --- HAPUS IKLAN (Admin Only) ---
      if (interaction.isButton() && (interaction.customId === "hapus_iklan_main" || interaction.customId === "hapus_iklan_item")) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }
        return interaction.message.delete().catch(() => {});
      }

      // --- PROSES TICKET ---
      if (interaction.isButton() && interaction.customId === "proses_ticket_iklan") {
        const guild = interaction.guild;
        
        // Mencari user berdasarkan username yang ada di footer
        const footerText = interaction.message.embeds[0].footer.text;
        const ownerUsername = footerText.replace("Pembuat: ", "");
        const members = await guild.members.fetch();
        const owner = members.find(m => m.user.username === ownerUsername);

        if (!owner) return interaction.reply({ content: "❌ Pembuat iklan tidak ditemukan di server ini.", ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        try {
          const channelTicket = await guild.channels.create({
            name: `ticket-iklan-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: interaction.channel.parentId,
            permissionOverwrites: [
              { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
              { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
              { id: owner.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
            ],
          });

          const embedTicket = new EmbedBuilder()
            .setTitle("Ticket Iklan Berhasil")
            .setDescription(`Silakan Membicarakan Tentang Iklan\n\n**Pembuat Iklan:** <@${owner.id}>\n**Pembeli:** <@${interaction.user.id}>`)
            .setColor("Blue");

          const rowTicket = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("hapus_ticket_channel")
              .setLabel("🗑 Hapus Ticket")
              .setStyle(ButtonStyle.Danger)
          );

          await channelTicket.send({ content: `<@${owner.id}> & <@${interaction.user.id}>`, embeds: [embedTicket], components: [rowTicket] });
          return interaction.editReply({ content: `✅ Ticket berhasil dibuat: ${channelTicket}` });

        } catch (err) {
          console.error(err);
          return interaction.editReply({ content: "❌ Terjadi kesalahan saat membuat ticket." });
        }
      }

      // --- HAPUS TICKET CHANNEL (Admin Only) ---
      if (interaction.isButton() && interaction.customId === "hapus_ticket_channel") {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }
        return interaction.channel.delete().catch(() => {});
      }

      // Info button for main setup
      if (interaction.isButton() && interaction.customId === "buat_ticket_info") {
        return interaction.reply({ content: "ℹ️ Silahkan klik tombol **Buat Ticket** pada pesan iklan produk yang ingin Anda beli.", ephemeral: true });
      }
    });
  }
};