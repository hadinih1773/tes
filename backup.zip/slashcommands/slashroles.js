const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("role")
            .setDescription("Give Or Take Role From Administrator To Our Members")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .addUserOption(option => 
                option.setName("user")
                    .setDescription("Pilih user yang akan dikelola")
                    .setRequired(true))
            .addRoleOption(option => 
                option.setName("role")
                    .setDescription("Pilih role yang akan diberikan/diambil")
                    .setRequired(true))
            .toJSON()
    ],

    async setup(client) {
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;

            // VALIDASI AGAR TIDAK MENGGANGGU FILE/FITUR LAIN
            if (interaction.commandName !== "role") return;

            // Pengecekan Izin Administrator
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ 
                    content: "❌ Hanya Admin Yang Bisa Gunakan", 
                    ephemeral: true 
                });
            }

            const targetMember = interaction.options.getMember("user");
            const role = interaction.options.getRole("role");

            if (!targetMember) {
                return interaction.reply({ content: "❌ Member tidak ditemukan.", ephemeral: true });
            }

            try {
                if (targetMember.roles.cache.has(role.id)) {
                    await targetMember.roles.remove(role);
                    const embed = new EmbedBuilder()
                        .setColor("#FF0000")
                        .setDescription(`✅ Berhasil mengambil kembali role ${role} dari ${targetMember}`);
                    
                    return interaction.reply({ embeds: [embed] });
                } else {
                    await targetMember.roles.add(role);
                    const embed = new EmbedBuilder()
                        .setColor("#50C878")
                        .setDescription(`✅ Berhasil memberikan role ${role} kepada ${targetMember}`);
                    
                    return interaction.reply({ embeds: [embed] });
                }
            } catch (err) {
                console.error(err);
                if (interaction.replied || interaction.deferred) {
                    return interaction.followUp({ 
                        content: "❌ Gagal mengelola role. Pastikan posisi role bot lebih tinggi dari role tersebut.", 
                        ephemeral: true 
                    });
                } else {
                    return interaction.reply({ 
                        content: "❌ Gagal mengelola role. Pastikan posisi role bot lebih tinggi dari role tersebut.", 
                        ephemeral: true 
                    });
                }
            }
        });
    }
};