const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");

const autoThreadFile = "./database/autothread.json";

function getAutoThreadChannels() {
  if (fs.existsSync(autoThreadFile)) {
    try {
      return JSON.parse(fs.readFileSync(autoThreadFile, "utf8"));
    } catch (e) {
      console.error("Gagal membaca autothread.json:", e);
      return {};
    }
  }
  return {};
}

function saveAutoThreads(data) {
  try {
    fs.writeFileSync(autoThreadFile, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("Gagal menyimpan autothread.json:", e);
  }
}

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("autothread")
      .setDescription("Pengaturan otomatis pembuatan thread (hanya admin).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand((subcommand) =>
        subcommand
          .setName("manage")
          .setDescription("Tambah atau hapus channel dari auto-thread")
          .addStringOption((option) =>
            option
              .setName("aksi")
              .setDescription("Pilih aksi untuk auto-thread")
              .setRequired(true)
              .setAutocomplete(true)
          )
          .addStringOption((option) =>
            option
              .setName("judul")
              .setDescription("Judul thread yang akan dibuat (Wajib jika memilih aksi add)")
              .setRequired(false)
          )
          .addChannelOption((option) =>
            option
              .setName("channel")
              .setDescription("Pilih channel tujuan (opsional, default channel saat ini)")
              .setRequired(false)
          )
      )
      .toJSON(),
  ],

  setup(client) {
    // Handler untuk Interaksi Slash Command dan Autocomplete
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      // 1. HANDLER AUTOCOMPLETE
      if (interaction.isAutocomplete()) {
        if (interaction.commandName === "autothread") {
          const focusedValue = interaction.options.getFocused();
          const choices = ["add", "delete"];
          const filtered = choices.filter((choice) =>
            choice.toLowerCase().startsWith(focusedValue.toLowerCase())
          );
          await interaction.respond(
            filtered.map((choice) => ({ name: choice, value: choice }))
          );
        }
        return;
      }

      // 2. HANDLER SLASH COMMAND CHAT INPUT
      if (!interaction.isChatInputCommand()) return;
      if (interaction.commandName !== "autothread") return;

      const subcommand = interaction.options.getSubcommand();

      if (subcommand === "manage") {
        const aksi = interaction.options.getString("aksi");
        const threadTitle = interaction.options.getString("judul");
        const targetChannel = interaction.options.getChannel("channel") || interaction.channel;

        if (!targetChannel || !targetChannel.id) {
          return interaction.reply({ content: "❌ Gagal mendeteksi channel.", ephemeral: true });
        }

        let autoThreadChannels = getAutoThreadChannels();

        if (aksi === "add") {
          if (!threadTitle || threadTitle.trim().length < 1) {
            return interaction.reply({
              content: "❌ Anda harus memasukkan judul thread jika memilih opsi `add`!",
              ephemeral: true,
            });
          }

          autoThreadChannels[targetChannel.id] = threadTitle.trim();
          saveAutoThreads(autoThreadChannels);
          return interaction.reply({
            content: `Auto-thread aktif di <#${targetChannel.id}> dengan judul thread: **${threadTitle.trim()}**`,
          });
        } 
        
        if (aksi === "delete") {
          if (!autoThreadChannels[targetChannel.id]) {
            return interaction.reply({
              content: "Channel ini belum diatur auto-thread!",
              ephemeral: true,
            });
          }

          delete autoThreadChannels[targetChannel.id];
          saveAutoThreads(autoThreadChannels);
          return interaction.reply({
            content: `Auto-thread dimatikan untuk channel <#${targetChannel.id}>`,
          });
        }

        return interaction.reply({ content: "Aksi tidak valid. Pilih `add` atau `delete` via autocomplete.", ephemeral: true });
      }
    });
  },
};