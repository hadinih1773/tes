const { SlashCommandBuilder, PermissionFlagsBits, REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

const ownerFile = path.join(__dirname, "..", "database", "owner.json");

function loadOwner() {
  try {
    const raw = JSON.parse(fs.readFileSync(ownerFile, "utf8"));
    return String(raw.owner);
  } catch {
    return null;
  }
}

module.exports = {
  data: [
    // 1. /setnamebot
    new SlashCommandBuilder()
      .setName("setnamebot")
      .setDescription("Mengubah nama bot (Hanya Owner).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("name")
          .setDescription("Nama baru bot")
          .setRequired(true)
      ),

    // 2. /setppbot
    new SlashCommandBuilder()
      .setName("setppbot")
      .setDescription("Mengubah foto profil bot (Hanya Owner).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addAttachmentOption(option => 
        option.setName("image")
          .setDescription("Upload gambar langsung")
          .setRequired(true)
      ),

    // 3. /setbiobot
    new SlashCommandBuilder()
      .setName("setbiobot")
      .setDescription("Mengubah bio/deskripsi bot (Hanya Owner).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("deskripsi")
          .setDescription("Bio baru bot")
          .setRequired(true)
      ),

    // 4. /setbannerbot
    new SlashCommandBuilder()
      .setName("setbannerbot")
      .setDescription("Mengubah banner bot (Hanya Owner).")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addAttachmentOption(option => 
        option.setName("image")
          .setDescription("Upload gambar langsung")
          .setRequired(true)
      )
  ],

  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, user } = interaction;
    const OWNER_ID = loadOwner();

    // Validasi super ketat: Hanya owner asli yang bisa mengeksekusi (Admin guild diblokir)
    if (!user || user.id !== OWNER_ID) {
      return await interaction.reply({
        content: "❌ Hanya Owner Yang Bisa Gunakan",
        ephemeral: true
      });
    }

    await interaction.deferReply({ ephemeral: true });

    // --- EXECUTE: /setnamebot ---
    if (commandName === "setnamebot") {
      const name = interaction.options.getString("name");
      try {
        await interaction.client.user.setUsername(name);
        return await interaction.editReply({ content: `✅ Nama bot berhasil diubah menjadi: **${name}**` });
      } catch (err) {
        return await interaction.editReply({ content: "❌ Gagal mengubah nama." });
      }
    }

    // --- EXECUTE: /setbiobot ---
    if (commandName === "setbiobot") {
      const deskripsi = interaction.options.getString("deskripsi");
      try {
        await interaction.client.user.setAboutMe(deskripsi);
        return await interaction.editReply({ content: "✅ Deskripsi bot berhasil diubah." });
      } catch (err) {
        return await interaction.editReply({ content: "❌ Gagal mengubah deskripsi." });
      }
    }

    // --- EXECUTE: /setppbot ---
    if (commandName === "setppbot") {
      const attachment = interaction.options.getAttachment("image");
      if (!attachment || !attachment.url) {
        return await interaction.editReply({ content: "Kirim gambar atau reply gambar dengan command ini." });
      }
      try {
        await interaction.client.user.setAvatar(attachment.url);
        return await interaction.editReply({ content: "✅ Foto profil bot berhasil diubah." });
      } catch (err) {
        return await interaction.editReply({ content: "❌ Gagal mengubah foto profil." });
      }
    }

    // --- EXECUTE: /setbannerbot ---
    if (commandName === "setbannerbot") {
      const attachment = interaction.options.getAttachment("image");
      if (!attachment || !attachment.url) {
        return await interaction.editReply({ content: "Kirim gambar atau reply gambar dengan command ini." });
      }
      try {
        await interaction.client.user.setBanner(attachment.url);
        return await interaction.editReply({ content: "✅ Banner bot berhasil diubah." });
      } catch (err) {
        return await interaction.editReply({ content: "❌ Gagal mengubah banner." });
      }
    }
  },

  setup(client) {
    // 1. Registrasi Otomatis saat Bot Berhasil Online
    client.once("ready", async () => {
      // Mengonversi SlashCommandBuilder ke format JSON yang dikenali API Discord
      const commandsJSON = module.exports.data.map(cmd => cmd.toJSON());
      
      // Daftar token dari env yang akan didaftarkan slash command-nya
      const tokens = [
        process.env.DISCORD_TOKEN,
        process.env.DISCORD_TOKEN_HCBB,
        process.env.DISCORD_TOKEN_SEWA,
        process.env.DISCORD_TOKEN_HCECO
      ];

      for (const token of tokens) {
        if (!token) continue; // Skip jika ada token yang kosong di env

        const rest = new REST({ version: "10" }).setToken(token);
        let botUser;

        try {
          // Mendapatkan ID aplikasi langsung dari token atau dari client jika token saat ini cocok
          botUser = await rest.get(Routes.user());
          
          await rest.put(
            Routes.applicationCommands(botUser.id),
            { body: commandsJSON }
          );
        } catch (error) {
          const botName = botUser ? botUser.username : "Unknown Bot";
          console.error(`❌ Gagal Mendaftarkan Slash Command Ke Bot ${botName}`);
        }
      }

      console.log(`✅ Sukses Mendaftarkan Slash Command /slashall Ke Semua Bot`);
    });

    // 2. Listener untuk Menangani Interaksi Chat Input
    client.on("interactionCreate", async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      
      const listCmd = ["setnamebot", "setppbot", "setbiobot", "setbannerbot"];
      if (listCmd.includes(interaction.commandName)) {
        try {
          await module.exports.execute(interaction);
        } catch (err) {
          console.error(`❌ Gagal mengeksekusi command ${interaction.commandName}:`, err);
        }
      }
    });
  }
};