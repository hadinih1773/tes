const axios = require('axios');

async function spotifydl(url) {

  if (

    !/^https?:\/\/(open\.)?spotify\.com\/track\/[A-Za-z0-9]{22}(?:\?.*)?$/i.test(

      url

    )

  ) {

    throw new Error('Invalid Spotify URL.')

  }

  try {

    // Perbaikan: Menggunakan query parameter '?' yang benar untuk API

    const apiUrl = `https://api.nekolabs.web.id/downloader/spotify/v1?url=${encodeURIComponent(url)}`;

    const response = await axios.get(apiUrl);

    

    const data = response.data;

    if (!data.success || !data.result) {

      throw new Error('Failed to retrieve track information from API.');

    }

    // Mengembalikan data untuk diproses menjadi buffer & diupload ke Top4Top di kode utama

    return {

      link: data.result.downloadUrl,

      title: data.result.title || 'Unknown',

      artist: data.result.artist || 'Unknown',

      // Fallback ke URL gambar kosong jika tidak ada, agar setImage tidak error

      thumbnail: data.result.cover && data.result.cover !== '' ? data.result.cover : 'https://files.catbox.moe/yoofza.gif',

      duration: data.result.duration || '00:00'

    };

  } catch (error) {

    throw new Error(`Spotify Downloader Error: ${error.message}`);

  }

}

module.exports = { spotifydl };

