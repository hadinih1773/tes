// fix.js
// GLOBAL STABILITY & CLEANER MODULE

const fs = require("fs");
const path = require("path");
const axios = require("axios");

let FIXED = false;

function setup(client) {
  if (FIXED) return;
  FIXED = true;

  console.log("🧯 FIX MODE AKTIF");

  /* ===============================
     1. GLOBAL AXIOS RATE LIMIT
  =============================== */
  axios.defaults.timeout = 10_000;

  let lastRequest = 0;
  const MIN_DELAY = 1200; // 1.2 detik (aman buat webhook)

  const originalPost = axios.post;
  axios.post = async function (...args) {
    const now = Date.now();
    const diff = now - lastRequest;
    if (diff < MIN_DELAY) {
      await new Promise(r => setTimeout(r, MIN_DELAY - diff));
    }
    lastRequest = Date.now();
    return originalPost.apply(this, args);
  };

  console.log("✅ Axios rate-limit dipasang");

  /* ===============================
     2. NETRALIN fs.watch LIAR
  =============================== */
  const originalWatch = fs.watch;
  fs.watch = function (...args) {
    console.log("⚠️ fs.watch diblok (stability mode)");
    return { close() {} };
  };

  /* ===============================
     3. BERSIHIN FILE SAMPAH
  =============================== */
  const JUNK_DIRS = [
    "tmp",
    "temp",
    "logs",
    "cache",
    "downloads"
  ];

  for (const dir of JUNK_DIRS) {
    const full = path.join(process.cwd(), dir);
    if (fs.existsSync(full)) {
      try {
        fs.rmSync(full, { recursive: true, force: true });
        console.log("🧹 Bersih:", dir);
      } catch {}
    }
  }

  /* ===============================
     4. LIMIT INTERVAL & TIMEOUT
  =============================== */
  const _setInterval = global.setInterval;
  global.setInterval = (fn, time, ...args) => {
    if (time < 1000) time = 1000;
    return _setInterval(fn, time, ...args);
  };

  const _setTimeout = global.setTimeout;
  global.setTimeout = (fn, time, ...args) => {
    if (time < 500) time = 500;
    return _setTimeout(fn, time, ...args);
  };

  console.log("⏱️ Interval & timeout distabilkan");

  /* ===============================
     5. BLOCK LOOP CRASH
  =============================== */
  process.on("unhandledRejection", err => {
    console.log("⚠️ UnhandledRejection dicegah:", err?.message);
  });

  process.on("uncaughtException", err => {
    console.log("⚠️ UncaughtException dicegah:", err?.message);
  });

  /* ===============================
     6. STOP MEMORY BLOAT
  =============================== */
  setInterval(() => {
    if (global.gc) {
      global.gc();
      console.log("🧠 GC dipaksa (memory clean)");
    }
  }, 60_000);

  /* ===============================
     7. DISABLE MASS ATTACHMENT
  =============================== */
  (client._msgHandlers = client._msgHandlers || []).push(msg => {
    if (msg.attachments && msg.attachments.size > 3) {
      try {
        msg.attachments.clear();
        console.log("📎 Attachment berlebihan diblok");
      } catch {}
    }
  });

  console.log("🛡️ FIX MODULE SIAP & AMAN");
}

module.exports = { setup };