const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../databasewa/economywa.json");
const userPath = path.join(__dirname, "../databasewa/userwa.json");
const adminPath = path.join(__dirname, "../databasewa/adminwa.json");

// 30 Daftar Hewan Buas / Liar + Item Hasil Pancing & Tambang dengan range harga beli, harga jual random + Emoji
const shopItems = {
  "rusa": { name: "Rusa", emoji: "🦌", buyMin: 1000, buyMax: 2000, sellMin: 600, sellMax: 1200 },
  "kelinci": { name: "Kelinci", emoji: "🐇", buyMin: 300, buyMax: 700, sellMin: 200, sellMax: 450 },
  "babi": { name: "Babi Hutan", emoji: "🐗", buyMin: 900, buyMax: 1500, sellMin: 500, sellMax: 950 },
  "ayam": { name: "Ayam Hutan", emoji: "🐓", buyMin: 200, buyMax: 500, sellMin: 100, sellMax: 250 },
  "serigala": { name: "Serigala", emoji: "🐺", buyMin: 1500, buyMax: 3000, sellMin: 700, sellMax: 1400 },
  "beruang": { name: "Beruang", emoji: "🐻", buyMin: 3000, buyMax: 6000, sellMin: 1400, sellMax: 2800 },
  "harimau": { name: "Harimau", emoji: "🐯", buyMin: 4000, buyMax: 8000, sellMin: 1900, sellMax: 3800 },
  "singa": { name: "Singa", emoji: "🦁", buyMin: 4500, buyMax: 9000, sellMin: 2100, sellMax: 4200 },
  "macan": { name: "Macan Tutul", emoji: "🐆", buyMin: 3500, buyMax: 7000, sellMin: 1600, sellMax: 3300 },
  "ular": { name: "Ular Kobra", emoji: "🐍", buyMin: 800, buyMax: 1800, sellMin: 400, sellMax: 900 },
  "buaya": { name: "Buaya", emoji: "🐊", buyMin: 2500, buyMax: 5000, sellMin: 1200, sellMax: 2400 },
  "banteng": { name: "Banteng", emoji: "🐂", buyMin: 2000, buyMax: 4000, sellMin: 900, sellMax: 1900 },
  "rubah": { name: "Rubah", emoji: "🦊", buyMin: 600, buyMax: 1300, sellMin: 300, sellMax: 650 },
  "elang": { name: "Elang", emoji: "🦅", buyMin: 1200, buyMax: 2500, sellMin: 550, sellMax: 1150 },
  "burung": { name: "Burung Hantu", emoji: "🦉", buyMin: 400, buyMax: 900, sellMin: 180, sellMax: 400 },
  "landak": { name: "Landak", emoji: "🦔", buyMin: 350, buyMax: 800, sellMin: 150, sellMax: 380 },
  "luwak": { name: "Luwak", emoji: "🦦", buyMin: 500, buyMax: 1100, sellMin: 220, sellMax: 500 },
  "kancil": { name: "Kancil", emoji: "🦌", buyMin: 450, buyMax: 1000, sellMin: 200, sellMax: 480 },
  "tupai": { name: "Tupai", emoji: "🐿️", buyMin: 150, buyMax: 400, sellMin: 70, sellMax: 180 },
  "musang": { name: "Musang", emoji: "🦡", buyMin: 400, buyMax: 900, sellMin: 180, sellMax: 420 },
  "gorila": { name: "Gorila", emoji: "🦍", buyMin: 3800, buyMax: 7500, sellMin: 1800, sellMax: 3600 },
  "simpanse": { name: "Simpanse", emoji: "🐒", buyMin: 1500, buyMax: 3200, sellMin: 700, sellMax: 1500 },
  "babon": { name: "Monyet Babon", emoji: "🦧", buyMin: 1000, buyMax: 2200, sellMin: 450, sellMax: 1000 },
  "hyena": { name: "Hyena", emoji: "🐺", buyMin: 1800, buyMax: 3600, sellMin: 850, sellMax: 1700 },
  "cheetah": { name: "Cheetah", emoji: "🐆", buyMin: 4000, buyMax: 7800, sellMin: 1900, sellMax: 3700 },
  "badak": { name: "Badak", emoji: "🦏", buyMin: 5000, buyMax: 10000, sellMin: 2400, sellMax: 4800 },
  "gajah": { name: "Gajah", emoji: "🐘", buyMin: 5500, buyMax: 11000, sellMin: 2600, sellMax: 5300 },
  "kudanil": { name: "Kuda Nil", emoji: "🦛", buyMin: 4800, buyMax: 9500, sellMin: 2200, sellMax: 4600 },
  "jerapah": { name: "Jerapah", emoji: "🦒", buyMin: 3000, buyMax: 6500, sellMin: 1400, sellMax: 3000 },
  "zebra": { name: "Zebra", emoji: "🦓", buyMin: 2000, buyMax: 4500, sellMin: 950, sellMax: 2100 },
  
  // Item Hasil Memancing
  "lele": { name: "Ikan Lele", emoji: "🐟", buyMin: 150, buyMax: 350, sellMin: 80, sellMax: 160 },
  "gurame": { name: "Ikan Gurame", emoji: "🐠", buyMin: 400, buyMax: 800, sellMin: 200, sellMax: 400 },
  "tuna": { name: "Ikan Tuna", emoji: "🐟", buyMin: 1000, buyMax: 2500, sellMin: 500, sellMax: 1200 },
  "salmon": { name: "Ikan Salmon", emoji: "🍣", buyMin: 1500, buyMax: 3500, sellMin: 750, sellMax: 1700 },
  "hiu": { name: "Ikan Hiu", emoji: "🦈", buyMin: 5000, buyMax: 9000, sellMin: 2300, sellMax: 4500 },

  // Item Hasil Menambang
  "berlian": { name: "Berlian", emoji: "💎", buyMin: 8000, buyMax: 15000, sellMin: 4000, sellMax: 7500 },
  "emas": { name: "Emas", emoji: "🪙", buyMin: 4000, buyMax: 8000, sellMin: 2000, sellMax: 4000 },
  "perak": { name: "Perak", emoji: "🥈", buyMin: 1500, buyMax: 3000, sellMin: 700, sellMax: 1400 },
  "emerald": { name: "Batu Emerald", emoji: "💚", buyMin: 3000, buyMax: 6000, sellMin: 1400, sellMax: 2900 },
  "batubara": { name: "Batu Bara", emoji: "🪨", buyMin: 200, buyMax: 500, sellMin: 90, sellMax: 220 },
  "minyak": { name: "Miyak Bumi", emoji: "🛢️", buyMin: 2500, buyMax: 5000, sellMin: 1200, sellMax: 2400 }
};

function readDB() {
  if (!fs.existsSync(path.dirname(dbPath))) {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}), "utf8");
  }
  try {
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch (e) {
    return {};
  }
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), "utf8");
}

function getUserData(guildId, userId) {
  const db = readDB();
  if (!db[guildId]) db[guildId] = {};
  if (!db[guildId][userId]) {
    db[guildId][userId] = {
      wallet: 0,
      bank: 0,
      lastWork: 0,
      lastDaily: 0,
      lastWeekly: 0,
      lastHunt: 0,
      lastFish: 0,
      lastMine: 0,
      workCooldown: 0,
      inventory: {},
      xp: 0,
      level: 1
    };
  }
  if (!db[guildId][userId].inventory) db[guildId][userId].inventory = {};
  if (db[guildId][userId].xp === undefined) db[guildId][userId].xp = 0;
  if (db[guildId][userId].level === undefined) db[guildId][userId].level = 1;
  if (db[guildId][userId].lastHunt === undefined) db[guildId][userId].lastHunt = 0;
  if (db[guildId][userId].lastFish === undefined) db[guildId][userId].lastFish = 0;
  if (db[guildId][userId].lastMine === undefined) db[guildId][userId].lastMine = 0;
  return { db, user: db[guildId][userId] };
}

function formatCooldown(ms) {
  const totalSecs = Math.floor(ms / 1000);
  const hours = Math.floor(totalSecs / 3600);
  const minutes = Math.floor((totalSecs % 3600) / 60);
  const seconds = totalSecs % 60;
  
  let res = [];
  if (hours > 0) res.push(`⏳ ${hours} Jam`);
  if (minutes > 0) res.push(`⏳ ${minutes} Menit`);
  if (seconds > 0) res.push(`⏳ ${seconds} Detik`);
  return res.join(" ") || "0 Detik";
}

async function addXpRandom(guildId, userId, sock, from, m) {
  const chance = Math.random();
  if (chance > 0.5) { 
    const { db, user } = getUserData(guildId, userId);
    const xpGained = Math.floor(Math.random() * (25 - 5 + 1)) + 5;
    user.xp += xpGained;
    
    const xpNeeded = 1000;
    let levelUp = false;
    if (user.xp >= xpNeeded) {
      user.xp -= xpNeeded;
      user.level += 1;
      levelUp = true;
    }
    writeDB(db);

    if (levelUp) {
      let response = `🎉 *ʟᴇᴠᴇʟ ᴜᴘ sᴜᴄᴄᴇs*\n\n✨✨ Horeee! @${userId.split('@')[0]} Selamat Kamu Naik Ke Level *${user.level}*! ✨✨`;
      await sock.sendMessage(from, { text: response, mentions: [userId] }, { quoted: m }).catch(() => {});
    }
  }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
  try {
    if (!m.message) return;

    const from = jid;
    const rawSender = m.key.participant || m.key.remoteJid;
    const sender = rawSender.replace(/:[0-9]+/g, '');

    // Cek Registrasi User (Jika belum terdaftar, bot diam saja)
    if (!fs.existsSync(userPath)) return;
    const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
    const registeredUsers = userDb.map(v => v.replace(/:[0-9]+/g, ''));
    if (!registeredUsers.includes(sender)) return;

    // Ambil Data Admin untuk proteksi command admin
    const adminData = fs.existsSync(adminPath) ? JSON.parse(fs.readFileSync(adminPath, "utf-8")) : [];
    const isAdmin = adminData.some(v => v.replace(/:[0-9]+/g, '') === sender);

    const economyCommands = [
      'mystats', 'cekstats', 'work', 'daily', 'weekly', 'deposite', 'depo', 'depositeall', 'depoall',
      'withdraw', 'with', 'withdrawall', 'withall', 'balance', 'bal', 'rob', 'hunt', 'fish', 'mine',
      'inventory', 'inv', 'sell', 'sellall', 'shop', 'buy', 'transfer', 'leaderboard', 'lb',
      'addmoney', 'takemoney', 'cekinventory', 'cekinv', 'resetmoney', 'resetuser', 'resetinventory',
      'resetinv', 'addlevel', 'takelevel', 'resetlevel'
    ];

    if (!economyCommands.includes(command)) return;

    // Tambahkan level atau XP ketika menggunakan command economy
    await addXpRandom(from, sender, sock, from, m);

    // Filter Command Admin
    const adminOnlyCommands = ['cekstats', 'addmoney', 'takemoney', 'cekinventory', 'cekinv', 'resetmoney', 'resetuser', 'resetinventory', 'resetinv', 'addlevel', 'takelevel', 'resetlevel'];
    if (adminOnlyCommands.includes(command) && !isAdmin) {
      await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
      return;
    }

    // MYSTATS COMMAND
    if (command === "mystats") {
      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { user } = getUserData(from, sender);
        let itemsStr = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} *${shopItems[key]?.name || key}*: ${val} Buah`);
        }
        const isiTas = itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Kamu Kosong.";

        let response = `📊 *ᴜsᴇʀ sᴛᴀᴛᴜs ᴘʀᴏғɪʟᴇ*\n\n👤 *User Target:* @${sender.split('@')[0]}\n💵 *Uang Saku:* $${user.wallet}\n🏦 *Saldo Bank:* $${user.bank}\n📈 *Level Status:* Lv. ${user.level} *(XP: ${user.xp}/1000)*\n\n🎒 *Isi Dalam Tas:*\n${isiTas}`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // CEKSTATS COMMAND (ADMIN ONLY)
    if (command === "cekstats") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { user } = getUserData(from, cleanTarget);
        let itemsStr = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} *${shopItems[key]?.name || key}*: ${val} Buah`);
        }
        const isiTas = itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Kamu Kosong.";

        let response = `📊 *ᴜsᴇʀ sᴛᴀᴛᴜs ᴘʀᴏғɪʟᴇ*\n\n👤 *User Target:* @${cleanTarget.split('@')[0]}\n💵 *Uang Saku:* $${user.wallet}\n🏦 *Saldo Bank:* $${user.bank}\n📈 *Level Status:* Lv. ${user.level} *(XP: ${user.xp}/1000)*\n\n🎒 *Isi Dalam Tas:*\n${isiTas}`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 1. WORK
    if (command === "work") {
      const { db, user } = getUserData(from, sender);
      const now = Date.now();
      if (now < user.lastWork) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        let response = `❌ *ᴡᴏʀᴋɪɴɢ ʀᴇᴊᴇᴄᴛᴇᴅ*\n\n🛑 @${sender.split('@')[0]} Anda Sudah Mengklaim Uang Kerja Coba Lagi Dalam ${formatCooldown(user.lastWork - now)}`;
        return await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const randUang = Math.floor(Math.random() * (500 - 100 + 1)) + 100; 
        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000; 

        user.wallet += randUang;
        user.lastWork = now + randCooldown;
        writeDB(db);

        let response = `💼 *ᴡᴏʀᴋɪɴɢ ʀᴇᴡᴀʀᴅ*\n\n✅ @${sender.split('@')[0]} Kamu Telah Mendapatkan Uang Saku Sebesar *$${randUang}* dari pekerjaanmu!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 2. DAILY
    if (command === "daily") {
      const { db, user } = getUserData(from, sender);
      const todayDate = new Date().toISOString().slice(0, 10);

      if (user.lastDaily === todayDate) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        let response = `❌ *ᴅᴀɪʟʏ ʀᴇᴊᴇᴄᴛᴇᴅ*\n\n🛑 @${sender.split('@')[0]} Anda Sudah Mengklaim Hari Ini Kembali Lagi Besok`;
        return await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const randUang = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000;
        user.wallet += randUang;
        user.lastDaily = todayDate;
        writeDB(db);

        let response = `📅 *ᴅᴀɪʟʏ ʀᴇᴡᴀʀᴅ*\n\n✅ @${sender.split('@')[0]} Kamu Telah Mendapatkan Uang Hadiah Harian Sebesar *$${randUang}*!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 3. WEEKLY
    if (command === "weekly") {
      const { db, user } = getUserData(from, sender);
      const now = Date.now();
      const cooldown = 7 * 24 * 60 * 60 * 1000;

      if (now - user.lastWeekly < cooldown) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        let response = `❌ *ᴡᴇᴇᴋʟʏ ʀᴇᴊᴇᴄᴛᴇᴅ*\n\n🛑 @${sender.split('@')[0]} Kembali Lagi Satu Minggu Kedepan Setelah Hari Ini`;
        return await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const randUang = Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000;
        user.wallet += randUang;
        user.lastWeekly = now;
        writeDB(db);

        let response = `📮 *ᴡᴇᴇᴋʟʏ ʀᴇᴡᴀʀᴅ*\n\n✅ @${sender.split('@')[0]} Kamu Telah Mendapatkan Uang Hadiah Mingguan Sebesar *$${randUang}*!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 4. DEPOSITE
    if (command === "deposite" || command === "depo" || command === "depositeall" || command === "depoall") {
      const { db, user } = getUserData(from, sender);
      let amountStr = args[0];

      if (command === "depositeall" || command === "depoall" || (amountStr && amountStr.toLowerCase() === "all")) {
        await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
        try {
          const total = user.wallet;
          user.bank += total;
          user.wallet = 0;
          writeDB(db);

          let response = `🏦 *ᴅᴇᴘᴏsɪᴛᴇ ᴍᴏɴᴇʏ*\n\n💰 @${sender.split('@')[0]} Menyimpan Semua Uang Yang Ada Di Dompet Sebanyak *$${total}* Ke Bank!`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
        } catch (err) {
          await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        }
        return;
      }

      if (!amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} Jumlah\`` }, { quoted: m });
      }

      const amount = parseInt(amountStr);
      if (amount > user.wallet) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Uang Di Saku Kamu Tidak Mencukupi." }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        user.wallet -= amount;
        user.bank += amount;
        writeDB(db);

        let response = `🏦 *ᴅᴇᴘᴏsɪᴛᴇ ᴍᴏɴᴇʏ*\n\n💰 @${sender.split('@')[0]} Menyimpan Uang Di Bank Sebanyak *$${amount}*!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 5. WITHDRAW
    if (command === "withdraw" || command === "with" || command === "withdrawall" || command === "withall") {
      const { db, user } = getUserData(from, sender);
      let amountStr = args[0];

      if (command === "withdrawall" || command === "withall" || (amountStr && amountStr.toLowerCase() === "all")) {
        await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
        try {
          const total = user.bank;
          user.wallet += total;
          user.bank = 0;
          writeDB(db);

          let response = `✍️ *ᴡɪᴛʜᴅʀᴀᴡ ᴍᴏɴᴇʏ*\n\n💵 @${sender.split('@')[0]} Mengambil Semua Uang Dari Bank Sebanyak *$${total}*!`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
        } catch (err) {
          await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        }
        return;
      }

      if (!amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} Jumlah\`` }, { quoted: m });
      }

      const amount = parseInt(amountStr);
      if (amount > user.bank) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Uang Di Bank Kamu Tidak Mencukupi." }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        user.bank -= amount;
        user.wallet += amount;
        writeDB(db);

        let response = `✍️ *ᴡɪᴛʜᴅʀᴀᴡ ᴍᴏɴᴇʏ*\n\n💵 @${sender.split('@')[0]} Mengambil Uang Dari Bank Sebanyak *$${amount}*!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 6. BALANCE
    if (command === "balance" || command === "bal") {
      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { user } = getUserData(from, sender);
        let response = `💸 *ʙᴀʟᴀɴᴄᴇ ᴍᴏɴᴇʏ*\n\n👤 *User Saku:* @${sender.split('@')[0]}\n🏧 *Bank Balance:* $${user.bank}\n📥 *Dompet Saku:* $${user.wallet}\n📊 *Level Status:* Lv. ${user.level} *(XP: ${user.xp}/1000)*`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 7. ROB
    if (command === "rob") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      if (cleanTarget === sender) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Kamu Tidak Bisa Merampok Diri Sendiri." }, { quoted: m });
      }

      const { db, user: attacker } = getUserData(from, sender);
      const { user: targetData } = getUserData(from, cleanTarget);

      if (targetData.wallet < 100) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Target Terlalu Miskin, Saku Mereka Tidak Memiliki Cukup Uang Untuk Dirampok." }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const chance = Math.random();
        if (chance > 0.4) {
          const robAmount = Math.floor(Math.random() * (targetData.wallet - 50 + 1)) + 50;
          targetData.wallet -= robAmount;
          attacker.wallet += robAmount;
          writeDB(db);

          let response = `⚔️ *ʀᴏʙʙᴀʀʏ ᴜsᴇʀ*\n\n⚔️ @${sender.split('@')[0]} Telah Mengambil Uang Saku @${cleanTarget.split('@')[0]} Sebesar *$${robAmount}*!`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender, cleanTarget] }, { quoted: m });
        } else {
          const fine = Math.floor(Math.random() * (attacker.wallet > 100 ? 100 : attacker.wallet || 50)) + 10;
          attacker.wallet = Math.max(0, attacker.wallet - fine);
          writeDB(db);

          let response = `🚨 *ᴀʀʀᴇsᴛᴇᴅ ʙʏ ᴘᴏʟɪᴄᴇ*\n\n🚨 Sial! @${sender.split('@')[0]} Ketahuan Aksi Merampok. Telah Ditangkap Oleh Polisi Dan Didenda Uang Sebanyak *$${fine}*!`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
        }
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // 8. HUNT
    if (command === "hunt") {
      const { db, user } = getUserData(from, sender);
      const now = Date.now();
      if (now < user.lastHunt) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        let response = `❌ *ʜᴜɴᴛɪɴɢ ʀᴇᴊᴇᴄᴛᴇᴅ*\n\n🛑 @${sender.split('@')[0]} Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastHunt - now)}`;
        return await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000; 
        user.lastHunt = now + randCooldown;

        const chance = Math.random();
        if (chance < 0.25) {
          const fine = Math.floor(Math.random() * (200 - 50 + 1)) + 50;
          user.wallet = Math.max(0, user.wallet - fine);
          writeDB(db);

          let response = `💥 *ʜᴜɴᴛ ᴅɪsᴀsᴛᴇʀ*\n\n💥 Gawat! @${sender.split('@')[0]} Kamu Diserang Oleh Babi Hutan! Uangmu Berkurang Sebanyak *$${fine}* Untuk Biaya Pengobatan Rumah Sakit.`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
        } else {
          const keys = ["rusa", "kelinci", "babi", "ayam", "serigala", "beruang", "harimau", "singa", "macan", "ular", "buaya", "banteng", "rubah", "elang", "burung", "landak", "luwak", "kancil", "tupai", "musang", "gorila", "simpanse", "babon", "hyena", "cheetah", "badak", "gajah", "kudanil", "jerapah", "zebra"];
          const randomKey = keys[Math.floor(Math.random() * keys.length)];
          
          user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
          writeDB(db);

          let response = `🏹 *ʜᴜɴᴛɪɴɢ sᴜᴄᴄᴇs*\n\n🏹 @${sender.split('@')[0]} Berhasil Memburu Dan Mendapatkan *1 ${shopItems[randomKey].emoji} ${shopItems[randomKey].name}*! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
        }
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // FISH
    if (command === "fish") {
      const { db, user } = getUserData(from, sender);
      const now = Date.now();
      if (now < user.lastFish) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        let response = `❌ *ғɪsʜɪɴɢ ʀᴇᴊᴇᴄᴛᴇᴅ*\n\n🛑 @${sender.split('@')[0]} Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastFish - now)}`;
        return await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastFish = now + randCooldown;

        const keys = ["lele", "gurame", "tuna", "salmon", "hiu"];
        const randomKey = keys[Math.floor(Math.random() * keys.length)];

        user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
        writeDB(db);

        let response = `🌊 *ғɪsʜɪɴɢ sᴜᴄᴄᴇs*\n\n🌊 @${sender.split('@')[0]} Berhasil Memancing Dan Mendapatkan *1 ${shopItems[randomKey].emoji} ${shopItems[randomKey].name}*! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // MINE
    if (command === "mine") {
      const { db, user } = getUserData(from, sender);
      const now = Date.now();
      if (now < user.lastMine) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        let response = `❌ *ᴍɪɴɪɴɢ ʀᴇᴊᴇᴄᴛᴇᴅ*\n\n🛑 @${sender.split('@')[0]} Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastMine - now)}`;
        return await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastMine = now + randCooldown;

        const keys = ["berlian", "emas", "perak", "emerald", "batubara", "minyak"];
        const randomKey = keys[Math.floor(Math.random() * keys.length)];

        user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
        writeDB(db);

        let response = `💎 *ᴍɪɴɪɴɢ sᴜᴄᴄᴇs*\n\n💎 @${sender.split('@')[0]} Berhasil Menambang Dan Mendapatkan *1 ${shopItems[randomKey].emoji} ${shopItems[randomKey].name}*! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // INVENTORY
    if (command === "inventory" || command === "inv") {
      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { user } = getUserData(from, sender);
        let kancut = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) kancut.push(`📦 ${shopItems[key]?.emoji || ""} *${shopItems[key]?.name || key}*: ${val} Buah`);
        }

        let response = `🎒 *ʏᴏᴜʀ ɪɴᴠᴇɴᴛᴏʀʏ*\n\n${kancut.length > 0 ? kancut.join("\n") : "✨ Inventory Tas Milikmu Masih Kosong."}`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // SELL
    if (command === "sell" || command === "sellall") {
      const { db, user } = getUserData(from, sender);

      if (command === "sellall" || (args[0] && args[0].toLowerCase() === "all")) {
        await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
        try {
          let totalEarned = 0;
          let totalItems = 0;

          for (const [key, val] of Object.entries(user.inventory)) {
            if (val > 0) {
              const itemConf = shopItems[key];
              if (itemConf) {
                for (let i = 0; i < val; i++) {
                  totalEarned += Math.floor(Math.random() * (itemConf.sellMax - itemConf.sellMin + 1)) + itemConf.sellMin;
                }
                totalItems += val;
                user.inventory[key] = 0;
              }
            }
          }

          if (totalItems === 0) {
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            return await sock.sendMessage(from, { text: "❌ Kamu Tidak Memiliki Barang Apapun Untuk Dijual." }, { quoted: m });
          }
          user.wallet += totalEarned;
          writeDB(db);

          let response = `💰 *sᴇʟʟ ᴀʟʟ ɪᴛᴇᴍs sᴜᴄᴄᴇs*\n\n💵 @${sender.split('@')[0]} Berhasil Menjual Semua Isi Tas Sebanyak *${totalItems} Item* Dan Mendapatkan Uang Total Sebesar *$${totalEarned}*!`;
          await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
          await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
        } catch (err) {
          await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        }
        return;
      }

      const inputItem = args[0]?.toLowerCase();
      const inputQtyStr = args[1];

      if (!inputItem || (!shopItems[inputItem] && !Object.values(shopItems).some(i => i.name.toLowerCase() === inputItem))) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} item|jumlah\`` }, { quoted: m });
      }

      const itemKey = shopItems[inputItem] ? inputItem : Object.keys(shopItems).find(k => shopItems[k].name.toLowerCase() === inputItem);
      const qty = inputQtyStr ? parseInt(inputQtyStr) : 1;
      
      if (isNaN(qty) || qty <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} item|jumlah\`` }, { quoted: m });
      }

      if (!user.inventory[itemKey] || user.inventory[itemKey] < qty) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Jumlah Item Di Inventory Kamu Tidak Mencukupi." }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        let earned = 0;
        const itemConf = shopItems[itemKey];
        for (let i = 0; i < qty; i++) {
          earned += Math.floor(Math.random() * (itemConf.sellMax - itemConf.sellMin + 1)) + itemConf.sellMin;
        }

        user.inventory[itemKey] -= qty;
        user.wallet += earned;
        writeDB(db);

        let response = `💰 *sᴇʟʟ ɪᴛᴇᴍ sᴜᴄᴄᴇs*\n\n💵 @${sender.split('@')[0]} Berhasil Menjual *${qty} ${itemConf.emoji} ${itemConf.name}* Dan Mendapatkan Uang Saku Sebesar *$${earned}*!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // SHOP
    if (command === "shop") {
      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const itemsArray = Object.entries(shopItems);
        let listStr = [];
        
        for (const [key, val] of itemsArray) {
          const randomBuyPrice = Math.floor(Math.random() * (val.buyMax - val.buyMin + 1)) + val.buyMin;
          listStr.push(`${val.emoji} *${val.name}* (\`${key}\`)\n 🔹 Harga Beli: *$${randomBuyPrice}*\n 🔹 Estimasi Jual: *$${val.sellMin} - $${val.sellMax}*`);
        }

        let response = `🏪 *ᴇᴄᴏɴᴏᴍʏ sʜᴏᴘ ᴍᴀʀᴋᴇᴛ*\n\n${listStr.join("\n\n")}`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // BUY
    if (command === "buy") {
      const inputItem = args[0]?.toLowerCase();
      const inputQtyStr = args[1];

      if (!inputItem || (!shopItems[inputItem] && !Object.values(shopItems).some(i => i.name.toLowerCase() === inputItem)) || !inputQtyStr || isNaN(inputQtyStr)) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} item|jumlah\`` }, { quoted: m });
      }

      const qty = parseInt(inputQtyStr);
      if (qty <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} item|jumlah\`` }, { quoted: m });
      }

      const itemKey = shopItems[inputItem] ? inputItem : Object.keys(shopItems).find(k => shopItems[k].name.toLowerCase() === inputItem);
      const { db, user } = getUserData(from, sender);
      const itemConf = shopItems[itemKey];
      const randomBuyPrice = Math.floor(Math.random() * (itemConf.buyMax - itemConf.buyMin + 1)) + itemConf.buyMin;
      const totalPrice = randomBuyPrice * qty;

      if (user.wallet < totalPrice) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Uang Di Saku Kamu Tidak Mencukupi Untuk Membeli Item Ini." }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        user.wallet -= totalPrice;
        user.inventory[itemKey] = (user.inventory[itemKey] || 0) + qty;
        writeDB(db);

        let response = `🛒 *ᴘᴜʀᴄʜᴀsᴇ sᴜᴄᴄᴇs*\n\n🛒 @${sender.split('@')[0]} Berhasil Membeli *${qty} ${itemConf.emoji} ${itemConf.name}* Dengan Total Pembayaran Sebesar *$${totalPrice}*!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // TRANSFER
    if (command === "transfer") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      const amountStr = args[1];

      if (!target || !amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user jumlah\`` }, { quoted: m });
      }

      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      if (cleanTarget === sender) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Kamu Tidak Bisa Mentransfer Uang Ke Dirimu Sendiri." }, { quoted: m });
      }

      const amount = parseInt(amountStr);
      const { db, user: senderData } = getUserData(from, sender);
      const { user: receiverData } = getUserData(from, cleanTarget);

      if (senderData.wallet < amount) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: "❌ Uang Di Saku Kamu Tidak Mencukupi Untuk Melakukan Transfer." }, { quoted: m });
      }

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        senderData.wallet -= amount;
        receiverData.wallet += amount;
        writeDB(db);

        let response = `💸 *ᴛʀᴀɴsғᴇʀ ᴍᴏɴᴇʏ sᴜᴄᴄᴇs*\n\n💸 @${sender.split('@')[0]} Berhasil Mentransfer Uang Kiriman Sebesar *$${amount}* Kepada Target @${cleanTarget.split('@')[0]}!`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: [sender, cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // LEADERBOARD
    if (command === "leaderboard" || command === "lb") {
      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const db = readDB();
        const guildData = db[from] || {};
        
        let sorted = Object.keys(guildData)
          .map(userId => ({ id: userId, level: guildData[userId].level || 0 }))
          .filter(u => u.level > 0)
          .sort((a, b) => b.level - a.level)
          .slice(0, 10);

        if (sorted.length === 0) {
          await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
          return await sock.sendMessage(from, { text: "❌ Belum ada data pengguna dengan level di atas 0." }, { quoted: m });
        }

        let mentions = [];
        let lbStr = sorted.map((u, index) => {
          let medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `🔹 *#${index + 1}*`;
          mentions.push(u.id);
          return `${medal} @${u.id.split('@')[0]} - *Level ${u.level}*`;
        }).join("\n");

        let response = `🏆 *ᴛᴏᴘ ʜɪɢʜ ʟᴇᴠᴇʟ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ*\n\nBerikut peringkat pengguna dengan level tertinggi:\n\n${lbStr}`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        await sock.sendMessage(from, { text: response, mentions: mentions }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
      return;
    }

    // ADMIN ADD MONEY
    if (command === "addmoney") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      const amountStr = args[1];
      if (!target || !amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user jumlah\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const amount = parseInt(amountStr);
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.wallet += amount;
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Menambahkan Uang Sebesar *$${amount}* Ke Saku @${cleanTarget.split('@')[0]}`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN TAKE MONEY
    if (command === "takemoney") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      const amountStr = args[1];
      if (!target || !amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user jumlah\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const amount = parseInt(amountStr);
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.wallet = Math.max(0, targetData.wallet - amount);
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Mengurangi Uang Saku @${cleanTarget.split('@')[0]} Sebesar *$${amount}*`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN CEK INVENTORY
    if (command === "cekinventory" || command === "cekinv") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { user: targetData } = getUserData(from, cleanTarget);
        let itemsStr = [];
        for (const [key, val] of Object.entries(targetData.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} *${shopItems[key]?.name || key}*: ${val} Buah`);
        }
        let response = `🎒 *ɪɴsᴘᴇᴄᴛ ɪɴᴠᴇɴᴛᴏʀʏ ʙᴀɢ ʙʏ ᴀᴅᴍɪɴ*\n\n🔍 Memeriksa isi tas milik: @${cleanTarget.split('@')[0]}\n\n${itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Member Ini Kosong."}`;
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: response, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN RESET MONEY
    if (command === "resetmoney") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.wallet = 0;
        targetData.bank = 0;
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Mereset Uang Dompet dan Bank @${cleanTarget.split('@')[0]} Menjadi *0*`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN RESET USER
    if (command === "resetuser") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { db } = getUserData(from, cleanTarget);
        db[from][cleanTarget] = {
          wallet: 0,
          bank: 0,
          lastWork: 0,
          lastDaily: 0,
          lastWeekly: 0,
          lastHunt: 0,
          lastFish: 0,
          lastMine: 0,
          workCooldown: 0,
          inventory: {},
          xp: 0,
          level: 1
        };
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Mereset Total Seluruh Data Pengguna @${cleanTarget.split('@')[0]} Kembali ke Awal`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN RESET INVENTORY
    if (command === "resetinventory" || command === "resetinv") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.inventory = {};
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Mengosongkan Dan Mereset Semua Isi Inventory Tas @${cleanTarget.split('@')[0]}`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN ADD LEVEL
    if (command === "addlevel") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      const amtStr = args[1];
      if (!target || !amtStr || isNaN(amtStr) || parseInt(amtStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user jumlah\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const val = parseInt(amtStr);
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.level += val;
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Menambahkan Level Pengguna @${cleanTarget.split('@')[0]} Sebanyak *+${val} Level*`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN TAKE LEVEL
    if (command === "takelevel") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      const amtStr = args[1];
      if (!target || !amtStr || isNaN(amtStr) || parseInt(amtStr) <= 0) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user jumlah\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const val = parseInt(amtStr);
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.level = Math.max(1, targetData.level - val);
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Mengurangi Level Pengguna @${cleanTarget.split('@')[0]} Sebanyak *-${val} Level*`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

    // ADMIN RESET LEVEL
    if (command === "resetlevel") {
      let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[0];
      if (!target) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @user\`` }, { quoted: m });
      }
      if (!target.includes('@')) target = target + '@s.whatsapp.net';
      const cleanTarget = target.replace(/:[0-9]+/g, '');

      await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
      try {
        const { db, user: targetData } = getUserData(from, cleanTarget);
        targetData.level = 1;
        targetData.xp = 0;
        writeDB(db);
        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        return await sock.sendMessage(from, { text: `✅ *Admin Action:* Berhasil Mereset Level Dan XP Pengguna @${cleanTarget.split('@')[0]} Kembali ke Level 1`, mentions: [cleanTarget] }, { quoted: m });
      } catch (err) {
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
      }
    }

  } catch (err) {
    console.error(err);
  }
};