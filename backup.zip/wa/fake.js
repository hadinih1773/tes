const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const from = jid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'fakecall' || command === 'fakecallwa') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text || !text.includes('|')) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { 
                    text: `❌ Format Salah : \`.${command}|nama|durasi\`\n📋 Reply Gambar Untuk Avatar` 
                }, { quoted: m });
            }

            const [nama, durasi] = text.split('|').map(s => s.trim());
            if (!nama) return;

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            let avatar = 'https://files.catbox.moe/nwvkbt.png';
            const q = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
            const isImage = q.imageMessage;

            if (isImage) {
                try {
                    const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
                    const stream = await downloadContentFromMessage(q.imageMessage, 'image');
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }

                    const form = new FormData();
                    form.append('file', buffer, { filename: 'avatar.jpg', contentType: 'image/jpeg' });
                    const uploadRes = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
                        headers: form.getHeaders(),
                        timeout: 30000
                    });
                    if (uploadRes.data?.data?.url) {
                        avatar = uploadRes.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
                    }
                } catch (e) {}
            } else {
                try {
                    avatar = await sock.profilePictureUrl(sender, 'image');
                } catch (e) {}
            }

            const apiUrl = `https://api.zenzxz.my.id/maker/fakecall?nama=${encodeURIComponent(nama)}&durasi=${encodeURIComponent(durasi)}&avatar=${encodeURIComponent(avatar)}`;
            
            await sock.sendMessage(from, { 
                image: { url: apiUrl }
            }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        }

        if (command === 'fakeff' || command === 'fakefreefire') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} nama\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                const apiUrl = `https://api.nexray.web.id/maker/fakelobyff?nickname=${encodeURIComponent(text)}`;
                
                await sock.sendMessage(from, { 
                    image: { url: apiUrl }
                }, { quoted: m });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (e) {
                console.error(e);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === 'fakeml' || command === 'mlbbfake' || command === 'mlcard' || command === 'mlfake') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { 
                    text: `❌ Format Salah : \`.${command} nama\`\n📋 Reply Gambar Untuk Avatar` 
                }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                let buffer;
                const q = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
                const isImage = q.imageMessage;

                if (isImage) {
                    const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
                    const stream = await downloadContentFromMessage(q.imageMessage, 'image');
                    buffer = Buffer.from([]);
                    for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                } else {
                    try {
                        let pfp = await sock.profilePictureUrl(sender, "image");
                        buffer = (await axios.get(pfp, { responseType: "arraybuffer" })).data;
                    } catch (e) {
                        buffer = Buffer.alloc(0); 
                    }
                }

                if (!buffer || buffer.length === 0) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: `❌ Kirim/reply gambar untuk dijadikan avatar!` }, { quoted: m });
                }

                const form = new FormData();
                form.append('file', buffer, { filename: 'avatar.jpg', contentType: 'image/jpeg' });
                const uploadRes = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
                    headers: form.getHeaders(),
                    timeout: 30000
                });

                if (uploadRes.data?.data?.url) {
                    const directUrl = uploadRes.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
                    const apiUrl = `https://api.nexray.web.id/maker/fakelobyml?avatar=${encodeURIComponent(directUrl)}&nickname=${encodeURIComponent(text)}`;
                    
                    await sock.sendMessage(from, { 
                        image: { url: apiUrl }
                    }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                }
            } catch (error) {
                console.error(error);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
    } catch (err) {
        console.error(err);
    }
};