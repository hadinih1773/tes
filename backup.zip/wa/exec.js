const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");

const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");

function readDB(filePath) {
    if (!fs.existsSync(filePath)) return [];
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return [];
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // ================= VALIDASI PERINTAH ($) =================
        if (command !== '$') return;

        // ================= CEK HASIL AKSES OWNER =================
        const ownerData = readDB(ownerPath);
        const isOwner = ownerData.includes(sender);

        if (!isOwner) {
            return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
        }

        // ================= MENYUSUN TERTULIS COMMAND =================
        let commandToExec = text.trim();

        if (!commandToExec) {
            return sock.sendMessage(from, { text: "❌ Format Salah : `.$ command`" }, { quoted: m });
        }

        // ================= EKSEKUSI SHELL COMMAND =================
        exec(commandToExec, { timeout: 60000 }, (err, stdout, stderr) => {
            try {
                if (err) {
                    return sock.sendMessage(from, { text: `❌ *Error:* ${err.message}` }, { quoted: m });
                }
                if (stderr) {
                    return sock.sendMessage(from, { text: `⚠️ *Stderr:*\n\`\`\`${stderr}\`\`\`` }, { quoted: m });
                }
                if (!stdout) {
                    return sock.sendMessage(from, { text: "✅ Perintah berhasil dijalankan (tanpa output)." }, { quoted: m });
                }

                sock.sendMessage(from, { text: `📤 *Output:*\n\n\`\`\`${stdout}\`\`\`` }, { quoted: m });
            } catch (e) {
                sock.sendMessage(from, { text: `❌ Error:\n${e.message}` }, { quoted: m });
            }
        });

    } catch (e) {
        console.error("Exec Feature Error:", e);
        sock.sendMessage(jid, { text: `❌ Error:\n${e.message}` }, { quoted: m });
    }
};
