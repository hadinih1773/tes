const fs = require("fs");
const path = require("path");

const selfPath = path.join(__dirname, "../databasewa/selfwa.json");
const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");
const adminPath = path.join(__dirname, "../databasewa/adminwa.json");
const sewaPath = path.join(__dirname, "../databasewa/sewawa.json");

function readDB(filePath) {
    if (!fs.existsSync(filePath)) return [];
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return [];
    }
}

function readObjectDB(filePath) {
    if (!fs.existsSync(filePath)) return {};
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return {};
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        
        // Mengambil body asli untuk pengecekan prefix
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';
        
        const ownerData = readDB(ownerPath);
        const adminData = readDB(adminPath);
        const selfData = readObjectDB(selfPath);
        const sewaData = readDB(sewaPath);
        
        const isOwner = ownerData.includes(sender);
        const isAdmin = adminData.includes(sender);

        // Fitur Blokir Japri (Logika Lama)
        if (!isGroup && body.startsWith('.') && !isOwner && !isAdmin) {
            if (selfData.onlyGC === true) {
                const replyMsg = `🚫 @${sender.split('@')[0]} Jangan Gunakan Command Di Chat Pribadi Bot, Atau Tidak ID Mu Akan Di Ban. 🚷 Gunakan Command Bot Di Grup Chat \nhttps://chat.whatsapp.com/BGK4F2cOZBKFTSsUyonQIT 😡. Terimakasih 😁`;
                await sock.sendMessage(from, { text: replyMsg, mentions: [sender] });

                const notifyMsg = `🚫 Terdeteksi Member Yang Melakukan Command Di Chat Pribadi @${sender.split('@')[0]} Dengan ID ${sender} 🛡`;
                for (let ownerJid of ownerData) {
                    await sock.sendMessage(ownerJid, { text: notifyMsg, mentions: [sender] });
                }
            }
        }

        // Fitur Cek Sewa Grup (Fitur Baru - Diperbaiki)
        if (isGroup && body.startsWith('.') && !isOwner) {
            const excludedGroup = "120363407314023936@g.us";
            if (from !== excludedGroup) {
                // Perbaikan: Mengecek string atau object dalam array
                const isSewa = sewaData.some(item => {
                    if (typeof item === 'string') return item === from;
                    if (typeof item === 'object' && item !== null) return item.id === from;
                    return false;
                });

                if (!isSewa) {
                    const sewaMsg = `🚫 Grup Ini Tidak Termasuk Kedalam Daftar Sewa. Jadi, Semua Member Tidak Bisa Menggunakan Command Bot 😞. Sewa Ke Onwer Untuk Menggunakan Fitur Bot wa.me/6282311544652 😅. Terima Kasih 👋.`;
                    await sock.sendMessage(from, { text: sewaMsg });
                }
            }
        }

    } catch (err) {
        console.error("Notif Error: ", err);
    }
};