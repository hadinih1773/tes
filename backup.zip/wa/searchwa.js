const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const yts = require("yt-search");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const from = jid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'npms' || command === 'npmsearch' || command === 'npmjs' || command === 'npmfind') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });

            try {
                const res = await axios.get(`https://registry.npmjs.com/-/v1/search?text=${encodeURIComponent(text)}&size=10`);
                const data = res.data;

                if (!data.objects || data.objects.length === 0) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: `❌ *ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ*\n\n> Package "${text}" tidak ditemukan` }, { quoted: m });
                }

                let resultText = `📦 *ɴᴘᴍ sᴇᴀʀᴄʜ*\n\n`;
                resultText += `> Query: \`${text}\`\n`;
                resultText += `> Found: ${data.total} packages\n\n`;

                data.objects.slice(0, 8).forEach((item, i) => {
                    const pkg = item.package;
                    const score = Math.round((item.score?.final || 0) * 100);

                    resultText += `${i + 1}. *${pkg.name}*\n`;
                    resultText += `> 📌 v${pkg.version}\n`;
                    if (pkg.description) {
                        resultText += `> 📝 ${pkg.description.slice(0, 50)}${pkg.description.length > 50 ? '...' : ''}\n`;
                    }
                    resultText += `> 🔗 ${pkg.links?.npm || '-'}\n`;
                    if (pkg.author?.name) {
                        resultText += `> 👤 ${pkg.author.name}\n`;
                    }
                    resultText += `> ⭐ Score: ${score}%\n\n`;
                });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(from, { text: resultText.trim() }, { quoted: m });

            } catch (e) {
                console.error(e);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === 'play' || command === 'playaudio') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });

            try {
                const search = await yts(text);
                if (!search.videos.length) throw "Video tidak ditemukan";
                
                const video = search.videos[0];
                const { data } = await axios.get(`https://api.nexray.web.id/downloader/ytmp3?url=${video.url}`);
        
                await sock.sendMessage(from, {
                    audio: { url: data?.result.url },
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: video.title + '.mp3',
                    contextInfo: {
                        forwardingScore: 9,
                        isForwarded: true,
                        externalAdReply: {
                            title: video.title,
                            body: `Selamat menikmati musiknya`,
                            mediaType: 2,
                            mediaUrl: video.url,
                            sourceUrl: video.url,
                            thumbnailUrl: video.thumbnail,
                            showAdAttribution: false,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

            } catch (err) {
                console.error('[Play]', err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                await sock.sendMessage(from, { text: `❌ Gagal Putar Musik` }, { quoted: m });
            }
        }
    } catch (err) {
        console.error(err);
    }
};