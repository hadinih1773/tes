const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");
const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");
const adminPath = path.join(__dirname, "../databasewa/adminwa.json");
const antiDbPath = path.join(__dirname, "../databasewa/antiwa.json");

// Inisialisasi antiwa.json jika belum ada
if (!fs.existsSync(antiDbPath)) {
    fs.writeFileSync(antiDbPath, JSON.stringify({ antitagsw: [], antilink: [], antikasar: [], autotyping: [] }, null, 2));
}

const daftarKataKasar = ["anjing", "babi", "bangsat", "goblok", "kontol", "memek", "ngentot", "ngentod", "anj", "jembut", "peler", "pler", "pantek", "ngentid", "puki", "pepek", "ppk", "lonte"];

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        const sender = m.key.participant || m.key.remoteJid;
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';

        // Cek Registrasi User
        const userDb = JSON.parse(fs.readFileSync(userPath));
        if (!userDb.includes(sender)) return;

        // Cek Admin & Owner
        const adminDb = JSON.parse(fs.readFileSync(adminPath));
        const ownerDb = JSON.parse(fs.readFileSync(ownerPath));
        const isAdmin = adminDb.includes(sender) || ownerDb.includes(sender);

        const antiDb = JSON.parse(fs.readFileSync(antiDbPath));

        // Auto Typing Logic
        if (antiDb.autotyping && antiDb.autotyping.includes(from)) {
            await sock.sendPresenceUpdate('composing', from);
        }

        // Fungsi Ambil Foto Profil
        const sendWithPfp = async (jid, text) => {
            let ppUrl;
            try {
                ppUrl = await sock.profilePictureUrl(jid, 'image');
            } catch {
                ppUrl = 'https://telegra.ph/file/0a711fce09d0acc593926.jpg';
            }
            await sock.sendMessage(from, { image: { url: ppUrl }, caption: text, mentions: [jid] });
        };

        // 1. Logic Anti Tag Status/Story
        if (isGroup && antiDb.antitagsw.includes(from) && !isAdmin) {
            const contextInfo = m.message?.extendedTextMessage?.contextInfo || m.message[type]?.contextInfo;
            const externalAd = contextInfo?.externalAdReply;
            const isTagStatus = 
                contextInfo?.mentionedJid?.includes('status@broadcast') || 
                contextInfo?.remoteJid === 'status@broadcast' ||
                externalAd?.sourceType === 'Status' ||
                externalAd?.sourceType === 1 ||
                externalAd?.sourceId === 'status@broadcast';

            if (isTagStatus) {
                const kickMsg = `╭───• *KICK USER* •───
├⎆ Status: ✅ Success
├⎆ Name: @${sender.split('@')[0]}
├⎆ Pesan: Kamu Telah Menandai Story WhatsApp Di Grup. Kamu Akan Dikeluarkan

⟢ *ID*: ${sender}

⟢ 𝗗𝗮𝘁𝗲: ${new Date().toLocaleString()}

_Silahkan PM Owner Jika Ingin Kembali Masuk Ke Grup_`;
                
                await sendWithPfp(sender, kickMsg);
                await sock.sendMessage(from, { delete: m.key });
                await sock.groupParticipantsUpdate(from, [sender], 'remove');
                return;
            }
        }

        // 2. Logic Anti Link
        if (isGroup && antiDb.antilink.includes(from) && !isAdmin) {
            const linkGrup = /chat.whatsapp.com\/(?:invite\/)?([0-9a-zA-Z]{20,26})/i;
            const linkSaluran = /whatsapp.com\/channel\/([0-9a-zA-Z]{20,26})/i;
            if (linkGrup.test(body) || linkSaluran.test(body)) {
                const kickMsg = `╭───• *KICK USER* •───
├⎆ Status: ✅ Success
├⎆ Name: @${sender.split('@')[0]}
├⎆ Pesan: Kamu Telah Mengirimkan Link Grup dan Saluran Lain. Kamu Akan Dikeluarkan

⟢ *ID*: ${sender}

⟢ 𝗗𝗮𝘁𝗲: ${new Date().toLocaleString()}

_Silahkan PM Owner Jika Ingin Kembali Masuk Ke Grup_`;

                await sendWithPfp(sender, kickMsg);
                await sock.sendMessage(from, { delete: m.key });
                await sock.groupParticipantsUpdate(from, [sender], 'remove');
                return;
            }
        }

        // Logic Anti Kasar
        if (isGroup && antiDb.antikasar && antiDb.antikasar.includes(from) && !isAdmin) {
            const containsKasar = daftarKataKasar.some(kasar => body.toLowerCase().includes(kasar));

            if (containsKasar) {
                const warnMsg = `╭───• *WARNING USER* •───
├⎆ Status: ✅ Success
├⎆ Name: @${sender.split('@')[0]}
├⎆ Pesan: Jangan Berkata Kasar, Anda Bisa Dikeluarkan

⟢ *ID*: ${sender}

⟢ 𝗗𝗮𝘁𝗲: ${new Date().toLocaleString()}

_Jaga Ketikan Anda Dan Jangan Lupa Lihat Rules_`;

                await sendWithPfp(sender, warnMsg);
                await sock.sendMessage(from, { delete: m.key });
                return;
            }
        }

        // 3. Command Section
        if (command === 'antitagsw') {
            if (!isAdmin) return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            const opt = args[0]?.toLowerCase();
            if (opt !== 'on' && opt !== 'off') return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                if (opt === 'on') {
                    if (!antiDb.antitagsw.includes(from)) antiDb.antitagsw.push(from);
                } else {
                    antiDb.antitagsw = antiDb.antitagsw.filter(id => id !== from);
                }
                fs.writeFileSync(antiDbPath, JSON.stringify(antiDb, null, 2));
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: `✅ Antitagsw Berhasil Diatur ke ${opt}` }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === 'antilink') {
            if (!isAdmin) return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            const opt = args[0]?.toLowerCase();
            if (opt !== 'on' && opt !== 'off') return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                if (opt === 'on') {
                    if (!antiDb.antilink.includes(from)) antiDb.antilink.push(from);
                } else {
                    antiDb.antilink = antiDb.antilink.filter(id => id !== from);
                }
                fs.writeFileSync(antiDbPath, JSON.stringify(antiDb, null, 2));
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: `✅ Antilink Berhasil Diatur ke ${opt}` }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === 'antikasar') {
            if (!isAdmin) return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            const opt = args[0]?.toLowerCase();
            if (opt !== 'on' && opt !== 'off') return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                if (opt === 'on') {
                    if (!antiDb.antikasar) antiDb.antikasar = [];
                    if (!antiDb.antikasar.includes(from)) antiDb.antikasar.push(from);
                } else {
                    antiDb.antikasar = antiDb.antikasar?.filter(id => id !== from) || [];
                }
                fs.writeFileSync(antiDbPath, JSON.stringify(antiDb, null, 2));
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: `✅ Antikasar Berhasil Diatur ke ${opt}` }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === 'autotyping') {
            if (!isAdmin) return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            const opt = args[0]?.toLowerCase();
            if (opt !== 'on' && opt !== 'off') return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                if (!antiDb.autotyping) antiDb.autotyping = [];
                if (opt === 'on') {
                    if (!antiDb.autotyping.includes(from)) antiDb.autotyping.push(from);
                } else {
                    antiDb.autotyping = antiDb.autotyping.filter(id => id !== from);
                }
                fs.writeFileSync(antiDbPath, JSON.stringify(antiDb, null, 2));
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: `✅ Autotyping Berhasil Diatur ke ${opt}` }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === 'settings') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const statusTag = antiDb.antitagsw.includes(from) ? "✅" : "❌";
                const statusLink = antiDb.antilink.includes(from) ? "✅" : "❌";
                const statusKasar = antiDb.antikasar?.includes(from) ? "✅" : "❌";
                const statusTyping = antiDb.autotyping?.includes(from) ? "✅" : "❌";
                const setMsg = `╭───• *MENU ANTI GRUP* •───
├⎆ Antitagsw : ${statusTag}
├⎆ Antilink : ${statusLink}
├⎆ Antikasar : ${statusKasar}
├⎆ Autonotifjapri : ✅
├⎆ Autotyping : ${statusTyping}

⟢ *ID GRUP*: ${from}

⟢ 𝗗𝗮𝘁𝗲: ${new Date().toLocaleString()}

_Hati-Hati Dalam Bertindak, Atau Kamu Akan Ditindak_`;
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: setMsg }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

    } catch (err) {
        console.error(err);
    }
};