const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        if (command !== 'txt2qr') return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Cek Registrasi User
        if (fs.existsSync(userDbPath)) {
            const userDb = JSON.parse(fs.readFileSync(userDbPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

        const q = text?.trim();
        if (!q) {
            await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks\`` }, { quoted: m });
        }

        try {
            const url = `https://api-faa.my.id/faa/qr-create?text=${encodeURIComponent(q)}`;
            const res = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: 30000
            });

            await sock.sendMessage(from, {
                image: Buffer.from(res.data),
                caption: `📱 *Qʀ ᴄᴏᴅᴇ*\n\n> ${q.substring(0, 100)}${q.length > 100 ? '...' : ''}`
            }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

        } catch (error) {
            await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            await sock.sendMessage(from, { text: `❌ Gagal membuat QR Code.` }, { quoted: m });
        }

    } catch (err) {
        console.error('Txt2Qr Error:', err);
    }
};