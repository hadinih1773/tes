const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { uploadToTmpFiles } = require('../lib/tmpfiles.js');
const { obfuscate: luaObfuscate } = require('../lib/enc.js');

// Inisialisasi database memory temporary jika belum ada
if (!global.db_obf) global.db_obf = {};

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        
        const from = jid;
        const type = Object.keys(m.message)[0];
        const sender = m.key.participant || m.key.remoteJid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Cek Registrasi User
        if (fs.existsSync(userDbPath)) {
            const userDb = JSON.parse(fs.readFileSync(userDbPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        // 1. LOGIKA RESPONS TOMBOL / BUTTON RESPONSE
        let buttonId = '';
        if (type === 'buttonsResponseMessage') {
            buttonId = m.message.buttonsResponseMessage.selectedButtonId;
        } else if (type === 'interactiveResponseMessage') {
            const paramsJson = m.message.interactiveResponseMessage.nativeFlowResponse.paramsJson;
            buttonId = JSON.parse(paramsJson).id;
        } else if (m.message.templateButtonReplyMessage) {
            buttonId = m.message.templateButtonReplyMessage.selectedId;
        }

        if (buttonId && (buttonId.startsWith('obf_wearedevs|') || buttonId.startsWith('obf_luaobfuscator|'))) {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            // Memecah parameter aman: [tipe_obf, targetMessageId, fileName]
            const [obfType, targetMessageId, savedFileName] = buttonId.split('|');

            // Ambil data pesan utuh yang sudah kita amankan di database global memory
            const savedMessage = global.db_obf[targetMessageId];
            if (!savedMessage) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                throw new Error("Sesi tombol kedaluwarsa, silakan kirim ulang perintah .obf");
            }

            try {
                // Tentukan target objek untuk didownload secara presisi dari memory cache
                const cacheMain = savedMessage.message?.ephemeralMessage?.message || 
                                  savedMessage.message?.viewOnceMessage?.message || 
                                  savedMessage.message?.viewOnceMessageV2?.message || 
                                  savedMessage.message;

                const cacheQuotedInfo = cacheMain?.extendedTextMessage?.contextInfo;
                
                let messageToDownload;
                if (cacheMain?.documentMessage) {
                    messageToDownload = savedMessage; // Jika kirim file langsung
                } else {
                    messageToDownload = { message: cacheQuotedInfo?.quotedMessage }; // Jika lewat reply
                }

                const bufferData = await downloadMediaMessage(
                    messageToDownload,
                    'buffer',
                    {},
                    { 
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );

                const originalCode = bufferData.toString('utf-8');
                const originalSize = Buffer.byteLength(originalCode, 'utf8');

                let obfuscatedCode = '';

                // Eksekusi Berdasarkan Tombol Pilihan
                if (obfType === "obf_wearedevs") {
                    obfuscatedCode = await luaObfuscate(originalCode);
                } else if (obfType === "obf_luaobfuscator") {
                    const sessionResponse = await axios.post('https://api.luaobfuscator.com/v1/obfuscator/newscript', originalCode, {
                        headers: { 'content-type': 'text', 'apikey': '2eacf7f3-840f-e5a9-dba4-ca117effd02b2b07' },
                        timeout: 0
                    });

                    const sessionId = sessionResponse.data.sessionId;
                    if (!sessionId) throw new Error("Gagal membuat session ID dari LuaObfuscator");

                    const apiResponse = await axios.post('https://api.luaobfuscator.com/v1/obfuscator/obfuscate', {
                        MinifiyAll: true,
                        Virtualize: true
                    }, {
                        headers: {
                            'content-type': 'application/json',
                            'apikey': '2eacf7f3-840f-e5a9-dba4-ca117effd02b2b07',
                            'sessionId': sessionId
                        },
                        timeout: 0
                    });

                    obfuscatedCode = apiResponse.data.code;
                }

                if (!obfuscatedCode) throw new Error("Gagal mendapatkan kode dari API Obfuscator");

                const obfuscatedSize = Buffer.byteLength(obfuscatedCode, 'utf8');
                const bufferObf = Buffer.from(obfuscatedCode, 'utf8');
                const newFileName = `Obfuscated_${savedFileName}`;

                // Upload ke TmpFiles
                const uploadResult = await uploadToTmpFiles(bufferObf, {
                    filename: newFileName,
                    contentType: "text/plain"
                });

                const caption = `✅ *Obfuscator File Succesful*\n\n` +
                    `👤 *User Request* : @${sender.split('@')[0]}\n` +
                    `📁 *File Name* : ${savedFileName}\n` +
                    `📦 *Original Size* : ${(originalSize / 1024).toFixed(2)} KB\n` +
                    `📮 *Obfuscated Size* : ${(obfuscatedSize / 1024).toFixed(2)} KB\n` +
                    `🔗 *Link* : ${uploadResult.directUrl}`;

                // Kirim notifikasi ke grup/chat asal
                await sock.sendMessage(from, {
                    text: `@${sender.split('@')[0]} Silahkan Cek DM Dari Bot!! Terima Kasih\n\n${caption}`,
                    mentions: [sender]
                }, { quoted: m });

                // Kirim Dokumen Hasil langsung ke nomor DM user (sender)
                await sock.sendMessage(sender, {
                    document: bufferObf,
                    fileName: newFileName,
                    mimetype: "text/plain",
                    caption: `@${sender.split('@')[0]} File Telah Sukses Di Obfuscate. Silahkan Di Cek Dibawah Ini.`,
                    mentions: [sender]
                });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

                // Hapus pesan command asli milik user (Pesan menu interaktif tidak dihapus sesuai perintah)
                if (targetMessageId) {
                    await sock.sendMessage(from, {
                        delete: { remoteJid: from, fromMe: false, id: targetMessageId, participant: sender }
                    }).catch(() => {});
                }

                // Bersihkan data memory agar tidak menumpuk RAM
                delete global.db_obf[targetMessageId];
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                console.error(err);
            }
            return;
        }

        // 2. LOGIKA UTAMA JALANNYA COMMAND AWAL
        if (command !== 'obf') return;

        // Antisipasi pembungkus pesan (ephemeral/viewOnce) pada pesan utama
        const mainMessage = m.message?.ephemeralMessage?.message || 
                            m.message?.viewOnceMessage?.message || 
                            m.message?.viewOnceMessageV2?.message || 
                            m.message;

        // Ambil pesan yang berisi dokumen (langsung atau reply)
        const quotedInfo = mainMessage?.extendedTextMessage?.contextInfo;
        const quoted = quotedInfo?.quotedMessage?.ephemeralMessage?.message || 
                       quotedInfo?.quotedMessage?.viewOnceMessage?.message || 
                       quotedInfo?.quotedMessage?.viewOnceMessageV2?.message || 
                       quotedInfo?.quotedMessage;
        
        const msgDoc = mainMessage?.documentMessage || quoted?.documentMessage;

        if (!msgDoc || (!msgDoc.fileName.endsWith('.lua') && !msgDoc.fileName.endsWith('.txt'))) {
            return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} reply file\`` }, { quoted: m });
        }

        // Amankan objek pesan `m` secara utuh ke global memory database dengan ID pesan sebagai kuncinya
        global.db_obf[m.key.id] = m;

        // Menyiapkan Menu Pilihan Button Interactive menggunakan pemisah "|" agar payload aman terbaca lengkap
        const buttons = [
            {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: 'WeAreDevs',
                    id: `obf_wearedevs|${m.key.id}|${msgDoc.fileName}`
                })
            },
            {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Lua Obfuscator',
                    id: `obf_luaobfuscator|${m.key.id}|${msgDoc.fileName}`
                })
            }
        ];

        const msgMenu = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: "Ada 2 Tipe Obfuscator, Silahkan Dipilih Yang Diinginkan\n\n1. WeAreDevs\n2. Lua Obfuscator" },
                        footer: { text: "Pilih salah satu di bawah" },
                        header: { hasVideoMessage: false },
                        nativeFlowMessage: {
                            buttons: buttons
                        },
                        contextInfo: {
                            quotedMessage: m.message,
                            participant: sender,
                            remoteJid: from,
                            stanzaId: m.key.id
                        }
                    }
                }
            }
        };

        await sock.relayMessage(from, msgMenu, {});

    } catch (error) {
        console.error(error);
        await sock.sendMessage(jid, { text: `❌ Error: ${error.message}` }, { quoted: m });
    }
};