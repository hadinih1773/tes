const fs = require('fs');
const path = require('path');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        // Lokasi folder relatif dari folder 'wa' ke root
        const pathsToDelete = [
            path.join(__dirname, '../.cache')
        ];

        pathsToDelete.forEach(targetPath => {
            if (fs.existsSync(targetPath)) {
                const files = fs.readdirSync(targetPath);
                for (const file of files) {
                    const curPath = path.join(targetPath, file);
                    if (fs.lstatSync(curPath).isDirectory()) {
                        // Hapus folder secara rekursif
                        fs.rmSync(curPath, { recursive: true, force: true });
                    } else {
                        // Hapus file
                        fs.unlinkSync(curPath);
                    }
                }
            }
        });
    } catch (err) {
        // Silent Error
    }
};
