const fs = require("fs");
const path = require("path");
const axios = require("axios");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

// Fungsi pembantu untuk jeda (delay)
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = async (sock, m, { jid, text, command, args: args_from_listener }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : '';

        // Menggunakan pemisah '|' sesuai logika kode awal
        const args = body.trim().split('|');
        const cmd = args[0].toLowerCase();

        // Cek Registrasi User (Silent)
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
        if (!userDb.includes(sender)) return;

        // HANDLER CEK WEBHOOK
        if (cmd === ".cekwebhook") {
            const webhookUrl = args[1]?.trim();
            if (!webhookUrl) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`${cmd}|url\`` }, { quoted: m });
            }

            // Reaction awal
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                const response = await axios.get(webhookUrl);
                const data = response.data;
                const successText = `*Cheking Webhook Succesful*
*Status* : Aktif ✅
*Name* : ${data.name || "N/A"}
*Channel ID* : ${data.channel_id || "N/A"}
*Guild ID* : ${data.guild_id || "N/A"}
*Webhook ID* : ${data.id || "N/A"}`;
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: successText }, { quoted: m });
            } catch (err) {
                const failText = `*Cheking Webhook Successful*
*Status* : Tidak Aktif ❌
*Note* : Sepertinya Url Webhook Sudah Dihapus`;
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: failText }, { quoted: m });
            }
        }

        // HANDLER SPAM WEBHOOK
        if (cmd === ".spamwebhook") {
            const webhookUrl = args[1]?.trim();
            const message = args[2]?.trim();
            const amount = parseInt(args[3]);

            if (!webhookUrl || !message || isNaN(amount)) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`${cmd}|url|pesan|jumlah\`` }, { quoted: m });
            }

            // Validasi Maksimal 500 Pesan
            if (amount > 500) {
                return sock.sendMessage(from, { text: "❌ Maksimal Jumlah Pesan Hanya 500" }, { quoted: m });
            }

            // PROSES CEK WEBHOOK SEBELUM SPAM
            try {
                await axios.get(webhookUrl);
            } catch (err) {
                const failText = `*Cheking Webhook Successful*
*Status* : Tidak Aktif ❌
*Note* : Sepertinya Url Webhook Sudah Dihapus`;
                return sock.sendMessage(from, { text: failText }, { quoted: m });
            }

            // Jika aktif, lanjut ke spam
            // Reaction awal
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                for (let x = 0; x < amount; x++) {
                    try {
                        await axios.post(webhookUrl, {
                            content: message,
                            username: "Captcha Hook"
                        });
                        // Jeda 1 detik (1000ms) per pesan
                        await sleep(1000); 
                    } catch (err) {
                        console.error("Webhook Error:", err.message);
                        // Jika terkena rate limit (429), jeda otomatis 5 detik agar tidak mati total
                        if (err.response && err.response.status === 429) {
                            await sleep(5000);
                        }
                    }
                }

                // Reaction berhasil dan kirim pesan konfirmasi
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: `✅ Berhasil mengirim pesan ke webhook` }, { quoted: m });
            } catch (error) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

    } catch (err) {
        // Silent Error
    }
};