const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");

const idch = "120363424062451116@newsletter";
const isNumber = (x) => (x = parseInt(x), typeof x === 'number' && !isNaN(x));

function getRandomHexColor() {
    return "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
}

const userPath = path.join(__dirname, '../databasewa/userwa.json');
const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        if (!isGroup) return;

        const sender = (m.key.participant || m.key.remoteJid).replace(/:[0-9]+/g, '');

        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        if (!userDb.map(v => v.replace(/:[0-9]+/g, '')).includes(sender)) return;

        const ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));
        const isOwner = ownerDb.some(v => v.replace(/:[0-9]+/g, '') === sender);
        const isMainOwner = ownerDb[0].replace(/:[0-9]+/g, '') === sender;

        const type = Object.keys(m.message)[0];

        const commands = ['setppbot', 'setnamebot', 'setswbot', 'delppbot', 'setbiobot', 'join', 'leavegc', 'restart', 'revoke', 'spamwa', 'linkgc', 'addowner', 'delowner'];
        
        if (commands.includes(command) && !isOwner) {
            await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            return;
        }

        if ((command === 'addowner' || command === 'delowner') && !isMainOwner) {
            await sock.sendMessage(from, { text: '❌ Hanya Owner Utama Yang Bisa Menggunakan' }, { quoted: m });
            return;
        }

        if (!isOwner) return;

        if (command === 'addowner') {
            let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant || args[0];
            if (!target) return await sock.sendMessage(from, { text: '❌ Format Salah : `.addowner @tag/reply/id`' }, { quoted: m });
            if (!target.includes('@')) target = target + '@s.whatsapp.net';
            if (ownerDb.includes(target)) return await sock.sendMessage(from, { text: '❌ Nomor tersebut sudah menjadi owner' }, { quoted: m });
            ownerDb.push(target);
            fs.writeFileSync(ownerPath, JSON.stringify(ownerDb, null, 2));
            await sock.sendMessage(from, { text: `✅ Berhasil menambah ${target} sebagai owner` }, { quoted: m });
        }

        if (command === 'delowner') {
            let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant || args[0];
            if (!target) return await sock.sendMessage(from, { text: '❌ Format Salah : `.delowner @tag/reply/id`' }, { quoted: m });
            if (!target.includes('@')) target = target + '@s.whatsapp.net';
            if (target === ownerDb[0]) return await sock.sendMessage(from, { text: '❌ Tidak dapat menghapus Owner Utama' }, { quoted: m });
            if (!ownerDb.includes(target)) return await sock.sendMessage(from, { text: '❌ Nomor tersebut bukan owner' }, { quoted: m });
            const index = ownerDb.indexOf(target);
            ownerDb.splice(index, 1);
            fs.writeFileSync(ownerPath, JSON.stringify(ownerDb, null, 2));
            await sock.sendMessage(from, { text: `✅ Berhasil menghapus ${target} dari list owner` }, { quoted: m });
        }

        if (command === 'setppbot') {
            const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
            const isImage = type === 'imageMessage' || (quoted && quoted.imageMessage);
            if (isImage) {
                const msgImage = quoted ? quoted.imageMessage : m.message.imageMessage;
                const stream = await downloadContentFromMessage(msgImage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                await sock.updateProfilePicture(sock.user.id, buffer);
                await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
            } else {
                await sock.sendMessage(from, { text: '❌ Format Salah : ⚠️ Kirim/Reply Gambar' }, { quoted: m });
            }
        }

        if (command === 'setnamebot') {
            if (!text) return await sock.sendMessage(from, { text: '❌ Format Salah : `.setnamebot namanya`' }, { quoted: m });
            await sock.updateProfileName(text);
            await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
        }

        if (command === 'setswbot') {
            const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
            const groupMetadata = await sock.groupMetadata(from).catch(() => ({ participants: [] }));
            const participants = groupMetadata.participants.map(p => p.id);
            const statusOptions = {
                backgroundColor: getRandomHexColor(),
                font: Math.floor(Math.random() * 9),
                statusJidList: participants,
                annotations: [{
                    polygonVertices: [{ x: 0.0563, y: 0.1531 }, { x: 0.9437, y: 0.1531 }, { x: 0.9437, y: 0.8459 }, { x: 0.0563, y: 0.8459 }],
                    newsletter: { newsletterJid: idch, serverMessageId: null, newsletterName: "Hady Community", contentType: "UPDATE_CARD" }
                }]
            };
            if (type === 'imageMessage' || (quoted && quoted.imageMessage)) {
                const msg = quoted ? quoted.imageMessage : m.message.imageMessage;
                const stream = await downloadContentFromMessage(msg, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                await sock.sendMessage('status@broadcast', { image: buffer, caption: text || '' }, statusOptions);
                await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
            } else if (type === 'videoMessage' || (quoted && quoted.videoMessage)) {
                const msg = quoted ? quoted.videoMessage : m.message.videoMessage;
                const stream = await downloadContentFromMessage(msg, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                await sock.sendMessage('status@broadcast', { video: buffer, caption: text || '' }, statusOptions);
                await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
            } else if (text) {
                await sock.sendMessage('status@broadcast', { text: text }, statusOptions);
                await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
            } else {
                await sock.sendMessage(from, { text: '❌ Format Salah : `.setswbot teks / reply gambar dan video`' }, { quoted: m });
            }
        }

        if (command === 'delppbot') {
            await sock.removeProfilePicture(sock.user.id);
            await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
        }

        if (command === 'setbiobot') {
            if (!text) return await sock.sendMessage(from, { text: '❌ Format Salah : `.setbiobot bio`' }, { quoted: m });
            await sock.updateProfileStatus(text);
            await sock.sendMessage(from, { text: 'Succes ✅' }, { quoted: m });
        }

        if (command === 'join') {
            let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})( [0-9]{1,3})?/i;
            let [_, code, expired] = text.match(linkRegex) || [];
            if (!code) return await sock.sendMessage(from, { text: '❌ Format Salah : `.join link grup`' }, { quoted: m });
            try {
                let res = await sock.groupAcceptInvite(code);
                expired = Math.floor(Math.max(1, isOwner ? (isNumber(expired) ? parseInt(expired) : 0) : 3));
                await sock.sendMessage(from, { text: `✅ Berhasil join grup ${res}${expired ? ` selama ${expired} hari\n\nJika grup menggunakan persetujuan admin, silahkan ACC nomor ini` : ''}` }, { quoted: m });
            } catch (error) {
                if (error?.message?.includes('not-authorized')) {
                    return await sock.sendMessage(from, { text: '❌ Tidak dapat bergabung karena sebelumnya terkena kick' }, { quoted: m });
                }
                console.error(error);
            }
        }

        if (command === 'revoke') {
            try {
                let rest = await sock.groupRevokeInvite(from);
                await sock.sendMessage(from, { text: 'https://chat.whatsapp.com/' + rest }, { quoted: m });
            } catch (error) {
                await sock.sendMessage(from, { text: '❌ Gagal revoke link grup (Pastikan Bot Admin)' }, { quoted: m });
            }
        }

        if (command === 'spamwa') {
            // Karena listener sudah memecah text berdasarkan '|', kita gunakan args langsung
            let nomor = args[0];
            let pesan = args[1];
            let jumlah = args[2];

            if (!nomor || !pesan) return await sock.sendMessage(from, { text: '❌ Format Salah : `.spamwa nomor|pesan|jumlah`' }, { quoted: m });
            
            let fixedNumber = nomor.replace(/[-+<>@]/g, '').replace(/ +/g, '').replace(/^[0]/g, '62') + '@s.whatsapp.net';
            let fixedJumlah = jumlah ? parseInt(jumlah) : 10;
            
            await sock.sendMessage(from, { text: `✅ Spam Sukses Ke Nomor Tujuan\nEstimated Sent All *${fixedJumlah}*` }, { quoted: m });

            for (let i = 0; i < fixedJumlah; i++) {
                let teksPesan = `${pesan.trim()}\n\n[${i + 1}/${fixedJumlah}]`;
                await sock.relayMessage(fixedNumber, { extendedTextMessage: { text: teksPesan } }, {});
            }
        }

        if (command === 'linkgc') {
            try {
                let metadata = await sock.groupMetadata(from);
                let code = await sock.groupInviteCode(from);
                let teks = `> — ( *${metadata.subject}* )\n> ( *${metadata.id}* )\n> https://chat.whatsapp.com/${code}\n${metadata.desc || ""}`;
                await sock.sendMessage(from, { text: teks }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { text: '❌ Gagal mengambil link (Pastikan Bot Admin)' }, { quoted: m });
            }
        }

        if (command === 'leavegc') {
            await sock.sendMessage(from, { text: 'Sayonaraaa 👋' });
            await sock.groupLeave(from);
        }

        if (command === 'restart') {
            await sock.sendMessage(from, { text: 'Restarting bot... 🔄' }, { quoted: m });
            setTimeout(() => { process.exit(); }, 1000);
        }

    } catch (err) {
        console.error(err);
    }
};