const fs = require('fs');
const path = require('path');

const userPath = path.join(__dirname, '../databasewa/userwa.json');
const adminPath = path.join(__dirname, '../databasewa/adminwa.json');
const reportDbPath = path.join(__dirname, '../databasewa/reportwa.json');

// Inisialisasi Database Report
if (!fs.existsSync(reportDbPath)) {
    fs.writeFileSync(reportDbPath, JSON.stringify([], null, 2));
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Cek Registrasi User
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath));
        if (!userDb.includes(sender)) return;

        // Load Database Lain
        const adminDb = JSON.parse(fs.readFileSync(adminPath));
        let reportDb = JSON.parse(fs.readFileSync(reportDbPath));

        // --- LOGIC REPORT & ASK ---
        if (command === 'report' || command === 'ask') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            if (!text) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks\`` }, { quoted: m });
            }

            // Ambil Foto Profil
            let pp_user;
            try {
                pp_user = await sock.profilePictureUrl(sender, 'image');
            } catch {
                pp_user = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg';
            }

            const dateStr = new Date().toLocaleString();
            const title = command === 'report' ? 'REPORT MEMBER' : 'ASK MEMBER';

            const msgToAdmin = `╭───• *${title}* •───
├⎆ Member : @${sender.split('@')[0]}
├⎆ Ask/Report : ${text}

⟢ *ID*: ${sender}

⟢ 𝗗𝗮𝘁𝗲: ${dateStr}

_Reply Pesan Ini Untuk Menjawab Dengan Command \`.ans\`_`;

            const reportGroupId = Math.random().toString(36).substring(7);

            // Kirim ke semua admin
            for (let admin of adminDb) {
                const sent = await sock.sendMessage(admin, { 
                    image: { url: pp_user }, 
                    caption: msgToAdmin, 
                    mentions: [sender] 
                });

                // Simpan data pesan
                reportDb.push({
                    reportMsgId: sent.key.id,
                    reportGroupId: reportGroupId,
                    userJid: sender,
                    userFrom: from,
                    reportText: text,
                    status: 'pending'
                });
            }
            
            fs.writeFileSync(reportDbPath, JSON.stringify(reportDb, null, 2));
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return sock.sendMessage(from, { text: `✅ Berhasil mengirim ${command} ke admin.` }, { quoted: m });
        }

        // --- LOGIC ANSWER (.ans) ---
        if (command === 'ans') {
            if (!adminDb.includes(sender)) return;
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedId = m.message?.extendedTextMessage?.contextInfo?.stanzaId;

            if (!quoted || !quotedId) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: '⚠️ Reply Pesan Report' }, { quoted: m });
            }
            if (!text) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} jawaban\`` }, { quoted: m });
            }

            const reportIndex = reportDb.findIndex(r => r.reportMsgId === quotedId);
            
            if (reportIndex === -1) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: '⚠️ Ask/Report Ini Sudah Di Jawab Oleh Admin Lainnya' }, { quoted: m });
            }
            
            const data = reportDb[reportIndex];
            const currentGroupId = data.reportGroupId;
            const dateStr = new Date().toLocaleString();

            // Ambil Foto Profil Admin yang Menjawab
            let pp_admin;
            try {
                pp_admin = await sock.profilePictureUrl(sender, 'image');
            } catch {
                pp_admin = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg';
            }

            const msgToUser = `╭───• *ANSWER ADMIN* •───
├⎆ Admin : @${sender.split('@')[0]}
├⎆ Ask/Report : ${data.reportText}
├⎆ Answer : ${text}

⟢ *ID*: ${sender}

⟢ 𝗗𝗮𝘁𝗲: ${dateStr}

_Terima Kasih Telah Melaporkan Masalah Tersebut_`;

            // Kirim jawaban ke chat pribadi member
            await sock.sendMessage(data.userJid, { 
                image: { url: pp_admin },
                caption: msgToUser, 
                mentions: [sender] 
            });

            // Hapus SEMUA pesan yang terkait dengan grup laporan ini
            const filteredReport = reportDb.filter(r => r.reportGroupId !== currentGroupId);
            fs.writeFileSync(reportDbPath, JSON.stringify(filteredReport, null, 2));

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return sock.sendMessage(from, { text: '✅ Jawaban berhasil terkirim ke member.' }, { quoted: m });
        }

    } catch (err) {
        console.error(err);
    }
};