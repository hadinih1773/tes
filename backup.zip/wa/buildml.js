const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'buildml') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text) {
                return await sock.sendMessage(from, { text: '❌ Format Salah : `.buildml nama hero`' }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                const { data } = await axios.get(
                    `https://api.apocalypse.web.id/search/buildml?hero=${encodeURIComponent(text)}`
                );

                const heroes = data.builds;
                if (!heroes || !heroes.length) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: "❌ Build tidak ditemukan" }, { quoted: m });
                }

                const pickRandom = heroes[Math.floor(Math.random() * heroes.length)];
                const title = pickRandom.title;

                const itemnya = pickRandom.items?.map(v => {
                    return `*ITEM NYA*
🌿 \`Nama\`: ${v.name}
🔮 \`Tipe\`: ${v.type}
💵 \`Harga\`: ${v.price}

*STATS*
🚧 \`Magic Power\`: ${v.stats?.magic_power || "-"}
👻 \`Movement Speed\`: ${v.stats?.movement_speed || "-"}
🎗️ \`Magic Penetration\`: ${v.stats?.magic_penetration || "-"}

*PASSIVE*
${v.passive_description || "-"}`;
                }).join("\n\n");

                const hasilPesan = `*BUILD ${text.toUpperCase()}*

🍯 *Title*
${title}

${itemnya}`;

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(from, { text: hasilPesan }, { quoted: m });

            } catch (error) {
                console.error('BuildML Error:', error);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                // Karena 'te' memerlukan context khusus dari template lama, kita kirim pesan error manual sesuai fungsionalitas aslinya
                await sock.sendMessage(from, { text: `❌ Terjadi kesalahan saat mengambil data build hero.` }, { quoted: m });
            }
        }
    } catch (err) {
        console.error(err);
    }
};