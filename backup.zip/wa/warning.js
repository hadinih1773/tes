const fs = require("fs");
const path = require("path");

const userFile = path.join(__dirname, "../databasewa/userwa.json");
const adminFile = path.join(__dirname, "../databasewa/adminwa.json");
const ownerFile = path.join(__dirname, "../databasewa/ownerwa.json");
const warningFile = path.join(__dirname, "../databasewa/warning.json");
const banFile = path.join(__dirname, "../databasewa/banuser.json");

// Pastikan file database ada
if (!fs.existsSync(warningFile)) {
    fs.writeFileSync(warningFile, JSON.stringify({ warnings: {}, maxWarnings: 3 }, null, 2));
}
if (!fs.existsSync(banFile)) {
    fs.writeFileSync(banFile, JSON.stringify([], null, 2));
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        if (!isGroup) return;

        const sender = m.key.participant || m.key.remoteJid;

        // CEK USER DAFTAR
        if (!fs.existsSync(userFile)) return;
        const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
        if (!userDb.includes(sender)) return;

        // AMBIL DATA ADMIN & OWNER & DATABASE WARNING
        if (!fs.existsSync(adminFile)) return;
        const adminDb = JSON.parse(fs.readFileSync(adminFile, "utf8"));
        
        if (!fs.existsSync(ownerFile)) return;
        const ownerDb = JSON.parse(fs.readFileSync(ownerFile, "utf8"));

        let dbWarning = JSON.parse(fs.readFileSync(warningFile, "utf8"));

        // CEK STATUS ADMIN
        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;
        const groupAdmins = participants.filter(p => p.admin !== null).map(p => p.id);
        const isAdmins = groupAdmins.includes(sender);
        const isAdminBot = adminDb.includes(sender);

        // =====================================================
        //                COMMAND .warn
        // =====================================================
        if (command === "warn") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            
            let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
            if (!target && args.length > 0) target = args[0].replace('@', '') + '@s.whatsapp.net';

            if (!target) return sock.sendMessage(from, { text: "❌ Format Salah : `.warn @tag/reply pesan`" }, { quoted: m });

            // CEK JIKA TARGET ADALAH OWNER
            if (ownerDb.includes(target)) {
                return sock.sendMessage(from, { 
                    text: `❌ @${sender.split('@')[0]} Tidak Bisa Memberikan Warning Kepada @${target.split('@')[0]} Owner Bro 😎`,
                    mentions: [sender, target]
                }, { quoted: m });
            }

            const groupId = from;
            if (!dbWarning.warnings[groupId]) dbWarning.warnings[groupId] = {};
            if (!dbWarning.warnings[groupId][target]) dbWarning.warnings[groupId][target] = 0;

            dbWarning.warnings[groupId][target] += 1;
            const currentWarn = dbWarning.warnings[groupId][target];
            const maxWarn = dbWarning.maxWarnings;

            if (currentWarn >= maxWarn) {
                await sock.sendMessage(from, { 
                    text: `👋 @${target.split('@')[0]} Telah Mencapai Batas Warning. Anda Diban Dari Bot 🚫`,
                    mentions: [target]
                }, { quoted: m });

                let banDb = JSON.parse(fs.readFileSync(banFile, "utf8"));
                if (!banDb.includes(target)) {
                    banDb.push(target);
                    fs.writeFileSync(banFile, JSON.stringify(banDb, null, 2));
                }

                delete dbWarning.warnings[groupId][target];
            } else {
                await sock.sendMessage(from, { 
                    text: `⚠️ @${sender.split('@')[0]} Telah Memberikan ${currentWarn}/${maxWarn} Warning Kepada @${target.split('@')[0]} 🚫`,
                    mentions: [sender, target]
                }, { quoted: m });
            }
            fs.writeFileSync(warningFile, JSON.stringify(dbWarning, null, 2));
        }

        // =====================================================
        //                COMMAND .unwarn
        // =====================================================
        if (command === "unwarn") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });

            let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
            if (!target && args.length > 0) target = args[0].replace('@', '') + '@s.whatsapp.net';

            if (!target) return sock.sendMessage(from, { text: "❌ Format Salah : `.unwarn @tag/reply pesan`" }, { quoted: m });

            const groupId = from;
            if (!dbWarning.warnings[groupId] || !dbWarning.warnings[groupId][target]) {
                return sock.sendMessage(from, { text: "❌ Pengguna Tidak Memiliki Warning" }, { quoted: m });
            }

            dbWarning.warnings[groupId][target] -= 1;
            const currentWarn = dbWarning.warnings[groupId][target];
            const maxWarn = dbWarning.maxWarnings;

            if (dbWarning.warnings[groupId][target] <= 0) {
                delete dbWarning.warnings[groupId][target];
            }

            await sock.sendMessage(from, { 
                text: `🤗 @${sender.split('@')[0]} Telah Mengurangi Warning Member @${target.split('@')[0]} Menjadi ${currentWarn}/${maxWarn} 🥳`,
                mentions: [sender, target]
            }, { quoted: m });
            fs.writeFileSync(warningFile, JSON.stringify(dbWarning, null, 2));
        }

        // =====================================================
        //                COMMAND .clearwarn
        // =====================================================
        if (command === "clearwarn") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });

            let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
            if (!target && args.length > 0) target = args[0].replace('@', '') + '@s.whatsapp.net';

            if (!target) return sock.sendMessage(from, { text: "❌ Format Salah : `.clearwarn @tag/reply pesan`" }, { quoted: m });

            const groupId = from;
            if (dbWarning.warnings[groupId] && dbWarning.warnings[groupId][target]) {
                delete dbWarning.warnings[groupId][target];
                fs.writeFileSync(warningFile, JSON.stringify(dbWarning, null, 2));
            }

            await sock.sendMessage(from, { 
                text: `🥳 @${sender.split('@')[0]} Telah Menghapus Semua Warning @${target.split('@')[0]} 🎉`,
                mentions: [sender, target]
            }, { quoted: m });
        }

        // =====================================================
        //                COMMAND .cekwarn
        // =====================================================
        if (command === "cekwarn") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });

            let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
            if (!target && args.length > 0) target = args[0].replace('@', '') + '@s.whatsapp.net';

            if (!target) return sock.sendMessage(from, { text: "❌ Format Salah : `.cekwarn @tag/reply pesan`" }, { quoted: m });

            const groupId = from;
            const targetWarn = dbWarning.warnings[groupId]?.[target] || 0;
            const maxWarn = dbWarning.maxWarnings;

            await sock.sendMessage(from, { 
                text: `🚫 Warning @${target.split('@')[0]} Sebanyak ${targetWarn}/${maxWarn} 😱`,
                mentions: [target]
            }, { quoted: m });
        }

        // =====================================================
        //                COMMAND .mywarn
        // =====================================================
        if (command === "mywarn") {
            const groupId = from;
            const myWarn = dbWarning.warnings[groupId]?.[sender] || 0;
            const maxWarn = dbWarning.maxWarnings;
            await sock.sendMessage(from, { 
                text: `🚫 Warning Kamu Di grup Ini Sebanyak ${myWarn}/${maxWarn} 😱`,
                mentions: [sender]
            }, { quoted: m });
        }

        // =====================================================
        //                COMMAND .setmaxwarnings
        // =====================================================
        if (command === "setmaxwarnings") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            const jumlah = parseInt(args[0]);

            if (isNaN(jumlah)) return sock.sendMessage(from, { text: "❌ Format Salah : `.setmaxwarnings jumlah`" }, { quoted: m });

            dbWarning.maxWarnings = jumlah;
            fs.writeFileSync(warningFile, JSON.stringify(dbWarning, null, 2));
            await sock.sendMessage(from, { text: `✅ Berhasil Mengubah Max Warning Menjadi ${dbWarning.maxWarnings}` }, { quoted: m });
        }

        // =====================================================
        //                COMMAND .maxwarnings
        // =====================================================
        if (command === "maxwarnings") {
            await sock.sendMessage(from, { text: `📋 Max Warning Saat Ini Adalah ${dbWarning.maxWarnings}` }, { quoted: m });
        }

    } catch (err) {
        console.error(err);
    }
};