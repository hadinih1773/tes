const fs = require('fs');
const path = require('path');

const stickyFile = path.join(__dirname, "../databasewa/stickywa.json");

// Load data awal
let stickyData = {};
if (fs.existsSync(stickyFile)) {
    try {
        stickyData = JSON.parse(fs.readFileSync(stickyFile, "utf8"));
    } catch (e) {
        stickyData = {};
    }
}

function saveSticky() {
    fs.writeFileSync(stickyFile, JSON.stringify(stickyData, null, 2));
}

module.exports = async (sock, m, { jid, command, text, args }) => {
    try {
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const parseJid = (id) => id.replace(/:[0-9]+/g, '');
        const senderClean = parseJid(sender);

        // Path database izin
        const adminPath = path.join(__dirname, "../databasewa/adminwa.json");
        const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");
        const adminData = fs.existsSync(adminPath) ? JSON.parse(fs.readFileSync(adminPath, "utf-8")) : [];
        const ownerData = fs.existsSync(ownerPath) ? JSON.parse(fs.readFileSync(ownerPath, "utf-8")) : [];

        const isAdmin = adminData.some(v => parseJid(v) === senderClean);
        const isOwner = ownerData.some(v => parseJid(v) === senderClean);

        // ===== AUTO UPDATE STICKY (Akan jalan setiap ada pesan masuk) =====
        // Ditambahkan delay 6 detik agar tidak spam
        if (!command && stickyData[from] && !m.key.fromMe) {
            const s = stickyData[from];
            
            setTimeout(async () => {
                const newMsg = await sock.sendMessage(from, { text: s.content });
                stickyData[from].lastMsgId = newMsg.key.id;
                saveSticky();
            }, 6000); // 6000ms = 6 detik
        }

        // ===== COMMAND STICKY =====
        if (command === 'sticky') {
            if (!isAdmin && !isOwner) {
                return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            }

            const teksSticky = text.split('|')[1]?.trim() || text.trim();
            if (!teksSticky || teksSticky === command) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.sticky|teks\`` }, { quoted: m });
            }

            // Kirim pesan sticky pertama kali
            const msg = await sock.sendMessage(from, { text: teksSticky });
            
            stickyData[from] = {
                content: teksSticky,
                lastMsgId: msg.key.id
            };

            saveSticky();
            await sock.sendMessage(from, { text: "✅ Sticky message berhasil diaktifkan di grup ini." }, { quoted: m });
        }

        // ===== COMMAND UNSTICKY =====
        if (command === 'unsticky') {
            if (!isAdmin && !isOwner) {
                return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            }

            if (!stickyData[from]) {
                return await sock.sendMessage(from, { text: "❌ Tidak ada sticky di grup ini." }, { quoted: m });
            }

            delete stickyData[from];
            saveSticky();
            await sock.sendMessage(from, { text: "✅ Sticky message berhasil dihapus!" }, { quoted: m });
        }

    } catch (err) {
        console.error('Error di sticky.js:', err);
    }
};