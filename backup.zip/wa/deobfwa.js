const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

const OBFUSCATOR_SIGNATURES = {
  "obfuscator.com": [
    /local\s+[A-Za-z_]+\s*=\s*\{[^\}]{200,\}}/i,
    /-- Obfuscated by obfuscator\.com/i,
    /loadstring\(.*base64.*\)/i,
    /local\s+[a-zA-Z_]+\s*=\s*"[A-Za-z0-9+/=]{100,}"/i,
    /\bLuaObfuscator\b/i
  ],
  "Prometheus / MoonSec v3": [
    /-- Prometheus/i,
    /-- MoonSec/i,
    /local\s+[a-z]+\s*=\s*\{\s*\[1\]\s*=/i,
    /xor_key/i,
    /string\.byte.*string\.char.*for.*do/i,
    /\bMoonSecurity\b/i,
    /moonsec/i
  ],
  "Yasu": [
    /-- Yasu/i,
    /YASU/i,
    /local\s+[A-Z_]{5,}\s*=\s*\{/i,
    /rawget.*rawset/i,
    /getfenv\(\)/i,
    /setfenv\(/i
  ]
};

function detectObfuscator(content) {
  for (const [name, patterns] of Object.entries(OBFUSCATOR_SIGNATURES)) {
    let score = 0;
    for (const pattern of patterns) {
      if (pattern.test(content)) score++;
    }
    if (score >= 1) return name;
  }
  return "Unknown / Plain Lua";
}

function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Cek Registrasi User
        if (fs.existsSync(userDbPath)) {
            const userDb = JSON.parse(fs.readFileSync(userDbPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        if (command !== 'deobf') return;

        // Antisipasi pembungkus pesan (ephemeral/viewOnce) pada pesan utama
        const mainMessage = m.message?.ephemeralMessage?.message || 
                            m.message?.viewOnceMessage?.message || 
                            m.message?.viewOnceMessageV2?.message || 
                            m.message;

        // Ambil pesan yang berisi dokumen (langsung atau reply)
        const quotedInfo = mainMessage?.extendedTextMessage?.contextInfo;
        const quoted = quotedInfo?.quotedMessage?.ephemeralMessage?.message || 
                       quotedInfo?.quotedMessage?.viewOnceMessage?.message || 
                       quotedInfo?.quotedMessage?.viewOnceMessageV2?.message || 
                       quotedInfo?.quotedMessage;
        
        const msgDoc = mainMessage?.documentMessage || quoted?.documentMessage;

        if (!msgDoc || (!msgDoc.fileName.endsWith('.lua') && !msgDoc.fileName.endsWith('.txt'))) {
            return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} kirim/reply file\`` }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

        try {
            let messageToDownload;
            if (mainMessage?.documentMessage) {
                messageToDownload = m; // Jika kirim file langsung
            } else {
                messageToDownload = { message: quotedInfo?.quotedMessage }; // Jika lewat reply
            }

            const bufferData = await downloadMediaMessage(
                messageToDownload,
                'buffer',
                {},
                { 
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            const fileContentText = bufferData.toString('utf-8');
            const detectedType = detectObfuscator(fileContentText);
            const savedFileName = msgDoc.fileName;

            // Setup Multipart Form Data untuk API POST upload file
            const form = new FormData();
            form.append("file", bufferData, {
                filename: savedFileName,
                contentType: "text/plain"
            });

            // Request Menggunakan Skema Retry Percobaan (Max 3 Kali)
            let apiResponse;
            let lastError = null;

            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    apiResponse = await axios.post("https://tw8rev-deobfuscator.vercel.app/api/deobfuscate", form, {
                        headers: {
                            ...form.getHeaders()
                        },
                        timeout: 90000
                    });
                    lastError = null;
                    break;
                } catch (err) {
                    lastError = err;
                }
            }

            if (lastError) {
                throw new Error(`Koneksi API Gagal setelah 3 kali percobaan: ${lastError.message}`);
            }

            const data = apiResponse.data;

            if (data && (data.success || data.result)) {
                const resultClean = data.result || data.deobfuscated || "";
                const finalCodeOutput = resultClean;

                // Aturan penamaan file output
                const fileExtension = path.extname(savedFileName);
                const baseName = path.basename(savedFileName, fileExtension);
                const outputFileName = `${baseName}_deobfuscator${fileExtension}`;

                const outputBuffer = Buffer.from(finalCodeOutput, "utf-8");
                const fileSizeFormatted = formatBytes(outputBuffer.length);

                const caption = `✅ *Deobfuscate File Successful*\n\n` +
                    `👤 *User Request*\n@${sender.split('@')[0]}\n` +
                    `📁 *File Name*\n${outputFileName}\n` +
                    `📦 *Size File*\n${fileSizeFormatted}`;

                // Kirim Dokumen Hasil langsung ke grup/chat asal (from) dengan caption yang sesuai
                await sock.sendMessage(from, {
                    document: outputBuffer,
                    fileName: outputFileName,
                    mimetype: "text/plain",
                    caption: caption,
                    mentions: [sender]
                }, { quoted: m });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } else {
                throw new Error(data.result || "Struktur data respons dari API mengembalikan nilai gagal.");
            }

        } catch (err) {
            await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            console.error(err);
            await sock.sendMessage(from, { text: `❌ Deobfuscate Failed\n\n${err.message}` }, { quoted: m });
        }

    } catch (error) {
        console.error(error);
        await sock.sendMessage(jid, { text: `❌ Error: ${error.message}` }, { quoted: m });
    }
};