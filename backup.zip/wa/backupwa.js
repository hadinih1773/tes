const fs = require("fs");
const path = require("path");
const archiver = require("archiver");

// Jalur file database
const ownerFile = path.resolve(__dirname, "../databasewa/ownerwa.json");
const userFile = path.resolve(__dirname, "../databasewa/userwa.json");
const backupConfigFile = path.resolve(__dirname, "../databasewa/backupwa.json");
const backupDir = path.resolve(__dirname, "../sampah");

// Inisialisasi Database
if (!fs.existsSync(path.dirname(backupConfigFile))) fs.mkdirSync(path.dirname(backupConfigFile), { recursive: true });
if (!fs.existsSync(backupConfigFile)) {
    fs.writeFileSync(backupConfigFile, JSON.stringify({ groups: [], backupDelay: 300000, active: false }, null, 2));
}

let config = JSON.parse(fs.readFileSync(backupConfigFile, "utf8"));
let backupInterval = null;

// Helper untuk format ukuran file
const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const handleBackup = async (sock, jid) => {
    // --- HAPUS ISI FOLDER SAMPAH SEBELUM MULAI ---
    if (fs.existsSync(backupDir)) {
        fs.rmSync(backupDir, { recursive: true, force: true });
    }
    fs.mkdirSync(backupDir, { recursive: true });
    // ---------------------------------------------

    const date = new Date();
    const folderName = `backup_${date.getTime()}`;
    const folderPath = path.join(backupDir, folderName);
    
    if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });

    const zipFile = path.join(folderPath, "backup.zip");
    const output = fs.createWriteStream(zipFile);
    const archive = archiver("zip", { zlib: { level: 9 } });

    let fileCount = 0;

    try {
        archive.pipe(output);
        const excluded = [
            "node_modules",
            ".npm",
            ".cache",
            ".git",
            ".DS_Store",
            "thumbs.db",
            "desktop.ini",
            ".upm",
            "session",
            "assets",
            "sampah",
            "jadibot-session",
            ".replit"
        ];

        const addFiles = (dir, base = "") => {
            const items = fs.readdirSync(dir);
            for (const item of items) {
                const fullPath = path.join(dir, item);
                const relativePath = path.join(base, item);
                if (excluded.includes(item) || excluded.some(ex => item.startsWith(ex))) continue;
                if (fs.statSync(fullPath).isDirectory()) addFiles(fullPath, relativePath);
                else {
                    archive.file(fullPath, { name: relativePath });
                    fileCount++;
                }
            }
        };

        addFiles(process.cwd());
        await archive.finalize();

        await new Promise((resolve) => output.on("close", resolve));

        // Kirim ke JID tujuan
        await sock.sendMessage(jid, { 
            document: fs.readFileSync(zipFile), 
            mimetype: "application/zip", 
            fileName: `Backup_${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}_${String(date.getHours()).padStart(2, "0")}-${String(date.getMinutes()).padStart(2, "0")}.zip`,
            caption: `📦 *Backup Selesai*`
        });

        const totalBytes = archive.pointer();

        // HAPUS FOLDER BACKUP SPESIFIK SETELAH KIRIM
        try {
            fs.rmSync(folderPath, { recursive: true, force: true });
            console.log(`🗑️ Backup dihapus: ${folderName}`);
        } catch (err) {
            console.error("⚠️ Gagal menghapus folder backup:", err);
        }

        return { fileCount, totalBytes };
    } catch (err) {
        console.error("❌ Gagal backup:", err);
        if (fs.existsSync(folderPath)) fs.rmSync(folderPath, { recursive: true, force: true });
        throw err;
    }
};

const startAutoBackup = (sock) => {
    if (backupInterval) clearInterval(backupInterval);
    if (config.active && config.groups.length > 0) {
        backupInterval = setInterval(() => {
            config.groups.forEach(jid => handleBackup(sock, jid).catch(() => {}));
        }, config.backupDelay);
    }
};

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Start autobackup if active on first message
        if (config.active && !backupInterval) startAutoBackup(sock);

        // Guard Clause: Hanya respon command yang ada di file ini
        const validCommands = ["backup", "autobackup", "settimebackup"];
        if (!validCommands.includes(command)) return;

        // Cek ID Spesifik
        if (sender !== "73577453879303@lid") {
            return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
        }

        if (command === "backup") {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const { fileCount, totalBytes } = await handleBackup(sock, sender);

                const senderName = m.pushName || sender.split("@")[0];

                const captionMessage = 
                    `✅ *Backup Script Successful*\n\n` +
                    `📦 *Backup File*\n\`\`\`backup.zip\`\`\`\n\n` +
                    `📂 *Total Files*\n\`\`\`${fileCount}\`\`\`\n\n` +
                    `🏷 *File Size*\n\`\`\`${formatBytes(totalBytes)}\`\`\`\n\n` +
                    `📌 *Status Backup*\n\`\`\`File Backup Berhasil Dikirim Ke DM Owner\`\`\`\n\n` +
                    `By ${senderName}`;

                await sock.sendMessage(from, { text: captionMessage }, { quoted: m });
                return await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                return await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        if (command === "autobackup") {
            const action = args[0];
            if (!action) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });
            }
            
            if (action === "on") {
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    config.active = true;
                    if (!config.groups.includes(from)) config.groups.push(from);
                    fs.writeFileSync(backupConfigFile, JSON.stringify(config, null, 2));
                    startAutoBackup(sock);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return sock.sendMessage(from, { text: "✅ Autobackup Aktif untuk grup ini." }, { quoted: m });
                } catch (err) {
                    return await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } else if (action === "off") {
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    config.active = false;
                    config.groups = [];
                    fs.writeFileSync(backupConfigFile, JSON.stringify(config, null, 2));
                    if (backupInterval) clearInterval(backupInterval);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return sock.sendMessage(from, { text: "🗑️ Autobackup Dinonaktifkan & Data dihapus." }, { quoted: m });
                } catch (err) {
                    return await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } else {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });
            }
        }

        if (command === "settimebackup") {
            const timeArg = args[0];
            if (!timeArg) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} time\`` }, { quoted: m });
            }
            
            const match = timeArg.match(/^(\d+)([smh])$/);
            if (!match) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} time\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const value = parseInt(match[1]);
                const unit = match[2];
                let ms = value * 1000;
                if (unit === "m") ms = value * 60 * 1000;
                if (unit === "h") ms = value * 60 * 60 * 1000;

                config.backupDelay = ms;
                fs.writeFileSync(backupConfigFile, JSON.stringify(config, null, 2));
                if (config.active) startAutoBackup(sock);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: `✅ Interval backup diatur ke ${value}${unit.toUpperCase()}.` }, { quoted: m });
            } catch (err) {
                return await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
    } catch (err) {
        console.error("Error in backup module:", err);
    }
};