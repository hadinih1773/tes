const fs = require('fs');
const path = require('path');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        if (command !== 'intro') return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Cek Registrasi User
        if (fs.existsSync(userDbPath)) {
            const userDb = JSON.parse(fs.readFileSync(userDbPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        // Waiting bot reaction
        await sock.sendMessage(from, { react: { text: "🙋", key: m.key } });

        const introMsg = `*[ ✨ INTRODUCE YOURSELF ✨ ]*
Kenalan Dulu Yok
* Nama :
* Umur :
* Asal Daerah :
* Hobi :
* Cita-cita :
* Single : Ya/No
* Note :`;

        await sock.sendMessage(from, { text: introMsg }, { quoted: m });

    } catch (err) {
        console.error('Intro Error:', err);
    }
};