const os = require("os");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'ping') {
            const userDb = JSON.parse(fs.readFileSync(userPath));
            if (!userDb.includes(sender)) return;

            await sock.sendMessage(from, { react: { text: "📡", key: m.key } });

            // Latency Speed Test
            const start = Date.now();
            await new Promise(r => setTimeout(r, 10)); // Delay kecil untuk kalkulasi real
            const pingValue = Date.now() - start; // Diubah ke milidetik (ms)

            // Info OS Akurat
            let osDistro = "Ubuntu 25.04";
            try {
                osDistro = execSync('lsb_release -ds').toString().replace(/"/g, "").trim();
            } catch (e) {
                osDistro = `${os.type()} ${os.release()}`;
            }

            // RAM Logic
            const totalRam = (os.totalmem() / (1024 ** 3)).toFixed(0);
            const usedRam = (process.memoryUsage().rss / (1024 ** 2)).toFixed(2);

            // Penyimpanan (Disk Usage)
            let diskTotal = "0", diskUsed = "0", diskFree = "0", diskPercent = "0";
            try {
                const df = execSync('df -h / --output=size,used,avail,pcent').toString().split('\n')[1].split(/\s+/);
                diskTotal = df[1]; diskUsed = df[2]; diskFree = df[3]; diskPercent = df[4];
            } catch (e) { diskPercent = "0%"; }

            // CPU & Runtime
            const uptimeMin = Math.floor(process.uptime() / 60);
            const cpus = os.cpus();
            const times = cpus[0].times;
            const totalTicks = Object.values(times).reduce((acc, tv) => acc + tv, 0);
            const getPerc = (tick) => ((tick / totalTicks) * 100).toFixed(2);
            
            const usedP = parseInt(diskPercent);
            const freeP = 100 - usedP;

            // Format Tampilan Baru Sesuai Request
            const responseText = `📡 *JARINGAN SERVER*
- Ping: ${pingValue} ms

📣 *INFO SERVER*
- OS: ${osDistro}
- Type OS: ${os.type()}

⏱️ *RUNTIME SERVER*
Aktif:
${uptimeMin}m

🖨 *CPU USAGE (${cpus.length} CORE CPU)*
${cpus[0].model} (${cpus[0].speed} MHZ)
- *user* : ${getPerc(times.user)}%
- *nice* : ${getPerc(times.nice)}%
- *sys* : ${getPerc(times.sys)}%
- *idle* : ${getPerc(times.idle)}%
- *irq* : ${getPerc(times.irq)}%`;

            await sock.sendMessage(from, { 
                text: responseText 
            }, { quoted: m });
        }
    } catch (error) {
        console.error('Error in ping monitor:', error);
    }
};