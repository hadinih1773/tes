const fs = require("fs");
const path = require("path");

const selfPath = path.join(__dirname, "../databasewa/selfwa.json");
const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");
const userPath = path.join(__dirname, "../databasewa/userwa.json");
const adminPath = path.join(__dirname, "../databasewa/adminwa.json");

// Inisialisasi Database selfwa.json jika belum ada
if (!fs.existsSync(path.dirname(selfPath))) {
    fs.mkdirSync(path.dirname(selfPath), { recursive: true });
}

if (!fs.existsSync(selfPath)) {
    fs.writeFileSync(selfPath, JSON.stringify({ groupSelf: {}, onlyGC: false }, null, 2));
}

function readDB(filePath) {
    if (!fs.existsSync(filePath)) return [];
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return [];
    }
}

function writeDB(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // ================= CEK USER TERDAFTAR (SILENT) =================
        const userData = readDB(userPath);
        if (!userData.includes(sender)) return;

        const isGroup = from.endsWith('@g.us');
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';
        
        const ownerData = readDB(ownerPath);
        const adminData = readDB(adminPath);
        
        const isOwner = ownerData.includes(sender);
        const isAdmin = adminData.includes(sender);
        let selfDB = JSON.parse(fs.readFileSync(selfPath, "utf-8"));
        
        if (!selfDB.groupSelf) selfDB.groupSelf = {};

        // ================= COMMAND OWNER =================
        if (isOwner) {
            if (command === 'self') {
                selfDB.groupSelf[from] = true;
                writeDB(selfPath, selfDB);
                return sock.sendMessage(from, { text: "🚨 Bot Dalam Mode Self (Owner Only)" }, { quoted: m });
            }
            if (command === 'public') {
                selfDB.groupSelf[from] = false;
                writeDB(selfPath, selfDB);
                return sock.sendMessage(from, { text: "👤 Bot Sudah Bisa Digunakan Public" }, { quoted: m });
            }
            if (command === 'onlygc') {
                if (args[0] === 'on') {
                    selfDB.onlyGC = true;
                    writeDB(selfPath, selfDB);
                    return sock.sendMessage(from, { text: "🏢 Bot Hanya Bisa Digunakan Di Dalam Grup" }, { quoted: m });
                }
                if (args[0] === 'off') {
                    selfDB.onlyGC = false;
                    writeDB(selfPath, selfDB);
                    return sock.sendMessage(from, { text: "🔓 Bot Bisa Digunakan Di PM/Grup" }, { quoted: m });
                }
            }
        } else {
            if (body.startsWith('.')) {
                if (command === 'self' || command === 'public' || command === 'onlygc') {
                    return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
                }
            }
        }

        // ================= PROTEKSI MODE =================
        if (selfDB.groupSelf[from] === true && !isOwner) {
            delete m.message;
            return;
        }
        
        if (selfDB.onlyGC && !isGroup && !isOwner && !isAdmin) {
            delete m.message;
            return;
        }
    } catch (err) {
        console.error("Self Mode Error: ", err);
    }
};