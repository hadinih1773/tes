const { downloadContentFromMessage, getContentType } = require("@whiskeysockets/baileys");
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../databasewa/adminwa.json');
const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');
const userPath = path.join(__dirname, '../databasewa/userwa.json');
const banPath = path.join(__dirname, '../databasewa/banuser.json');

if (!fs.existsSync(path.join(__dirname, '../databasewa'))) {
    fs.mkdirSync(path.join(__dirname, '../databasewa'), { recursive: true });
}

if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([], null, 2));
if (!fs.existsSync(ownerPath)) fs.writeFileSync(ownerPath, JSON.stringify([], null, 2));
if (!fs.existsSync(userPath)) fs.writeFileSync(userPath, JSON.stringify([], null, 2));
if (!fs.existsSync(banPath)) fs.writeFileSync(banPath, JSON.stringify([], null, 2));

function readDB(filePath) {
    if (!fs.existsSync(filePath)) return [];
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return [];
    }
}

function writeDB(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message || !jid.endsWith('@g.us')) return;

        const from = jid;
        const type = getContentType(m.message);
        
        const sender = m.key.participant || m.key.remoteJid;

        const registeredUsers = readDB(userPath);
        if (!registeredUsers.includes(sender)) return; 

        const ownerDb = readDB(ownerPath);
        const adminDb = readDB(dbPath);
        const banDb = readDB(banPath);
        const isOwner = ownerDb.includes(sender);
        const isAdminBot = adminDb.includes(sender);

        if (banDb.includes(sender) && !isOwner) {
            m.message = null;
            return;
        }

        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;
        
        const groupAdmins = participants.filter(v => v.admin !== null).map(v => v.id);
        const isGroupAdmin = groupAdmins.includes(sender);

        // 1. .addadmin (Owner Only) - FIXED TAG & REPLY
        if (command === 'addadmin') {
            if (!isOwner) return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            
            let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (!target) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @tag/reply\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            if (!adminDb.includes(target)) {
                adminDb.push(target);
                writeDB(dbPath, adminDb);
            }
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Berhasil Menambah @${target.split('@')[0]} Sebagai Admin Bot`, mentions: [sender, target] }, { quoted: m });
        }

        // 2. .deladmin (Owner Only) - FIXED TAG & REPLY
        if (command === 'deladmin') {
            if (!isOwner) return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            
            let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (!target) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @tag/reply\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            if (adminDb.includes(target)) {
                adminDb.splice(adminDb.indexOf(target), 1);
                writeDB(dbPath, adminDb);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Menghapus @${target.split('@')[0]} Sebagai Admin Bot`, mentions: [sender, target] }, { quoted: m });
            } else {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ @${sender.split('@')[0]} User Tersebut Bukan Admin Bot`, mentions: [sender] }, { quoted: m });
            }
        }

        // .listadmin (Bisa digunakan semua member)
        if (command === 'listadmin') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            let teks = `🛡 List Admin Helper MD\n`;
            for (let x of adminDb) {
                teks += `➣ @${x.split('@')[0]}\n`;
            }
            teks += `\n🎉 List Admin Grup\n`;
            for (let g of groupAdmins) {
                teks += `➣ @${g.split('@')[0]}\n`;
            }
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return await sock.sendMessage(from, { text: teks.trim(), mentions: [...adminDb, ...groupAdmins] }, { quoted: m });
        }

        // --- PROTEKSI SEMUA COMMAND ADMIN ---
        const commandAdminList = ['ban', 'unban', 'pinchat', 'unpinchat', 'hidetag', 'h', 'kick', 'add', 'setppgc', 'setnamegc', 'setgc', 'tagall', 'setdescgc'];
        const isExecutingAdminCmd = commandAdminList.includes(command);
        
        if (isExecutingAdminCmd && !isAdminBot && !isOwner && !isGroupAdmin) {
            return await sock.sendMessage(from, { text: '❌ Hanya Bisa Digunakan Oleh Admin' }, { quoted: m });
        }

        // 3. .ban
        if (command === 'ban') {
            let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            if (!target && text) target = text;
            
            if (!target) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @tag/reply/id\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            if (!banDb.includes(target)) {
                banDb.push(target);
                writeDB(banPath, banDb);
            }
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            
            const targetTag = target.includes('@') ? `@${target.split('@')[0]}` : target;
            const mentionsArr = target.includes('@') ? [sender, target] : [sender];

            return await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Berhasil Membanned ${targetTag}`, mentions: mentionsArr }, { quoted: m });
        }

        // 4. .unban
        if (command === 'unban') {
            let target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            if (!target && text) target = text;

            if (!target) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @tag/reply/id\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const targetTag = target.includes('@') ? `@${target.split('@')[0]}` : target;
            const mentionsArr = target.includes('@') ? [sender, target] : [sender];

            if (banDb.includes(target)) {
                banDb.splice(banDb.indexOf(target), 1);
                writeDB(banPath, banDb);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Menghapus ${targetTag} Dari Daftar Banned`, mentions: mentionsArr }, { quoted: m });
            } else {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ @${sender.split('@')[0]} User Tersebut Tidak Dalam Daftar Ban`, mentions: mentionsArr }, { quoted: m });
            }
        }

        // 5. .pinchat
        if (command === 'pinchat') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            const context = m.message.extendedTextMessage?.contextInfo;
            try {
                if (context?.stanzaId) {
                    await sock.sendMessage(from, { pin: { remoteJid: from, fromMe: context.participant === sock.decodeJid(sock.user.id), id: context.stanzaId }, type: 1, time: 2592000 });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else if (text) {
                    const sent = await sock.sendMessage(from, { text: text });
                    await sock.sendMessage(from, { pin: sent.key, type: 1, time: 2592000 });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } catch (pinErr) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 6. .unpinchat
        if (command === 'unpinchat') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                await sock.sendMessage(from, { pin: { remoteJid: from, fromMe: false, id: m.key.id }, type: 0, time: 0 });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (unpinErr) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 7. .hidetag / .h
        if (command === 'hidetag' || command === 'h') {
            const quoted = m.message.extendedTextMessage?.contextInfo;
            const fallbackText = (
                quoted?.quotedMessage?.conversation ||
                quoted?.quotedMessage?.extendedTextMessage?.text ||
                quoted?.quotedMessage?.imageMessage?.caption ||
                quoted?.quotedMessage?.videoMessage?.caption ||
                ''
            ).trim();
            
            const msgText = text || fallbackText;
            
            if (!msgText) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const fkontak = {
                "key": {
                    "participants": "0@s.whatsapp.net",
                    "remoteJid": "status@broadcast",
                    "fromMe": false,
                    "id": "Halo"
                },
                "message": {
                    "contactMessage": {
                        "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
                    }
                },
                "participant": "0@s.whatsapp.net"
            };

            try {
                await sock.sendMessage(from, { text: msgText, mentions: participants.map(a => a.id) }, { quoted: fkontak });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (hideErr) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 8. .kick
        if (command === 'kick') {
            const target = m.message.extendedTextMessage?.contextInfo?.participant || m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            if (!target) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @tag/reply\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            await sock.groupParticipantsUpdate(from, [target], "remove")
                .asyncAndThen(async () => {
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Telah Mengeluarkan Member @${target.split('@')[0]}`, mentions: [sender, target] }, { quoted: m });
                })
                .catch(async (err) => {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    await sock.sendMessage(from, { text: '❌ Gagal Mengeluarkan Member. Pastikan Bot Adalah Admin Grup' }, { quoted: m });
                });
        }

        // 9. .add
        if (command === 'add') {
            try {
                let userJid;
                const quoted = m.message.extendedTextMessage?.contextInfo;

                if (quoted?.quotedMessage?.contactMessage) {
                    const vcard = quoted.quotedMessage.contactMessage.vcard;
                    const match = vcard?.match(/waid=(\d+)/);
                    if (match && match[1]) {
                        userJid = match[1] + '@s.whatsapp.net';
                    } else {
                        return await sock.sendMessage(from, { text: '❌ Tidak dapat mengekstrak nomor dari kontak yang direply' }, { quoted: m });
                    }
                } else if (text) {
                    userJid = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                } else {
                    return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} 628xx/reply kontak\`` }, { quoted: m });
                }

                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

                await sock.groupParticipantsUpdate(from, [userJid], 'add');
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Berhasil Menambahkan @${userJid.split('@')[0]} Ke Dalam Grup`, mentions: [sender, userJid] }, { quoted: m });
            } catch (e) {
                console.error('Error in add:', e);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                await sock.sendMessage(from, { text: '❌ Gagal menambahkan member' }, { quoted: m });
            }
        }

        // 10. .setppgc
        if (command === 'setppgc') {
            const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
            const isImage = type === 'imageMessage' || (quoted && quoted.imageMessage);
            if (isImage) {
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    const msgImage = quoted ? quoted.imageMessage : m.message.imageMessage;
                    const stream = await downloadContentFromMessage(msgImage, 'image');
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
                    await sock.updateProfilePicture(from, buffer);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Berhasil Mengubah Foto Profil Grup Ini`, mentions: [sender] }, { quoted: m });
                } catch (ppErr) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } else {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} reply/kirim gambar\`` }, { quoted: m });
            }
        }

        // 11. .setnamegc
        if (command === 'setnamegc') {
            if (!text) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} namegc\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                await sock.groupUpdateSubject(from, text);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Mengubah Nama Grup Menjadi ${text}`, mentions: [sender] }, { quoted: m });
            } catch (nameErr) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 12. .setgc
        if (command === 'setgc') {
            if (text === 'open') {
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    await sock.groupSettingUpdate(from, 'not_announcement');
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Telah Membuka Kembali Grup. Selamat Menikmati`, mentions: [sender] }, { quoted: m });
                } catch (gcErr) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } else if (text === 'close') {
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    await sock.groupSettingUpdate(from, 'announcement');
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Telah Menutup Grup. Jadi Mohon Bersabar dan Tunggu`, mentions: [sender] }, { quoted: m });
                } catch (gcErr) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } else {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} open/close\`` }, { quoted: m });
            }
        }

        // 13. .tagall
        if (command === 'tagall') {
            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            const pesan = text || 'Kosong';
            let teks = `📢 *Tag Everyone*\n📝 *Pesan :* ${pesan}\n\n`;
            for (let mem of participants) {
                teks += `📌 @${mem.id.split('@')[0]}\n`;
            }
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            await sock.sendMessage(from, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m });
        }

        // 14. .setdescgc
        if (command === 'setdescgc') {
            if (!text) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks\`` }, { quoted: m });
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                await sock.groupUpdateDescription(from, text);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(from, { text: `✅ @${sender.split('@')[0]} Berhasil Mengubah Deskripsi Grup Menjadi \n${text}`, mentions: [sender] }, { quoted: m });
            } catch (descErr) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

    } catch (err) {
        console.error(err);
    }
};