const yts = require("yt-search");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { generateWAMessageContent, generateWAMessageFromContent } = require("@whiskeysockets/baileys");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Cek Database User
        const userPath = path.join(__dirname, "../databasewa/userwa.json");
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath, "utf-8"));
        if (!userDb.includes(sender)) return;

        // Command .ytsearch
        if (command === 'ytsearch') {
            if (!text) return sock.sendMessage(from, { text: `❌ Format Salah : \`.ytsearch query\`` }, { quoted: m });

            try {
                await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });

                const query = text;
                let res = await yts(query);
                const rawVideos = res.all.filter(v => v.type === "video");
                if (!rawVideos.length) return sock.sendMessage(from, { text: "Tidak ditemukan hasil." }, { quoted: m });

                const videos = rawVideos.map(v => ({
                    title: v.title,
                    channel: v.author?.name || "-",
                    duration: v.timestamp || "0:00",
                    cover: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`,
                    url: v.url
                }));

                const rows = videos.slice(0, 10).flatMap(v => [
                    {
                        header: v.channel,
                        title: `📹 Video: ${v.title.length > 40 ? v.title.slice(0, 37) + "..." : v.title}`,
                        description: `⏱️ ${v.duration}`,
                        id: `.ytv ${v.url}`
                    },
                    {
                        header: v.channel,
                        title: `🎧 Audio: ${v.title.length > 40 ? v.title.slice(0, 37) + "..." : v.title}`,
                        description: `⏱️ ${v.duration}`,
                        id: `.yta ${v.url}`
                    }
                ]);

                const media = await generateWAMessageContent({ image: { url: videos[0].cover } }, { upload: sock.waUploadToServer });

                const interactiveMessage = {
                    body: { text: `🎬 *Hasil pencarian YouTube*\nQuery: *${query}*` },
                    footer: { text: 'Klik untuk download Video/Audio' },
                    header: {
                        hasVideoMessage: false,
                        imageMessage: media.imageMessage,
                        title: "",
                        subtitle: ""
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '📥 Pilih Video/Audio',
                                    sections: [
                                        {
                                            title: 'Hasil Pencarian',
                                            rows
                                        }
                                    ]
                                })
                            }
                        ]
                    }
                };

                const message = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: interactiveMessage
                        }
                    }
                }, { quoted: m });

                await sock.relayMessage(from, message.message, { messageId: message.key.id });

            } catch (e) {
                console.error(e);
                sock.sendMessage(from, { text: `❌ Terjadi error: ${e.message}` }, { quoted: m });
            }
        }

        // Command .yta (Integrasi API Velyn)
        if (command === 'yta') {
            if (!text) return;
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            const resMp3 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp3?url=${encodeURIComponent(text)}`, { timeout: 0 });
            await sock.sendMessage(from, { audio: { url: resMp3.data.output }, mimetype: 'audio/mp4', caption: `\`𝗬 𝗧 𝗠 𝗣 𝟯 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
        }

        // Command .ytv (Integrasi API Velyn)
        if (command === 'ytv') {
            if (!text) return;
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            const resMp4 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(text)}`, { timeout: 0 });
            await sock.sendMessage(from, { video: { url: resMp4.data.data.url }, caption: `\`𝗬 𝗧 𝗠 𝗣 𝟰 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
        }

    } catch (err) {
        console.error(err);
    }
};