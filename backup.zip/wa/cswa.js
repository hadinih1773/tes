const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { proto, generateWAMessageFromContent } = require("@whiskeysockets/baileys");

const PASTEBIN_API_KEY = "AuXzweHGDu1aH2JLjXqTw7VkoFsVWW0W";
const userPath = path.join(__dirname, "../databasewa/userwa.json");

const ARNARU_AI_API = 'https://arnaru-ai.vercel.app/api/chat';

async function askAI(question, userId = 'default_user', model = 'claude-sonnet-5', webSearch = false, onStreamUpdate = null) {
    const conversationId = `${userId}_session_1`;

    try {
        const payload = {
            question: question,
            model: model,
            conversationId: conversationId,
            systemPrompt: "",
            webSearch: webSearch
        };

        const response = await axios.post(ARNARU_AI_API, payload, {
            headers: { 'Content-Type': 'application/json' },
            responseType: 'stream',
            timeout: 60000
        });

        let fullAnswer = "";
        let buffer = "";

        return new Promise((resolve, reject) => {
            response.data.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
                let lines = buffer.split('\n');
                
                buffer = lines.pop();

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const jsonStr = line.substring(6).trim();
                        if (jsonStr === '[DONE]') continue;
                        
                        try {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) {
                                fullAnswer += parsed.answer;
                                let cleanedText = fullAnswer.replace(/[-=_]{3,}/g, '');
                                
                                if (onStreamUpdate) {
                                    onStreamUpdate(cleanedText);
                                }
                            }
                        } catch (e) {}
                    }
                }
            });

            response.data.on('end', () => {
                if (buffer.startsWith('data: ')) {
                    try {
                        const jsonStr = buffer.substring(6).trim();
                        if (jsonStr !== '[DONE]') {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) fullAnswer += parsed.answer;
                        }
                    } catch (e) {}
                }
                
                let finalCleaned = fullAnswer.replace(/[-=_]{3,}/g, '');
                resolve(finalCleaned || "Sori ngab, server AInya lagi ampas nih ga ngasih jawaban bener.");
            });

            response.data.on('error', (err) => reject(err));
        });
    } catch (error) {
        throw new Error(error.response?.data?.error || error.response?.data?.message || error.message);
    }
}

module.exports = async (sock, m, { jid, text, command, args: cmdArgs }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        // Mengambil body asli untuk parsing pemisah "|"
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';

        if (command === 'cs') {
            // Cek Registrasi User
            const userDb = JSON.parse(fs.readFileSync(userPath));
            if (!userDb.includes(sender)) return;

            const args = body.split("|");
            if (args.length < 4) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command}|nama ic|tanggal lahir|tempat tinggal\`\n📝 Contoh : \`.${command}|Larry Salvatore|17 Agustus 1945|Los Santos\`` }, { quoted: m });
            }

            // Reaction ⏱️
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                const charName = args[1].trim();
                const birthDate = args[2].trim();
                const address = args[3].trim();

                const promptInput = `Buatkan character story random dari ia lahir sampai besar untuk karakter bernama "${charName}", lahir ${birthDate}, alamat ${address}. Buat 4 paragraf singkat dengan bahasa baku setiap paragraf terdiri 4 kalimat perhatikan setiap huruf kapital buat ceritanya seolah-olah orang yang membuatkannya di kalimat awal paragraf saja jarakin ke tengah 4 spasi dan jangan respon pesan saya dengan kata-katamu, jangan gunakan banyak istilah bikin seperti seolah-olah orang asli 100% yang membuatnya jangan jawab pertanyaannya dan jangan ada kata kata dan kode bahasa hanya ceritanya yang dikirim.`;

                // Request ke Arnaru AI
                const story = await askAI(promptInput, sender);

                if (!story) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: "❌ AI gagal menghasilkan cerita." }, { quoted: m });
                }

                // Upload ke Pastebin
                const params = new URLSearchParams();
                params.append("api_dev_key", PASTEBIN_API_KEY);
                params.append("api_option", "paste");
                params.append("api_paste_code", story);
                params.append("api_paste_private", "1");
                params.append("api_paste_expire_date", "1D");
                params.append("api_paste_format", "text");

                const res = await axios.post("https://pastebin.com/api/api_post.php", params, { timeout: 0 });
                const pasteUrl = res.data;

                const resultText = `📜 *Character Story*\n*Nama Character* : ${charName}\n*Tanggal Lahir* : ${birthDate}\n*Alamat* : ${address}\n*Story* : ${pasteUrl}`;
                
                let interactiveMsg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text: resultText
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                    buttons: [{
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "Copy ID",
                                            copy_code: pasteUrl
                                        })
                                    }]
                                }),
                                contextInfo: {
                                    mentionedJid: [sender],
                                    quotedMessage: m.message
                                }
                            })
                        }
                    }
                }, { userJid: from, quoted: m });

                await sock.relayMessage(from, interactiveMsg.message, { messageId: interactiveMsg.key.id });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
    } catch (error) {
        console.error('Error in CS command:', error);
    }
};