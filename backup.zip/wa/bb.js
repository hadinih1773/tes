const axios = require("axios");
const FormData = require("form-data");
const { load } = require("cheerio");
const https = require("https");
const fs = require("fs");
const path = require("path");
const yts = require("yt-search");
const { generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

const axiosClient = axios.create({
    timeout: 0, 
    httpsAgent: new https.Agent({
        keepAlive: true,
        maxSockets: Infinity,
        maxFreeSockets: 256,
        scheduling: 'fifo',
        rejectUnauthorized: false 
    }),
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
});

/* ================= UTILS ================= */
async function streamToBuffer(url) {
    const response = await axiosClient.get(url, { 
        responseType: 'stream',
        timeout: 0,
        headers: {
            "Referer": "https://googlevideo.com/",
            "Origin": "https://googlevideo.com/"
        }
    });
    return new Promise((resolve, reject) => {
        const chunks = [];
        response.data.on('data', (chunk) => chunks.push(chunk));
        response.data.on('end', () => resolve(Buffer.concat(chunks)));
        response.data.on('error', (err) => reject(err));
    });
}

async function uploadTop4Top(buffer, filename = 'file.mp3') {
    const form = new FormData();
    form.append('file_0_', buffer, { filename, contentType: 'audio/mpeg' });
    form.append('submitr', '[ رفع الملفات ]');
    const response = await axiosClient.post('https://top4top.io/index.php', form, { 
        timeout: 0,
        headers: { ...form.getHeaders() } 
    });
    const html = response.data;
    const $ = load(html);
    let link = $('input.all_boxes').val() || 
               $('.alert-success a').attr('href') || 
               $('a[href*="top4top.io/download"]').attr('href') ||
               html.match(/https?:\/\/d\.top4top\.io\/m_[^"]+\.mp3/g)?.[0];

    if (!link) throw new Error('Link Top4Top tidak ditemukan');
    return link.replace(/^https:/, 'http:');
}

/* ================= DOWNLOADERS (UPDATED API) ================= */
async function getYoutubeBuffer(link) {
    const { data } = await axiosClient.get(`https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(link)}`, { timeout: 0 });
    
    if (!data.status || !data.result || !data.result.mp3) throw new Error("Gagal mendapatkan data dari API YouTube.");
    
    const res = data.result;
    const buffer = await streamToBuffer(res.mp3);
    
    return { 
        buffer, 
        title: res.title || "-", 
        thumbnail: res.thumbnail || "-", 
        duration: res.duration || "-", 
        views: "-", 
        channel: "-" 
    };
}

async function internalTikTokDl(url) {
    const { data } = await axiosClient.get(`https://api-faa.my.id/faa/tiktok?url=${encodeURIComponent(url)}`, { timeout: 0 });
    if (!data.status || !data.result) throw new Error("Gagal mengambil data TikTok.");
    const d = data.result;
    return { 
        link: d.music_info ? d.music_info.url : null, 
        title: d.title || "-", 
        cover: d.cover || "-", 
        views: d.stats ? d.stats.views : "-", 
        like: d.stats ? d.stats.likes : "-", 
        author: d.author ? d.author.nickname : "-" 
    };
}

async function internalSpotifyDl(url) {
    const { data } = await axiosClient.get(`https://api.nexray.web.id/downloader/spotify?url=${encodeURIComponent(url)}`, { timeout: 0 });
    if (!data.status || !data.result) throw new Error("Gagal mengambil data Spotify.");
    const d = data.result;

    return { 
        link: d.url, 
        title: d.title, 
        artist: d.artist || "-", 
        duration: "-", 
        thumbnail: "-" 
    };
}

/* ================= MAIN MODULE ================= */
module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        // Ambil body teks asli untuk pengecekan non-prefix command
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : 
                     (type === 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : 
                     (type === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponse.paramsJson).id : '';

        const dbPath = path.join(__dirname, '../databasewa/userwa.json');
        if (!fs.existsSync(dbPath)) return;
        const registeredUsers = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
        if (!registeredUsers.includes(sender)) return;

        // Handle Tombol Quick Reply (Boombox Convert)
        if (body.startsWith(".bb_convert ")) {
            const url = body.replace(".bb_convert ", "");
            return await processFinalMedia(sock, from, url, m, sender);
        }

        const quotedMsg = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
        if (body.toUpperCase() === "YES" && quotedMsg) {
            const quotedText = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || quotedMsg.imageMessage?.caption || "";
            if (quotedText.includes("Balas Pesan Ini Dengan Kata *YES*")) {
                const urlMatch = quotedText.match(/https?:\/\/[^\s]+/);
                if (urlMatch) {
                    return await processFinalMedia(sock, from, urlMatch[0], m, sender);
                }
            }
        }

        if (command === 'bbsearch' || command === 'bbs') {
            const query = text;
            if (!query) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });

            const boomboxDbPath = path.join(__dirname, '../database/boombox.json');
            if (!fs.existsSync(boomboxDbPath)) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ Tidak ditemukan lagu dengan judul "${query}" di database.` }, { quoted: m });
            }

            const boomboxDb = JSON.parse(fs.readFileSync(boomboxDbPath, 'utf-8'));
            const filteredResults = boomboxDb.filter(item => item.title && item.title.toLowerCase().includes(query.toLowerCase()));

            if (!filteredResults || filteredResults.length === 0) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ Tidak ditemukan lagu dengan judul "${query}" di database.` }, { quoted: m });
            }

            let listStr = "";
            filteredResults.forEach((item, index) => {
                listStr += `${index + 1}. *${item.title}*\n🔗 Top4Top : ${item.top4top}\n`;
            });

            const caption = `📦 *Boombox Search Result From Database*\nDitemukan ${filteredResults.length} Lagu Yang Berjudul ${query}\n\n${listStr.trim()}`;

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return await sock.sendMessage(from, { text: caption }, { quoted: m });
        }

        if (command === 'bbplaylist') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const boomboxDbPath = path.join(__dirname, '../database/boombox.json');
            if (!fs.existsSync(boomboxDbPath)) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "🎶 Daftar Lagu Yang Sudah Diproses\nTotal Lagu : 0\n\n*Belum ada lagu yang diproses.*" }, { quoted: m });
            }

            const boomboxDb = JSON.parse(fs.readFileSync(boomboxDbPath, 'utf-8'));
            if (!boomboxDb || boomboxDb.length === 0) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "🎶 Daftar Lagu Yang Sudah Diproses\nTotal Lagu : 0\n\n*Belum ada lagu yang diproses.*" }, { quoted: m });
            }

            let listStr = "";
            boomboxDb.forEach((item, index) => {
                listStr += `${index + 1}. *${item.title}*\n🔗 Top4Top : ${item.top4top}\n`;
            });

            const caption = `🎶 Daftar Lagu Yang Sudah Diproses\nTotal Lagu : ${boomboxDb.length}\n\n${listStr.trim()}`;

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return await sock.sendMessage(from, { text: caption }, { quoted: m });
        }

        if (command === 'bb') {
            const query = text;
            if (!query) return await sock.sendMessage(from, { text: "❌ Format Salah : `.bb link/query`" }, { quoted: m });

            const isUrl = /https?:\/\//.test(query);
            if (isUrl) {
                await processFinalMedia(sock, from, query, m, sender);
            } else {
                await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });
                
                let res = await yts(query);
                const rawVideos = res.all.filter(v => v.type === "video");
                if (!rawVideos.length) throw new Error("Video tidak ditemukan.");
                
                let rows = [];
                const results = rawVideos.slice(0, 10);
                
                for (let i = 0; i < results.length; i++) {
                    const resVideo = results[i];
                    rows.push({
                        title: resVideo.title.substring(0, 100),
                        description: `Duration: ${resVideo.timestamp} | Ch: ${resVideo.author.name || 'Unknown'}`,
                        id: `.bb ${resVideo.url}`
                    });
                }

                const msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                body: { text: `🔍 Hasil pencarian Boombox untuk *${query}*` },
                                footer: { text: 'Boombox Search Results' },
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "single_select",
                                            buttonParamsJson: JSON.stringify({
                                                title: "Pilih Musik",
                                                sections: [
                                                    {
                                                        title: "Hasil Pencarian",
                                                        highlight_label: "Popular",
                                                        rows: rows
                                                    }
                                                ]
                                            })
                                        }
                                    ]
                                }
                            }
                        }
                    }
                }, { quoted: m });

                await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
            }
        }
    } catch (err) {
        console.error(err);
        if (typeof from !== 'undefined') {
            await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            await sock.sendMessage(from, { text: `❌ Gagal: ${err.message}` }, { quoted: m });
        }
    }
};

async function processFinalMedia(sock, from, query, m, sender) {
    await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

    let finalBuffer, finalTitle, thumb, platform = "Search", extraData = {};
    const isYt = /youtube\.com|youtu\.be/.test(query);
    const isSp = /spotify/i.test(query);
    const isTt = /tiktok/i.test(query);

    try {
        if (isSp) {
            const res = await internalSpotifyDl(query);
            finalBuffer = await streamToBuffer(res.link);
            finalTitle = res.title; thumb = res.thumbnail; platform = "Spotify";
            extraData = { duration: res.duration, artist: res.artist };
        } else if (isYt || !/https?:\/\//.test(query)) {
            const ytRes = await getYoutubeBuffer(query);
            finalBuffer = ytRes.buffer; finalTitle = ytRes.title; thumb = ytRes.thumbnail; platform = "YouTube";
            extraData = { duration: ytRes.duration, views: ytRes.views, channel: ytRes.channel };
        } else if (isTt) {
            const res = await internalTikTokDl(query);
            finalBuffer = await streamToBuffer(res.link);
            finalTitle = res.title; thumb = res.cover; platform = "TikTok";
            extraData = { views: res.views, like: res.like, channel: res.author };
        }

        const top4topLink = await uploadTop4Top(finalBuffer, `${finalTitle.replace(/[^\w\s.-]/gi, '')}.mp3`);
        
        let caption = `✅ *Audio Berhasil Diproses!*\n@${sender.split('@')[0]} Done Bro 😎!\n\n`;
        caption += `*🎵 Judul*\n${finalTitle}\n\n`;
        if (platform === "YouTube") {
            caption += `*🕕 Durasi*\n${extraData.duration}\n\n*👀 Views*\n${extraData.views}\n\n*👤 Channel*\n${extraData.channel}\n\n`;
        } else if (platform === "TikTok") {
            caption += `*👀 Views*\n${extraData.views}\n\n*❤ Likes*\n${extraData.like}\n\n*👤 Channel*\n${extraData.channel}\n\n`;
        } else if (platform === "Spotify") {
            caption += `*🕕 Durasi*\n${extraData.duration}\n\n*👤 Artis*\n${extraData.artist}\n\n`;
        }
        caption += `*🔗 Top4Top*\n${top4topLink}\n\n🔄 Kalau Tidak Ada Suara Request Ulang Saja`;

        await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

        if (thumb && thumb !== "-") {
            await sock.sendMessage(from, { image: { url: thumb }, caption, mentions: [sender] }, { quoted: m });
        } else {
            await sock.sendMessage(from, { text: caption, mentions: [sender] }, { quoted: m });
        }
    } catch (e) {
        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
        await sock.sendMessage(from, { text: `❌ Gagal memproses media: ${e.message}` }, { quoted: m });
    }
}