const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'kerangajaib') {
            // Cek Registrasi User
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const query = text;

            if (!query) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} pertanyaan\`` }, { quoted: m });
            }

            const responses = [
                'Mungkin suatu hari',
                'Tidak juga',
                'Tidak keduanya',
                'Kurasa tidak',
                'Ya',
                'Coba tanya lagi',
                'Tidak ada'
            ];

            const randomResponse = responses[Math.floor(Math.random() * responses.length)];

            await sock.sendMessage(from, { text: `"${randomResponse}."` }, { quoted: m });
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        }
    } catch (err) {
        // Silent error
    }
};