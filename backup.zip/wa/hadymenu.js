const fs = require("fs");
const path = require("path");
const { spawn } = require('child_process');
const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// Fungsi Konversi Buffer ke Audio WhatsApp (Opus/Ogg)
function toPTT(buffer) {
    return new Promise((resolve, reject) => {
        let ffmpeg = spawn('ffmpeg', [
            '-i', 'pipe:0',
            '-vn',
            '-c:a', 'libopus',
            '-b:a', '128k',
            '-vbr', 'on',
            '-f', 'ogg',
            'pipe:1'
        ]);
        let buffers = [];
        ffmpeg.stdout.on('data', (chunk) => buffers.push(chunk));
        ffmpeg.stderr.on('data', (err) => {}); // Silent error ffmpeg
        ffmpeg.on('close', () => resolve(Buffer.concat(buffers)));
        ffmpeg.on('error', (err) => reject(err));
        ffmpeg.stdin.write(buffer);
        ffmpeg.stdin.end();
    });
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'hadymenu') {
            if (sender !== '73577453879303@lid') {
                return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            }

            // 1. Eksekusi Reaksi
            const emojis = ['👋', '😁', '😜', '😏'];
            const sendReactions = async () => {
                for (const emoji of emojis) {
                    sock.sendMessage(from, { react: { text: emoji, key: m.key } });
                    await new Promise(resolve => setTimeout(resolve, 100)); 
                }
            };
            sendReactions();

            // 2. Persiapan Menu
            const menuText = `👋 ᴡᴇʟᴄᴏᴍᴇ ʙᴏs ᴅɪ ʜᴀᴅʏ ᴍᴇɴᴜ 😏

━━━━━━━━━━━━━━━━━━━
📌 sɪʟᴀʜᴋᴀɴ ɢᴜɴᴀᴋᴀɴ ᴍᴇɴᴜ sᴇᴘᴇʀᴛɪ ʙɪᴀsᴀɴʏᴀ 🗿. ʜᴀʜᴀʜᴀ 
🚫 ᴊᴀɴɢᴀɴ ᴋᴇʀᴊᴀ ᴛᴇʀʟᴀʟᴜ ᴋᴇʀᴀs ɴᴀɴᴛɪ ɢᴀʙɪsᴀ ɴᴀғᴀs ʟᴇᴋ 😂😂
━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━
🤖 \`ʏᴏᴜʀ sᴛᴀᴛᴜs\` 🤖:
👑 ʙᴏs ʜᴀᴅʏ (ᴏᴡɴᴇʀ)
📞 ᴄᴏɴᴛᴀᴄᴛ : wa.me/6282311544652
━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━
\`ꜱᴇʟᴀᴍᴀᴛ ᴍᴇɴɪᴋᴍᴀᴛɪ ʜᴇʟᴘᴇʀ - ᴍᴅ!\`
©ʜᴀᴅʏʟᴜᴀ

◣──────────❈
◤─「 \`🗿 𝐇𝐚𝐝𝐲 𝐌𝐞𝐧𝐮\` 」─✦
│⦿ .getfile [nama file]
│⦿ .update|[nama file]|[kode baru]
│⦿ .rnmfile|[nama file]|[nama file baru]
│⦿ .delfile [nama file]
│⦿ .addfile|[lokasi file|nama file]|[kode file]
│⦿ .listfile
│⦿ .clearsession
│⦿ .addlimit [@tag/reply pesan/id][jumlah]
│⦿ .resetlimittime [time]
│⦿ .resetalllimit
│⦿ .setmaxlimit [jumlah]
│⦿ .limitsistem [on/off]
│⦿ .limitsistemgc [on/off]
│⦿ .creategc|[nama grup]
│⦿ .cekdisck
◣──────────❈`;

            const buttons = [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: 'Hady ID',
                        id: 'hady_id_copy',
                        copy_code: '73577453879303@lid'
                    })
                },
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: 'Hady Chat',
                        url: 'https://wa.me/6282311544652',
                        merchant_url: 'https://wa.me/6282311544652'
                    })
                }
            ];

            const preparedMedia = await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/b5m5x4.jpg" } }, { upload: sock.waUploadToServer });

            const interactiveMessage = proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({ text: menuText }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Helper - MD" }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    hasMediaAttachment: true,
                    imageMessage: preparedMedia.imageMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons: buttons })
            });

            const message = generateWAMessageFromContent(from, {
                viewOnceMessage: { message: { interactiveMessage: interactiveMessage } }
            }, { quoted: m });

            // Ambil file MP3 dan konversi ke Buffer yang valid untuk WhatsApp
            const audioPath = path.join(__dirname, '../vn/Welcome Back Bos.mp3');
            const rawBuffer = fs.readFileSync(audioPath);
            const convertedBuffer = await toPTT(rawBuffer);

            // 3. Kirim Menu dan Audio
            await sock.relayMessage(from, message.message, { messageId: message.key.id });
            
            await sock.sendMessage(from, { 
                audio: convertedBuffer, 
                mimetype: 'audio/mp4', 
                ptt: true
            }, { quoted: m });

        }
    } catch (err) {
        // Silent error
    }
};