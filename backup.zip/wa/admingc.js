const fs = require("fs");
const path = require("path");

const userFile = path.join(__dirname, "../databasewa/userwa.json");
const adminFile = path.join(__dirname, "../databasewa/adminwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        const from = jid;
        const isGroup = from.endsWith('@g.us');
        if (!isGroup) return;

        const sender = m.key.participant || m.key.remoteJid;

        // CEK USER DAFTAR
        if (!fs.existsSync(userFile)) return;
        const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
        if (!userDb.includes(sender)) return;

        // AMBIL DATA ADMIN BOT
        if (!fs.existsSync(adminFile)) return;
        const adminDb = JSON.parse(fs.readFileSync(adminFile, "utf8"));

        // CEK STATUS ADMIN GRUP
        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;
        const groupAdmins = participants.filter(p => p.admin !== null).map(p => p.id);
        const isAdmins = groupAdmins.includes(sender);
        const isAdminBot = adminDb.includes(sender);

        // =====================================================
        //                COMMAND .promote
        // =====================================================
        if (command === "promote") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            
            let users = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
            if (!users && args.length > 0) users = args[0].replace('@', '') + '@s.whatsapp.net';

            if (!users) return sock.sendMessage(from, { text: "❌ Format Salah : `.promote @tag/reply pesan`" }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            await sock.groupParticipantsUpdate(from, [users], "promote")
                .then(async () => {
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    sock.sendMessage(from, { 
                        text: `🎉 *@${sender.split("@")[0]} telah menjadikan @${users.split("@")[0]} sebagai admin grup ini!* 👑`,
                        contextInfo: { mentionedJid: [sender, users] }
                    }, { quoted: m });
                })
                .catch(async (err) => {
                    console.log(err);
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                });
        }

        // =====================================================
        //                COMMAND .demote
        // =====================================================
        if (command === "demote") {
            if (!isAdmins && !isAdminBot) return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            
            let users = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
            if (!users && args.length > 0) users = args[0].replace('@', '') + '@s.whatsapp.net';

            if (!users) return sock.sendMessage(from, { text: "❌ Format Salah : `.demote @tag/reply pesan`" }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            await sock.groupParticipantsUpdate(from, [users], "demote")
                .then(async () => {
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    sock.sendMessage(from, { 
                        text: `😔 *@${sender.split("@")[0]} telah menghapus @${users.split("@")[0]} dari jabatan admin grup ini.* 🚫`,
                        contextInfo: { mentionedJid: [sender, users] }
                    }, { quoted: m });
                })
                .catch(async (err) => {
                    console.log(err);
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                });
        }

    } catch (err) {
        console.error(err);
    }
};