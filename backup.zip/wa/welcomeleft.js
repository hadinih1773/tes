const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../databasewa/welcomeleft.json');
const userPath = path.join(__dirname, '../databasewa/userwa.json');
const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');

if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const isGroup = from.endsWith('@g.us');

        if (!fs.existsSync(userPath)) return;
        const users = JSON.parse(fs.readFileSync(userPath));
        if (!users.includes(sender)) return;

        const isOwner = () => {
            if (!fs.existsSync(ownerPath)) return false;
            const owners = JSON.parse(fs.readFileSync(ownerPath));
            return owners.includes(sender);
        };

        const reactOk = async () => {
            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        };

        let db = JSON.parse(fs.readFileSync(dbPath));

        if (command === 'wl') {
            if (!isOwner()) return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
            if (!isGroup) return;
            if (!args[0] || !['on', 'off'].includes(args[0])) return sock.sendMessage(from, { text: "❌ Format Salah : `.wl on/off`" }, { quoted: m });
            
            await reactOk();
            if (!db[from]) db[from] = {};
            db[from].status = (args[0] === 'on');
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
            sock.sendMessage(from, { text: `✅ Welcome & Left berhasil di ${args[0] === 'on' ? 'aktifkan' : 'matikan'}` }, { quoted: m });
        }

        else if (command === 'setwelcome') {
            if (!isOwner()) return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
            if (!isGroup) return;
            if (!text) return sock.sendMessage(from, { text: "❌ Format Salah : `.setwelcome teks`" }, { quoted: m });
            
            await reactOk();
            if (!db[from]) db[from] = {};
            db[from].welcome = text;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
            sock.sendMessage(from, { text: "✅ Teks Welcome berhasil diatur" }, { quoted: m });
        }

        else if (command === 'setleft') {
            if (!isOwner()) return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
            if (!isGroup) return;
            if (!text) return sock.sendMessage(from, { text: "❌ Format Salah : `.setleft teks`" }, { quoted: m });
            
            await reactOk();
            if (!db[from]) db[from] = {};
            db[from].left = text;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
            sock.sendMessage(from, { text: "✅ Teks Left berhasil diatur" }, { quoted: m });
        }

        else if (command === 'welcome' && args[0] === 'test') {
            if (!isGroup) return;
            await reactOk();
            let pp_user;
            try { pp_user = await sock.profilePictureUrl(sender, 'image'); } catch { pp_user = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg'; }
            
            let teks = (db[from] && db[from].welcome) ? db[from].welcome : "Welcome {tag}";
            teks = teks.replace(/{tag}/g, `@${sender.split('@')[0]}`);
            sock.sendMessage(from, { image: { url: pp_user }, caption: teks, mentions: [sender] }, { quoted: m });
        }

        else if (command === 'left' && args[0] === 'test') {
            if (!isGroup) return;
            await reactOk();
            let pp_user;
            try { pp_user = await sock.profilePictureUrl(sender, 'image'); } catch { pp_user = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg'; }
            
            let teks = (db[from] && db[from].left) ? db[from].left : "Goodbye {tag}";
            teks = teks.replace(/{tag}/g, `@${sender.split('@')[0]}`);
            sock.sendMessage(from, { image: { url: pp_user }, caption: teks, mentions: [sender] }, { quoted: m });
        }

    } catch (err) {
        console.error('Error di welcome.js command:', err);
    }
};