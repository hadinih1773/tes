const moment = require('moment-timezone');
const PhoneNum = require('awesome-phonenumber');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

let regionNames = new Intl.DisplayNames(['en'], {
    type: 'region'
});

function shortNum(num) {
    if (!num) return '0'
    if (num >= 1_000_000_000)
        return (num / 1_000_000_000).toFixed(1).replace('.0', '') + ' miliar'
    if (num >= 1_000_000)
        return (num / 1_000_000).toFixed(1).replace('.0', '') + ' jt'
    if (num >= 1_000)
        return (num / 1_000).toFixed(1).replace('.0', '') + ' rb'
    return num.toString()
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const from = jid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");
        const sender = m.key.participant || m.key.remoteJid;

        const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
        if (!users.includes(sender)) return;

        if (command === 'wastalk' || command === 'stalkwa') {
            let num = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant || text;
            
            if (!num) {
                return await sock.sendMessage(from, { text: '❌ Format Salah : `.wastalk 628xx`' }, { quoted: m });
            }

            num = num.replace(/\D/g, '') + '@s.whatsapp.net';

            try {
                const onWa = await sock.onWhatsApp(num);
                if (!onWa || !onWa[0]?.exists) {
                    return await sock.sendMessage(from, { text: '❌ User not exists on WhatsApp' }, { quoted: m });
                }

                let img = 'https://telegra.ph/file/70e8de9b1879568954f09.jpg';
                try {
                    img = await sock.profilePictureUrl(num, 'image');
                } catch (e) {}

                let bio = {};
                try {
                    bio = await sock.fetchStatus(num);
                } catch (e) {}

                let name = 'Unknown';
                try {
                    name = await sock.getName(num) || num.split('@')[0];
                } catch (e) {}

                let business = null;
                try {
                    business = await sock.getBusinessProfile(num);
                } catch (e) {}

                let format, country;
                try {
                    format = PhoneNum(`+${num.split('@')[0]}`);
                    country = regionNames.of(format.getRegionCode('mobile'));
                } catch (e) {
                    format = null;
                    country = 'Unknown';
                }

                const formattedNumber = format ? format.getNumber('international') : num.split('@')[0];

                let res = `\t\t\t\t*▾ WHATSAPP ▾*\n\n` +
                          `*° Country :* ${country ? country.toUpperCase() : '-'}\n` +
                          `*° Name :* ${name}\n` +
                          `*° Format Number :* ${formattedNumber}\n` +
                          `*° Url Api :* wa.me/${num.split('@')[0]}\n` +
                          `*° Mentions :* @${num.split('@')[0]}\n` +
                          `*° Status :* ${bio?.status || '-'}\n` +
                          `*° Date Status :* ${bio?.setAt ? moment(bio.setAt).tz('Asia/Jakarta').format('LLLL') : '-'}\n\n`;

                if (business) {
                    res += `\t\t\t\t*▾ INFO BUSINESS ▾*\n\n` +
                           `*° BusinessId :* ${business.wid}\n` +
                           `*° Website :* ${business.website ? business.website : '-'}\n` +
                           `*° Email :* ${business.email ? business.email : '-'}\n` +
                           `*° Category :* ${business.category}\n` +
                           `*° Address :* ${business.address ? business.address : '-'}\n` +
                           `*° Timezone :* ${business.business_hours?.timezone ? business.business_hours.timezone : '-'}\n` +
                           `*° Description :* ${business.description ? business.description : '-'}`;
                } else {
                    res += '*Standard WhatsApp Account*';
                }

                await sock.sendMessage(from, {
                    image: { url: img },
                    caption: res,
                    mentions: [num]
                }, { quoted: m });

            } catch (e) {
                await sock.sendMessage(from, { text: '❌ Failed to stalk user.' }, { quoted: m });
            }
        }

        if (command === 'igstalk') {
            const username = args[0]?.replace('@', '')
            if (!username) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.igstalk username\`` }, { quoted: m });

            try {
                const res = await axios.post(
                    'https://api.boostfluence.com/api/instagram-profile-v2',
                    { username },
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Agent': 'Mozilla/5.0'
                        },
                        timeout: 30000
                    }
                )
                
                const d = res.data
                if (!d?.username) {
                    return await sock.sendMessage(from, { text: `❌ Akun *@${username}* tidak ditemukan` }, { quoted: m });
                }
                
                const caption = `👤 Username : ${d.username}\n` +
                    `📋 Nama : ${d.full_name || '-'}\n` +
                    `✅ Verifid : ${d.is_verified ? 'Ya' : 'Tidak'}\n` +
                    `🔐 Private : ${d.is_private ? 'Ya' : 'Tidak'}\n` +
                    `👥 Pengikut : ${shortNum(d.follower_count)}\n` +
                    `👤 Mengikuti : ${shortNum(d.following_count)}\n` +
                    `📸 Postingan : ${shortNum(d.media_count)}\n` +
                    `📝 Bio :\n${d.biography || '-'}`
                
                const profilePic = d.profile_pic_url_hd || d.profile_pic_url
                if (profilePic) {
                    await sock.sendMessage(from, {
                        image: { url: profilePic },
                        caption
                    }, { quoted: m })
                } else {
                    await sock.sendMessage(from, { text: caption }, { quoted: m })
                }
            } catch (error) {
                await sock.sendMessage(from, { text: '❌ Failed to stalk Instagram user.' }, { quoted: m });
            }
        }
    } catch (err) {
        console.error(err);
    }
};