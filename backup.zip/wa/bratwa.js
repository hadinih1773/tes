const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const os = require('os');
const webp = require('node-webpmux');
const { tmpdir } = os;

async function imageToWebp (media) {
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ffmpeg(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function videoToWebp (media) {
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ffmpeg(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
                "-loop",
                "0",
                "-ss",
                "00:00:00",
                "-t",
                "00:00:05",
                "-preset",
                "default",
                "-an",
                "-vsync",
                "0"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function writeExifImg (media, metadata) {
    let wMedia = await imageToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "sticker-pack-id": `https://github.com/KirBotz`, "sticker-pack-name": metadata.packname, "sticker-pack-publisher": metadata.author, "emojis": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

async function writeExifVid (media, metadata) {
    let wMedia = await videoToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "sticker-pack-id": `https://github.com/KirBotz`, "sticker-pack-name": metadata.packname, "sticker-pack-publisher": metadata.author, "emojis": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");
        const from = jid;
        const type = Object.keys(m.message)[0];
        const sender = m.key.participant || m.key.remoteJid;

        // Logic for Button Response
        let buttonId = '';
        if (type === 'buttonsResponseMessage') {
            buttonId = m.message.buttonsResponseMessage.selectedButtonId;
        } else if (type === 'interactiveResponseMessage') {
            const paramsJson = m.message.interactiveResponseMessage.nativeFlowResponse.paramsJson;
            buttonId = JSON.parse(paramsJson).id;
        } else if (m.message.templateButtonReplyMessage) {
            buttonId = m.message.templateButtonReplyMessage.selectedId;
        }

        if (buttonId && (buttonId.startsWith('bratimg-') || buttonId.startsWith('bratvid-'))) {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            const isImg = buttonId.startsWith('bratimg-');
            const textValue = buttonId.replace(isImg ? 'bratimg-' : 'bratvid-', '');
            
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                const apiBase = isImg ? 'brat' : 'bratvid';
                const apiUrl = `https://api-faa.my.id/faa/${apiBase}?text=${encodeURIComponent(textValue)}`;
                const response = await axios.get(apiUrl, { timeout: 0, responseType: 'arraybuffer' });

                let stickerPath;
                if (isImg) {
                    stickerPath = await writeExifImg(response.data, { packname: "Helper - MD", author: "HadyLua" });
                } else {
                    stickerPath = await writeExifVid(response.data, { packname: "Helper - MD", author: "HadyLua" });
                }

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(from, { sticker: { url: stickerPath } }, { quoted: m });
                if (fs.existsSync(stickerPath)) fs.unlinkSync(stickerPath);
            } catch (error) {
                console.error(error);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                await sock.sendMessage(from, { text: `Gagal membuat brat.` }, { quoted: m });
            }
            return;
        }

        // Logic for Commands
        if (command === 'brat' || command === 'bratvid') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (!text) {
                return await sock.sendMessage(from, { text: '❌ Format Salah : `.brat/.bratvid teks`' }, { quoted: m });
            }

            const buttons = [
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '🖼 Gambar',
                        id: `bratimg-${text}`
                    })
                },
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '🎥 Video',
                        id: `bratvid-${text}`
                    })
                }
            ];

            const msg = {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: "Ada 2 Tipe Brat. Silahkan Dipilih Mana Yang Disukai :\n\n1. 🖼 Gambar\n2. 🎥 Video" },
                            footer: { text: "Pilih salah satu di bawah" },
                            header: { hasVideoMessage: false },
                            nativeFlowMessage: {
                                buttons: buttons
                            },
                            contextInfo: {
                                quotedMessage: m.message,
                                participant: sender,
                                remoteJid: from,
                                stanzaId: m.key.id
                            }
                        }
                    }
                }
            };

            await sock.relayMessage(from, msg, {});
        }
    } catch (err) {
        console.error(err);
    }
};