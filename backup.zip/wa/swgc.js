const { prepareWAMessageMedia, generateWAMessageFromContent, downloadContentFromMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// Path database
const userPath = path.join(__dirname, '../databasewa/userwa.json');
const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');
const adminPath = path.join(__dirname, '../databasewa/adminwa.json');

// Konfigurasi Newsletter
const idch = "120363424062451116@newsletter";

// Map Warna Background
const warnaMap = {
    'biru': '#34B7F1',
    'hijau': '#25D366',
    'kuning': '#FFD700',
    'jingga': '#FF8C00',
    'merah': '#FF3B30',
    'ungu': '#9C27B0',
    'abu': '#9E9E9E',
    'hitam': '#000000',
    'putih': '#FFFFFF',
    'cyan': '#00BCD4'
};

// Fungsi pembantu
function getRandomHexColor() {
    return "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // 1. Pengecekan User Terdaftar (Silent jika tidak terdaftar)
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        if (!userDb.includes(sender)) return;

        // 2. Pengecekan Izin Owner & Admin
        const ownerDb = fs.existsSync(ownerPath) ? JSON.parse(fs.readFileSync(ownerPath, "utf8")) : [];
        const adminDb = fs.existsSync(adminPath) ? JSON.parse(fs.readFileSync(adminPath, "utf8")) : [];
        
        const isOwner = ownerDb.includes(sender);
        const isAdminBot = adminDb.includes(sender);

        if (command === 'swgc' || command === 'statusgrup') {
            // Cek Izin: Hanya Owner & Admin
            if (!isOwner && !isAdminBot) {
                return await sock.sendMessage(from, { text: "❌ Hanya Owner & Admin Bot Yang Bisa Gunakan" }, { quoted: m });
            }

            // Cek Lokasi: Harus di Grup
            if (!from.endsWith('@g.us')) {
                return await sock.sendMessage(from, { text: "⚠️ Fitur ini hanya dapat digunakan di dalam grup!" }, { quoted: m });
            }

            // 3. Logika Pengambilan Media/Teks
            let q = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
            
            const isImage = q.imageMessage || m.message.imageMessage;
            const isVideo = q.videoMessage || m.message.videoMessage;
            // Perbaikan: isText hanya true jika ada input teks yang nyata (bukan string kosong)
            const isText = (text && text.trim().length > 0);

            // Jika tidak ada media DAN tidak ada teks, kirim pesan format salah
            if (!isImage && !isVideo && !isText) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks/reply video dan foto\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            // Parse teks dan warna jika ada pemisah "|"
            let inputText = text || "";
            let selectedColor = null;
            if (inputText.includes('|')) {
                const parts = inputText.split('|').map(v => v.trim());
                inputText = parts[0];
                const colorKey = parts[1]?.toLowerCase();
                if (warnaMap[colorKey]) {
                    selectedColor = warnaMap[colorKey];
                }
            }

            // Setup Status Options
            const groupMetadata = await sock.groupMetadata(from).catch(() => ({ participants: [] }));
            const participants = groupMetadata.participants.map(p => p.id);
            const messageSecret = crypto.randomBytes(32);

            const statusOptions = {
                backgroundColor: selectedColor || getRandomHexColor(),
                font: Math.floor(Math.random() * 9),
                statusJidList: participants,
                annotations: [{
                    polygonVertices: [{ x: 0.0563, y: 0.1531 }, { x: 0.9437, y: 0.1531 }, { x: 0.9437, y: 0.8459 }, { x: 0.0563, y: 0.8459 }],
                    newsletter: {
                        newsletterJid: idch,
                        serverMessageId: null,
                        newsletterName: "Hady Community",
                        contentType: "UPDATE_CARD"
                    }
                }]
            };

            try {
                let rawContent = {};
                if (isImage || isVideo) {
                    const mediaMsg = isImage ? (q.imageMessage || m.message.imageMessage) : (q.videoMessage || m.message.videoMessage);
                    const type = isImage ? 'image' : 'video';
                    
                    const stream = await downloadContentFromMessage(mediaMsg, type);
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                    
                    if (isImage) rawContent.image = buffer;
                    else rawContent.video = buffer;
                    rawContent.caption = inputText || mediaMsg.caption || "";

                    const mediaContent = await prepareWAMessageMedia(rawContent, { upload: sock.waUploadToServer });
                    
                    const msg = generateWAMessageFromContent(from, {
                        groupStatusMessageV2: {
                            message: { ...mediaContent },
                            messageContextInfo: { messageSecret }
                        }
                    }, { userJid: sock.user.id });

                    await sock.relayMessage(from, msg.message, { messageId: msg.key.id });

                } else {
                    // Logika pengiriman teks
                    const msg = generateWAMessageFromContent(from, {
                        groupStatusMessageV2: {
                            message: {
                                protocolMessage: {
                                    key: {
                                        remoteJid: 'status@broadcast',
                                        fromMe: true,
                                        id: crypto.randomBytes(16).toString('hex')
                                    },
                                    type: 3 // KHUSUS TEKS
                                },
                                extendedTextMessage: {
                                    text: inputText,
                                    ...statusOptions
                                }
                            },
                            messageContextInfo: { messageSecret }
                        }
                    }, { userJid: sock.user.id });

                    await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
                }
                
                await sock.sendMessage(from, { text: "✅ Berhasil posting ke story grup ini!" }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                console.error("SWGC Error: ", err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        } else if (command === 'swgcall' || command === 'statusgrupall') {
            // Fitur pengiriman status ke seluruh grup (hanya Owner & Admin)
            if (!isOwner && !isAdminBot) {
                return await sock.sendMessage(from, { text: "❌ Hanya Owner & Admin Bot Yang Bisa Gunakan" }, { quoted: m });
            }

            let q = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
            const isImage = q.imageMessage || m.message.imageMessage;
            const isVideo = q.videoMessage || m.message.videoMessage;
            const isText = (text && text.trim().length > 0);

            if (!isImage && !isVideo && !isText) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks/reply video dan foto\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            let inputText = text || "";
            let selectedColor = null;
            if (inputText.includes('|')) {
                const parts = inputText.split('|').map(v => v.trim());
                inputText = parts[0];
                const colorKey = parts[1]?.toLowerCase();
                if (warnaMap[colorKey]) {
                    selectedColor = warnaMap[colorKey];
                }
            }

            try {
                const groups = await sock.groupFetchAllParticipating();
                const groupIds = Object.keys(groups);

                if (groupIds.length === 0) {
                    return await sock.sendMessage(from, { text: "❌ Bot belum bergabung di grup manapun." }, { quoted: m });
                }

                let buffer = null;
                let type = null;
                if (isImage || isVideo) {
                    const mediaMsg = isImage ? (q.imageMessage || m.message.imageMessage) : (q.videoMessage || m.message.videoMessage);
                    type = isImage ? 'image' : 'video';
                    const stream = await downloadContentFromMessage(mediaMsg, type);
                    buffer = Buffer.from([]);
                    for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                }

                for (const targetJid of groupIds) {
                    try {
                        const messageSecret = crypto.randomBytes(32);
                        const groupMetadata = groups[targetJid] || { participants: [] };
                        const participants = groupMetadata.participants ? groupMetadata.participants.map(p => p.id) : [];

                        const statusOptions = {
                            backgroundColor: selectedColor || getRandomHexColor(),
                            font: Math.floor(Math.random() * 9),
                            statusJidList: participants,
                            annotations: [{
                                polygonVertices: [{ x: 0.0563, y: 0.1531 }, { x: 0.9437, y: 0.1531 }, { x: 0.9437, y: 0.8459 }, { x: 0.0563, y: 0.8459 }],
                                newsletter: {
                                    newsletterJid: idch,
                                    serverMessageId: null,
                                    newsletterName: "Hady Community",
                                    contentType: "UPDATE_CARD"
                                }
                            }]
                        };

                        if (isImage || isVideo) {
                            let rawContent = {};
                            if (type === 'image') rawContent.image = buffer;
                            else rawContent.video = buffer;
                            rawContent.caption = inputText || "";

                            const mediaContent = await prepareWAMessageMedia(rawContent, { upload: sock.waUploadToServer });
                            const msg = generateWAMessageFromContent(targetJid, {
                                groupStatusMessageV2: {
                                    message: { ...mediaContent },
                                    messageContextInfo: { messageSecret }
                                }
                            }, { userJid: sock.user.id });

                            await sock.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
                        } else {
                            const msg = generateWAMessageFromContent(targetJid, {
                                groupStatusMessageV2: {
                                    message: {
                                        protocolMessage: {
                                            key: {
                                                remoteJid: 'status@broadcast',
                                                fromMe: true,
                                                id: crypto.randomBytes(16).toString('hex')
                                            },
                                            type: 3
                                        },
                                        extendedTextMessage: {
                                            text: inputText,
                                            ...statusOptions
                                        }
                                    },
                                    messageContextInfo: { messageSecret }
                                }
                            }, { userJid: sock.user.id });

                            await sock.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
                        }
                    } catch (errGroup) {
                        console.error(`Gagal kirim swgc ke ${targetJid}: `, errGroup);
                    }
                }

                await sock.sendMessage(from, { text: `✅ Berhasil posting story ke seluruh grup (${groupIds.length} grup)!` }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                console.error("SWGC ALL Error: ", err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
    } catch (err) {
        console.error("SWGC Error: ", err);
    }
};