const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');
const webp = require('node-webpmux');
const os = require('os');
const { tmpdir } = os;

async function imageToWebp (media) {
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ffmpeg(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function writeExifImg (media, metadata) {
    let wMedia = await imageToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "sticker-pack-id": `https://github.com/KirBotz`, "sticker-pack-name": metadata.packname, "sticker-pack-publisher": metadata.author, "emojis": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        if (command !== 'swm' && command !== 'wm' && command !== 'stickerwm' && command !== 'stickermark' && command !== 'colong') return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Cek Registrasi User
        if (fs.existsSync(userDbPath)) {
            const userDb = JSON.parse(fs.readFileSync(userDbPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        }

        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted || !quoted.stickerMessage) {
            return await sock.sendMessage(from, { 
                text: `❌ Format Salah :\n\`.${command} packname|author\`\n\`.${command} packname\`\n\`.${command}|author\`` 
            }, { quoted: m });
        }

        const input = text?.trim();
        if (!input && !m.message.extendedTextMessage.text.includes('|')) {
            return await sock.sendMessage(from, { 
                text: `❌ Format Salah :\n\`.${command} packname|author\`\n\`.${command} packname\`\n\`.${command}|author\`` 
            }, { quoted: m });
        }

        let packname = "";
        let author = "";

        if (input.includes('|')) {
            const parts = input.split('|');
            packname = parts[0]?.trim() || "";
            author = parts[1]?.trim() || "";
        } else {
            packname = input || "";
        }

        if (packname.length > 50 || author.length > 50) {
            return await sock.sendMessage(from, { text: `❌ *ɢᴀɢᴀʟ*\n\n> Packname/Author terlalu panjang (max 50 karakter)` }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

        try {
            const stream = await downloadContentFromMessage(quoted.stickerMessage, 'sticker');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const stickerPath = await writeExifImg(buffer, { packname, author });
            const stickerBuffer = fs.readFileSync(stickerPath);

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            await sock.sendMessage(from, { sticker: stickerBuffer }, { quoted: m });
            
            fs.unlinkSync(stickerPath);
        } catch (err) {
            await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            console.error(err);
        }

    } catch (err) {
        console.error('SWM Error:', err);
        await sock.sendMessage(jid, { react: { text: "❌", key: m.key } });
    }
};