const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);

// Fungsi Auto Install Module (Hanya yang diperlukan saja)
const checkAndInstall = (modules) => {
    modules.forEach(mod => {
        try {
            require.resolve(mod);
        } catch (e) {
            console.log(`Installing ${mod}...`);
            exec(`npm install ${mod}`, (err) => {
                if (err) console.error(`Gagal install ${mod}:`, err);
                else console.log(`${mod} berhasil diinstall.`);
            });
        }
    });
};

// Daftar module yang diperlukan untuk fitur sticker ini
const modulesToInstall = [
    'fluent-ffmpeg',
    'node-webpmux',
    '@whiskeysockets/baileys',
    'crypto'
];

checkAndInstall(modulesToInstall);

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');
const webp = require('node-webpmux');
const os = require('os');
const { tmpdir } = os;

// Konversi Gambar ke WebP
async function imageToWebp (media) {
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ffmpeg(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

// Konversi Video ke WebP (Animasi)
async function videoToWebp (media) {
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ffmpeg(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
                "-loop",
                "0",
                "-ss",
                "00:00:00",
                "-t",
                "00:00:10",
                "-preset",
                "default",
                "-an",
                "-vsync",
                "0"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

// Menulis Metadata Exif ke WebP
async function writeExif (media, metadata, isVideo = false) {
    let wMedia = isVideo ? await videoToWebp(media) : await imageToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "sticker-pack-id": `https://github.com/KirBotz`, "sticker-pack-name": metadata.packname, "sticker-pack-publisher": metadata.author, "emojis": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
    return tmpFileIn;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

    try {
        if (!m.message) return;
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 's' || command === 'sticker' || command === 'toimg' || command === 'toimage') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            if (command === 's' || command === 'sticker') {
                const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
                const imageMsg = m.message.imageMessage || quoted?.imageMessage;
                const videoMsg = m.message.videoMessage || quoted?.videoMessage;
                const mediaMsg = imageMsg || videoMsg;

                if (!mediaMsg) {
                    let caption = `❌ Format Salah :\n\`.s Reply Gambar/Video\`\n\`.s Reply+Packname|Author\``;
                    
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: caption }, { quoted: m });
                }

                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

                // Opsi Packname dan Author
                let packname = "Helper - MD";
                let author = "HadyLua";

                if (text && text.includes('|')) {
                    const parts = text.split('|');
                    packname = parts[0].trim() || packname;
                    author = parts[1] ? parts[1].trim() : author;
                } else if (text && text.trim().length > 0) {
                    packname = text.trim();
                }

                const isVideo = !!videoMsg;

                try {
                    const type = isVideo ? 'video' : 'image';
                    const stream = await downloadContentFromMessage(mediaMsg, type);
                    let buffer = Buffer.from([]);
                    for await (const chunk of stream) {
                        buffer = Buffer.concat([buffer, chunk]);
                    }

                    const stickerPath = await writeExif(buffer, { packname, author }, isVideo);
                    const stickerBuffer = fs.readFileSync(stickerPath);

                    await sock.sendMessage(from, { sticker: stickerBuffer }, { quoted: m });
                    if (fs.existsSync(stickerPath)) fs.unlinkSync(stickerPath);

                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } catch (err) {
                    console.error("Error saat membuat stiker:", err);
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            }

            if (command === 'toimg' || command === 'toimage') {
                const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
                const stickerMsg = quoted?.stickerMessage;
                if (stickerMsg) {
                    try {
                        const stream = await downloadContentFromMessage(stickerMsg, 'sticker');
                        let buffer = Buffer.from([]);
                        for await (const chunk of stream) {
                            buffer = Buffer.concat([buffer, chunk]);
                        }

                        await sock.sendMessage(from, { image: buffer, caption: "✅ Berhasil" }, { quoted: m });
                        await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    } catch (err) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    }
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    await sock.sendMessage(from, { text: `⚠️ Reply Sticker` }, { quoted: m });
                }
            }
        }
    } catch (err) {
        console.error("Error Sticker Fitur: ", err);
    }
};