const { exec } = require('child_process');
const { promisify } = require('util');
const fs = require('fs');
const path = require('path');

const execAsync = promisify(exec);
const userPath = path.join(__dirname, "../databasewa/userwa.json");
const sampahDir = path.join(__dirname, "../sampah");

// Pastikan folder sampah ada
if (!fs.existsSync(sampahDir)) {
    fs.mkdirSync(sampahDir, { recursive: true });
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Cek Registrasi User
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath));
        if (!userDb.includes(sender)) return;

        if (command === 'tovn' || command === 'tomp3') {
            // Antisipasi pembungkus pesan ephemeral / viewOnce
            const mainMessage = m.message?.ephemeralMessage?.message || 
                                m.message?.viewOnceMessage?.message || 
                                m.message?.viewOnceMessageV2?.message || 
                                m.message;

            const quoted = mainMessage.extendedTextMessage?.contextInfo?.quotedMessage;
            
            // Cek media dari pesan langsung atau dari pesan reply
            const targetMessage = mainMessage.audioMessage || mainMessage.videoMessage ? mainMessage : 
                                 (quoted?.ephemeralMessage?.message || quoted?.viewOnceMessage?.message || quoted?.viewOnceMessageV2?.message || quoted);

            if (!targetMessage) {
                return sock.sendMessage(from, { text: `⚠️ Reply Video/Audio atau Kirim Langsung dengan Caption` }, { quoted: m });
            }

            const hasAudio = !!targetMessage.audioMessage;
            const hasVideo = !!targetMessage.videoMessage;

            if (!hasAudio && !hasVideo) {
                return sock.sendMessage(from, { text: `⚠️ Reply Video/Audio atau Kirim Langsung dengan Caption` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                // Download Media
                const stream = await require('@whiskeysockets/baileys').downloadContentFromMessage(
                    targetMessage.audioMessage || targetMessage.videoMessage,
                    hasAudio ? 'audio' : 'video'
                );
                
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                const mime = (targetMessage.audioMessage?.mimetype || targetMessage.videoMessage?.mimetype || '');
                let inExt = 'bin';
                if (/ogg|opus/i.test(mime)) inExt = 'ogg';
                else if (/mpeg|mp3/i.test(mime)) inExt = 'mp3';
                else if (/wav/i.test(mime)) inExt = 'wav';
                else if (/mp4|quicktime/i.test(mime)) inExt = 'mp4';
                else if (/3gpp/i.test(mime)) inExt = '3gp';

                const suffix = Date.now();
                const inputPath = path.join(sampahDir, `${sender.split('@')[0]}_${suffix}.in.${inExt}`);
                const outputPath = path.join(sampahDir, `${sender.split('@')[0]}_${suffix}.out.${command === 'tovn' ? 'ogg' : 'mp3'}`);

                fs.writeFileSync(inputPath, buffer);

                try {
                    if (command === 'tovn') {
                        await execAsync(`ffmpeg -y -i "${inputPath}" -vn -af "silenceremove=1:0:-50dB" -c:a libopus -b:a 96k -ar 48000 -ac 1 "${outputPath}"`);
                        
                        await sock.sendMessage(from, {
                            audio: { url: outputPath },
                            mimetype: 'audio/ogg; codecs=opus',
                            ptt: true
                        }, { quoted: m });
                    } else {
                        await execAsync(`ffmpeg -y -i "${inputPath}" -vn -acodec libmp3lame -b:a 192k "${outputPath}"`);
                        
                        await sock.sendMessage(from, {
                            audio: { url: outputPath },
                            mimetype: 'audio/mpeg',
                            ptt: false
                        }, { quoted: m });
                    }
                    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                } catch (err) {
                    console.error(err);
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    await sock.sendMessage(from, { text: `❌ Error: ${err.message}` }, { quoted: m });
                }

                // Hapus file temporary di folder sampah
                if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
                
            } catch (error) {
                console.error(error);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
    } catch (err) {
        console.error(err);
    }
};