const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { uploadToTmpFiles } = require('../lib/tmpfiles.js');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        if (command !== 'luaobf') return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Cek Registrasi User
        if (fs.existsSync(userDbPath)) {
            const userDb = JSON.parse(fs.readFileSync(userDbPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        // Antisipasi pembungkus pesan (ephemeral/viewOnce) pada pesan utama
        const mainMessage = m.message?.ephemeralMessage?.message || 
                            m.message?.viewOnceMessage?.message || 
                            m.message?.viewOnceMessageV2?.message || 
                            m.message;

        // Ambil pesan yang berisi dokumen (langsung atau reply)
        const quotedInfo = mainMessage?.extendedTextMessage?.contextInfo;
        const quoted = quotedInfo?.quotedMessage?.ephemeralMessage?.message || 
                       quotedInfo?.quotedMessage?.viewOnceMessage?.message || 
                       quotedInfo?.quotedMessage?.viewOnceMessageV2?.message || 
                       quotedInfo?.quotedMessage;
        
        const msgDoc = mainMessage?.documentMessage || quoted?.documentMessage;

        if (!msgDoc || (!msgDoc.fileName.endsWith('.lua') && !msgDoc.fileName.endsWith('.txt'))) {
            return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} reply file\`` }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: "⏳", key: m.key } });

        // Tentukan objek pesan mentah yang akan didownload
        let messageToDownload;
        if (mainMessage?.documentMessage) {
            messageToDownload = m; // Jika file dikirim langsung
        } else {
            messageToDownload = { message: quotedInfo?.quotedMessage }; // Jika file hasil reply
        }
        
        const bufferData = await downloadMediaMessage(
            messageToDownload,
            'buffer',
            {},
            { 
                logger: console,
                reuploadRequest: sock.updateMediaMessage
            }
        );

        const originalCode = bufferData.toString('utf-8');
        const originalSize = Buffer.byteLength(originalCode, 'utf8');

        // LANGKAH 1: Membuat Script / Session Baru (Body berupa teks mentah sesuai dokumentasi)
        const sessionResponse = await axios.post('https://api.luaobfuscator.com/v1/obfuscator/newscript', originalCode, {
            headers: {
                'content-type': 'text',
                'apikey': '2eacf7f3-840f-e5a9-dba4-ca117effd02b2b07'
            },
            timeout: 0
        });

        const sessionId = sessionResponse.data.sessionId;
        if (!sessionId) throw new Error("Gagal membuat session ID dari LuaObfuscator");

        // LANGKAH 2: Mengirim Perintah Obfuscate menggunakan Session ID
        const apiResponse = await axios.post('https://api.luaobfuscator.com/v1/obfuscator/obfuscate', {
            MinifiyAll: true,
            Virtualize: true
        }, {
            headers: {
                'content-type': 'application/json',
                'apikey': '2eacf7f3-840f-e5a9-dba4-ca117effd02b2b07',
                'sessionId': sessionId
            },
            timeout: 0
        });

        const obfuscatedCode = apiResponse.data.code;
        if (!obfuscatedCode) throw new Error("Gagal mendapatkan kode dari API LuaObfuscator");

        const obfuscatedSize = Buffer.byteLength(obfuscatedCode, 'utf8');
        const bufferObf = Buffer.from(obfuscatedCode, 'utf8');
        const newFileName = `Obfuscated_${msgDoc.fileName}`;

        // Upload ke TmpFiles
        const uploadResult = await uploadToTmpFiles(bufferObf, {
            filename: newFileName,
            contentType: "text/plain"
        });

        const caption = `✅ *Obfuscator File Succesful*\n\n` +
            `👤 *User Request* : @${sender.split('@')[0]}\n` +
            `📁 *File Name* : ${msgDoc.fileName}\n` +
            `📦 *Original Size* : ${(originalSize / 1024).toFixed(2)} KB\n` +
            `📮 *Obfuscated Size* : ${(obfuscatedSize / 1024).toFixed(2)} KB\n` +
            `🔗 *Link* : ${uploadResult.directUrl}`;

        // Kirim notifikasi ke channel/grup asal target request
        await sock.sendMessage(from, {
            text: `@${sender.split('@')[0]} Silahkan Cek DM Dari Bot!! Terima Kasih\n\n${caption}`,
            mentions: [sender]
        }, { quoted: m });

        // Kirim Dokumen Hasil langsung ke nomor DM/Private Chat user (sender)
        await sock.sendMessage(sender, {
            document: bufferObf,
            fileName: newFileName,
            mimetype: "text/plain",
            caption: `@${sender.split('@')[0]} File Telah Sukses Di Obfuscate. Silahkan Di Cek Dibawah Ini.`,
            mentions: [sender]
        });

        await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

        // LOGIKA HAPUS: Menghapus pesan command (baik yang berupa reply maupun kirim langsung)
        if (mainMessage?.documentMessage) {
            // Jika kirim langsung, hapus pesan utama (m)
            await sock.sendMessage(from, {
                delete: m.key
            }).catch(() => {});
        } else if (quotedInfo?.stanzaId) {
            // Jika lewat reply, hapus pesan file yang di-reply
            await sock.sendMessage(from, {
                delete: {
                    remoteJid: from,
                    fromMe: quotedInfo.participant === sock.user.id.split(':')[0] + '@s.whatsapp.net',
                    id: quotedInfo.stanzaId,
                    participant: quotedInfo.participant
                }
            }).catch(() => {});

            // Hapus juga pesan teks perintah `.luaobf` nya
            await sock.sendMessage(from, {
                delete: m.key
            }).catch(() => {});
        }

    } catch (error) {
        console.error(error);
        await sock.sendMessage(jid, { text: `❌ Error: ${error.message}` }, { quoted: m });
    }
};