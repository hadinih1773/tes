const fs = require("fs");
const path = require("path");
const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

const userFile = path.join(__dirname, "../databasewa/userwa.json");
const ownerFile = path.join(__dirname, "../databasewa/ownerwa.json");
const sambutanFile = path.join(__dirname, "../databasewa/sambutan.json");

// Pastikan file sambutan ada
if (!fs.existsSync(sambutanFile)) {
    fs.writeFileSync(sambutanFile, JSON.stringify({}, null, 2));
}

let lastOwnerMessage = {};
const OWNER_TIMEOUT = 15 * 60 * 1000;

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';
        
        const msg = body.toLowerCase();
        const isCommand = msg.startsWith('.');

        // CEK USER DAFTAR
        if (!fs.existsSync(userFile)) return;
        const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
        if (!userDb.includes(sender)) return;

        // CEK OWNER DAFTAR
        if (!fs.existsSync(ownerFile)) return;
        const ownerDb = JSON.parse(fs.readFileSync(ownerFile, "utf8"));
        
        let sambutanData = JSON.parse(fs.readFileSync(sambutanFile, "utf8"));

        // =====================================================
        //                COMMAND .owner
        // =====================================================
        if (command === "owner") {
            await sock.sendMessage(from, { react: { text: "📞", key: m.key } });

            const PRIMARY_OWNER = ownerDb[0];
            let ownerPp;
            try {
                ownerPp = await sock.profilePictureUrl(PRIMARY_OWNER, 'image');
            } catch {
                ownerPp = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";
            }

            const preparedMedia = await prepareWAMessageMedia({ image: { url: ownerPp } }, { upload: sock.waUploadToServer });

            const buttons = [
                { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'Tiktok', url: 'https://www.tiktok.com/@hadinih_?_t=ZS-90TZ3PGNoiy&_r=1', merchant_url: 'https://www.tiktok.com/@hadinih_?_t=ZS-90TZ3PGNoiy&_r=1' }) },
                { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'YouTube', url: 'https://www.youtube.com/@hadinih', merchant_url: 'https://www.youtube.com/@hadinih' }) },
                { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'Twitter/X', url: 'https://x.com/hadinih_?t=_wqwZxUhvYUAMOpSsElwRw&s=08', merchant_url: 'https://x.com/hadinih_?t=_wqwZxUhvYUAMOpSsElwRw&s=08' }) },
                { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'Instagram', url: 'https://www.instagram.com/hadinih_?igsh=MWl4NjY3cWEyNXEwMg==', merchant_url: 'https://www.instagram.com/hadinih_?igsh=MWl4NjY3cWEyNXEwMg==' }) },
                { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'Saluran WhatsApp', url: 'https://whatsapp.com/channel/0029Vb6TwQ84tRrw2345Ut1z', merchant_url: 'https://whatsapp.com/channel/0029Vb6TwQ84tRrw2345Ut1z' }) },
                { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'Discord Community', url: 'https://discord.gg/4uzdM25KYv', merchant_url: 'https://discord.gg/4uzdM25KYv' }) }
            ];

            const ownerMentions = ownerDb.map(id => `@${id.split('@')[0]}`).join(' & ');

            const interactiveMessage = proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `🤴 *Owner Community*\n\nInilah orang yang dibalik berdirinya Hady Community jangan ragu untuk bertanya atau mengobrol langsung saja tag. Jika mau bertanya silahkan gunakan command .ask.\n\nOwner: ${ownerMentions}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Hady Community" }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    hasMediaAttachment: true,
                    imageMessage: preparedMedia.imageMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons: buttons }),
                contextInfo: { mentionedJid: ownerDb }
            });

            const message = generateWAMessageFromContent(from, {
                viewOnceMessage: { message: { interactiveMessage: interactiveMessage } }
            }, { quoted: m });

            await sock.relayMessage(from, message.message, { messageId: message.key.id });

            const vcardHady = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:Hady\n' + 'ORG:Hady Community;\n' + 'TEL;type=CELL;type=VOICE;waid=6282311544652:+6282311544652\n' + 'END:VCARD';
            const vcardAka = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:Aka\n' + 'ORG:Hady Community;\n' + 'TEL;type=CELL;type=VOICE;waid=6281266950382:+6281266950382\n' + 'END:VCARD';
            const vcardHelper = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:HC Helper MD\n' + 'ORG:Hady Community;\n' + 'TEL;type=CELL;type=VOICE;waid=6285165754930:+6285165754930\n' + 'END:VCARD';

            return await sock.sendMessage(from, {
                contacts: {
                    displayName: 'Owner List',
                    contacts: [{ vcard: vcardHady }, { vcard: vcardAka }, { vcard: vcardHelper }]
                }
            }, { quoted: m });
        }

        // =====================================================
        //       COMMAND .sambutan on / off
        // =====================================================
        if (command === "sambutan") {
            if (!ownerDb.includes(sender)) return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
            const option = args[0];

            if (option === "on") {
                sambutanData[from] = true;
                fs.writeFileSync(sambutanFile, JSON.stringify(sambutanData, null, 2));
                return sock.sendMessage(from, { text: "✅ Sambutan owner berhasil *diaktifkan* untuk grup ini." }, { quoted: m });
            } else if (option === "off") {
                sambutanData[from] = false;
                fs.writeFileSync(sambutanFile, JSON.stringify(sambutanData, null, 2));
                return sock.sendMessage(from, { text: "❌ Sambutan owner berhasil *dimatikan* untuk grup ini." }, { quoted: m });
            } else {
                return sock.sendMessage(from, { text: "❌ Format Salah : `.sambutan on/off`" }, { quoted: m });
            }
        }

        // =====================================================
        //              FITUR SAMBUTAN OWNER (LOGIC FIX)
        // =====================================================
        if (ownerDb.includes(sender) && !isCommand) {
            if (sambutanData[from] === true) {
                const now = Date.now();
                const keyId = `${from}-${sender}`;
                const lastMsg = lastOwnerMessage[keyId] || 0;

                if (now - lastMsg >= OWNER_TIMEOUT) {
                    lastOwnerMessage[keyId] = now;
                    let ppUrl;
                    try {
                        ppUrl = await sock.profilePictureUrl(sender, 'image');
                    } catch {
                        ppUrl = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";
                    }

                    const caption = `[ 📢 DINGG ]\n\nOwnerku telah tiba sambutlah dia. Jika kalian ada yang mau ditanyakan silahkan .ask saja atau langsung tag dia. \nOwner Joined The Chat @${sender.split('@')[0]}`;
                    
                    await sock.sendMessage(from, { 
                        image: { url: ppUrl }, 
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: m });
                }
            }
        }

    } catch (err) {
        console.error(err);
    }
};