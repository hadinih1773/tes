const fs = require("fs");
const path = require("path");
const request = require("request");
const cheerio = require("cheerio");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'artinama') {
            // Cek Registrasi User
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            let nama = text;

            if (!nama) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} nama\`` }, { quoted: m });
            }

            // WAITING REACTION
            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });

            request.get({
                headers: { 'content-type': 'application/x-www-form-urlencoded' },
                url: 'http://www.primbon.com/arti_nama.php?nama1=' + nama + '&proses=+Submit%21+',
            }, async function (error, response, body) {
                if (error) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return;
                }
                let $ = cheerio.load(body);
                var y = $.html().split('arti:')[1];
                if (!y) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `Arti nama ${nama} tidak ditemukan.` }, { quoted: m });
                }
                
                var t = y.split('method="get">')[1];
                var f = y.replace(t, " ");
                var x = f.replace(/<br\s*[\/]?>/gi, "\n");
                var h = x.replace(/<[^>]*>?/gm, '');
                
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                await sock.sendMessage(from, { 
                    text: `Arti Dari Nama ${nama} Adalah ${nama}\n\n${h}`.trim() 
                }, { quoted: m });
            });
        }
    } catch (err) {
        // Silent error
    }
};