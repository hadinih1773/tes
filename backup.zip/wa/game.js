const Axios = require("axios");
const fs = require('fs');
const path = require('path');

// Menggunakan global agar data tidak hilang saat file di-reload oleh listener.js
if (!global.activeGames) {
    global.activeGames = new Map();
}

let family100json = null;
let susunkatajson = null;
let tebakbenderajson = null;
let tebakgambarjson = null;
let tebakkatajson = null;
let tebaktebakanjson = null;
let tekatekijson = null;
let siapakahakujson = null;

/**
 * Fungsi Ambil Soal
 */
async function getFamily100() {
    if (!family100json) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json');
            family100json = res.data;
        } catch (error) { return null; }
    }
    return family100json[Math.floor(Math.random() * family100json.length)];
}

async function getSusunKata() {
    if (!susunkatajson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json');
            susunkatajson = res.data;
        } catch (error) { return null; }
    }
    return susunkatajson[Math.floor(Math.random() * susunkatajson.length)];
}

async function getTebakBendera() {
    if (!tebakbenderajson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera2.json');
            tebakbenderajson = res.data;
        } catch (error) { return null; }
    }
    return tebakbenderajson[Math.floor(Math.random() * tebakbenderajson.length)];
}

async function getTebakGambar() {
    if (!tebakgambarjson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json');
            tebakgambarjson = res.data;
        } catch (error) { return null; }
    }
    return tebakgambarjson[Math.floor(Math.random() * tebakgambarjson.length)];
}

async function getTebakKata() {
    if (!tebakkatajson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json');
            tebakkatajson = res.data;
        } catch (error) { return null; }
    }
    return tebakkatajson[Math.floor(Math.random() * tebakkatajson.length)];
}

async function getTebakTebakan() {
    if (!tebaktebakanjson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json');
            tebaktebakanjson = res.data;
        } catch (error) { return null; }
    }
    return tebaktebakanjson[Math.floor(Math.random() * tebaktebakanjson.length)];
}

async function getTekaTeki() {
    if (!tekatekijson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json');
            tekatekijson = res.data;
        } catch (error) { return null; }
    }
    return tekatekijson[Math.floor(Math.random() * tekatekijson.length)];
}

async function getSiapakahAku() {
    if (!siapakahakujson) {
        try {
            const res = await Axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json');
            siapakahakujson = res.data;
        } catch (error) { return null; }
    }
    return siapakahakujson[Math.floor(Math.random() * siapakahakujson.length)];
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        const userPath = path.join(__dirname, '../databasewa/userwa.json');
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        const type = Object.keys(m.message)[0];
        let body = (type === 'conversation') ? m.message.conversation : 
                   (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                   (type === 'imageMessage') ? m.message.imageMessage.caption : '';
        
        const content = body.trim().toLowerCase();

        // =================== CEK USER TERDAFTAR ===================
        if (!fs.existsSync(userPath)) return;
        const registeredUsers = JSON.parse(fs.readFileSync(userPath, "utf-8"));
        const parseJid = (id) => id.replace(/:[0-9]+/g, '');
        if (!registeredUsers.some(v => parseJid(v) === parseJid(sender))) return;

        // =================== COMMAND MULAI GAME ===================
        if (command === "family100") {
            const soalObj = await getFamily100();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            const listJawaban = soalObj.jawaban.map(j => j.toLowerCase().trim());
            const captionSoal = `🎮 *Game Family 100*\n\n*Pertanyaan:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab salah satu jawabannya!_`;
            const sentMsg = await sock.sendMessage(from, { text: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "family100", jawaban: listJawaban, jawabanAsli: soalObj.jawaban });
            return;
        }

        if (command === "susunkata") {
            const soalObj = await getSusunKata();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            const captionSoal = `🎮 *Game Susun Kata*\n\n*Susun Kata Ini:* \`${soalObj.soal}\`\n*Tipe:* ${soalObj.tipe}\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { text: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "susunkata", jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
            return;
        }

        if (command === "tebakbendera") {
            const soalObj = await getTebakBendera();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            let imageUrl = soalObj.img.replace("http://", "https://");
            const captionSoal = `🏳 *Tebak Bendera Negara!*\n\n*Bendera Negara Manakah Ini?*\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { image: { url: imageUrl }, caption: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "tebakbendera", jawaban: soalObj.name.toLowerCase().trim(), jawabanAsli: soalObj.name });
            return;
        }

        if (command === "tebakgambar") {
            const soalObj = await getTebakGambar();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            let imageUrl = soalObj.img.replace("http://", "https://");
            const captionSoal = `🖼️ *Tebak Gambar!*\n\n*Coba Tebak Gambar Apakah Ini?*\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { image: { url: imageUrl }, caption: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "tebakgambar", jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
            return;
        }

        if (command === "tebakkata") {
            const soalObj = await getTebakKata();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            const captionSoal = `🎮 *Game Tebak Kata*\n\n*Soal:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { text: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "tebakkata", jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
            return;
        }

        if (command === "tebaktebakan") {
            const soalObj = await getTebakTebakan();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            const captionSoal = `🎮 *Game Tebak-Tebakan*\n\n*Soal:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { text: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "tebaktebakan", jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
            return;
        }

        if (command === "tekateki") {
            const soalObj = await getTekaTeki();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            const captionSoal = `🎮 *Game Teka-Teki*\n\n*Soal:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { text: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "tekateki", jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
            return;
        }

        if (command === "siapakahaku") {
            const soalObj = await getSiapakahAku();
            if (!soalObj) return;
            await sock.sendMessage(from, { react: { text: "🎮", key: m.key } });
            const captionSoal = `🎮 *Game Siapakah Aku*\n\n*Soal:*\n"${soalObj.soal}"\n\n_Reply pesan ini untuk menjawab!_`;
            const sentMsg = await sock.sendMessage(from, { text: captionSoal }, { quoted: m });
            global.activeGames.set(sentMsg.key.id, { type: "siapakahaku", jawaban: soalObj.jawaban.toLowerCase().trim(), jawabanAsli: soalObj.jawaban });
            return;
        }

        // =================== LOGIKA PENGECEKAN JAWABAN ===================
        const quotedMsg = m.message.extendedTextMessage?.contextInfo;
        if (quotedMsg && quotedMsg.stanzaId) {
            const refId = quotedMsg.stanzaId;
            if (global.activeGames.has(refId)) {
                const gameData = global.activeGames.get(refId);
                const userGuess = content.trim();

                if (gameData.type === "family100") {
                    if (gameData.jawaban.includes(userGuess)) {
                        const teksBenar = `✅ *Jawaban Kamu Benar!*\n\n@${sender.split('@')[0]} Mantap! Jawaban tersebut ada dalam daftar.\n\n*Semua Jawaban:*\n${gameData.jawabanAsli.join(", ")}`;
                        await sock.sendMessage(from, { text: teksBenar, mentions: [sender] }, { quoted: m });
                        global.activeGames.delete(refId);
                    } else {
                        const teksSalah = `❌ *Jawaban Kamu Salah!*\n\nSayang sekali! Jawaban itu tidak ada dalam daftar.\n\n*Jawaban Benar:*\n${gameData.jawabanAsli.join(", ")}`;
                        await sock.sendMessage(from, { text: teksSalah }, { quoted: m });
                        global.activeGames.delete(refId);
                    }
                } else {
                    if (userGuess === gameData.jawaban) {
                        const teksBenar = `✅ *Jawaban Kamu Benar!*\n\n@${sender.split('@')[0]} luar biasa! Jawaban kamu tepat.\n\n*Jawaban:* ${gameData.jawabanAsli.toUpperCase()}`;
                        await sock.sendMessage(from, { text: teksBenar, mentions: [sender] }, { quoted: m });
                        global.activeGames.delete(refId);
                    } else {
                        const teksSalah = `❌ *Jawaban Kamu Salah!*\n\nSalah tu! Coba lagi lain kali.\n\n*Jawaban Sebenarnya:* ${gameData.jawabanAsli.toUpperCase()}`;
                        await sock.sendMessage(from, { text: teksSalah }, { quoted: m });
                        global.activeGames.delete(refId);
                    }
                }
            }
        }
    } catch (err) { console.error("Error Games:", err); }
};