const fs = require("fs");
const path = require("path");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        sock.autosholat = sock.autosholat ? sock.autosholat : {};

        if (!m.message) return;

        const id = jid;
        const who = m.key.participant || m.key.remoteJid;

        if (id in sock.autosholat) {
            return;
        }

        let jadwalSholat = {
            Fajar: "04:30",
            Shubuh: "05:02",
            Dzuhur: "12:23",
            Ashar: "15:03",
            Sunset: "17:54",
            Maghrib: "18:26",
            Isya: "19:34",
            Imsak: "04:30",
            Midnight: "23:55",
            Firstthird: "21:54",
            Lastthird: "01:55"
        };

        const date = new Date((new Date()).toLocaleString("en-US", {
            timeZone: "Asia/Jakarta"
        }));
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;

        for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                let caption = `Hai kak @${who.split('@')[0]},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Jakarta dan sekitarnya._`;
                
                sock.autosholat[id] = [
                    await sock.sendMessage(id, {
                        text: caption,
                        contextInfo: {
                            mentionedJid: [who]
                        }
                    }, { quoted: m }),
                    setTimeout(() => {
                        delete sock.autosholat[id];
                    }, 57000)
                ];
            }
        }
    } catch (err) {
        // Silent error
    }
};
