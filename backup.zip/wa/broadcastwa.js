const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        const userPath = path.join(__dirname, '../databasewa/userwa.json');
        const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');
        const blPath = path.join(__dirname, '../databasewa/blacklistbc.json');

        if (!fs.existsSync(blPath)) fs.writeFileSync(blPath, JSON.stringify([]));

        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        const sender = m.key.participant || m.key.remoteJid;

        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        if (!userDb.includes(sender)) return;

        // Mendukung pengecekan command tanpa prefix dari body asli jika diperlukan, 
        // namun di sini kita gunakan variabel 'command' dari listener.
        const validCommands = ['bc', 'bctagsw', 'bcchat'];
        if (!validCommands.includes(command)) return;

        const ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));
        if (!ownerDb.includes(sender)) {
            return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
        }

        let blacklist = JSON.parse(fs.readFileSync(blPath, 'utf-8'));

        if (args[0]?.toLowerCase() === 'blacklist' && isGroup) {
            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            try {
                if (blacklist.includes(from)) {
                    blacklist = blacklist.filter(id => id !== from);
                    fs.writeFileSync(blPath, JSON.stringify(blacklist));
                    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                    return await sock.sendMessage(from, { text: 'ⓘ Grup dihapus dari blacklist broadcast' }, { quoted: m });
                } else {
                    blacklist.push(from);
                    fs.writeFileSync(blPath, JSON.stringify(blacklist));
                    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                    return await sock.sendMessage(from, { text: 'ⓘ Grup ditambahkan ke blacklist broadcast' }, { quoted: m });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return;
            }
        }

        const groups = Object.keys(await sock.groupFetchAllParticipating());
        const targetGroups = groups.filter(id => !blacklist.includes(id));

        if (command === 'bcchat') {
            const pesan = text;
            if (!pesan) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            try {
                let allMembers = new Set();
                for (let id of targetGroups) {
                    try {
                        const metadata = await sock.groupMetadata(id);
                        metadata.participants.forEach(p => allMembers.add(p.id));
                    } catch (e) { console.error(e); }
                }

                const membersArray = Array.from(allMembers);
                await sock.sendMessage(from, { text: `ⓘ Mengirim pesan ke ${membersArray.length} member...` }, { quoted: m });

                for (let jidDest of membersArray) {
                    try {
                        await sock.sendMessage(jidDest, { text: pesan });
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } catch (e) { console.error(e); }
                }
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                await sock.sendMessage(from, { text: '✅ Broadcast Chat Selesai' }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            }

        } else if (command === 'bctagsw') {
            const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
            const msgImage = m.message.imageMessage || quoted?.imageMessage;
            const msgVideo = m.message.videoMessage || quoted?.videoMessage;
            const teks = text || (quoted?.conversation || quoted?.extendedTextMessage?.text) || "";

            let content = {};
            if (msgImage) {
                await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
                const stream = await downloadContentFromMessage(msgImage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                content = { image: buffer, caption: teks };
            } else if (msgVideo) {
                await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
                const stream = await downloadContentFromMessage(msgVideo, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                content = { video: buffer, caption: teks };
            } else if (teks) {
                await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
                content = { text: teks };
            } else {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks/reply media\`` }, { quoted: m });
            }

            try {
                await sock.sendMessage(from, { text: `ⓘ Mengirim status ke ${targetGroups.length} grup...` }, { quoted: m });

                for (let id of targetGroups) {
                    try {
                        const metadata = await sock.groupMetadata(id);
                        const participants = metadata.participants.map(v => v.id);
                        await sock.sendMessage(id, content, { 
                            backgroundColor: '#25D366', 
                            font: 1, 
                            groupStatus: true, 
                            statusJidList: participants 
                        });
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } catch (e) { console.error(e); }
                }
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                await sock.sendMessage(from, { text: '✅ Broadcast Status Selesai' }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            }

        } else if (command === 'bc') {
            const pesan = text || m.message.extendedTextMessage?.contextInfo?.quotedMessage?.conversation;
            if (!pesan) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} teks/reply pesan\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            try {
                await sock.sendMessage(from, { text: `ⓘ Mengirim broadcast ke ${targetGroups.length} grup...` }, { quoted: m });

                for (let id of targetGroups) {
                    try {
                        await sock.sendMessage(id, { text: pesan });
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } catch (e) { console.error(e); }
                }
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                await sock.sendMessage(from, { text: '✅ Broadcast Selesai' }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            }
        }

    } catch (err) {
        console.error(err);
    }
};