const axios = require('axios');
const fs = require('fs');
const path = require('path');

const userPath = path.join(__dirname, '../databasewa/userwa.json');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        // Mengambil body asli untuk parsing pemisah "|"
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';

        // Cek Registrasi User
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath));
        if (!userDb.includes(sender)) return;

        if (command === 'iqc') {
            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });

            const parts = body.split('|');
            if (parts.length < 4) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, { text: '❌ Format Salah : `.iqc|teks|jam|batre`\n📑 Contoh : `.iqc|Halo Bang|12:00|100`' }, { quoted: m });
            }

            const prompt = parts[1].trim();
            const jam = parts[2].trim();
            const batre = parts[3].trim();

            try {
                const apiUrl = `https://api-faa.my.id/faa/iqcv2?prompt=${encodeURIComponent(prompt)}&jam=${encodeURIComponent(jam)}&batre=${encodeURIComponent(batre)}`;
                
                const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
                
                await sock.sendMessage(from, { 
                    image: Buffer.from(response.data), 
                    caption: '✅ Berhasil membuat gambar' 
                }, { quoted: m });

                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

            } catch (error) {
                console.error('Error IQC:', error.message);
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                await sock.sendMessage(from, { text: '❌ Gagal mengambil gambar dari API. Pastikan format benar.' }, { quoted: m });
            }
        }
    } catch (err) {
        console.error(err);
    }
};