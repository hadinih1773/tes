const fs = require("fs");
const path = require("path");

const userFile = path.join(__dirname, "../databasewa/userwa.json");
const adminFile = path.join(__dirname, "../databasewa/adminwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const isBot = sender === botNumber;

        if (command === 'cc') {
            // CEK USER TERDAFTAR
            if (!fs.existsSync(userFile)) return;
            const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
            if (!userDb.includes(sender) && !isBot) return;

            // CEK ADMIN
            if (!fs.existsSync(adminFile)) return;
            const adminDb = JSON.parse(fs.readFileSync(adminFile, "utf8"));
            if (!adminDb.includes(sender) && !isBot) {
                return sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            }

            // Antisipasi pembungkus pesan agar contextInfo dari media langsung/reply tetap terbaca
            const mainMessage = m.message?.ephemeralMessage?.message || 
                                m.message?.viewOnceMessage?.message || 
                                m.message?.viewOnceMessageV2?.message || 
                                m.message;

            const quoted = mainMessage?.extendedTextMessage?.contextInfo || 
                           mainMessage?.imageMessage?.contextInfo || 
                           mainMessage?.videoMessage?.contextInfo || 
                           mainMessage?.documentMessage?.contextInfo || 
                           mainMessage?.stickerMessage?.contextInfo || 
                           mainMessage?.audioMessage?.contextInfo;

            const mention = quoted?.mentionedJid?.[0];

            // REACTION WAITING
            await sock.sendMessage(from, { react: { text: '🗑', key: m.key } });

            // LOGIKA CC REPLY (Memastikan menghapus pesan yang di reply)
            if (quoted && quoted.stanzaId) {
                const key = {
                    remoteJid: from,
                    fromMe: quoted.participant === botNumber,
                    id: quoted.stanzaId,
                    participant: quoted.participant
                };
                await sock.sendMessage(from, { delete: key });
            } 
            // LOGIKA CC @TAG
            else if (mention) {
                const listMessages = await sock.fetchMessagesFromWAServer({
                    remoteJid: from,
                    count: 50
                }).catch(() => []);

                const userMessages = listMessages.filter(msg => 
                    (msg.key.participant || msg.key.remoteJid) === mention
                ).reverse().slice(0, 5); // Ambil 5 pesan terbaru dari user tersebut

                for (let msg of userMessages) {
                    await sock.sendMessage(from, { 
                        delete: { 
                            remoteJid: from, 
                            fromMe: msg.key.fromMe, 
                            id: msg.key.id, 
                            participant: msg.key.participant || msg.key.remoteJid 
                        } 
                    });
                }
            } else {
                return sock.sendMessage(from, { text: "❌ Reply pesan atau tag orangnya!" }, { quoted: m });
            }

            // REACTION SUKSES
            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        }
    } catch (err) {
        // Silent error
    }
};