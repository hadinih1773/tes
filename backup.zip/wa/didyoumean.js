const fs = require('fs');
const path = require('path');
const didyoumean = require('didyoumean');
const similarity = require('similarity');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

const menuPath = path.join(__dirname, "../databasewa/menuwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const prefix = '.';
        
        // Ambil body teks dari pesan
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';

        // Jika pesan diawali prefix tetapi command tidak terdaftar
        if (body.startsWith(prefix) && command) {
            if (!fs.existsSync(menuPath)) return;
            const menuData = JSON.parse(fs.readFileSync(menuPath, 'utf-8'));
            
            // Mengambil semua list command dari menuwa.json dan menghilangkan prefix titiknya untuk dicocokkan
            let alias = menuData.flatMap(v => v.value).map(cmd => cmd.replace(/^\./, ''));
            
            // Jika command saat ini sudah terdaftar di database menu, abaikan didyoumean
            if (alias.includes(command.toLowerCase())) return;

            let mean = didyoumean(command, alias);
            if (mean && command.toLowerCase() !== mean.toLowerCase()) {
                let sim = similarity(command, mean);
                let similarityPercentage = parseInt(sim * 100);

                // Hanya tampilkan jika kemiripan di atas 40% agar tidak random/spam
                if (similarityPercentage > 40) {
                    const sender = m.sender || (m.key && m.key.participant) || from;
                    const tagUser = `@${sender.split('@')[0]}`;
                    const correctCommand = prefix + mean;

                    let response = `👋 ${tagUser} Apakah Kamu Mencoba Untuk Menggunakan Command Berikut Ini??\n\n🔑 Nama Command : ➠ \`${correctCommand}\` \n📡 Hasil Kemiripan : ➠ *${similarityPercentage}%*`;
                    
                    // Trigger reaksi tanda tanya
                    if (typeof sock.sendMessage === 'function') {
                        await sock.sendMessage(from, { react: { text: "❓", key: m.key } });

                        // Membuat pesan interaktif dengan tombol Copy Command
                        let msg = generateWAMessageFromContent(from, {
                            viewOnceMessage: {
                                message: {
                                    messageContextInfo: {
                                        deviceListMetadata: {},
                                        deviceListMetadataVersion: 2
                                    },
                                    interactiveMessage: proto.Message.InteractiveMessage.create({
                                        body: proto.Message.InteractiveMessage.Body.create({
                                            text: response
                                        }),
                                        footer: proto.Message.InteractiveMessage.Footer.create({
                                            text: ""
                                        }),
                                        header: proto.Message.InteractiveMessage.Header.create({
                                            hasMediaAttachment: false
                                        }),
                                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                            buttons: [
                                                {
                                                    name: "cta_copy",
                                                    buttonParamsJson: JSON.stringify({
                                                        display_text: "Copy Command",
                                                        id: correctCommand,
                                                        copy_code: correctCommand
                                                    })
                                                }
                                            ]
                                        }),
                                        contextInfo: {
                                            mentionedJid: [sender],
                                            quotedMessage: m.message,
                                            participant: sender,
                                            stanzaId: m.key.id
                                        }
                                    })
                                }
                            }
                        }, { quoted: m });

                        await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
                    }
                }
            }
        }
    } catch (err) {
        console.error('Error di didyoumean.js:', err);
    }
};