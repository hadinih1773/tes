const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'sc' || command === 'sourcecode') {
            // Cek Registrasi User (Silent)
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            let tag = `@${sender.split('@')[0]}`;
            let esce = `👋 Hai ${tag} Bot Ini Menggunakan Script Yang Langsung Dibuat Owner. Tapi Jika Kamu Perlu Script Bot Lain Nih Ada Rekomendasi 😜🤔
RTXZY - MD
https://github.com/BOTCAHX/RTXZY-MD
Hydro - MD
https://github.com/AhmadAkbarID/hydro
Ourin - MD
https://github.com/LuckyArch/OurinMD
Terima Kasih ✨✨`;

            await sock.sendMessage(from, { 
                text: esce, 
                mentions: [sender] 
            }, { quoted: m });
        }
    } catch (err) {
        // Silent error
    }
};