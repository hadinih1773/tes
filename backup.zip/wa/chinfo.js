const fs = require("fs");
const path = require("path");
const { proto, generateWAMessageFromContent } = require("@whiskeysockets/baileys");

const userFile = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // CEK USER DAFTAR
        if (!fs.existsSync(userFile)) return;
        const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
        if (!userDb.includes(sender)) return;

        // =====================================================
        //                COMMAND .cekidch
        // =====================================================
        if (command === 'cekidch' || command === 'idch') {
            if (args.length === 0) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            
            const url = args[0];
            if (!url.includes('whatsapp.com/channel/')) {
                return sock.sendMessage(from, { text: '❌ Link tidak valid! Pastikan menggunakan format https://whatsapp.com/channel/KODE' }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });

            try {
                const filterCode = url.match(/channel\/([A-Za-z0-9]{20,24})/)?.[1];
                if (!filterCode) {
                    await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                    return sock.sendMessage(from, { text: '❌ Kode channel tidak ditemukan dalam link!' }, { quoted: m });
                }

                const metadata = await sock.newsletterMetadata('invite', filterCode);

                const channelId = metadata.id;
                const channelState = metadata.state?.type || 'UNKNOWN';
                const creationTime = metadata.thread_metadata?.creation_time;
                const description = metadata.thread_metadata?.description?.text || 'Tidak ada deskripsi';
                const channelName = metadata.thread_metadata?.name?.text || 'Unknown Channel';
                const subscribersCount = metadata.thread_metadata?.subscribers_count || '0';
                const inviteCode = metadata.thread_metadata?.invite || filterCode;

                const formattedSubscribers = parseInt(subscribersCount).toLocaleString('id-ID');
                const createdAt = creationTime ? new Date(creationTime * 1000).toLocaleString('id-ID') : 'Tidak diketahui';

                const teksHasil = `*Nama Channel* : ${channelName}\n*ID Channel* : ${channelId}\n*Dibuat* : ${createdAt}\n*Subscriber* : ${formattedSubscribers}\n*Status* : ${channelState}\n*Link Channel* : https://whatsapp.com/channel/${inviteCode}\n*Deskripsi* : ${description}`;

                let interactiveMsg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text: teksHasil
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                    buttons: [{
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "Copy ID",
                                            copy_code: channelId
                                        })
                                    }]
                                }),
                                contextInfo: {
                                    mentionedJid: [sender],
                                    quotedMessage: m.message
                                }
                            })
                        }
                    }
                }, { userJid: from, quoted: m });

                await sock.relayMessage(from, interactiveMsg.message, { messageId: interactiveMsg.key.id });
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

            } catch (error) {
                console.error(error);
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                await sock.sendMessage(from, { text: '❌ Terjadi kesalahan saat mengambil informasi channel: ' + error.message }, { quoted: m });
            }
        }

    } catch (err) {
        console.error(err);
    }
};