const axios = require("axios");
const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");
const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");
const autoAiPath = path.join(__dirname, "../databasewa/autoai.json");

// Inisialisasi autoai.json jika belum ada
if (!fs.existsSync(autoAiPath)) {
    fs.writeFileSync(autoAiPath, JSON.stringify([], null, 2));
}

const ARNARU_AI_API = 'https://arnaru-ai.vercel.app/api/chat';

async function askAI(question, userId = 'default_user', model = 'claude-sonnet-5', webSearch = false, onStreamUpdate = null) {
    const SYSTEM_PROMPT = "Kamu adalah asisten AI super pintar, andal, dan gaul. Wajib gunakan bahasa kasual Indonesia (gw, lu, bro, legit, dll). TAMPILAN VISUAL ADALAH PRIORITAS UTAMA. Ikuti gaya formatting premium ini:\n1. PENGGUNAAN EMOJI: Gunakan emoji secara rapi dan estetis HANYA di luar blok kode markdown (misal untuk mempertegas judul 🏆, status ✅❌, atau reaksi 💀💥).\n2. DATA TERSTRUKTUR: Saat menyajikan info model, konsep dasar, desain sistem, spesifikasi, statistik, probabilitas, atau rincian spesifik, WAJIB bungkus teks tersebut ke dalam blok kode markdown. Di dalam blok kode, buat tata letak yang sejajar/presisi dan rapi. Gunakan simbol peluru sederhana seperti '-', '✓', atau '→'.\n3. KODE SCRIPT: Jika memberikan source code murni, taruh di blok kode dengan nama bahasanya (contoh blok kode lua, pawn, html).\n4. PEMBATAS & HEADER: Gunakan teks tebal (**teks**) untuk judul di luar blok kode. Gunakan garis pembatas Markdown resmi (---) HANYA untuk memisahkan section besar agar elegan. DILARANG KERAS mengetik deretan garis manual panjang seperti ------- atau =======.\n5. Intinya: Buat respons yang visualnya memanjakan mata, perpaduan pas antara obrolan santai ber-emoji di luar, dan blok data yang rapi/teknis di dalam.";

    const conversationId = `${userId}_session_1`;

    try {
        const payload = {
            question: question,
            model: model,
            conversationId: conversationId,
            systemPrompt: SYSTEM_PROMPT,
            webSearch: webSearch
        };

        const response = await axios.post(ARNARU_AI_API, payload, {
            headers: { 'Content-Type': 'application/json' },
            responseType: 'stream',
            timeout: 60000
        });

        let fullAnswer = "";
        let buffer = "";

        return new Promise((resolve, reject) => {
            response.data.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
                let lines = buffer.split('\n');
                
                buffer = lines.pop();

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const jsonStr = line.substring(6).trim();
                        if (jsonStr === '[DONE]') continue;
                        
                        try {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) {
                                fullAnswer += parsed.answer;
                                let cleanedText = fullAnswer.replace(/[-=_]{3,}/g, '');
                                
                                if (onStreamUpdate) {
                                    onStreamUpdate(cleanedText);
                                }
                            }
                        } catch (e) {}
                    }
                }
            });

            response.data.on('end', () => {
                if (buffer.startsWith('data: ')) {
                    try {
                        const jsonStr = buffer.substring(6).trim();
                        if (jsonStr !== '[DONE]') {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) fullAnswer += parsed.answer;
                        }
                    } catch (e) {}
                }
                
                let finalCleaned = fullAnswer.replace(/[-=_]{3,}/g, '');
                resolve(finalCleaned || "Sori ngab, server AInya lagi ampas nih ga ngasih jawaban bener.");
            });

            response.data.on('error', (err) => reject(err));
        });
    } catch (error) {
        throw new Error(error.response?.data?.error || error.response?.data?.message || error.message);
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        // Ambil body asli untuk logika Auto AI (tanpa prefix)
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : '';

        // Cek Registrasi User
        const userDb = JSON.parse(fs.readFileSync(userPath));
        if (!userDb.includes(sender)) return;

        // 1. Command .ai
        if (command === 'ai') {
            const question = text;
            if (!question) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                await sock.sendPresenceUpdate('composing', from);
                const answer = await askAI(question, sender);
                await sock.sendMessage(from, { text: answer }, { quoted: m });
                return await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                throw err;
            }
        }

        // Command .gemini
        if (command === 'gemini') {
            const question = text;
            if (!question) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                await sock.sendPresenceUpdate('composing', from);
                const answer = await askAI(question, sender);
                await sock.sendMessage(from, { text: answer }, { quoted: m });
                return await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                throw err;
            }
        }

        // 2. Command .autoai (Owner Only)
        if (command === 'autoai') {
            const ownerDb = JSON.parse(fs.readFileSync(ownerPath));
            if (!ownerDb.includes(sender)) return await sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });

            const status = args[0]?.toLowerCase();
            if (!status || (status !== 'on' && status !== 'off')) {
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                let autoAiDb = JSON.parse(fs.readFileSync(autoAiPath));
                if (status === 'on') {
                    if (!autoAiDb.includes(from)) {
                        autoAiDb.push(from);
                        fs.writeFileSync(autoAiPath, JSON.stringify(autoAiDb, null, 2));
                    }
                    await sock.sendMessage(from, { text: "✅ Auto AI telah dihidupkan di grup ini." }, { quoted: m });
                } else if (status === 'off') {
                    autoAiDb = autoAiDb.filter(id => id !== from);
                    fs.writeFileSync(autoAiPath, JSON.stringify(autoAiDb, null, 2));
                    await sock.sendMessage(from, { text: "🗑️ Auto AI telah dimatikan di grup ini." }, { quoted: m });
                }
                return await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                throw err;
            }
        }

        // 3. Logika Auto AI (Tanpa Prefix)
        const autoAiDb = JSON.parse(fs.readFileSync(autoAiPath));
        if (autoAiDb.includes(from) && !body.startsWith('.')) {
            await sock.sendPresenceUpdate('composing', from);
            const answer = await askAI(body, sender);
            return await sock.sendMessage(from, { text: answer }, { quoted: m });
        }

    } catch (err) {
        console.error(err);
    }
};