const axios = require('axios');
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const webp = require('node-webpmux');
const crypto = require('crypto');

/**
 * Fungsi untuk menambahkan Metadata/Exif ke Sticker
 */
async function addExif(webpSticker, packname, author) {
    const img = new webp.Image();
    const json = { 
        'sticker-pack-id': crypto.randomBytes(32).toString('hex'), 
        'sticker-pack-name': packname, 
        'sticker-pack-publisher': author, 
        'emojis': [''] 
    };
    let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
    let jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
    let exif = Buffer.concat([exifAttr, jsonBuffer]);
    exif.writeUIntLE(jsonBuffer.length, 14, 4);
    await img.load(webpSticker);
    img.exif = exif;
    return await img.save(null);
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'smeme') {
            const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
            if (!users.includes(sender)) return;

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            let q = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
            const isImage = q.imageMessage || q.viewOnceMessageV2?.message?.imageMessage || m.message.imageMessage;
            const isSticker = q.stickerMessage || m.message.stickerMessage;

            if (!isImage && !isSticker) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} reply atau kirim gambar/sticker\`\nContoh: \`.${command} Bro|Chill\`` }, { quoted: m });
            }

            const input = text || args.join(' ');
            if (!input || !input.includes('|')) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} reply atau kirim gambar/sticker\`\nContoh: \`.${command} Bro|Chill\`` }, { quoted: m });
            }

            const [top, bottom] = input.split('|').map(s => s.trim());

            try {
                const mediaMsg = q.imageMessage || q.viewOnceMessageV2?.message?.imageMessage || q.stickerMessage || m.message.imageMessage || m.message.stickerMessage;
                const type = isImage ? 'image' : 'sticker';

                const stream = await downloadContentFromMessage(mediaMsg, type);
                let mediaBuffer = Buffer.from([]);
                for await (const chunk of stream) { 
                    mediaBuffer = Buffer.concat([mediaBuffer, chunk]); 
                }

                let imageBuffer = await sharp(mediaBuffer)
                    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
                    .png()
                    .toBuffer();

                let imageUrl;
                const form = new FormData();
                form.append('file', imageBuffer, { filename: 'meme.png', contentType: 'image/png' });
                const uploadRes = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
                    headers: form.getHeaders(),
                    timeout: 30000
                });
                
                if (uploadRes.data?.data?.url) {
                    imageUrl = uploadRes.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
                }

                if (!imageUrl) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: `❌ Gagal upload gambar.` }, { quoted: m });
                }

                const encodeText = (t) => t ? t.replace(/\s+/g, '_').replace(/\?/g, '~q').replace(/\%/g, '~p').replace(/\#/g, '~h').replace(/\//g, '~s') : '_';
                const memeUrl = `https://api.memegen.link/images/custom/${encodeText(top)}/${encodeText(bottom)}.png?background=${imageUrl}`;
                
                const response = await axios.get(memeUrl, { responseType: 'arraybuffer' });
                
                // Konversi hasil meme ke WebP (Sticker)
                const stickerBuffer = await sharp(Buffer.from(response.data))
                    .resize(512, 512)
                    .webp()
                    .toBuffer();

                // Tambahkan Metadata agar informasi sticker muncul
                const finalSticker = await addExif(stickerBuffer, "HC Helper MD", "HadyLua");

                await sock.sendMessage(from, { sticker: finalSticker }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

            } catch (error) {
                console.error('SMEME Error:', error);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                await sock.sendMessage(from, { text: `❌ Terjadi kesalahan.` }, { quoted: m });
            }
        }
    } catch (err) {
        console.error(err);
    }
};