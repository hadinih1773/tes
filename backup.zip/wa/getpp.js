const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        // Definisi path database menggunakan __dirname
        const userPath = path.join(__dirname, '../databasewa/userwa.json');

        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        if (!isGroup) return;

        const sender = m.key.participant || m.key.remoteJid;

        // Pengecekan User Terdaftar (Silent jika tidak terdaftar)
        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        if (!userDb.includes(sender)) return;

        // Command .getpp
        if (command === 'getpp' || command === 'pp') {
            const quoted = m.message.extendedTextMessage?.contextInfo;
            const mention = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            // Menentukan target: dari tag, atau dari reply pesan
            let target = mention || quoted?.participant || quoted?.remoteJid;

            // Jika tidak ada target atau targetnya adalah JID grup itu sendiri tanpa mention/reply
            if (!target || target === from) {
                return await sock.sendMessage(from, { text: '❌ Format Salah : `.getpp @tag/reply pesan`' }, { quoted: m });
            }

            // Reaction ✅ sebagai waiting
            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

            try {
                // Ambil URL Foto Profil, jika gagal/private gunakan foto default pinterest
                const ppUrl = await sock.profilePictureUrl(target, 'image').catch(() => 'https://i.pinimg.com/736x/70/dd/61/70dd612c65034b88ebf474a52ccc70c4.jpg');
                
                await sock.sendMessage(from, { 
                    image: { url: ppUrl }, 
                    caption: `➛ *Akun*: @${target.split('@')[0]}`,
                    mentions: [target]
                }, { quoted: m });
            } catch (e) {
                console.error(e);
            }
        }

    } catch (err) {
        console.error(err);
    }
};