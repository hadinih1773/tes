const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

const REMOVE_BG_KEY = "s5CmtWemsJHj31uriVWfs934";
const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const type = Object.keys(m.message)[0];
        const sender = m.key.participant || m.key.remoteJid;

        // Pengecekan User Daftar
        const userDb = JSON.parse(fs.readFileSync(userPath));
        const isRegistered = userDb.includes(sender);

        if (!isRegistered) return;

        if (command === 'removebg') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const isQuotedImage = type === 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo.quotedMessage?.imageMessage;
            const isImage = type === 'imageMessage';

            if (!isImage && !isQuotedImage) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `⚠️ Kirim gambar atau reply gambar dengan caption .${command} untuk menghapus background!` }, { quoted: m });
            }

            // Download Gambar
            const messageToDownload = isQuotedImage ? m.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : m.message.imageMessage;
            const stream = await downloadContentFromMessage(messageToDownload, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // Convert Buffer to Base64 untuk API
            const base64Image = buffer.toString('base64');

            try {
                const response = await axios({
                    method: 'post',
                    url: "https://api.remove.bg/v1.0/removebg",
                    data: {
                        image_file_b64: base64Image,
                        size: "auto"
                    },
                    headers: {
                        "X-Api-Key": REMOVE_BG_KEY
                    },
                    responseType: 'arraybuffer'
                });

                const resultBuffer = Buffer.from(response.data, "binary");

                await sock.sendMessage(from, { 
                    image: resultBuffer, 
                    caption: "✅ Background Removed! 🎉" 
                }, { quoted: m });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

            } catch (err) {
                console.log(err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                await sock.sendMessage(from, { text: "❌ Gagal menghapus background! Pastikan API Key aktif dan gambar valid." }, { quoted: m });
            }
        }
    } catch (err) {
        console.log(err);
    }
};