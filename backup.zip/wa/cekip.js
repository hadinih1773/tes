const os = require('os');
const fs = require('fs');
const path = require('path');

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        if (command === 'cekip') {
            const from = jid;
            const sender = m.key.participant || m.key.remoteJid;
            
            // Cek Registrasi User
            const userDb = JSON.parse(fs.readFileSync(userPath));
            if (!userDb.includes(sender)) return;

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const networkInterfaces = os.networkInterfaces();
            const result = [];

            for (const interfaceName in networkInterfaces) {
                const addresses = networkInterfaces[interfaceName];
                for (const address of addresses) {
                    if (address.family === 'IPv4' && !address.internal) {
                        result.push({
                            interface: interfaceName,
                            address: address.address,
                            mac: address.mac,
                            netmask: address.netmask
                        });
                    }
                }
            }

            if (result.length === 0) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "❌ Tidak ada interface IP publik ditemukan." }, { quoted: m });
            }

            for (const info of result) {
                const messageText = `*User* : @${sender.split('@')[0]}
*Interface* : ${info.interface}
*IP Address* : ${info.address}
*MAC Address* : ${info.mac}
*Netmask* : ${info.netmask}`;

                const buttonMessage = {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                body: { text: messageText },
                                footer: { text: "IP Checker" },
                                header: { hasMediaAttachment: false },
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "cta_copy",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "Copy IP",
                                                id: "copy_ip",
                                                copy_code: info.address
                                            })
                                        },
                                        {
                                            name: "cta_copy",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "Copy Netmask",
                                                id: "copy_netmask",
                                                copy_code: info.netmask
                                            })
                                        }
                                    ]
                                },
                                contextInfo: {
                                    mentionedJid: [sender]
                                }
                            }
                        }
                    }
                };

                await sock.relayMessage(from, buttonMessage.viewOnceMessage.message, { messageId: m.key.id });
            }

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        }
    } catch (error) {
        console.error('Error in cekip:', error);
        try {
            const from = jid;
            await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
        } catch (reactErr) {
            // Silent catch
        }
    }
};