const fs = require('fs');
const path = require('path');

const sewaPath = path.join(__dirname, '../databasewa/sewawa.json');
const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');
const userPath = path.join(__dirname, '../databasewa/userwa.json');

if (!fs.existsSync(path.join(__dirname, '../databasewa'))) {
    fs.mkdirSync(path.join(__dirname, '../databasewa'), { recursive: true });
}
if (!fs.existsSync(sewaPath)) {
    fs.writeFileSync(sewaPath, JSON.stringify([], null, 2));
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        const sender = m.key.participant || m.key.remoteJid;
        
        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        const ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));
        let sewaDb = JSON.parse(fs.readFileSync(sewaPath, 'utf-8'));

        const isOwner = ownerDb.includes(sender);
        const isUser = userDb.includes(sender);

        if (!isUser) return;

        const isSewa = sewaDb.some(x => typeof x === 'string' ? x === from : x.id === from);
        const isWhitelist = from === '120363407314023936@g.us';

        if (isGroup && !isSewa && !isOwner && !isWhitelist) {
            delete m.message;
            return;
        }

        if (command === 'sewa') {
            if (!isOwner) return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            if (!isGroup) return await sock.sendMessage(from, { text: '❌ Command ini hanya bisa digunakan di dalam grup.' }, { quoted: m });

            let durasi = args[0];
            const existingIndex = sewaDb.findIndex(x => (typeof x === 'string' ? x === from : x.id === from));

            if (!durasi) {
                if (existingIndex !== -1) {
                    sewaDb[existingIndex] = from;
                } else {
                    sewaDb.push(from);
                }
                fs.writeFileSync(sewaPath, JSON.stringify(sewaDb, null, 2));
                return await sock.sendMessage(from, { text: '✅ Berhasil mendaftarkan grup ini ke daftar sewa (Permanen).' }, { quoted: m });
            } else {
                const typeD = durasi.slice(-1).toLowerCase();
                const num = parseInt(durasi);
                if (isNaN(num) || !['s', 'm', 'h', 'd', 'b', 'y'].includes(typeD)) {
                    return await sock.sendMessage(from, { text: '❌ Format Salah : `.sewa atau .sewa waktu`' }, { quoted: m });
                }

                let now = Date.now();
                let expired;
                if (typeD === 's') expired = now + (num * 1000);
                if (typeD === 'm') expired = now + (num * 60 * 1000);
                if (typeD === 'h') expired = now + (num * 60 * 60 * 1000);
                if (typeD === 'd') expired = now + (num * 24 * 60 * 60 * 1000);
                if (typeD === 'b') expired = now + (num * 30 * 24 * 60 * 60 * 1000);
                if (typeD === 'y') expired = now + (num * 365 * 24 * 60 * 60 * 1000);

                const newData = { id: from, expired };
                if (existingIndex !== -1) {
                    sewaDb[existingIndex] = newData;
                } else {
                    sewaDb.push(newData);
                }
                
                fs.writeFileSync(sewaPath, JSON.stringify(sewaDb, null, 2));
                return await sock.sendMessage(from, { text: `✅ Berhasil mendaftarkan grup ini selama ${durasi}.` }, { quoted: m });
            }
        }

        if (command === 'unsewa') {
            if (!isOwner) return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            if (!isGroup) return await sock.sendMessage(from, { text: '❌ Command ini hanya bisa digunakan di dalam grup.' }, { quoted: m });
            
            const filtered = sewaDb.filter(x => (typeof x === 'string' ? x !== from : x.id !== from));
            fs.writeFileSync(sewaPath, JSON.stringify(filtered, null, 2));
            await sock.sendMessage(from, { text: `🗑️ Grup ini telah dihapus dari daftar sewa.` }, { quoted: m });
        }

        if (command === 'delsewa') {
            if (!isOwner) return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            const target = args[0] || from;
            const filtered = sewaDb.filter(x => (typeof x === 'string' ? x !== target : x.id !== target));
            fs.writeFileSync(sewaPath, JSON.stringify(filtered, null, 2));
            await sock.sendMessage(from, { text: `🗑️ Grup \`${target}\` telah dihapus dari daftar sewa.` }, { quoted: m });
            if (target.endsWith('@g.us')) {
                await sock.groupLeave(target);
            }
        }

        if (command === 'listsewa') {
            if (!isOwner) return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            if (sewaDb.length === 0) return await sock.sendMessage(from, { text: '📋 Belum ada grup yang menyewa.' }, { quoted: m });
            let teks = '*📋 DAFTAR SEWA GRUP*\n\n';
            for (let i = 0; i < sewaDb.length; i++) {
                let id = typeof sewaDb[i] === 'string' ? sewaDb[i] : sewaDb[i].id;
                let meta = await sock.groupMetadata(id).catch(() => null);
                teks += `${i + 1}. *${meta ? meta.subject : 'Grup Tidak Terdeteksi'}*\nID: \`${id}\`\nExp: ${sewaDb[i].expired ? new Date(sewaDb[i].expired).toLocaleString() : 'Permanen'}\n\n`;
            }
            await sock.sendMessage(from, { text: teks }, { quoted: m });
        }

        // Cek Expiration
        for (let i = 0; i < sewaDb.length; i++) {
            if (sewaDb[i].expired && Date.now() > sewaDb[i].expired) {
                let targetId = sewaDb[i].id;
                await sock.sendMessage(targetId, { text: '🕘 Sepertinya Masa Sewa Sudah Habis, Saya Pamit Dari Grup 👋. Terima Kasih Telah Menyewa 😅. Hubungi 6282311544652 Jika Ingin Memperpanjang Sewa. 😁' });
                sewaDb.splice(i, 1);
                fs.writeFileSync(sewaPath, JSON.stringify(sewaDb, null, 2));
                await sock.groupLeave(targetId);
            }
        }

    } catch (err) {
        console.error(err);
    }
};
