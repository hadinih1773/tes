const fs = require("fs");
const path = require("path");
const cron = require("node-cron");

const limitPath = path.join(__dirname, "../databasewa/limit.json");
const userPath = path.join(__dirname, "../databasewa/userwa.json");
const menuJsonPath = path.join(__dirname, "../databasewa/menuwa.json");

let currentCron = null;

if (!fs.existsSync(path.dirname(limitPath))) {
    fs.mkdirSync(path.dirname(limitPath), { recursive: true });
}

if (!fs.existsSync(limitPath)) {
    fs.writeFileSync(limitPath, JSON.stringify({ maxLimit: 25, users: {}, groups: {}, resetTime: "05:00", lastExecuted: "" }, null, 2));
}

function readDB(filePath) {
    if (!fs.existsSync(filePath)) return [];
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return [];
    }
}

function writeDB(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const startCron = (sock) => {
    let db = JSON.parse(fs.readFileSync(limitPath, "utf-8"));
    let [hour, minute] = (db.resetTime || "05:00").split(':');
    
    if (currentCron) currentCron.stop();
    
    currentCron = cron.schedule(`${minute} ${hour} * * *`, async () => {
        const now = new Date();
        const hariIni = now.toLocaleDateString('en-GB', { timeZone: 'Asia/Jakarta' });
        let dbData = JSON.parse(fs.readFileSync(limitPath, "utf-8"));
        
        // Cek agar tidak spam (lastExecuted dengan tanggal)
        if (dbData.lastExecuted === hariIni) return;

        for (let jid in dbData.users) {
            dbData.users[jid] = dbData.maxLimit;
        }
        
        dbData.lastExecuted = hariIni;
        writeDB(limitPath, dbData);
        
        const resetMsg = "🛡 Limit Notice\n> Helper MD Telah Mereset Semua Limit Member Kembali Menjadi " + dbData.maxLimit;
        const groups = Object.keys(await sock.groupFetchAllParticipating());
        for (let id of groups) {
            // Hanya kirim ke grup yang limitnya aktif
            if (dbData.groups && dbData.groups[id] === true) {
                await sock.sendMessage(id, { text: resetMsg });
            }
        }
    }, {
        scheduled: true,
        timezone: "Asia/Jakarta"
    });
};

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        if (!currentCron) startCron(sock);

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        const userData = readDB(userPath);
        if (!userData.includes(sender)) return;

        let db = JSON.parse(fs.readFileSync(limitPath, "utf-8"));
        const isOwner = sender === '73577453879303@lid';

        const fullCommand = '.' + command;

        // ================= COMMAND KHUSUS OWNER =================
        const ownerCmds = ['addlimit', 'setmaxlimit', 'resetlimittime', 'resetalllimit', 'limitsistem', 'limitsistemgc'];
        if (ownerCmds.includes(command)) {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            if (!isOwner) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            }

            if (command === 'limitsistem') {
                let status = args[0]?.toLowerCase();
                if (status === 'on') {
                    // Semua grup yang terdaftar menjadi true
                    for (let id in db.groups) {
                        db.groups[id] = true;
                    }
                    writeDB(limitPath, db);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return sock.sendMessage(from, { text: "✅ Sistem Limit Berhasil Diaktifkan Untuk Semua Grup" }, { quoted: m });
                } else if (status === 'off') {
                    // Semua grup yang terdaftar menjadi false
                    for (let id in db.groups) {
                        db.groups[id] = false;
                    }
                    writeDB(limitPath, db);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return sock.sendMessage(from, { text: "✅ Sistem Limit Berhasil Dimatikan Untuk Semua Grup" }, { quoted: m });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });
                }
            }

            if (command === 'limitsistemgc') {
                let status = args[0]?.toLowerCase();
                if (!db.groups) db.groups = {}; 
                if (status === 'on') {
                    db.groups[from] = true;
                    writeDB(limitPath, db);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return sock.sendMessage(from, { text: "✅ Sistem Limit Berhasil Diaktifkan Untuk Grup Ini" }, { quoted: m });
                } else if (status === 'off') {
                    db.groups[from] = false;
                    writeDB(limitPath, db);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return sock.sendMessage(from, { text: "✅ Sistem Limit Berhasil Dimatikan Untuk Grup Ini" }, { quoted: m });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} on/off\`` }, { quoted: m });
                }
            }

            if (command === 'addlimit') {
                let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant || args[0];
                let jumlah = parseInt(args[1]);
                if (!target || isNaN(jumlah)) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} @tag/reply pesan/id jumlah\`` }, { quoted: m });
                }
                if (db.users[target] === undefined) db.users[target] = db.maxLimit;
                db.users[target] += jumlah; 
                writeDB(limitPath, db);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: `✅ Berhasil menambah ${jumlah} limit ke ${target.split('@')[0]}` }, { quoted: m });
            }

            if (command === 'setmaxlimit') {
                let newMax = parseInt(args[0]);
                if (isNaN(newMax)) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} jumlah\`` }, { quoted: m });
                }
                db.maxLimit = newMax;
                writeDB(limitPath, db);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: `✅ Max Limit Global diubah menjadi: ${newMax}` }, { quoted: m });
            }

            if (command === 'resetlimittime') {
                let time = args[0];
                if (!time || !time.includes(':')) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} waktu\`` }, { quoted: m });
                }
                db.resetTime = time;
                writeDB(limitPath, db);
                startCron(sock); 
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: `✅ Waktu reset limit diubah menjadi: ${time} WIB` }, { quoted: m });
            }

            if (command === 'resetalllimit') {
                for (let jid in db.users) db.users[jid] = db.maxLimit;
                writeDB(limitPath, db);
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                return sock.sendMessage(from, { text: "✅ Berhasil Reset Semua Limit" }, { quoted: m });
            }
        }

        if (command === 'mylimit') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            if (db.users[sender] === undefined) {
                db.users[sender] = db.maxLimit;
                writeDB(limitPath, db);
            }
            const sisaLimit = db.users[sender];
            const myLimitMsg = `🎉 [ *Limit Notice* ] 🎉\n> 🗿 : Sisa Limit Kamu Tinggal ${sisaLimit}\n> 📜 : Makanya Jangan Salah Command Dan Boros`;
            await sock.sendMessage(from, { text: myLimitMsg }, { quoted: m });
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            return;
        }

        // ================= PENGECEKAN STATUS AKTIF (Berdasarkan Grup) =================
        if (db.groups && db.groups[from] === false) return;

        if (!isOwner) {
            if (db.users[sender] === undefined) {
                db.users[sender] = db.maxLimit;
                writeDB(limitPath, db);
            }

            if (db.users[sender] <= 0) {
                return; 
            }
        }

        const menuData = readDB(menuJsonPath);
        const allValidCommands = [];
        menuData.forEach(menu => {
            menu.value.forEach(cmdStr => {
                allValidCommands.push(cmdStr.toLowerCase().trim());
            });
        });

        const extraCmds = ['.allmenu', '.categoryhc', '.menu', '.help', '.mylimit', '.daftar'];
        menuData.forEach(menuItem => extraCmds.push('.' + menuItem.id.toLowerCase()));
        
        if (!allValidCommands.includes(fullCommand) && !extraCmds.includes(fullCommand)) return;

        // ================= PENGURANGAN LIMIT =================
        if (!isOwner) {
            if (command === 'menu' || command === 'help' || command === 'mylimit') return;
            
            db.users[sender] -= 1;
            writeDB(limitPath, db);
            
            const limitMsg = `🎉 [ *Limit Notice* ] 🎉
> 👤 User : @${sender.split('@')[0]}
> 🎉 Limit : ${db.users[sender]}
> 📜 Note : Jangan Boros Menggunakan Command
> Jangan Sampai Salah Commandnya`;
            
            setTimeout(() => {
                sock.sendMessage(from, { text: limitMsg, mentions: [sender] }, { quoted: m });
            }, 4000);
        }

    } catch (err) {
        console.error("Module Error: ", err);
    }
};