const { downloadContentFromMessage, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { uploadToTelegraph, uploadTo0x0, uploadToTmpfiles, uploadToCatbox } = require('../lib/uploader');

// Fungsi Hady Uploader
async function uploadHady(buffer, filename) {
  const form = new FormData();
  form.append('file', buffer, filename);

  const res = await axios.post('https://hadytools.vercel.app/api/uploader', form, {
    headers: form.getHeaders()
  });

  return res.data.result.url;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const type = Object.keys(m.message)[0];

        // Cek Pendaftaran User
        const userPath = path.join(__dirname, '../databasewa/userwa.json');
        if (!fs.existsSync(userPath)) return;
        const registeredUsers = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        if (!registeredUsers.includes(sender)) return;

        if (command === 'tourl') {
            const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
            
            // Deteksi jenis media (Gambar, Video, Sticker, Audio, atau Document)
            const isMedia = /imageMessage|videoMessage|stickerMessage|audioMessage|documentMessage/.test(type) || 
                            /imageMessage|videoMessage|stickerMessage|audioMessage|documentMessage/.test(Object.keys(quoted || {})[0]);

            if (!isMedia) {
                return await sock.sendMessage(from, { text: `⚠️ Reply Gambar/Video/Audio/Sticker` }, { quoted: m });
            }

            // Reaction Emoji ⏱️
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                // Download Media
                const messageType = quoted ? Object.keys(quoted)[0] : type;
                const mediaContent = quoted ? quoted[messageType] : m.message[messageType];
                
                const stream = await downloadContentFromMessage(mediaContent, messageType.replace('Message', ''));
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                // Hitung Ukuran File
                const size = buffer.length;
                const fileSize = size < 1024 * 1024 
                    ? (size / 1024).toFixed(2) + ' KB' 
                    : (size / (1024 * 1024)).toFixed(2) + ' MB';

                // Nama File Random berdasarkan format asli atau default jpg
                const extension = mediaContent.mimetype ? mediaContent.mimetype.split('/')[1].split(';')[0] : 'jpg';
                const fileName = `upload_${Date.now()}.${extension}`;
                
                // Proses Upload ke berbagai layanan
                let results = {};
                try { results.catbox = await uploadToCatbox(buffer, fileName); } catch (e) { results.catbox = "❌ Eror"; }
                try { results.telegraph = await uploadToTelegraph(buffer, fileName); } catch (e) { results.telegraph = "❌ Eror"; }
                try { results.tmpfiles = await uploadToTmpfiles(buffer, fileName); } catch (e) { results.tmpfiles = "❌ Eror"; }
                try { results.oxo = await uploadTo0x0(buffer, fileName); } catch (e) { results.oxo = "❌ Eror"; }
                try { results.hady = await uploadHady(buffer, fileName); } catch (e) { results.hady = "❌ Eror"; }

                // Buat Caption
                let caption = `*Penggunggah* : @${sender.split('@')[0]}\n*Ukuran* : ${fileSize}\n\n`;
                caption += `*Catbox* : ${results.catbox}\n`;
                caption += `*Telegraph* : ${results.telegraph}\n`;
                caption += `*Tmpfiles* : ${results.tmpfiles}\n`;
                caption += `*Oxo* : ${results.oxo}\n`;
                caption += `*Hady Tools* : ${results.hady}\n`;

                // Buat List Button secara dinamis (Hanya muncul jika bukan "❌ Eror")
                const buttons = [];
                if (results.catbox !== "❌ Eror") {
                    buttons.push({
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({ display_text: "Copy Catbox", copy_code: results.catbox })
                    });
                }
                if (results.telegraph !== "❌ Eror") {
                    buttons.push({
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({ display_text: "Copy Telegraph", copy_code: results.telegraph })
                    });
                }
                if (results.tmpfiles !== "❌ Eror") {
                    buttons.push({
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({ display_text: "Copy Tmpfiles", copy_code: results.tmpfiles })
                    });
                }
                if (results.oxo !== "❌ Eror") {
                    buttons.push({
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({ display_text: "Copy Oxo", copy_code: results.oxo })
                    });
                }
                if (results.hady !== "❌ Eror") {
                    buttons.push({
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({ display_text: "Copy Hady Tools", copy_code: results.hady })
                    });
                }

                let msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.fromObject({
                                    text: caption
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                    buttons: buttons
                                }),
                                contextInfo: {
                                    mentionedJid: [sender],
                                    quotedMessage: m.message
                                }
                            })
                        }
                    }
                }, { userJid: from, quoted: m });

                await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (error) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                console.error(error);
            }
        }
    } catch (err) {
        console.error('Error tourl:', err);
    }
};