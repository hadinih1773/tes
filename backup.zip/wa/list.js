const fs = require('fs');
const path = require('path');

module.exports = async (sock, m, { jid, command, args }) => {
    try {
        const sender = m.key.participant || m.key.remoteJid;
        const parseJid = (id) => id.replace(/:[0-9]+/g, '');
        const senderClean = parseJid(sender);

        // Path database
        const adminPath = path.join(__dirname, "../databasewa/adminwa.json");
        const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");
        const banPath = path.join(__dirname, "../databasewa/banuser.json");
        const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

        // Load Data
        const adminData = fs.existsSync(adminPath) ? JSON.parse(fs.readFileSync(adminPath, "utf-8")) : [];
        const ownerData = fs.existsSync(ownerPath) ? JSON.parse(fs.readFileSync(ownerPath, "utf-8")) : [];

        // Cek Izin (Admin atau Owner)
        const isAdmin = adminData.some(v => parseJid(v) === senderClean);
        const isOwner = ownerData.some(v => parseJid(v) === senderClean);

        if (command === 'listban') {
            if (!isAdmin && !isOwner) {
                return await sock.sendMessage(jid, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            }
            const banData = fs.existsSync(banPath) ? JSON.parse(fs.readFileSync(banPath, "utf-8")) : [];
            if (banData.length === 0) return await sock.sendMessage(jid, { text: "Data ban kosong." }, { quoted: m });

            let caption = `*List Banned User Helper MD*\n\n`;
            let mentions = [];
            banData.forEach((v) => {
                caption += `🚫 @${v.split('@')[0]}\n🆔 ${v}\n\n`;
                mentions.push(v);
            });
            await sock.sendMessage(jid, { text: caption.trim(), mentions: mentions }, { quoted: m });
        }

        if (command === 'listdaftar') {
            if (!isAdmin && !isOwner) {
                return await sock.sendMessage(jid, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            }
            const userData = fs.existsSync(userDbPath) ? JSON.parse(fs.readFileSync(userDbPath, "utf-8")) : [];
            if (userData.length === 0) return await sock.sendMessage(jid, { text: "Data user kosong." }, { quoted: m });

            let caption = `*List Daftar User Helper MD*\n\n`;
            let mentions = [];
            userData.forEach((v) => {
                caption += `✅ @${v.split('@')[0]}\n🆔 ${v}\n\n`;
                mentions.push(v);
            });
            await sock.sendMessage(jid, { text: caption.trim(), mentions: mentions }, { quoted: m });
        }

    } catch (err) {
        console.error('Error di list.js:', err);
    }
};