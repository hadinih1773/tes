const fs = require("fs");
const path = require("path");

const userFile = path.join(__dirname, "../databasewa/userwa.json");
const ownerFile = path.join(__dirname, "../databasewa/ownerwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        // Perbaikan pengambilan body agar mendukung pesan biasa dan quoted message
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : 
                     (type === 'imageMessage') ? m.message.imageMessage.caption : 
                     (type === 'videoMessage') ? m.message.videoMessage.caption : '';

        if (!fs.existsSync(userFile)) return;
        const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
        if (!userDb.includes(sender)) return;

        const targetOwner = "73577453879303@lid";

        const folders = [
            '../wa', '../fitur', '../slashcommands', '../owner', '../scrape',
            '../databasewa', '../database', '../protect', '../databasetele',
            '../tele', '../dc', '../lib', '../game', '../economy', '../all', '../slashall'
        ];

        if (command === "getfile" || command === "gf") {
            if (sender !== targetOwner) return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            if (args.length === 0) return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} nama file\`` }, { quoted: m });

            const fileName = args[0];
            let filePath = path.resolve(__dirname, '..', fileName);

            if (!fs.existsSync(filePath)) {
                for (let folder of folders) {
                    let tempPath = path.join(__dirname, folder, fileName);
                    if (fs.existsSync(tempPath)) {
                        filePath = tempPath;
                        break;
                    }
                }
            }

            if (!fs.existsSync(filePath)) {
                return sock.sendMessage(from, { text: `❌ File tidak ditemukan: ${fileName}` }, { quoted: m });
            }

            const stats = fs.statSync(filePath);
            if (stats.isDirectory()) {
                return sock.sendMessage(from, { text: `❌ ${fileName} adalah sebuah folder.` }, { quoted: m });
            }

            const content = fs.readFileSync(filePath, "utf8");
            await sock.sendMessage(from, { text: content }, { quoted: m });
            await sock.sendMessage(from, {
                document: fs.readFileSync(filePath),
                fileName: path.basename(filePath),
                mimetype: 'application/javascript'
            }, { quoted: m });
        }

        if (command === "update" || command === "up" || command === "updateplugin") {
            if (sender !== targetOwner) return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            const parts = body.split('|');
            if (parts.length < 3) return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command}|nama file|kode baru\`` }, { quoted: m });

            const fileName = parts[1].trim();
            const newContent = parts.slice(2).join('|'); 
            let filePath = path.resolve(__dirname, '..', fileName);

            if (!fs.existsSync(filePath)) {
                for (let folder of folders) {
                    let tempPath = path.join(__dirname, folder, fileName);
                    if (fs.existsSync(tempPath)) {
                        filePath = tempPath;
                        break;
                    }
                }
            }

            if (!fs.existsSync(filePath)) {
                return sock.sendMessage(from, { text: `❌ File tidak ditemukan: ${fileName}` }, { quoted: m });
            }

            fs.writeFileSync(filePath, newContent, "utf8");
            await sock.sendMessage(from, { text: `✅ Berhasil update file: ${fileName}` }, { quoted: m });
        }

        if (command === "rnmfile" || command === "rnm" || command === "rp" || command === "renameplugin") {
            if (sender !== targetOwner) return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            const parts = body.split('|');
            if (parts.length < 3) return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command}|nama file|nama baru\`` }, { quoted: m });

            const oldName = parts[1].trim();
            const newName = parts[2].trim();
            let oldPath = path.resolve(__dirname, '..', oldName);

            if (!fs.existsSync(oldPath)) {
                for (let folder of folders) {
                    let tempPath = path.join(__dirname, folder, oldName);
                    if (fs.existsSync(tempPath)) {
                        oldPath = tempPath;
                        break;
                    }
                }
            }

            if (!fs.existsSync(oldPath)) {
                return sock.sendMessage(from, { text: `❌ File tidak ditemukan: ${oldName}` }, { quoted: m });
            }

            const newPath = path.join(path.dirname(oldPath), newName);
            fs.renameSync(oldPath, newPath);
            await sock.sendMessage(from, { text: `✅ Berhasil rename file dari ${oldName} menjadi ${newName}` }, { quoted: m });
        }

        if (command === "delfile" || command === "del" || command === "dp" || command === "deleteplugin") {
            if (sender !== targetOwner) return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            if (args.length === 0) return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} nama file\`` }, { quoted: m });

            const fileName = args[0];
            let filePath = path.resolve(__dirname, '..', fileName);

            if (!fs.existsSync(filePath)) {
                for (let folder of folders) {
                    let tempPath = path.join(__dirname, folder, fileName);
                    if (fs.existsSync(tempPath)) {
                        filePath = tempPath;
                        break;
                    }
                }
            }

            if (!fs.existsSync(filePath)) {
                return sock.sendMessage(from, { text: `❌ File tidak ditemukan: ${fileName}` }, { quoted: m });
            }

            fs.unlinkSync(filePath);
            await sock.sendMessage(from, { text: `✅ Berhasil menghapus file: ${fileName}` }, { quoted: m });
        }

        if (command === "listfile" || command === "lp" || command === "listplugin") {
            if (sender !== targetOwner) return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });

            let files = [];
            const mainDirFiles = fs.readdirSync(path.resolve(__dirname, '..'));
            mainDirFiles.forEach(f => {
                if (!fs.statSync(path.join(__dirname, '..', f)).isDirectory()) files.push(f);
            });

            for (let folder of folders) {
                const folderPath = path.resolve(__dirname, folder);
                if (fs.existsSync(folderPath)) {
                    const items = fs.readdirSync(folderPath);
                    items.forEach(item => {
                        const fullPath = path.join(folderPath, item);
                        if (!fs.statSync(fullPath).isDirectory()) {
                            files.push(`${folder.replace('../', '')}/${item}`);
                        }
                    });
                }
            }

            let listMsg = "*List Nama File Script Bot*\n";
            files.forEach(f => {
                listMsg += `➣ ${f}\n`;
            });

            await sock.sendMessage(from, { text: listMsg }, { quoted: m });
        }

        if (command === "addfile" || command === "ap" || command === "addplugin") {
            if (sender !== targetOwner) return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });

            const parts = body.split('|');
            let filePath;
            let fileName;
            let kode;

            if (parts.length >= 4) {
                const folderInput = parts[1].trim();
                fileName = parts[2].trim();
                kode = parts.slice(3).join('|');
                filePath = path.resolve(__dirname, folderInput, fileName);
            } else if (parts.length === 3) {
                fileName = parts[1].trim();
                kode = parts.slice(2).join('|');
                filePath = path.resolve(__dirname, '..', fileName);
            } else {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command}|tempat file|nama file|kode\`` }, { quoted: m });
            }

            const dir = path.dirname(filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            fs.writeFileSync(filePath, kode, "utf8");
            await sock.sendMessage(from, { text: `✅ Berhasil menambah file: ${fileName}\nLokasi: ${filePath}` }, { quoted: m });
        }

    } catch (err) {
        console.error(err);
        if (jid) sock.sendMessage(jid, { text: `❌ Terjadi Error: ${err.message}` }, { quoted: m });
    }
};