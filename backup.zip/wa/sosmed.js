const axios = require("axios");
const cheerio = require("cheerio");
const qs = require("qs");
const https = require('https');
const FormData = require("form-data");
const fs = require("fs");
const path = require("path");
const yts = require("yt-search");
const { spawn } = require("child_process");

const agent = new https.Agent({
    rejectUnauthorized: true,
    maxVersion: 'TLSv1.3',
    minVersion: 'TLSv1.2'
});

/* ================= ENGINE FUNCTIONS ================= */

function toPTT(buffer) {
    return new Promise((resolve, reject) => {
        let ffmpeg = spawn('ffmpeg', [
            '-i', 'pipe:0',
            '-vn',
            '-c:a', 'libopus',
            '-b:a', '128k',
            '-vbr', 'on',
            '-f', 'ogg',
            'pipe:1'
        ]);
        let buffers = [];
        ffmpeg.stdout.on('data', (chunk) => buffers.push(chunk));
        ffmpeg.stderr.on('data', (err) => {}); // Silent error ffmpeg
        ffmpeg.on('close', () => resolve(Buffer.concat(buffers)));
        ffmpeg.on('error', (err) => reject(err));
        ffmpeg.stdin.write(buffer);
        ffmpeg.stdin.end();
    });
}

async function CatBox(url) {
    try {
        const resBuffer = await axios.get(url, { 
            responseType: 'arraybuffer', 
            timeout: 0,
            headers: {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
            }
        });
        
        const buffer = Buffer.from(resBuffer.data);
        const formData = new FormData();
        formData.append('fileToUpload', buffer, { filename: 'thumbnail.jpg' });
        formData.append('reqtype', 'fileupload');
        formData.append('userhash', '');
        
        const response = await axios.post('https://catbox.moe/user/api.php', formData, {
            headers: { ...formData.getHeaders() },
            timeout: 0
        });
        
        return response.data;
    } catch (error) {
        console.error("Uploader Error: ", error.message);
        return url;
    }
}

async function getToken() {
    const res = await axios.get('https://savett.cc/en1/download')
    return {
        csrf: res.data.match(/name="csrf_token" value="([^"]+)"/)?.[1],
        cookie: res.headers['set-cookie'].map(v => v.split(';')[0]).join('; ')
    }
}

async function savett(url) {
    const { csrf, cookie } = await getToken()
    const res = await axios.post(
        'https://savett.cc/en1/download',
        `csrf_token=${encodeURIComponent(csrf)}&url=${encodeURIComponent(url)}`,
        { 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                Origin: 'https://savett.cc',
                Referer: 'https://savett.cc/en1/download',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, Bird/537.36',
                Cookie: cookie 
            } 
        }
    )
    
    const $ = cheerio.load(res.data)
    const stats = []
    $('#video-info .my-1 span').each((_, el) => { stats.push($(el).text().trim()) })

    const data = {
        username: $('#video-info h3').first().text().trim(),
        type: null,
        downloads: { nowm: [] },
        mp3: [],
        slides: []
    }

    const slides = $('.carousel-item[data-data]')
    if (slides.length) {
        data.type = 'photo'
        slides.each((_, el) => {
            try {
                const json = JSON.parse($(el).attr('data-data').replace(/&quot;/g, '"'))
                if (Array.isArray(json.URL)) {
                    json.URL.forEach(url => { data.slides.push({ url }) })
                }
            } catch {}
        })
        return data
    }

    data.type = 'video'
    $('#formatselect option').each((_, el) => {
        const label = $(el).text().toLowerCase()
        const raw = $(el).attr('value')
        if (!raw) return
        try {
            const json = JSON.parse(raw.replace(/&quot;/g, '"'))
            if (label.includes('mp4') && !label.includes('watermark')) data.downloads.nowm.push(...json.URL)
            if (label.includes('mp3')) data.mp3.push(...json.URL)
        } catch {}
    })
    return data
}

async function tiktokdl(url) {
    const res = await axios.get(`https://velynapi.vercel.app/api/downloader/tiktok?url=${encodeURIComponent(url)}`, { timeout: 0 });
    return res.data.data;
}

async function pinterest(query) {
	return new Promise(async (resolve, reject) => {
		const baseUrl = 'https://www.pinterest.com/resource/BaseSearchResource/get/';
		const params = {
			source_url: '/search/pins/?q=' + encodeURIComponent(query),
			data: JSON.stringify({
				options: {
					isPrefetch: false,
					query,
					scope: 'pins',
					no_fetch_context_on_resource: false
				},
				context: {}
			}),
			_: Date.now()
		};
		const headers = {
			'accept': 'application/json, text/javascript, */*, q=0.01',
			'accept-encoding': 'gzip, deflate',
			'accept-language': 'en-US,en;q=0.9',
			'dnt': '1',
			'referer': 'https://www.pinterest.com/',
			'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
			'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',
			'sec-ch-ua-mobile': '?0',
			'sec-ch-ua-model': '""',
			'sec-ch-ua-platform': '"Windows"',
			'sec-ch-ua-platform-version': '"10.0.0"',
			'sec-fetch-dest': 'empty',
			'sec-fetch-mode': 'cors',
			'sec-fetch-site': 'same-origin',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',
			'x-app-version': 'c056fb7',
			'x-pinterest-appstate': 'active',
			'x-pinterest-pws-handler': 'www/[username]/[slug].js',
			'x-pinterest-source-url': '/hargr003/cat-pictures/',
			'x-requested-with': 'XMLHttpRequest'
		};
		try {
			const { data } = await axios.get(baseUrl, { httpsAgent: agent, headers, params });
			const results = data.resource_response?.data?.results?? [];
			const result = results.map(item => ({
				pin: 'https://www.pinterest.com/pin/' + item.id?? '',
				link: item.link?? '',
				created_at: (new Date(item.created_at)).toLocaleDateString('id-ID', {
					day: 'numeric',
					month: 'long',
					year: 'numeric'
				}) ?? '',
				id: item.id?? '',
				images_url: item.images?.['736x']?.url?? '',
				grid_title: item.grid_title?? ''
			}));
			resolve(result);
		} catch (e) {
			reject([])
		}
	});
}

/* ================= MODULE SETUP ================= */

module.exports = async (sock, m, { jid, text, command, args }) => {
    const { generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys");
    const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

    try {
        if (!m.message) return;
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
        if (!users.includes(sender)) return;

        // 1. .yts (CAROUSEL)
        if (command === 'yts') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} judul\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });
            
            const resYts = await yts(text);
            const data = resYts.all.filter(v => v.type === "video");
            if (!data || data.length === 0) return;

            let cards = [];
            for (let i = 0; i < Math.min(data.length, 10); i++) {
                const v = data[i];
                const media = await prepareWAMessageMedia({ image: { url: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg` } }, { upload: sock.waUploadToServer });
                cards.push({
                    body: { text: `🎬 *${v.title}*\n👤 *Channel:* ${v.author.name || 'Unknown'}\n🕒 *Duration:* ${v.timestamp}\n🔗 YouTube Url : ${v.url}` },
                    footer: { text: 'YouTube Search Results' },
                    header: {
                        hasMediaAttachment: true,
                        ...media
                    },
                    nativeFlowMessage: {
                        buttons: []
                    }
                });
            }

            const msg = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🔍 Hasil pencarian YouTube untuk *${text}*` },
                            carouselMessage: { cards }
                        }
                    }
                }
            }, { quoted: m });

            await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
        }

        // 2. .ytdl alias .yt
        if (command === 'ytdl' || command === 'yt') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const resMp4 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(text)}`, { timeout: 0 });
                const resMp3 = await axios.get(`https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(text)}`, { timeout: 0 });
                await sock.sendMessage(from, { video: { url: resMp4.data.data.url }, caption: `\`𝗬 𝗢 𝗨 𝗧 𝗨 𝗕 𝗘 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                
                const resAudio = await axios.get(resMp3.data.result.mp3, { responseType: 'arraybuffer' });
                const audioBuffer = await toPTT(Buffer.from(resAudio.data));
                await sock.sendMessage(from, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
                
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .ytmp3
        if (command === 'ytmp3') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const resMp3 = await axios.get(`https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(text)}`, { timeout: 0 });
                
                const resAudio = await axios.get(resMp3.data.result.mp3, { responseType: 'arraybuffer' });
                const audioBuffer = await toPTT(Buffer.from(resAudio.data));
                await sock.sendMessage(from, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true, caption: `\`𝗬 𝗧 𝗠 𝗣 𝟯 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .ytmp4
        if (command === 'ytmp4') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const resMp4 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(text)}`, { timeout: 0 });
                await sock.sendMessage(from, { video: { url: resMp4.data.data.url }, caption: `\`𝗬 𝗧 𝗠 𝗣 𝟰 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 3. .tts (CAROUSEL)
        if (command === 'tts') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} judul\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });
            const res = await axios.get(`https://velynapi.vercel.app/api/search/tiktoksearch?query=${encodeURIComponent(text)}`, { timeout: 0 });
            const results = res.data.data;

            let cards = [];
            for (let i = 0; i < Math.min(results.length, 10); i++) {
                const v = results[i];
                const media = await prepareWAMessageMedia({ image: { url: v.cover } }, { upload: sock.waUploadToServer });
                cards.push({
                    body: { text: `🎵 *${v.title}*\n👤 *Creator:* ${v.music.author}\n💬 *Comment:* ${v.comment_count}\n🔗 TikTok Url : ${v.link}` },
                    footer: { text: 'TikTok Search Results' },
                    header: {
                        hasMediaAttachment: true,
                        ...media
                    },
                    nativeFlowMessage: {
                        buttons: []
                    }
                });
            }

            const msg = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🔍 Hasil pencarian TikTok untuk *${text}*` },
                            carouselMessage: { cards }
                        }
                    }
                }
            }, { quoted: m });

            await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
        }

        // 4. .ttdl alias .tt
        if (command === 'ttdl' || command === 'tt') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            
            try {
                const result = await savett(text);
                
                if (result.type === 'photo') {
                    let cards = [];
                    for (let i = 0; i < Math.min(result.slides.length, 10); i++) {
                        const media = await prepareWAMessageMedia({ image: { url: result.slides[i].url } }, { upload: sock.waUploadToServer });
                        cards.push({
                            body: { text: `📸 TikTok Slide ${i + 1}` },
                            header: { hasMediaAttachment: true, ...media },
                            nativeFlowMessage: { buttons: [] }
                        });
                    }
                    const msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: {
                                    body: { text: `✅ *Done kak*\n👤 *${result.username}*` },
                                    carouselMessage: { cards }
                                }
                            }
                        }
                    }, { quoted: m });
                    await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
                    
                    if (result.mp3.length > 0) {
                        const resAudio = await axios.get(result.mp3[0], { responseType: 'arraybuffer' });
                        const audioBuffer = await toPTT(Buffer.from(resAudio.data));
                        await sock.sendMessage(from, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
                    }
                    
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    const data = await tiktokdl(text);
                    await sock.sendMessage(from, { video: { url: data.no_watermark }, caption: `\`𝗧 𝗜 𝗞 𝗧 𝗢 𝗞 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                    
                    const resAudio = await axios.get(data.music, { responseType: 'arraybuffer' });
                    const audioBuffer = await toPTT(Buffer.from(resAudio.data));
                    await sock.sendMessage(from, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
                    
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .ttmp3
        if (command === 'ttmp3') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const data = await tiktokdl(text);
                
                const resAudio = await axios.get(data.music, { responseType: 'arraybuffer' });
                const audioBuffer = await toPTT(Buffer.from(resAudio.data));
                await sock.sendMessage(from, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true, caption: `\`𝗧 𝗧 𝗠 𝗣 𝟯 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .ttmp4
        if (command === 'ttmp4') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const data = await tiktokdl(text);
                await sock.sendMessage(from, { video: { url: data.no_watermark }, caption: `\`𝗧 𝗧 𝗠 𝗣 𝟰 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // 5. .igdl alias .ig
        if (command === 'igdl' || command === 'ig') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const res = await axios.get(`https://velynapi.vercel.app/api/downloader/instagram?url=${encodeURIComponent(text)}`, { timeout: 0 });
                const mediaUrls = res.data.data.url;

                if (Array.isArray(mediaUrls) && mediaUrls.length > 1) {
                    let cards = [];
                    for (let i = 0; i < Math.min(mediaUrls.length, 10); i++) {
                        const media = await prepareWAMessageMedia({ image: { url: mediaUrls[i] } }, { upload: sock.waUploadToServer });
                        cards.push({
                            body: { text: `📸 Instagram Image ${i + 1}` },
                            footer: { text: 'Instagram Downloader' },
                            header: {
                                hasMediaAttachment: true,
                                ...media
                            },
                            nativeFlowMessage: {
                                buttons: []
                            }
                        });
                    }

                    const msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: {
                                    body: { text: `\`𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` },
                                    carouselMessage: { cards }
                                }
                            }
                        }
                    }, { quoted: m });

                    await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
                } else {
                    const singleUrl = Array.isArray(mediaUrls) ? mediaUrls[0] : mediaUrls;
                    await sock.sendMessage(from, { video: { url: singleUrl }, caption: `\`𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                }
                
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // 6. .pinterest & .pin (CAROUSEL)
        if (command === 'pinterest' || command === 'pin') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });
            const results = await pinterest(text);
            const data = results.slice(0, 10);
            if (!data || data.length === 0) return;
            
            let cards = [];
            for (let i = 0; i < data.length; i++) {
                const v = data[i];
                const media = await prepareWAMessageMedia({ image: { url: v.images_url } }, { upload: sock.waUploadToServer });
                cards.push({
                    body: { text: `📌 *Title:* ${v.grid_title || 'Pinterest Image'}\n📅 *Created:* ${v.created_at}\n🔗 Pinterest Url : ${v.pin}` },
                    footer: { text: 'Pinterest Search Results' },
                    header: {
                        hasMediaAttachment: true,
                        ...media
                    },
                    nativeFlowMessage: {
                        buttons: []
                    }
                });
            }

            const msg = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🔍 Hasil pencarian Pinterest untuk *${text}*` },
                            carouselMessage: { cards }
                        }
                    }
                }
            }, { quoted: m });

            await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
        }
        // .aiodl
        if (command === 'aiodl') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const { data } = await axios.get(`https://api-faa.my.id/faa/aio?url=${encodeURIComponent(text)}`, { timeout: 0 });
                if (data.status) {
                    await sock.sendMessage(from, { video: { url: data.result.download_url }, caption: `\`𝗔 𝗜 𝗢 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .fbdl
        if (command === 'fbdl' || command === 'fb') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const { data } = await axios.get(`https://api-faa.my.id/faa/fbdownload?url=${encodeURIComponent(text)}`, { timeout: 0 });
                if (data.status) {
                    const videoUrl = data.result.media.video_hd || data.result.media.video_sd;
                    await sock.sendMessage(from, { video: { url: videoUrl }, caption: `\`𝗙 𝗔 𝗖 𝗘 𝗕 𝗢 𝗢 𝗞 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`` }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .xdl alias .x & .twdl
        if (command === 'xdl' || command === 'x' || command === 'twdl') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const { data } = await axios.get(`https://zelapioffciall.koyeb.app/download/twitter?url=${encodeURIComponent(text)}`, { timeout: 0 });
                if (data.status) {
                    await sock.sendMessage(from, { video: { url: data.result.download_link }, caption: `\`𝗫 / 𝗧 𝗪 𝗜 𝗧 𝗧 𝗘 𝗥 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 Ａ 𝗗 Ｅ 𝗥\`` }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
        // .mediafire & .mfdl
        if (command === 'mediafire' || command === 'mfdl') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            try {
                const { data } = await axios.get(`https://api.nexray.eu.cc/downloader/mediafire?url=${encodeURIComponent(text)}`, { timeout: 0 });
                if (data.status) {
                    const res = data.result;
                    const caption = `\`𝗠 𝗘 𝗗 𝗜 𝗔 𝗙 𝗜 𝗥 𝗘 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\`\n\n*💌 Name:* ${res.filename}\n*📊 Size:* ${res.filesize}\n*🗂️ Extension:* ${res.mimetype}\n*📨 Uploaded:* ${res.uploaded}`;
                    await sock.sendMessage(from, { document: { url: res.download_url }, fileName: res.filename, mimetype: res.mimetype, caption }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 7. .gitdl alias .git & .github
        if (command === 'gitdl' || command === 'git' || command === 'github') {
            if (!text) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }
            
            let username, repo, branch;
            if (args[0]?.includes('github.com')) {
                const urlMatch = args[0].match(/github\.com\/([^\/]+)\/([^\/]+)/i);
                if (urlMatch) {
                    username = urlMatch[1];
                    repo = urlMatch[2].replace(/\.git$/, '');
                    branch = args[1] || 'main';
                }
            } else {
                username = args[0];
                repo = args[1];
                branch = args[2] || 'main';
            }

            if (!username || !repo) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                const repoInfo = await fetch(`https://api.github.com/repos/${username}/${repo}`);
                if (!repoInfo.ok) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ *REPO TIDAK DITEMUKAN*\n\n> \`${username}/${repo}\` tidak ada` }, { quoted: m });
                }

                const repoData = await repoInfo.json();
                const defaultBranch = repoData.default_branch || 'main';
                branch = branch || defaultBranch;

                const zipUrl = `https://github.com/${username}/${repo}/archive/refs/heads/${branch}.zip`;
                const checkRes = await fetch(zipUrl, { method: 'HEAD' });
                
                if (!checkRes.ok) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return sock.sendMessage(from, { text: `❌ *BRANCH TIDAK ADA*\n\n> Branch \`${branch}\` tidak ditemukan\n> Default: \`${defaultBranch}\`` }, { quoted: m });
                }

                const caption = `\`𝗚 𝗜 𝗧 𝗛 𝗨 𝗕 - 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥\``;
                await sock.sendMessage(from, { 
                    document: { url: zipUrl }, 
                    fileName: `${repo} - Branch ${branch}.zip`, 
                    mimetype: 'application/zip', 
                    caption 
                }, { quoted: m });

                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                console.error(err);
            }
        }

    } catch (err) {
        console.error("Sosmed Error: ", err.message);
    }
};