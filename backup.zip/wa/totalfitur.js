const fs = require('fs');
const path = require('path');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // ================= VALIDASI PERINTAH =================
        if (command !== 'totalfitur') return;

        // ================= CEK USER TERDAFTAR (Sama seperti menuwa.js) =================
        const dbUserPath = path.join(__dirname, '../databasewa/userwa.json');
        if (fs.existsSync(dbUserPath)) {
            const userDb = JSON.parse(fs.readFileSync(dbUserPath, 'utf-8'));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        // ================= AMBIL DATA MENUWA.JSON =================
        const menuDbPath = path.join(__dirname, '../databasewa/menuwa.json');
        if (!fs.existsSync(menuDbPath)) {
            return sock.sendMessage(from, { text: "❌ Database menu belum tersedia. Silakan ketik `.menu` terlebih dahulu." }, { quoted: m });
        }

        const menuData = JSON.parse(fs.readFileSync(menuDbPath, 'utf-8'));

        // Hitung total category dan total fitur
        const totalCategory = menuData.length;
        let totalFitur = 0;

        menuData.forEach(category => {
            if (Array.isArray(category.value)) {
                totalFitur += category.value.length;
            }
        });

        // ================= FORMAT PESAN =================
        const captionText = `◤───「 *📌 Total Fitur/Category* 」──✦
> ⎆  [ Nama Bot : Helper - MD
> ⎆  [ Author : 6282311544652
> ⎆  [ Total Fitur : ${totalFitur} Fitur/Command
> ⎆  [ Total Category : ${totalCategory} Category
◣──────────❈`;

        // ================= MEMBUAT INTERACTIVE BUTTONS =================
        const buttons = [
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "📌 Fitur",
                    id: ".allmenu"
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "🔖 Category",
                    id: "categoryhc"
                })
            }
        ];

        const msg = generateWAMessageFromContent(from, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({ text: captionText }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "©Created By Hady" }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            title: "📊 Total Fitur Helper - MD",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: buttons
                        })
                    })
                }
            }
        }, { quoted: m });

        await sock.relayMessage(from, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error("Error di total.js:", err);
    }
};