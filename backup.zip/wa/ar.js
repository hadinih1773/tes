const fs = require("fs");
const path = require("path");

const arPath = path.join(__dirname, "../databasewa/ar.json");
const userPath = path.join(__dirname, "../databasewa/userwa.json");
const dbPath = path.join(__dirname, "../databasewa/adminwa.json");
const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");

if (!fs.existsSync(arPath)) fs.writeFileSync(arPath, "{}");

function readDB(filePath) {
    if (!fs.existsSync(filePath)) return [];
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } catch (e) {
        return [];
    }
}

function writeDB(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const loadArData = () => JSON.parse(fs.readFileSync(arPath, "utf8"));
const saveArData = (data) => fs.writeFileSync(arPath, JSON.stringify(data, null, 2));

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        const sender = m.key.participant || m.key.remoteJid;
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : '';

        if (!isGroup) return;

        const registeredUsers = readDB(userPath);
        if (!registeredUsers.includes(sender)) return; 

        const ownerDb = readDB(ownerPath);
        const adminDb = readDB(dbPath);
        const isOwner = ownerDb.includes(sender);
        const isAdminBot = adminDb.includes(sender);

        const data = loadArData();
        if (!data[from]) data[from] = {};

        // PERBAIKAN: Mengambil command murni (kata pertama sebelum '|')
        const cmd = body.split("|")[0].trim().toLowerCase();

        if (cmd === ".ar" || cmd === ".dar" || body === ".listar") {
            if (!isAdminBot && !isOwner) {
                return await sock.sendMessage(from, { text: "❌ Hanya Admin Yang Bisa Gunakan" }, { quoted: m });
            }

            if (cmd === ".ar") {
                const parts = body.split("|");
                if (parts.length < 3) {
                    return await sock.sendMessage(from, { text: `❌ Format Salah : \`${cmd}|kata|respon\`` }, { quoted: m });
                }
                
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    const kata = parts[1].trim().toLowerCase();
                    const response = parts.slice(2).join("|").trim();
                    
                    data[from][kata] = response;
                    saveArData(data);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return await sock.sendMessage(from, { text: `✅ AutoResponse ditambahkan:\n**${kata}** → ${response}` }, { quoted: m });
                } catch (err) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return;
                }
            }

            if (cmd === ".dar") {
                const parts = body.split("|");
                if (parts.length < 2) {
                    return await sock.sendMessage(from, { text: `❌ Format Salah : \`${cmd}|kata\`` }, { quoted: m });
                }
                
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    const kata = parts[1].trim().toLowerCase();
                    
                    if (!data[from][kata]) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return await sock.sendMessage(from, { text: `⚠️ Kata **${kata}** gak ditemukan.` }, { quoted: m });
                    }

                    delete data[from][kata];
                    saveArData(data);
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return await sock.sendMessage(from, { text: `🗑️ AutoResponse untuk **${kata}** udah dihapus.` }, { quoted: m });
                } catch (err) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return;
                }
            }

            if (body === ".listar") {
                await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                try {
                    const entries = Object.entries(data[from]);
                    if (entries.length === 0) {
                        await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                        return await sock.sendMessage(from, { text: "📃 Belum ada autoresponse di grup ini." }, { quoted: m });
                    }

                    let listMsg = `📘 *AutoResponse List — Grup*\n\n`;
                    entries.forEach(([k, v], i) => {
                        listMsg += `*${i + 1}.* ${k} → ${v}\n`;
                    });
                    listMsg += `\n_Gunakan .dar|kata untuk hapus._`;
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                    return await sock.sendMessage(from, { text: listMsg }, { quoted: m });
                } catch (err) {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return;
                }
            }
        }

        const groupData = data[from];
        const content = body.toLowerCase().trim();

        for (const trigger in groupData) {
            const regex = new RegExp(`\\b${trigger}\\b`, "i");
            if (regex.test(content)) {
                return await sock.sendMessage(from, { text: groupData[trigger] }, { quoted: m });
            }
        }

    } catch (err) {
        console.error("Error in AutoResponse:", err);
    }
};