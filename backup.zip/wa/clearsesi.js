const fs = require("fs");
const path = require("path");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'clearsession') {
            if (sender !== '73577453879303@lid') {
                return sock.sendMessage(from, { text: "❌ Hanya Hady Yang Bisa Gunakan" }, { quoted: m });
            }

            const credsPath = path.join(__dirname, "../session/creds.json");

            if (!fs.existsSync(credsPath)) {
                return sock.sendMessage(from, { text: `⚠️ file creds.json tidak ditemukan.` }, { quoted: m });
            }

            try {
                fs.unlinkSync(credsPath);
                await sock.sendMessage(from, { text: `✅ File creds.json telah dihapus.` }, { quoted: m });
            } catch (error) {
                await sock.sendMessage(from, { text: `⚠️ Terjadi kesalahan saat menghapus file.` }, { quoted: m });
            }
        }
    } catch (err) {
        // Silent error
    }
};
