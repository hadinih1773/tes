const fs = require("fs");
const path = require("path");
const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'donasi' || command === 'support') {
            // Cek Registrasi User (Silent)
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            // Tambahkan Reaction Emoji 💳
            await sock.sendMessage(from, { react: { text: "💳", key: m.key } });

            // Menyiapkan Media Gambar
            const media1 = await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/umo9ub.jpg" } }, { upload: sock.waUploadToServer });
            const media2 = await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/v68o1a.jpg" } }, { upload: sock.waUploadToServer });
            const media3 = await prepareWAMessageMedia({ image: { url: "https://jlvglfqdm1tbi0p9.public.blob.vercel-storage.com/QSb-pm-sjqEZ1sDD56RdSK8vOQWWZUoOXSk4A.jpeg" } }, { upload: sock.waUploadToServer });

            // Struktur Cards seperti pada fitur .yts
            const cards = [
                {
                    body: {
                        text: "> Klik Tombol Dibawah Untuk Payment DANA\n> Nomor DANA : 083160970479"
                    },
                    footer: { text: "Helper - MD" },
                    header: {
                        hasMediaAttachment: true,
                        ...media1
                    },
                    nativeFlowMessage: {
                        buttons: []
                    }
                },
                {
                    body: {
                        text: "> Scan QR Untuk Payment DANA\n> Thank's For You"
                    },
                    footer: { text: "Helper - MD" },
                    header: {
                        hasMediaAttachment: true,
                        ...media2
                    },
                    nativeFlowMessage: {
                        buttons: []
                    }
                },
                {
                    body: {
                        text: "> Scan QRIS Untuk Semua Payment\n> Thank's For You"
                    },
                    footer: { text: "Helper - MD" },
                    header: {
                        hasMediaAttachment: true,
                        ...media3
                    },
                    nativeFlowMessage: {
                        buttons: []
                    }
                }
            ];

            const msg = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: "Berikut Daftar Metode Pembayaran. Terima Kasih Telah Berdonasi ~😇~" },
                            footer: { text: "Donasi Payment" },
                            carouselMessage: {
                                cards: cards
                            }
                        }
                    }
                }
            }, { quoted: m });

            await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
        }
    } catch (err) {
        // Silent error
    }
};