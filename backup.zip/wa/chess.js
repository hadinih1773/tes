const fs = require("fs");
const path = require("path");
const { Chess } = require('chess.js');

const userPath = path.join(__dirname, "../databasewa/userwa.json");
let chessGames = {};

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'chess' || command === 'catur') {
            // Cek Registrasi User
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            const feature = args[0]?.toLowerCase();

            if (!feature) {
                return sock.sendMessage(from, { text: "❌ Gunakan Command `.chess menu` Untuk Melihat Semua Command Game Catur" }, { quoted: m });
            }

            if (feature === 'bot') {
                return sock.sendMessage(from, { text: "❌ Ketik `.chess menu` Untuk Melihat Semua Command" }, { quoted: m });
            }

            if (feature === 'menu') {
                const menuText = `🌟 *Perintah Permainan Catur:*
\`.chess create\` - Untuk Memulai Permainan
\`.chess join\` - Untuk Bergabung Dalam Permainan
\`.chess start\` - Memulai Permainan Jika Sudah 2 Orang
\`.chess delete\` - Menghentikan Permainan
\`.chess computer\` - Bermain Bersama Computer
\`.chess [dari] [ke]\``;
                return sock.sendMessage(from, { text: menuText }, { quoted: m });
            }

            // WAITING REACTION (Hanya untuk create dan computer)
            if (feature === 'create' || feature === 'computer') {
                await sock.sendMessage(from, { react: { text: '🏁', key: m.key } });
            }

            const key = from;
            chessGames[key] = chessGames[key] || {
                gameData: null,
                fen: null,
                currentTurn: null,
                players: [],
                hasJoined: [],
                isComputer: false
            };
            let chessData = chessGames[key];

            if (feature === 'delete') {
                delete chessGames[key];
                return sock.sendMessage(from, { text: '🏳️ *Permainan catur dihentikan.*' }, { quoted: m });
            }

            if (feature === 'create') {
                if (chessData.gameData) return sock.sendMessage(from, { text: '⚠️ *Permainan sudah dimulai.*' }, { quoted: m });
                chessData.gameData = { status: 'waiting', black: null, white: null };
                chessData.isComputer = false;
                return sock.sendMessage(from, { text: '🎮 *Permainan catur dimulai.*\nMenunggu pemain lain untuk bergabung.' }, { quoted: m });
            }

            if (feature === 'computer') {
                if (chessData.gameData) return sock.sendMessage(from, { text: '⚠️ *Selesaikan permainan yang ada dulu.*' }, { quoted: m });
                const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
                chessGames[key] = {
                    gameData: { status: 'playing', black: 'computer', white: sender },
                    fen: fen,
                    currentTurn: sender,
                    players: [sender, 'computer'],
                    hasJoined: [sender],
                    isComputer: true
                };
                const boardUrl = `https://www.chess.com/dynboard?fen=${encodeURIComponent(fen)}&board=graffiti&piece=graffiti&size=3&coordinates=inside`;
                return sock.sendMessage(from, { image: { url: boardUrl }, caption: `🎮 *Bermain melawan Computer*\n\n🎲 *Giliran:* Putih @${sender.split('@')[0]}`, mentions: [sender] }, { quoted: m });
            }

            if (feature === 'join') {
                if (chessData.players.includes(sender)) return sock.sendMessage(from, { text: '🙅‍♂️ *Anda sudah bergabung.*' }, { quoted: m });
                if (!chessData.gameData || chessData.gameData.status !== 'waiting') return sock.sendMessage(from, { text: '⚠️ *Tidak ada permainan menunggu.*' }, { quoted: m });
                chessData.players.push(sender);
                chessData.hasJoined.push(sender);
                if (chessData.players.length === 2) {
                    chessData.gameData.status = 'ready';
                    const [black, white] = Math.random() < 0.5 ? [chessData.players[1], chessData.players[0]] : [chessData.players[0], chessData.players[1]];
                    chessData.gameData.black = black;
                    chessData.gameData.white = white;
                    chessData.currentTurn = white;
                    return sock.sendMessage(from, { text: `Hitam: @${black.split('@')[0]}\nPutih: @${white.split('@')[0]}\n\nKetik *.chess start*`, mentions: [black, white] }, { quoted: m });
                }
                return sock.sendMessage(from, { text: '🙋‍♂️ *Berhasil bergabung.*' }, { quoted: m });
            }

            if (feature === 'start') {
                if (chessData.gameData?.status !== 'ready') return sock.sendMessage(from, { text: '⚠️ *Tunggu 2 pemain.*' }, { quoted: m });
                chessData.gameData.status = 'playing';
                const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
                chessData.fen = fen;
                const boardUrl = `https://www.chess.com/dynboard?fen=${encodeURIComponent(fen)}&board=graffiti&piece=graffiti&size=3&coordinates=inside`;
                return sock.sendMessage(from, { image: { url: boardUrl }, caption: `🎲 *Giliran:* Putih @${chessData.gameData.white.split('@')[0]}`, mentions: [chessData.gameData.white] }, { quoted: m });
            }

            if (args[0] && args[1]) {
                if (!chessData.gameData || chessData.gameData.status !== 'playing') return;
                if (chessData.currentTurn !== sender) return sock.sendMessage(from, { text: `⏳ *Giliran ${chessData.currentTurn === chessData.gameData.white ? 'Putih' : 'Hitam'}*` }, { quoted: m });

                const chess = new Chess(chessData.fen);
                try {
                    chess.move({ from: args[0], to: args[1], promotion: 'q' });
                } catch (e) {
                    return sock.sendMessage(from, { text: '❌ *Langkah tidak valid.*' }, { quoted: m });
                }

                chessData.fen = chess.fen();
                
                if (chess.isGameOver()) {
                    let msg = chess.isCheckmate() ? `🏁 *Checkmate!* Pemenang: @${sender.split('@')[0]}` : `🏁 *Game Over (Draw)*`;
                    delete chessGames[key];
                    return sock.sendMessage(from, { text: msg, mentions: [sender] }, { quoted: m });
                }

                if (chessData.isComputer) {
                    const moves = chess.moves();
                    const move = moves[Math.floor(Math.random() * moves.length)];
                    chess.move(move);
                    chessData.fen = chess.fen();
                    if (chess.isGameOver()) {
                        delete chessGames[key];
                        return sock.sendMessage(from, { text: `🏁 *Computer menang!*` }, { quoted: m });
                    }
                } else {
                    const currentIdx = chessData.players.indexOf(chessData.currentTurn);
                    chessData.currentTurn = chessData.players[(currentIdx + 1) % 2];
                }

                const boardUrl = `https://www.chess.com/dynboard?fen=${encodeURIComponent(chessData.fen)}&board=graffiti&piece=graffiti&size=3&coordinates=inside`;
                return sock.sendMessage(from, { image: { url: boardUrl }, caption: `🎲 *Giliran:* ${chessData.currentTurn === sender ? 'Anda' : '@' + chessData.currentTurn.split('@')[0]}`, mentions: [chessData.currentTurn] }, { quoted: m });
            }
        }
    } catch (err) {}
};
