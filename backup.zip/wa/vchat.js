const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const type = Object.keys(m.message)[0];
        const body = (type === 'conversation') ? m.message.conversation : 
                     (type === 'extendedTextMessage') ? m.message.extendedTextMessage.text : '';

        if (!body.startsWith('.chat')) return;

        // Cek Registrasi User (Silent)
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
        if (!userDb.includes(sender)) return;

        const parts = body.trim().split('|');
        const nomor = parts[1]?.trim();
        const pesan = parts[2]?.trim();

        if (command === 'chat') {
            if (!nomor || !pesan) {
                return sock.sendMessage(from, { text: `❌ Format Salah : \`.${command}|628xx|pesan\`` }, { quoted: m });
            }

            // WAITING REACTION
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            try {
                let fixedNumber = nomor.replace(/[-+<>@]/g, '').replace(/ +/g, '').replace(/^[0]/g, '62') + '@s.whatsapp.net';
                
                const time = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" });
                
                let ppUrl;
                try {
                    ppUrl = await sock.profilePictureUrl(sender, 'image');
                } catch {
                    ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png';
                }

                const virtualMessage = `╭───• *VIRTUAL MESSAGE* •───
├⎆ Pesan Dari : @${sender.split('@')[0]}
├⎆ Isi Pesan : ${pesan}
├⎆ Note : Terima Kasih 

⟢ *ID*: ${sender}

⟢ 𝗗𝗮𝘁𝗲: ${time}

Silahkan Hubungi Pengirim Pesan Untuk Lebih Lanjut`;

                await sock.sendMessage(fixedNumber, { 
                    image: { url: ppUrl },
                    caption: virtualMessage, 
                    mentions: [sender] 
                });

                await sock.sendMessage(from, { text: `✅ Berhasil Mengirim Pesan Ke: ${nomor}` }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

    } catch (err) {
        // Silent Error
    }
};