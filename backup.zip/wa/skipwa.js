const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const fetch = (...a) => import("node-fetch").then(({ default: f }) => f(...a));

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Pengecekan User Daftar
        const userDb = JSON.parse(fs.readFileSync(userPath));
        const isRegistered = userDb.includes(sender);

        if (!isRegistered) return;

        if (command === 'skip' || command === 'bps' || command === 'skiplink') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

            const link = args[0];
            if (!link) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} url\`` }, { quoted: m });
            }

            try {
                let hasilBypass = null;

                if (link.includes('sub4unlock.co')) {
                    const apiUrl = `https://fgsi.dpdns.org/api/tools/skip/sub4unlock?apikey=fgsiapi-353b23fd-6d&url=${encodeURIComponent(link)}`;
                    const response = await fetch(apiUrl);
                    const json = await response.json();
                    if (json.status && json.data && json.data.linkGo) {
                        hasilBypass = json.data.linkGo;
                    }
                } else {
                    const apiUrl = `https://tw8rev.vercel.app/api/bypass?url=${encodeURIComponent(link)}&apikey=arnarubypass_9f2d1s5q`;
                    const response = await fetch(apiUrl);
                    const json = await response.json();
                    if (json.success && json.direct) {
                        hasilBypass = json.direct;
                    }
                }

                if (hasilBypass) {
                    const teksHasil = `✅ *Bypass Link Berhasil*\n*User* : @${sender.split('@')[0]} Done Bro\n*Link Bypass* : ${link}\n*Hasil Bypass* : ${hasilBypass}`;
                    
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                    body: proto.Message.InteractiveMessage.Body.fromObject({
                                        text: teksHasil
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                        buttons: [{
                                            name: "cta_url",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "Hasil Bypass",
                                                url: hasilBypass,
                                                merchant_url: hasilBypass
                                            })
                                        }]
                                    }),
                                    contextInfo: {
                                        mentionedJid: [sender],
                                        quotedMessage: m.message
                                    }
                                })
                            }
                        }
                    }, { userJid: from, quoted: m });

                    await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
                    return await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                } else {
                    await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                    return await sock.sendMessage(from, { text: "Gagal melakukan bypass link tersebut." }, { quoted: m });
                }
            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "Terjadi kesalahan pada sistem API." }, { quoted: m });
            }
        }
    } catch (err) {
        console.log(err);
    }
};