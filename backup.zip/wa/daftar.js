const fs = require('fs-extra');
const path = require('path');
const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Ambil body teks atau ID tombol
        const body = (
            m.message?.conversation || 
            m.message?.extendedTextMessage?.text || 
            m.message?.buttonsResponseMessage?.selectedButtonId || 
            m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || 
            (m.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson && JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id) || 
            m.message?.templateButtonReplyMessage?.selectedId ||
            ''
        );

        const userPath = path.join(__dirname, '../databasewa/userwa.json');
        const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');

        if (!fs.existsSync(userPath)) fs.writeFileSync(userPath, JSON.stringify([]));
        if (!fs.existsSync(ownerPath)) fs.writeFileSync(ownerPath, JSON.stringify([]));
        
        let userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        let ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));
        
        const isRegistered = userDb.includes(sender);
        const isOwner = ownerDb.includes(sender);

        // HANDLE BUTTON OTOMATIS (Taruh di atas agar tidak terblokir filter isRegistered)
        if (body === '.regis Otomatis.17') {
            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            try {
                if (isRegistered) {
                    await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                    return await sock.sendMessage(from, { text: `🚫 @${sender.split('@')[0]} Anda Sudah Terdaftar Di Database. Gunakan Command \`.undaftar\` Untuk Menghapus Data 👋🎉`, mentions: [sender] }, { quoted: m });
                }
                const nama = "Otomatis";
                const umur = "17";
                const waktuLengkap = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
                userDb.push(sender);
                fs.writeFileSync(userPath, JSON.stringify(userDb, null, 2));
                let ppUrl;
                try { ppUrl = await sock.profilePictureUrl(sender, 'image'); } catch { ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'; }
                const regMsg = `╭───• *NEW USER* •───\n├⎆ Status: ✅ Success\n├⎆ Name: ${nama}\n├⎆ Umur: ${umur}\n\n⟢ *ID*: ${sender}\n\n⟢ 𝗗𝗮𝘁𝗲: ${waktuLengkap}\n\n_Sekarang anda sudah bisa mengakses HC Helper MD_`;
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                return await sock.sendMessage(from, { image: { url: ppUrl }, caption: regMsg, mentions: [sender] }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return;
            }
        }

        // FITUR DAFTAR
        if (command === 'daftar') {
            if (isRegistered) {
                return await sock.sendMessage(from, { text: `🚫 @${sender.split('@')[0]} Anda Sudah Terdaftar Di Database. Gunakan Command \`.undaftar\` Untuk Menghapus Data 👋🎉`, mentions: [sender] }, { quoted: m });
            }
            const input = text.split('.');
            if (input.length < 2) {
                return await sock.sendMessage(from, { text: `Format salah! Contoh: .${command} Hady.20` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            try {
                const nama = input[0].trim();
                const umur = input[1].trim();
                const waktuLengkap = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
                userDb.push(sender);
                fs.writeFileSync(userPath, JSON.stringify(userDb, null, 2));
                let ppUrl;
                try { ppUrl = await sock.profilePictureUrl(sender, 'image'); } catch { ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'; }
                const regMsg = `╭───• *NEW USER* •───\n├⎆ Status: ✅ Success\n├⎆ Name: ${nama}\n├⎆ Umur: ${umur}\n\n⟢ *ID*: ${sender}\n\n⟢ 𝗗𝗮𝘁𝗲: ${waktuLengkap}\n\n_Sekarang anda sudah bisa mengakses HC Helper MD_`;
                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                return await sock.sendMessage(from, { image: { url: ppUrl }, caption: regMsg, mentions: [sender] }, { quoted: m });
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return;
            }
        }

        // PROTEKSI
        if (!isRegistered) {
            const prefixes = ['.', '!', '/'];
            const hasPrefix = prefixes.some(p => body.startsWith(p));
            if (!hasPrefix) return;

            let ppUrl;
            try { ppUrl = await sock.profilePictureUrl(sender, 'image'); } catch { ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'; }
            const msgGagal = "👋 Halo kak, anda belum bisa mengakses bot nih daftar dulu ya.\n\n╭──「 *CARA DAFTAR* 」─✦\n│⦿ 〔 Cara : .daftar nama.umur\n│⦿ 〔 Contoh : .daftar Hady.20\n│⦿ 〔 Botname : HC Helper MD✨\n╰───────────────────✦\n\nDENGAN DAFTAR KAMU BISA AKSES BOT SEPUASNYA\n\n🗣️: Kenapa harus daftar sih?\n🗿: Agar bot mengenal siapa anda\n🗣️: Ribet banget harus daftar segala\n🗿: Jika tidak daftar, Anda tidak bisa menggunakan fitur bot";
            
            const preparedMedia = await prepareWAMessageMedia({ image: { url: ppUrl } }, { upload: sock.waUploadToServer });
            const msg = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.fromObject({ text: msgGagal }),
                            footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "©HC Helper MD" }),
                            header: proto.Message.InteractiveMessage.Header.fromObject({
                                title: "📝 Pendaftaran User",
                                hasMediaAttachment: true,
                                imageMessage: preparedMedia.imageMessage
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: [
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "⚡ Daftar Otomatis",
                                            id: ".regis Otomatis.17"
                                        })
                                    },
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "👤 Daftar Manual",
                                            copy_code: ".daftar Nama.Umur"
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m });
            return await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
        }

        if (command === 'undaftar') {
            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });
            try {
                if (text) {
                    if (!isOwner) {
                        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                        return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
                    }
                    let target = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || text.trim();
                    if (!userDb.includes(target)) {
                        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                        return await sock.sendMessage(from, { text: '❌ Target tidak ditemukan.' }, { quoted: m });
                    }
                    userDb.splice(userDb.indexOf(target), 1);
                    fs.writeFileSync(userPath, JSON.stringify(userDb, null, 2));
                    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                    return await sock.sendMessage(from, { text: `✅ Berhasil Menghapus ID ${target}` }, { quoted: m });
                } else {
                    userDb.splice(userDb.indexOf(sender), 1);
                    fs.writeFileSync(userPath, JSON.stringify(userDb, null, 2));
                    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                    await sock.sendMessage(from, { text: '✅ Berhasil Menghapus Data Anda Dari Database.' }, { quoted: m });
                }
            } catch (err) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            }
        }
    } catch (err) {
        console.error('Daftar Error:', err);
    }
};