const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'rvo') {
            // Cek Registrasi User
            const userDb = JSON.parse(fs.readFileSync(userPath));
            if (!userDb.includes(sender)) return;

            await sock.sendMessage(from, { react: { text: '⏱️', key: m.key } });

            // Check if message is quoted
            const quoted = m.message?.extendedTextMessage?.contextInfo;
            if (!quoted || !quoted.quotedMessage) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, { text: '⚠️ Reply Pesan View Once' }, { quoted: m });
            }

            const quotedMsg = quoted.quotedMessage;
            let innerMsg = null;

            // Path logic to find view once message
            if (quotedMsg?.viewOnceMessageV2) {
                innerMsg = quotedMsg.viewOnceMessageV2.message;
            } else if (quotedMsg?.viewOnceMessage) {
                innerMsg = quotedMsg.viewOnceMessage.message;
            } else if (quotedMsg?.ephemeralMessage?.message) {
                const ephemeral = quotedMsg.ephemeralMessage.message;
                if (ephemeral.viewOnceMessageV2) {
                    innerMsg = ephemeral.viewOnceMessageV2.message;
                } else if (ephemeral.viewOnceMessage) {
                    innerMsg = ephemeral.viewOnceMessage.message;
                }
            } else if (quotedMsg?.imageMessage || quotedMsg?.videoMessage || quotedMsg?.audioMessage) {
                innerMsg = quotedMsg;
            }

            if (!innerMsg) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Pesan yang di-reply bukan view once atau tidak mengandung media!' }, { quoted: m });
            }

            const ViewOnceImg = innerMsg?.imageMessage;
            const ViewOnceVid = innerMsg?.videoMessage;
            const ViewOnceAud = innerMsg?.audioMessage;

            if (!ViewOnceImg && !ViewOnceVid && !ViewOnceAud) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Tidak dapat menemukan media dalam pesan!' }, { quoted: m });
            }

            // Download media
            let buffer = await downloadMediaMessage(
                { 
                    message: innerMsg, 
                },
                'buffer',
                {},
                { logger: { info: () => {}, debug: () => {}, error: () => {}, warn: () => {} } }
            );

            if (!buffer) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Gagal mengunduh media view once.' }, { quoted: m });
            }

            // Send media
            if (ViewOnceImg) {
                await sock.sendMessage(from, { image: buffer, caption: ViewOnceImg.caption || '' }, { quoted: m });
            } else if (ViewOnceVid) {
                await sock.sendMessage(from, { video: buffer, caption: ViewOnceVid.caption || '' }, { quoted: m });
            } else if (ViewOnceAud) {
                await sock.sendMessage(from, { audio: buffer, mimetype: ViewOnceAud.mimetype || 'audio/mpeg', ptt: !!ViewOnceAud.ptt }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        }
    } catch (error) {
        console.error('Error in rvo:', error);
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
    }
};