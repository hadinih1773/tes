const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'sewabot') {
            // Cek Registrasi User (Silent)
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            let sewaMessage = `*SEWA BOT Helper MD*

💸 List Paket Harian 💸 

> • Rp 2.000 ( 2 Hari )
> • Rp 4.000 ( 4 Hari )
> • Rp 5.000 ( 1 Minggu )
> • Rp 10.000 ( 2 Minggu )
> • Rp 15.000 ( 3 Minggu )

💰 List Paket Bulanan 💰

> • Rp 20.000 ( 1 Bulan )
> • Rp 30.000 ( 2 Bulan )
> • Rp 50.000 ( 3 Bulan )

🛍 *Informasi Sewa*

> • Maaf Kami Tidak Memiliki Sewa Bot Permanent
> • Jangan Spam Bot Sewa Supaya Tidak Eror

🛒 Cara Pembayaran : 
Silahkan Hubungi Owner / Ketik : \`.owner\`
Untuk Payment :
> Dana : 083160970479 atau ketik \`.donasi\`

📝 Jika Ada Kesalahan Duit Akan Di Kembalikan`;

            await sock.sendMessage(from, { text: sewaMessage }, { quoted: m });
        }
    } catch (err) {
        // Silent error
    }
};