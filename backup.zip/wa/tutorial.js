const fs = require("fs");
const path = require("path");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (command === 'tutorial') {
            // Cek Registrasi User
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            const tutorialText = `📚 *Tutorial Menggunakan Fitur Helper MD*
━━━━━━━━━━━━━━━━━━━
📌 Fitur Daftar Dan Undaftar
* Ketika Masuk Grup Gunakan Command \`.menu\` 
* Muncul Pesan Daftar 
* Gunakan Command \`.daftar nama.umur\` Contohnya : \`.daftar Hady.17\`
* Setelah Mendaftar Baru Anda Bisa Menggunakan Command Bot
* Jika Ingin Menghapus Data Daftar, Gunakan Command \`.undaftar\`
━━━━━━━━━━━━━━━━━━━
📌 Fitur Boombox Convert 
* Gunakan Command \`.bb\` Yang Memiliki 2 Pilih Query/url
* Jika Query, Contohnya \`.bb dj viral\`
* Jika Pakai Url, Contohnya \`.bb https://youtu.be/RgKAFK5djSk?si=udMCaSeiUUXx0lrQ\` 
* Type Urlnya Ada 3 Yaitu YouTube, TikTok, dan Spotify
━━━━━━━━━━━━━━━━━━━
📌 Fitur Edit Gambar Dan ToFigure
* Kirim Gambar Terlebih Dahulu
* Reply Gambar Dengan Menggunakan Command \`.editimage ubah menjadi terang\`
* Reply Gambar Dengan Menggunakan Command \`.tofigure\`
━━━━━━━━━━━━━━━━━━━
📌 Fitur Downloader & Search
* Gunakan Command \`.downloadermenu\` Atau Bisa Langsung Cek Dari Command \`.menu\`
* Tunggu Bot Bekerja Baru Kirim Lagi
━━━━━━━━━━━━━━━━━━━`;

            await sock.sendMessage(from, { text: tutorialText }, { quoted: m });
        }
    } catch (err) {
        // Silent error
    }
};