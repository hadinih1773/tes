const fs = require("fs");
const path = require("path");

const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const isGroup = from.endsWith('@g.us');
        if (!isGroup) return;

        const sender = (m.key.participant || m.key.remoteJid).replace(/:[0-9]+/g, '');
        const ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));
        const isOwner = ownerDb.some(v => v.replace(/:[0-9]+/g, '') === sender);

        if (command === 'clearchat') {
            if (!isOwner) {
                await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
                return;
            }

            try {
                const now = Math.floor(Date.now() / 1000);
                
                await sock.chatModify({ 
                    delete: true, 
                    lastMessages: [{ 
                        key: m.key, 
                        messageTimestamp: m.messageTimestamp || now
                    }] 
                }, from);
                
                let response = `✅ Chat Grup Berhasil Dibersihkan\n@${sender.split('@')[0]} Telah Membersihkan Chat. Silahkan Lihat Di Nomor WhatsApp Bot`;
                await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
                
            } catch (error) {
                try {
                    await sock.chatModify({ 
                        clear: { 
                            messages: [{ 
                                id: m.key.id, 
                                fromMe: m.key.fromMe,
                                timestamp: Math.floor(Date.now() / 1000)
                            }] 
                        } 
                    }, from);
                    
                    let response = `✅ Chat Grup Berhasil Dibersihkan\n@${sender.split('@')[0]} Telah Membersihkan Chat. Silahkan Lihat Di Nomor WhatsApp Bot`;
                    await sock.sendMessage(from, { text: response, mentions: [sender] }, { quoted: m });
                } catch (e) {
                    console.error(e);
                }
            }
        }

    } catch (err) {
        console.error(err);
    }
};