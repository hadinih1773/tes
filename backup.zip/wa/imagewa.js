const axios = require("axios");
const fs = require("fs");
const path = require("path");
const https = require("https");
const FormData = require("form-data");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

const fastAxios = axios.create({
    timeout: 0,
    httpsAgent: new https.Agent({ 
        keepAlive: true, 
        maxSockets: 100,
        rejectUnauthorized: false 
    })
});

const FIGUR_PROMPT = "Using the model, create a 1/7 scale commercialized figurine of the characters in the picture, in a realistic style, in a real environment. The figurine is placed on an aesthetic computer desk. The figurine has a round transparant acrylic base, with no text on the base. The content on the computer screen is the ZBrush modeling process of this figurine. Next to the computer screen is a BANDAI-style toy packaging box printed with the original art work. The packaging features two-dimensional flat illustrations. Maintain original aspect ratio and resolution.";

// Helper fungsi untuk mendapatkan ekstensi file secara aman dari buffer
async function getFileType(buffer) {
    try {
        const { fileTypeFromBuffer } = await import('file-type');
        const type = await fileTypeFromBuffer(buffer);
        return type || { ext: 'png', mime: 'image/png' };
    } catch (e) {
        return { ext: 'png', mime: 'image/png' };
    }
}

// Helper fungsi untuk mengunggah buffer ke Nexray API
async function uploadToNexray(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename });
    
    const response = await fastAxios.post('https://api.nexray.eu.cc/upload?ttl=none', form, {
        headers: {
            ...form.getHeaders()
        }
    });

    if (response.data && response.data.result && response.data.result.url) {
        return response.data.result.url;
    } else {
        throw new Error("Gagal mengunggah gambar ke Nexray.");
    }
}

async function getBuffer(sock, m) {
    const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
    const msg = quoted ? quoted : m.message;
    const mime = (msg.imageMessage || msg.videoMessage || msg.stickerMessage || {}).mimetype || '';
    
    if (/image/.test(mime)) {
        const stream = await downloadContentFromMessage(msg.imageMessage, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    }
    return null;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath));
        const isRegistered = userDb.includes(sender);
        if (!isRegistered) return;

        // 1. .editimage
        if (command === 'editimage') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            let prompt = args.join(" ");
            const buffer = await getBuffer(sock, m);
            if (!buffer) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "Kirim Gambar Yang Mau Di Edit" }, { quoted: m });
            }
            
            if (!prompt) prompt = "enhance quality";
            
            try {
                const fileType = await getFileType(buffer);
                const ext = fileType.ext;
                const inputUrl = await uploadToNexray(buffer, `input_edit.${ext}`);
                
                const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(inputUrl)}&prompt=${encodeURIComponent(prompt)}`;
                
                const response = await fastAxios.get(apiUrl, { responseType: 'arraybuffer' });
                const resBuffer = Buffer.from(response.data);
                const resFileType = await getFileType(resBuffer);
                const extRes = resFileType.ext;
                const finalUrl = await uploadToNexray(resBuffer, `editimage.${extRes}`);
                
                await sock.sendMessage(from, { image: { url: finalUrl }, caption: `🖼 Image Edit\n@${sender.split('@')[0]} Done Bro 😎!`, mentions: [sender] }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                console.log(err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 2. .tofigure
        if (command === 'tofigure') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            const buffer = await getBuffer(sock, m);
            if (!buffer) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "⚠️ Kirim/Reply Gambar" }, { quoted: m });
            }
            
            try {
                const fileType = await getFileType(buffer);
                const ext = fileType.ext;
                const inputUrl = await uploadToNexray(buffer, `input_figure.${ext}`);
                
                const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(inputUrl)}&prompt=${encodeURIComponent(FIGUR_PROMPT)}`;
                
                const response = await fastAxios.get(apiUrl, { responseType: 'arraybuffer' });
                const resBuffer = Buffer.from(response.data);
                const resFileType = await getFileType(resBuffer);
                const extRes = resFileType.ext;
                const finalUrl = await uploadToNexray(resBuffer, `figure.${extRes}`);
                
                await sock.sendMessage(from, { image: { url: finalUrl }, caption: `🗿 Figure Edit\n@${sender.split('@')[0]} Done Bro 😎!`, mentions: [sender] }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                console.log(err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }

        // 3. .hd / .upscale
        if (command === 'hd' || command === 'upscale') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            const buffer = await getBuffer(sock, m);
            if (!buffer) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: "❌ Kirim gambar atau reply gambar dengan command `.hd`!" }, { quoted: m });
            }
            
            try {
                const fileType = await getFileType(buffer);
                const ext = fileType.ext;
                const inputUrl = await uploadToNexray(buffer, `input_hd.${ext}`);
                
                const apiUrl = `https://api-faa.my.id/faa/hdv4?image=${encodeURIComponent(inputUrl)}`;
                
                const apiRes = await fastAxios.get(apiUrl);
                const resultUrl = apiRes.data?.result?.image_upscaled;

                if (!resultUrl) {
                    throw new Error("API tidak memberikan URL hasil.");
                }
                
                await sock.sendMessage(from, { image: { url: resultUrl }, caption: `📸 HD Upscale\n@${sender.split('@')[0]} Done Bro 😎!\n✅ Gambar Anda Berhasil Ditingkatkan`, mentions: [sender] }, { quoted: m });
                await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
            } catch (err) {
                console.log(err);
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
            }
        }
    } catch (err) {
        console.log(err);
    }
};