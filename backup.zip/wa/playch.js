const crypto = require("crypto");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const { promisify } = require("util");
const yts = require("yt-search");

const run = promisify(exec);

const userPath = path.join(__dirname, "../databasewa/userwa.json");
const ownerPath = path.join(__dirname, "../databasewa/ownerwa.json");

const configSaluran = {
    id: '120363424062451116@newsletter',
    name: 'Hady Community || #ShareMods',
    link: 'https://whatsapp.com/channel/0029Vb6TwQ84tRrw2345Ut1z'
};

async function toOggOpus(mp3Buf) {
    const tmp = path.join(process.cwd(), "temp");
    if (!fs.existsSync(tmp)) fs.mkdirSync(tmp, { recursive: true });
    const id = crypto.randomBytes(6).toString("hex");
    const inp = path.join(tmp, `in_${id}.mp3`);
    const out = path.join(tmp, `out_${id}.ogg`);
    fs.writeFileSync(inp, mp3Buf);
    await run(`ffmpeg -y -i "${inp}" -vn -map_metadata -1 -ac 1 -ar 48000 -c:a libopus -b:a 96k -vbr on -application audio -f ogg "${out}"`);
    const buf = fs.readFileSync(out);
    try { fs.unlinkSync(inp); } catch {}
    try { fs.unlinkSync(out); } catch {}
    return buf;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        if (command !== 'playch') return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // Cek Database
        if (!fs.existsSync(userPath)) fs.writeFileSync(userPath, JSON.stringify([]));
        if (!fs.existsSync(ownerPath)) fs.writeFileSync(ownerPath, JSON.stringify([]));
        
        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        const ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));

        // Proteksi Registrasi & Owner
        if (!userDb.includes(sender)) return; 
        if (!ownerDb.includes(sender)) return await sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });

        const q = text?.trim();
        if (!q) return await sock.sendMessage(from, { text: `❌ Format Salah : \`.${command} query\`` }, { quoted: m });

        await sock.sendMessage(from, { react: { text: "🔎", key: m.key } });

        const { videos } = await yts(q);
        const video = videos.find((v) => v.seconds && v.seconds < 900) || videos[0];
        if (!video) return await sock.sendMessage(from, { text: "❌ Video tidak ditemukan" }, { quoted: m });

        const { data } = await axios.get(`https://api.nexray.web.id/downloader/ytmp3?url=${encodeURIComponent(video.url)}`);
        if (!data?.status || !data?.result?.url) throw new Error("Gagal mendapatkan URL Audio");

        await sock.sendMessage(from, { react: { text: "🎵", key: m.key } });

        const audioRes = await axios.get(data.result.url, { responseType: "arraybuffer", timeout: 60000 });
        const mp3Buf = Buffer.from(audioRes.data);
        const opusBuf = await toOggOpus(mp3Buf);

        const title = data.result.title || video.title;
        const ytChannel = video.author?.name || "Unknown";

        await sock.sendMessage(configSaluran.id, {
            audio: opusBuf,
            mimetype: "audio/ogg; codecs=opus",
            ptt: true,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: configSaluran.id,
                    serverMessageId: 100,
                    newsletterName: configSaluran.name
                },
                externalAdReply: {
                    title: title,
                    body: `Channel • ${ytChannel}`,
                    thumbnailUrl: video.thumbnail,
                    sourceUrl: configSaluran.link,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        });

        await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        await sock.sendMessage(from, { text: `✅ *${title}* berhasil dikirim ke saluran` }, { quoted: m });

    } catch (err) {
        console.error("PlayCh Error:", err);
        await sock.sendMessage(jid, { text: `❌ Gagal: ${err.message}` }, { quoted: m });
    }
};