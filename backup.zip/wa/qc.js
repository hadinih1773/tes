const fs = require("fs");
const path = require("path");
const axios = require("axios");
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');
const webp = require('node-webpmux');
const { tmpdir } = require('os');

const userPath = path.join(__dirname, "../databasewa/userwa.json");

async function imageToWebp (media) {
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)
    fs.writeFileSync(tmpFileIn, media)
    await new Promise((resolve, reject) => {
        ffmpeg(tmpFileIn)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec",
                "libwebp",
                "-vf",
                "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat("webp")
            .save(tmpFileOut)
    })
    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function writeExifImg (media, metadata) {
    let wMedia = await imageToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)
    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "sticker-pack-id": `https://github.com/KirBotz`, "sticker-pack-name": metadata.packname, "sticker-pack-publisher": metadata.author, "emojis": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (command === 'qc') {
            const sender = m.key.participant || m.key.remoteJid;
            if (!fs.existsSync(userPath)) return;
            const userDb = JSON.parse(fs.readFileSync(userPath, "utf8"));
            if (!userDb.includes(sender)) return;

            await sock.sendMessage(jid, { react: { text: "⏱️", key: m.key } });

            if (!text) {
                await sock.sendMessage(jid, { react: { text: "❌", key: m.key } });
                return sock.sendMessage(jid, { text: `❌ Format Salah : \`.${command} teks\`` }, { quoted: m });
            }

            let name = m.pushName || "User";
            let ppUrl;

            try {
                ppUrl = await sock.profilePictureUrl(sender, 'image');
            } catch {
                ppUrl = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
            }

            let obj = {
                type: 'quote',
                format: 'png',
                backgroundColor: '#1b1b1b',
                width: 512,
                height: 768,
                scale: 2,
                messages: [{
                    entities: [],
                    avatar: true,
                    from: {
                        id: 1,
                        name: name,
                        photo: { url: ppUrl }
                    },
                    text: text,
                    replyMessage: {}
                }]
            };

            try {
                let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
                    headers: { 'Content-Type': 'application/json' }
                });

                let buffer = Buffer.from(response.data.result.image, 'base64');
                
                const stickerPath = await writeExifImg(buffer, { packname: "HC Helper MD", author: "HadyLua" });
                const stickerBuffer = fs.readFileSync(stickerPath);

                await sock.sendMessage(jid, { react: { text: "✅", key: m.key } });
                await sock.sendMessage(jid, { sticker: stickerBuffer }, { quoted: m });
                
                fs.unlinkSync(stickerPath);

            } catch (e) {
                console.error(e);
                await sock.sendMessage(jid, { react: { text: "❌", key: m.key } });
                sock.sendMessage(jid, { text: '❌ ɢᴀɢᴀʟ ᴍᴇᴍʙᴜᴀᴛ ǫᴜᴏᴛᴇ sᴛɪᴄᴋᴇʀ' }, { quoted: m });
            }
        }
    } catch (err) {
        // Silent Error
    }
};