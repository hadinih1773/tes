const fs = require("fs");
const path = require("path");

const userFile = path.join(__dirname, "../databasewa/userwa.json");
const ownerFile = path.join(__dirname, "../databasewa/ownerwa.json");

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        const q = args;

        // CEK USER DAFTAR
        if (!fs.existsSync(userFile)) return;
        const userDb = JSON.parse(fs.readFileSync(userFile, "utf8"));
        if (!userDb.includes(sender)) return;

        // CEK OWNER DAFTAR
        if (!fs.existsSync(ownerFile)) return;
        const ownerDb = JSON.parse(fs.readFileSync(ownerFile, "utf8"));

        // =====================================================
        //                COMMAND .get
        // =====================================================
        if (command === "get") {
            if (!ownerDb.includes(sender)) return sock.sendMessage(from, { text: "❌ Hanya Owner Yang Bisa Gunakan" }, { quoted: m });
            
            if (q.length === 0) return sock.sendMessage(from, { text: "❌ Format Salah : `.get url`" }, { quoted: m });

            const url = q[0];

            try {
                const response = await fetch(url);
                const contentType = response.headers.get('content-type') || '';
                const contentDisposition = response.headers.get('content-disposition');
                
                let fileName = 'file';
                if (contentDisposition) {
                    const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
                    if (filenameMatch) {
                        fileName = filenameMatch[1].replace(/['"]/g, '');
                    }
                } else {
                    const urlFileName = url.split('/').pop();
                    if (urlFileName && urlFileName.includes('.')) {
                        fileName = urlFileName;
                    }
                }

                if (contentType.includes('application/json')) {
                    const jsonData = await response.json();
                    await sock.sendMessage(from, { text: `🛜 *GET Request*\n\n📃 *Response JSON:*\n${JSON.stringify(jsonData, null, 2)}` }, { quoted: m });
                } else if (contentType.includes('image')) {
                    const buffer = await response.arrayBuffer();
                    await sock.sendMessage(from, { image: Buffer.from(buffer), caption: '☑️ Response 200 OK ☑️' }, { quoted: m });
                } else if (contentType.includes('video')) {
                    const buffer = await response.arrayBuffer();
                    await sock.sendMessage(from, { video: Buffer.from(buffer), caption: '☑️ Response 200 OK ☑️' }, { quoted: m });
                } else if (contentType.includes('audio')) {
                    const buffer = await response.arrayBuffer();
                    await sock.sendMessage(from, { audio: Buffer.from(buffer), mimetype: 'audio/mp4', fileName: `${fileName}.mp3` }, { quoted: m });
                } else if (contentType.includes('application') || contentType.includes('text/csv') || contentType.includes('octet-stream')) {
                    const buffer = await response.arrayBuffer();
                    let mimetype = contentType;
                    await sock.sendMessage(from, { document: Buffer.from(buffer), mimetype: mimetype, fileName: fileName, caption: `🛜 *GET Request - Document*\n📃 *Type:* ${mimetype}\n📁 *File:* ${fileName}` }, { quoted: m });
                } else {
                    const data = await response.text();
                    await sock.sendMessage(from, { text: `🛜 *GET Request*\n\n📃 *Response:*\n${data}` }, { quoted: m });
                }

                await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

            } catch (error) {
                console.error(error);
                await sock.sendMessage(from, { text: '❌ Gagal melakukan request GET' }, { quoted: m });
            }
        }

    } catch (err) {
        console.error(err);
    }
};