const fs = require("fs");
const path = require("path");
const os = require("os");
const axios = require("axios");

function generateProgressBar(percent) {
    const total = 18;
    const progress = Math.round((percent / 100) * total);
    const empty = total - progress;
    return "[" + "▓".repeat(Math.max(0, progress)) + "░".repeat(Math.max(0, empty)) + "]";
}

function formatBytes(bytes) {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${d}d ${h}h ${m}m ${s}s`;
}

function getCpuLoad() {
    const cpus = os.cpus();
    let user = 0, nice = 0, sys = 0, idle = 0, irq = 0;
    for (let cpu of cpus) {
        for (let type in cpu.times) {
            if (type === "user") user += cpu.times[type];
            if (type === "nice") nice += cpu.times[type];
            if (type === "sys") sys += cpu.times[type];
            if (type === "idle") idle += cpu.times[type];
            if (type === "irq") irq += cpu.times[type];
        }
    }
    const total = user + nice + sys + idle + irq;
    return Math.min(100, Math.round(((total - idle) / total) * 100));
}

let publicIp = "127.0.0.1";
async function fetchIp() {
    try {
        const res = await axios.get("https://api.ipify.org?format=json", { timeout: 3000 });
        publicIp = res.data.ip;
    } catch {
        publicIp = "127.0.0.1";
    }
}
fetchIp();

async function buildText(wsPing) {
    const now = new Date();
    const formattedTime = now.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    const cpuPercent = getCpuLoad();
    const cpuBar = generateProgressBar(cpuPercent);

    // RAM Usage
    const memUsed = process.memoryUsage().rss;
    let memTotal = os.totalmem();
    if (process.env.SERVER_MEMORY) {
        memTotal = parseInt(process.env.SERVER_MEMORY) * 1024 * 1024;
    }
    const memPercent = Math.min(100, Math.round((memUsed / memTotal) * 100));
    const ramBar = generateProgressBar(memPercent);

    // DISK Usage
    let diskUsed = 0;
    let diskTotal = 100 * 1024 * 1024 * 1024;

    try {
        const fsStats = fs.statfsSync("/");
        diskTotal = fsStats.blocks * fsStats.bsize;
        diskUsed = (fsStats.blocks - fsStats.bfree) * fsStats.bsize;
    } catch {
        diskUsed = memUsed * 3;
        diskTotal = memTotal * 5;
    }

    if (process.env.SERVER_DISK) {
        diskTotal = parseInt(process.env.SERVER_DISK) * 1024 * 1024;
    }

    const diskPercent = Math.min(100, Math.round((diskUsed / diskTotal) * 100));
    const diskBar = generateProgressBar(diskPercent);

    const botUptime = formatUptime(process.uptime());
    const sysUptime = formatUptime(os.uptime());

    return `📡 *Helper | System Monitoring*
🕒 *Waktu* : ${formattedTime} WIB

🛠 *Resources Usage*
🛡 *CPU Bot Load* : ${cpuPercent}%
\`\`\`${cpuBar}\`\`\`
🏮 *RAM Bot Usage* : ${formatBytes(memUsed)} / ${formatBytes(memTotal)}
\`\`\`${ramBar}\`\`\`
🧿 *DISK Bot Usage* : ${formatBytes(diskUsed)} / ${formatBytes(diskTotal)}
\`\`\`${diskBar}\`\`\`

🌏 *Network & Latency*
🕹 *WS Ping* : ${wsPing}ms
🎛 *IP* : \`${publicIp}\`

🕒 *Uptime*
⏰ *Bot Uptime* : \`${botUptime}\`
🖥 *System Uptime* : \`${sysUptime}\``;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m || !m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        // ================= VALIDASI PERINTAH & ALIAS =================
        const validCommands = /^(monitor|info|server)$/i;
        if (!validCommands.test(command)) return;

        // ================= CEK USER TERDAFTAR (userwa.json) =================
        const dbUserPath = path.join(__dirname, "../databasewa/userwa.json");
        if (fs.existsSync(dbUserPath)) {
            const userDb = JSON.parse(fs.readFileSync(dbUserPath, "utf-8"));
            if (!userDb.includes(sender)) return;
        } else {
            return;
        }

        // 1. Reaksi emoji proses 📡
        await sock.sendMessage(from, { react: { text: "📡", key: m.key } });

        const timestampMsg = (m.messageTimestamp ? (m.messageTimestamp.low || m.messageTimestamp) * 1000 : Date.now());
        let wsPing = Math.max(1, Date.now() - timestampMsg);

        const initialText = await buildText(wsPing);

        // Kirim pesan monitor pertama kali
        const sentMsg = await sock.sendMessage(from, { text: initialText }, { quoted: m });

        // Reaksi emoji sukses ✅
        await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

        // Auto update pesan real-time setiap 5 detik (selama 1 menit)
        let count = 0;
        const interval = setInterval(async () => {
            count++;
            if (count > 12) { // Berhenti otomatis setelah 1 menit (12x5dtk) agar resource tetap aman
                clearInterval(interval);
                return;
            }
            try {
                const updatePingStart = Date.now();
                const updatedText = await buildText(wsPing);
                await sock.sendMessage(from, {
                    text: updatedText,
                    edit: sentMsg.key
                });
                wsPing = Date.now() - updatePingStart;
            } catch (err) {
                clearInterval(interval);
            }
        }, 5000);

    } catch (e) {
        console.error("Monitoring Error:", e);
        // Reaksi emoji gagal ❌ jika ada kendala
        await sock.sendMessage(jid, { react: { text: "❌", key: m.key } });
    }
};