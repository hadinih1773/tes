const axios = require("axios");
const fs = require("fs");
const path = require("path");
const https = require("https");

const userPath = path.join(__dirname, "../databasewa/userwa.json");

const agent = new https.Agent({
    rejectUnauthorized: false,
    keepAlive: true
});

async function fetchServers() {
    try {
        const res = await axios.get("https://sa-mp.co.id/api/server.php", {
            params: { _: Date.now() },
            headers: {
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": "https://sa-mp.co.id/",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
            },
            httpsAgent: agent,
            timeout: 30000
        });
        
        if (Array.isArray(res.data)) {
            return res.data.slice(0, 10);
        } else if (res.data && typeof res.data === 'object' && Array.isArray(res.data.servers)) {
             return res.data.servers.slice(0, 10);
        }
        return null;
    } catch (err) {
        console.error("Fetch error:", err.message);
        return null;
    }
}

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;
        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;
        
        // Pengecekan User Daftar
        if (!fs.existsSync(userPath)) return;
        const userDb = JSON.parse(fs.readFileSync(userPath));
        const isRegistered = userDb.includes(sender);
        if (!isRegistered) return;

        if (command === 'listserver') {
            // Reaction Command
            await sock.sendMessage(from, { react: { text: "🔍", key: m.key } });
            const servers = await fetchServers();
            if (!servers || !Array.isArray(servers)) {
                return await sock.sendMessage(from, { text: "❌ Gagal mengambil data server SA-MP." }, { quoted: m });
            }
            let teks = "🖥 *LIST SERVER GTA SA-MP INDONESIA* 🇮🇩\n\n";
            servers.forEach((s, i) => {
                let weburl = s.weburl ? s.weburl.trim() : "-";
                teks += `*${i + 1}. ${s.hostname}*\n`;
                teks += `🚨 Status: _${s.online ? "Online" : "Offline"}_\n`;
                teks += `📡 IP: \`${s.ipAddress}:${s.port}\`\n`;
                teks += `👤 Player: \`${s.onlinePlayers}/${s.maxplayers}\`\n`;
                teks += `🎮 Gamemode: \`${s.gamemode}\`\n`;
                teks += `🔗 Link: ${weburl}\n\n`;
            });
            teks += "_Auto-update data real-time_";
            await sock.sendMessage(from, { text: teks }, { quoted: m });
        }
    } catch (err) {
        console.log(err);
    }
};
