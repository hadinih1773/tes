const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

const adminPath = path.join(__dirname, '../databasewa/adminwa.json');
const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');
const userPath = path.join(__dirname, '../databasewa/userwa.json');

module.exports = async (sock, m, { jid, text, command, args }) => {
    try {
        if (!m.message) return;

        const from = jid;
        const sender = m.key.participant || m.key.remoteJid;

        const userDb = JSON.parse(fs.readFileSync(userPath, 'utf-8'));
        const isUser = userDb.includes(sender);
        if (!isUser) return;

        const adminDb = JSON.parse(fs.readFileSync(adminPath, 'utf-8'));
        const ownerDb = JSON.parse(fs.readFileSync(ownerPath, 'utf-8'));

        const isOwner = ownerDb.includes(sender);
        const isAdmin = adminDb.includes(sender);
        const hasAccess = isOwner || isAdmin;

        // Fungsi Helper Kirim Tombol Copy
        const sendCopyButton = async (targetJid, contentText, code, mentions = []) => {
            let msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.fromObject({ text: contentText }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: [{
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "Copy ID",
                                        copy_code: code
                                    })
                                }]
                            }),
                            contextInfo: { mentionedJid: mentions, quotedMessage: m.message }
                        })
                    }
                }
            }, { userJid: targetJid, quoted: m });
            await sock.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        };

        // 1. .cekid
        if (command === 'cekid') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            
            if (!hasAccess) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Hanya Admin Yang Bisa Gunakan' }, { quoted: m });
            }
            
            const quoted = m.message.extendedTextMessage?.contextInfo?.participant;
            const mention = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            let target = quoted || mention;

            if (!target && args[0]) {
                target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
            }

            if (!target) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Format Salah : `.cekid @tag/reply/628xx`' }, { quoted: m });
            }

            let joinDate = "-";
            if (from.endsWith('@g.us')) {
                const groupMetadata = await sock.groupMetadata(from);
                const participant = groupMetadata.participants.find(p => p.id === target);
                if (participant) {
                    joinDate = participant.date ? new Date(participant.date * 1000).toLocaleString('id-ID') : "-";
                }
            }

            const responseText = `*User* : @${target.split('@')[0]}\n*ID* : ${target}\n*Date* : ${joinDate}`;
            await sendCopyButton(from, responseText, target, [target]);
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        }

        // 2. .cekidgc
        if (command === 'cekidgc') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            
            if (!hasAccess) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Hanya Admin Yang Bisa Gunakan' }, { quoted: m });
            }
            
            let targetJid = from;
            if (args[0] && args[0].includes('chat.whatsapp.com')) {
                const code = args[0].split('https://chat.whatsapp.com/')[1];
                const info = await sock.groupGetInviteInfo(code);
                targetJid = info.id;
            }

            if (!targetJid.endsWith('@g.us')) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Command ini hanya bisa digunakan di dalam grup atau menggunakan link.' }, { quoted: m });
            }

            const metadata = await sock.groupMetadata(targetJid);
            const creationDate = new Date(metadata.creation * 1000).toLocaleString('id-ID');
            const admins = metadata.participants.filter(p => p.admin).map(p => p.id);
            
            const responseText = `*Nama Grup* : ${metadata.subject}\n*ID Grup* : ${targetJid}\n*Owner Grup* : @${(metadata.owner || '').split('@')[0]}\n*Admin Grup* : ${admins.map(v => '@' + v.split('@')[0]).join(', ')}\n*Tanggal Dibuat* : ${creationDate}`;
            
            await sendCopyButton(from, responseText, targetJid, [metadata.owner, ...admins]);
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        }

        // 3. .myid
        if (command === 'myid') {
            await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
            
            if (!isOwner) {
                await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                return await sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
            }
            
            const responseText = `*User* : @${sender.split('@')[0]}\n*ID* : ${sender}`;
            await sendCopyButton(from, responseText, sender, [sender]);
            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
        }

    } catch (err) {
        console.error(err);
        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
    }
};