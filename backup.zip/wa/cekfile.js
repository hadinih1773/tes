const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const SUSPICIOUS_PATTERNS = [
  "discord.com/api/webhooks",
  "sendMessageToDiscord",
  "ssl.https",
  "socket.http",
  "load",
  "sampGetPlayerNickname",
  "sampGetCurrentServerAddress",
  "onSendDialogResponse",
  "LuaObfuscator.com",
  "logKey",
  "captureKey",
  "recordKey",
  "keystroke",
  "hookkeyboard",
  "getkeystate",
  "readInput",
  "keyboard.",
  "input.",
  "onKeyPress",
  "RegisterHotKey",
  "GetAsyncKeyState",
  "Event.Key",
  "obfuscator",
  "sendToEmbed",
  "eval",
  "curl",
  "SendRequest",
  "PostRequest",
  "GetRequest",
  "fetch",
  "XMLHttpRequest",
  "popen",
  "ProcessBuilder",
  "CookieSteal"
];

const HIGH_RISK_PATTERNS = [
  "request",
  "sendToDiscordEmbed",
  "sampGetCurrentServerName",
  "load",
  "sampGetPlayerNickname",
  "sampGetCurrentServerAddress",
  "onSendDialogResponse",
  "discord.com/api/webhooks",
  "sendMessageToDiscord",
  "logger",
  "registerhotkey"
];

function analyzeContent(content) {
  const detected = [];
  const lower = content.toLowerCase();
  SUSPICIOUS_PATTERNS.forEach(pattern => {
    if (lower.includes(pattern.toLowerCase())) {
      detected.push(pattern);
    }
  });
  return detected;
}

function formatBytes(bytes, decimals = 2) {
    if (!bytes || bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes > 0) return `${minutes} Menit`;
    return `${seconds} Detik`;
}

function extractWebhook(content) {
    const regex = /https:\/\/discord\.com\/api\/webhooks\/\d+\/[a-zA-Z0-9_-]+/g;
    const found = content.match(regex);
    return found ? found[0] : null;
}

module.exports = async (sock, m, { jid, text, command, args }) => {
  try {
    const userDbPath = path.join(__dirname, "../databasewa/userwa.json");

    if (!m.message) return;

    const cmdLower = command?.toLowerCase();
    if (cmdLower === 'cekfile' || cmdLower === 'cek' || cmdLower === 'check') {
      const from = jid;
      const sender = m.key.participant || m.key.remoteJid;
      
      const users = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
      if (!users.includes(sender)) return;

      let targetMsg = m.message.documentMessage || m.message.extendedTextMessage?.contextInfo?.quotedMessage?.documentMessage;

      if (!targetMsg) {
        return await sock.sendMessage(from, { text: '❌ Format Salah : `.cekfile reply file`' }, { quoted: m });
      }

      const fileName = targetMsg.fileName.toLowerCase();
      if (!fileName.endsWith('.lua') && !fileName.endsWith('.txt') && !fileName.endsWith('.luac')) {
        return await sock.sendMessage(from, { 
          text: '🚨 *File Tidak Support*\n\nFile yang support untuk dicek adalah file dengan format .lua, .txt, dan .luac . Terima Kasih 😘💕' 
        }, { quoted: m });
      }

      const startTime = Date.now();
      await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });

      const stream = await downloadContentFromMessage(targetMsg, 'document');
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      const fileContent = buffer.toString('utf-8');
      const found = analyzeContent(fileContent);
      const duration = Date.now() - startTime;

      const highRiskMatches = found.filter(p => HIGH_RISK_PATTERNS.includes(p.toLowerCase()));
      const webhook = extractWebhook(fileContent);
      const block = "```\n" + found.join("\n") + "\n```";

      const commonDesc = `📁 Nama File : \`${targetMsg.fileName}\`\n📦 Ukuran : ${formatBytes(Number(targetMsg.fileLength))}\n🕒 Durasi : ${formatDuration(duration)}`;
      let responseText = "";

      if (found.length === 0) {
        responseText = `✅ *Scan File Successful : ${targetMsg.fileName}*\n\n${commonDesc}\n⚠️ Threat : Low\n\n📖 Detail :\nTidak Ditemukan Pola Yang Mencurigakan`;
      } else if (highRiskMatches.length > 1) {
        responseText = `✅ *Scan File Successful : ${targetMsg.fileName}*\n\n${commonDesc}\n⚠️ Threat : High\n\n${webhook ? `📋 Detail :\n🔗 Discord Webhook Detected\n${webhook}\n\n` : "📋 Detail : \n"}Ditemukan Pola Yang Mencurigakan (${found.length})\n${block}`;
      } else {
        responseText = `✅ *Scan File Successful : ${targetMsg.fileName}*\n\n${commonDesc}\n⚠️ Threat : Medium\n\n📋 Detail :\nDitemukan Pola Yang Mencurigakan (${found.length})\n${block}`;
      }

      await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
      await sock.sendMessage(from, { text: responseText }, { quoted: m });
    }
  } catch (err) {
    console.error("Cekfile Error:", err);
    try {
      const from = jid;
      await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
    } catch (reactErr) {
      // Silent catch
    }
  }
};