const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    makeCacheableSignalKeyStore, 
    DisconnectReason,
    fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');
const { initFunction } = require('buttons-warpper');
const pino = require('pino');
const fs = require('fs-extra');
const path = require('path');

// PERBAIKAN: Path yang benar untuk akses folder lib dari folder wa
const listener = require('../lib/listener');

class JadiBotManager {
    constructor() {
        this.baseDir = path.join(__dirname, '../jadibot-session');
        this.dbFile = path.join(__dirname, '../databasewa/jadibot.json');
        this.bots = new Map();
        this.botMetadata = new Map();
        this.parentSock = null;

        if (!fs.existsSync(this.baseDir)) fs.mkdirSync(this.baseDir, { recursive: true });
        if (!fs.existsSync(path.dirname(this.dbFile))) fs.mkdirSync(path.dirname(this.dbFile), { recursive: true });
        if (!fs.existsSync(this.dbFile)) fs.writeJsonSync(this.dbFile, []);
    }

    async savePersistence() {
        const botsData = [];
        for (const [sessionId, metadata] of this.botMetadata.entries()) {
            botsData.push({
                sessionId,
                userJid: metadata.userJid,
                phoneNumber: metadata.phoneNumber,
                chatId: metadata.chatId,
                createdAt: metadata.createdAt,
                status: metadata.status,
                isNotified: metadata.isNotified 
            });
        }
        await fs.writeJson(this.dbFile, botsData, { spaces: 2 });
    }

    async loadSessions() {
        try {
            if (!fs.existsSync(this.dbFile)) return;
            let botsData = await fs.readJson(this.dbFile).catch(() => []);
            for (const data of botsData) {
                this.botMetadata.set(data.sessionId, { ...data, isRestart: true, isNotified: true });
                const { sock: botSock } = await this.createSocket(data.sessionId, data.phoneNumber);
                this.bots.set(data.sessionId, botSock);
                this.setupSocketEventHandlers(botSock, data.sessionId);
            }
        } catch (e) { console.error("Gagal load sessions:", e); }
    }

    async createSocket(sessionId, phoneNumber) {
        const sessionDir = path.join(this.baseDir, sessionId);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" })),
            },
            printQRInTerminal: false,
            logger: pino({ level: "fatal" }),
            browser: ["Ubuntu", "Chrome", "20.0.04"],
            mobile: false,
            phoneNumber: phoneNumber
        });

        if (!sock.authState.creds.registered) {
            setTimeout(async () => {
                try {
                    let code = await sock.requestPairingCode(phoneNumber.trim());
                    const meta = this.botMetadata.get(sessionId);
                    if (this.parentSock && meta && meta.chatId) {
                        await this.parentSock.sendMessage(meta.chatId, {
                            text: `🤖 Kode Pairing Jadibot\n\n📱 Nomor: ${phoneNumber}\n🔐 Kode Pairing: ${code}`
                        });
                    }
                } catch (error) { console.error("❌ Gagal meminta kode pairing:", error); }
            }, 3000);
        }

        sock.ev.on('creds.update', saveCreds);
        return { sock, state, saveCreds };
    }

    setupSocketEventHandlers(sock, sessionId) {
        const meta = this.botMetadata.get(sessionId);
        if (!meta) return;

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === 'open') {
                meta.status = 'connected';
                await initFunction(sock);
                sock.isChildBot = true;

                // Hubungkan listener utama ke anak bot
                sock.ev.on('messages.upsert', async (m) => {
                    await listener(sock, m);
                });

                if (this.parentSock && meta.chatId && !meta.isNotified) {
                    await this.parentSock.sendMessage(meta.chatId, { 
                        text: `✅ Jadibot Terhubung\n\n📱 Nomor: ${sock.user.id.split(':')[0]}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}` 
                    });
                    meta.isNotified = true; 
                }
                
                await this.savePersistence();
                meta.isRestart = false; 
            }

            if (connection === 'close') {
                const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
                if (shouldReconnect) {
                    this.bots.delete(sessionId);
                    setTimeout(async () => {
                        const { sock: newSock } = await this.createSocket(sessionId, meta.phoneNumber);
                        this.bots.set(sessionId, newSock);
                        this.setupSocketEventHandlers(newSock, sessionId);
                    }, 5000);
                } else {
                    this.bots.delete(sessionId);
                    this.botMetadata.delete(sessionId);
                    const sessionDir = path.join(this.baseDir, sessionId);
                    if (fs.existsSync(sessionDir)) await fs.remove(sessionDir);
                    await this.savePersistence();
                }
            }
        });
    }

    getStatus(sessionId) {
        const meta = this.botMetadata.get(sessionId);
        return meta ? { exists: true, ...meta } : { exists: false };
    }

    getAllBots() { return Array.from(this.botMetadata.values()); }

    async deleteSession(sessionId) {
        const sock = this.bots.get(sessionId);
        if (sock) {
            try { await sock.logout(); } catch (e) {}
            this.bots.delete(sessionId);
        }
        this.botMetadata.delete(sessionId);
        const sessionDir = path.join(this.baseDir, sessionId);
        if (fs.existsSync(sessionDir)) {
            await fs.remove(sessionDir);
        }
        await this.savePersistence();
        return { success: true };
    }
}

const manager = new JadiBotManager();

module.exports = {
    setup(sock) {
        manager.parentSock = sock;
        const ownerPath = path.join(__dirname, '../databasewa/ownerwa.json');
        
        manager.loadSessions();

        // Handler pesan khusus untuk Main Bot (untuk mengelola command .jadibot)
        sock.ev.on('messages.upsert', async (chatUpdate) => {
            try {
                if (chatUpdate.type !== 'notify' && chatUpdate.type !== 'append') return;
                const m = chatUpdate.messages[0];
                if (!m.message) return;

                const from = m.key.remoteJid;
                const sender = m.key.participant || m.key.remoteJid;
                
                // Parsing body sederhana khusus untuk command manajemen jadibot
                const body = (m.message.conversation) ? m.message.conversation : 
                             (m.message.extendedTextMessage) ? m.message.extendedTextMessage.text : '';
                
                if (!body.startsWith('.')) return;
                const args = body.trim().split(/ +/).slice(1).join(' ');
                const command = body.trim().split(/ +/)[0].toLowerCase();

                const owners = fs.existsSync(ownerPath) ? JSON.parse(fs.readFileSync(ownerPath, 'utf-8')) : [];
                const isOwner = owners.includes(sender);

                if (command === '.jadibot') {
                    await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                    if (!isOwner) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
                    }
                    const phoneNumber = args.replace(/[^0-9]/g, '');
                    if (!phoneNumber) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: `❌ Format Salah : \`${command} 628xx\`` }, { quoted: m });
                    }
                    
                    if (manager.bots.has(phoneNumber)) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: '❌ Nomor tersebut sudah aktif!' }, { quoted: m });
                    }

                    manager.botMetadata.set(phoneNumber, {
                        userJid: sender, phoneNumber: phoneNumber, chatId: from, createdAt: new Date().toLocaleString('id-ID'), status: 'connecting', isRestart: false, isNotified: false 
                    });

                    const { sock: botSock } = await manager.createSocket(phoneNumber, phoneNumber);
                    manager.bots.set(phoneNumber, botSock);
                    manager.setupSocketEventHandlers(botSock, phoneNumber);
                    await sock.sendMessage(from, { text: "✅ Sedang membuat bot... Kode pairing akan dikirim segera!" }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                }

                if (command === '.statusjadibot') {
                    await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                    const phoneNumber = args.replace(/[^0-9]/g, '');
                    if (!phoneNumber) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: `❌ Format Salah : \`${command} 628xx\`` }, { quoted: m });
                    }
                    const status = manager.getStatus(phoneNumber);
                    if (!status.exists) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: '❌ Nomor tidak terdaftar.' }, { quoted: m });
                    }
                    await sock.sendMessage(from, { text: `✅ STATUS BOT\n\n• Status: ${status.status}\n• Nomor: ${status.phoneNumber}\n• Dibuat: ${status.createdAt}` }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                }

                if (command === '.deletejadibot') {
                    await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                    if (!isOwner) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: '❌ Hanya Owner Yang Bisa Gunakan' }, { quoted: m });
                    }
                    const phoneNumber = args.replace(/[^0-9]/g, '');
                    if (!phoneNumber) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: `❌ Format Salah : \`${command} 628xx\`` }, { quoted: m });
                    }
                    await manager.deleteSession(phoneNumber);
                    await sock.sendMessage(from, { text: `✅ Sesi bot ${phoneNumber} dihapus!` }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                }

                if (command === '.listjadibot') {
                    await sock.sendMessage(from, { react: { text: "⏱️", key: m.key } });
                    const bots = manager.getAllBots();
                    if (bots.length === 0) {
                        await sock.sendMessage(from, { react: { text: "❌", key: m.key } });
                        return sock.sendMessage(from, { text: '❌ Tidak ada bot aktif.' }, { quoted: m });
                    }
                    let txt = `📋 Daftar Nomor Jadibot\nTotal: ${bots.length}\n\n`;
                    bots.forEach((bot, i) => { txt += `${i + 1}. @${bot.phoneNumber}\nStatus: ${bot.status}\n\n`; });
                    await sock.sendMessage(from, { text: txt, mentions: bots.map(b => b.phoneNumber + '@s.whatsapp.net') }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: "✅", key: m.key } });
                }
            } catch (err) { console.error('Jadibot Error:', err); }
        });
    }
};