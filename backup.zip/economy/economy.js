const { EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../database/economy.json");

// 30 Daftar Hewan Buas / Liar + Item Hasil Pancing & Tambang dengan range harga beli, harga jual random + Emoji
const shopItems = {
  "rusa": { name: "Rusa", emoji: "🦌", buyMin: 1000, buyMax: 2000, sellMin: 600, sellMax: 1200 },
  "kelinci": { name: "Kelinci", emoji: "🐇", buyMin: 300, buyMax: 700, sellMin: 200, sellMax: 450 },
  "babi": { name: "Babi Hutan", emoji: "🐗", buyMin: 900, buyMax: 1500, sellMin: 500, sellMax: 950 },
  "ayam": { name: "Ayam Hutan", emoji: "🐓", buyMin: 200, buyMax: 500, sellMin: 100, sellMax: 250 },
  "serigala": { name: "Serigala", emoji: "🐺", buyMin: 1500, buyMax: 3000, sellMin: 700, sellMax: 1400 },
  "beruang": { name: "Beruang", emoji: "🐻", buyMin: 3000, buyMax: 6000, sellMin: 1400, sellMax: 2800 },
  "harimau": { name: "Harimau", emoji: "🐯", buyMin: 4000, buyMax: 8000, sellMin: 1900, sellMax: 3800 },
  "singa": { name: "Singa", emoji: "🦁", buyMin: 4500, buyMax: 9000, sellMin: 2100, sellMax: 4200 },
  "macan": { name: "Macan Tutul", emoji: "🐆", buyMin: 3500, buyMax: 7000, sellMin: 1600, sellMax: 3300 },
  "ular": { name: "Ular Kobra", emoji: "🐍", buyMin: 800, buyMax: 1800, sellMin: 400, sellMax: 900 },
  "buaya": { name: "Buaya", emoji: "🐊", buyMin: 2500, buyMax: 5000, sellMin: 1200, sellMax: 2400 },
  "banteng": { name: "Banteng", emoji: "🐂", buyMin: 2000, buyMax: 4000, sellMin: 900, sellMax: 1900 },
  "rubah": { name: "Rubah", emoji: "🦊", buyMin: 600, buyMax: 1300, sellMin: 300, sellMax: 650 },
  "elang": { name: "Elang", emoji: "🦅", buyMin: 1200, buyMax: 2500, sellMin: 550, sellMax: 1150 },
  "burung": { name: "Burung Hantu", emoji: "🦉", buyMin: 400, buyMax: 900, sellMin: 180, sellMax: 400 },
  "landak": { name: "Landak", emoji: "🦔", buyMin: 350, buyMax: 800, sellMin: 150, sellMax: 380 },
  "luwak": { name: "Luwak", emoji: "🦦", buyMin: 500, buyMax: 1100, sellMin: 220, sellMax: 500 },
  "kancil": { name: "Kancil", emoji: "🦌", buyMin: 450, buyMax: 1000, sellMin: 200, sellMax: 480 },
  "tupai": { name: "Tupai", emoji: "🐿️", buyMin: 150, buyMax: 400, sellMin: 70, sellMax: 180 },
  "musang": { name: "Musang", emoji: "🦡", buyMin: 400, buyMax: 900, sellMin: 180, sellMax: 420 },
  "gorila": { name: "Gorila", emoji: "🦍", buyMin: 3800, buyFace: 7500, buyMax: 7500, sellMin: 1800, sellMax: 3600 },
  "simpanse": { name: "Simpanse", emoji: "🐒", buyMin: 1500, buyMax: 3200, sellMin: 700, sellMax: 1500 },
  "babon": { name: "Monyet Babon", emoji: "🦧", buyMin: 1000, buyMax: 2200, sellMin: 450, sellMax: 1000 },
  "hyena": { name: "Hyena", emoji: "🐺", buyMin: 1800, buyMax: 3600, sellMin: 850, sellMax: 1700 },
  "cheetah": { name: "Cheetah", emoji: "🐆", buyMin: 4000, buyMax: 7800, sellMin: 1900, sellMax: 3700 },
  "badak": { name: "Badak", emoji: "🦏", buyMin: 5000, buyMax: 10000, sellMin: 2400, sellMax: 4800 },
  "gajah": { name: "Gajah", emoji: "🐘", buyMin: 5500, buyMax: 11000, sellMin: 2600, sellMax: 5300 },
  "kudanil": { name: "Kuda Nil", emoji: "🦛", buyMin: 4800, buyMax: 9500, sellMin: 2200, sellMax: 4600 },
  "jerapah": { name: "Jerapah", emoji: "🦒", buyMin: 3000, buyMax: 6500, sellMin: 1400, sellMax: 3000 },
  "zebra": { name: "Zebra", emoji: "🦓", buyMin: 2000, buyMax: 4500, sellMin: 950, sellMax: 2100 },
  
  // Item Hasil Memancing
  "lele": { name: "Ikan Lele", emoji: "🐟", buyMin: 150, buyMax: 350, sellMin: 80, sellMax: 160 },
  "gurame": { name: "Ikan Gurame", emoji: "🐠", buyMin: 400, buyMax: 800, sellMin: 200, sellMax: 400 },
  "tuna": { name: "Ikan Tuna", emoji: "🐟", buyMin: 1000, buyMax: 2500, sellMin: 500, sellMax: 1200 },
  "salmon": { name: "Ikan Salmon", emoji: "🍣", buyMin: 1500, buyMax: 3500, sellMin: 750, sellMax: 1700 },
  "hiu": { name: "Ikan Hiu", emoji: "🦈", buyMin: 5000, buyMax: 9000, sellMin: 2300, sellMax: 4500 },

  // Item Hasil Menambang
  "berlian": { name: "Berlian", emoji: "💎", buyMin: 8000, buyMax: 15000, sellMin: 4000, sellMax: 7500 },
  "emas": { name: "Emas", emoji: "🪙", buyMin: 4000, buyMax: 8000, sellMin: 2000, sellMax: 4000 },
  "perak": { name: "Perak", emoji: "🥈", buyMin: 1500, buyMax: 3000, sellMin: 700, sellMax: 1400 },
  "emerald": { name: "Batu Emerald", emoji: "💚", buyMin: 3000, buyMax: 6000, sellMin: 1400, sellMax: 2900 },
  "batubara": { name: "Batu Bara", emoji: "🪨", buyMin: 200, buyMax: 500, sellMin: 90, sellMax: 220 },
  "minyak": { name: "Miyak Bumi", emoji: "🛢️", buyMin: 2500, buyMax: 5000, sellMin: 1200, sellMax: 2400 }
};

function readDB() {
  if (!fs.existsSync(path.dirname(dbPath))) {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}), "utf8");
  }
  try {
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch (e) {
    return {};
  }
}

function writeDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), "utf8");
}

function getUserData(guildId, userId) {
  const db = readDB();
  if (!db[guildId]) db[guildId] = {};
  if (!db[guildId][userId]) {
    db[guildId][userId] = {
      wallet: 0,
      bank: 0,
      lastWork: 0,
      lastDaily: 0,
      lastWeekly: 0,
      lastHunt: 0,
      lastFish: 0,
      lastMine: 0,
      workCooldown: 0,
      inventory: {},
      xp: 0,
      level: 1
    };
  }
  if (!db[guildId][userId].inventory) db[guildId][userId].inventory = {};
  if (db[guildId][userId].xp === undefined) db[guildId][userId].xp = 0;
  if (db[guildId][userId].level === undefined) db[guildId][userId].level = 1;
  if (db[guildId][userId].lastHunt === undefined) db[guildId][userId].lastHunt = 0;
  if (db[guildId][userId].lastFish === undefined) db[guildId][userId].lastFish = 0;
  if (db[guildId][userId].lastMine === undefined) db[guildId][userId].lastMine = 0;
  return { db, user: db[guildId][userId] };
}

function formatCooldown(ms) {
  const totalSecs = Math.floor(ms / 1000);
  const hours = Math.floor(totalSecs / 3600);
  const minutes = Math.floor((totalSecs % 3600) / 60);
  const seconds = totalSecs % 60;
  
  let res = [];
  if (hours > 0) res.push(`⏳ ${hours} Jam`);
  if (minutes > 0) res.push(`⏳ ${minutes} Menit`);
  if (seconds > 0) res.push(`⏳ ${seconds} Detik`);
  return res.join(" ") || "0 Detik";
}

function addXpRandom(guildId, userId, messageOrInteraction) {
  const chance = Math.random();
  if (chance > 0.5) { 
    const { db, user } = getUserData(guildId, userId);
    const xpGained = Math.floor(Math.random() * (25 - 5 + 1)) + 5;
    user.xp += xpGained;
    
    const xpNeeded = 1000;
    let levelUp = false;
    if (user.xp >= xpNeeded) {
      user.xp -= xpNeeded;
      user.level += 1;
      levelUp = true;
    }
    writeDB(db);

    if (levelUp) {
      let avatarURL = "";
      if (messageOrInteraction.author) {
        avatarURL = messageOrInteraction.author.displayAvatarURL({ dynamic: true });
      } else if (messageOrInteraction.user) {
        avatarURL = messageOrInteraction.user.displayAvatarURL({ dynamic: true });
      }

      const embed = new EmbedBuilder()
        .setTitle("🎉 Level Up Succes")
        .setDescription(`✨✨ Horeee! <@${userId}> Selamat Kamu Naik Ke Level **${user.level}**! ✨✨`)
        .setThumbnail(avatarURL)
        .setColor("#FFD700");
      
      messageOrInteraction.channel.send({ embeds: [embed] }).catch(() => {});
    }
  }
}

module.exports = {
  shopItems,
  readDB,
  writeDB,
  getUserData,
  formatCooldown,
  addXpRandom,
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      // Tambahkan level atau XP ketika chat biasa (tanpa harus menggunakan command)
      addXpRandom(message.guild.id, message.author.id, message);

      const args = message.content.trim().split(/ +/);
      let command = args.shift().toLowerCase();

      // Penanganan khusus pemisah pipa (|) untuk command !sell dan !buy
      let pipelineArgs = [];
      if (message.content.startsWith("!sell|") || message.content.startsWith("!sellall")) {
        pipelineArgs = message.content.trim().split("|");
        command = pipelineArgs.shift().toLowerCase(); // !sell atau !sellall
      } else if (message.content.startsWith("!buy|")) {
        pipelineArgs = message.content.trim().split("|");
        command = pipelineArgs.shift().toLowerCase(); // !buy
      }

      // MYSTATS COMMAND
      if (command === "!mystats" || command === "!me" || command === "!stats" || command === "!status") {
        const { user } = getUserData(message.guild.id, message.author.id);
        let itemsStr = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }
        const isiTas = itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Kamu Kosong.";

        const embed = new EmbedBuilder()
          .setTitle("📊 User Status Profile")
          .setDescription(`👤 **User Target:** <@${message.author.id}>\n💵 **Uang Saku:** $${user.wallet}\n🏦 **Saldo Bank:** $${user.bank}\n📈 **Level Status:** Lv. ${user.level} *(XP: ${user.xp}/1000)*\n\n🎒 **Isi Dalam Tas:**\n${isiTas}`)
          .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
          .setColor("#0099FF");
        message.reply({ embeds: [embed] });
        return;
      }

      // CEKSTATS COMMAND (ADMIN ONLY)
      if (command === "!cekstats" || command === "!cekme" || command === "!cekstatus" || command === "!cekplayer") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`${command} @user\`\``);
        }

        const { user } = getUserData(message.guild.id, targetMember.id);
        let itemsStr = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }
        const isiTas = itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Kamu Kosong.";

        const embed = new EmbedBuilder()
          .setTitle("📊 User Status Profile")
          .setDescription(`👤 **User Target:** <@${targetMember.id}>\n💵 **Uang Saku:** $${user.wallet}\n🏦 **Saldo Bank:** $${user.bank}\n📈 **Level Status:** Lv. ${user.level} *(XP: ${user.xp}/1000)*\n\n🎒 **Isi Dalam Tas:**\n${isiTas}`)
          .setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }))
          .setColor("#0099FF");
        message.reply({ embeds: [embed] });
        return;
      }

      // 1. WORK
      if (command === "!work") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        const now = Date.now();
        if (now < user.lastWork) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Working Rejected")
            .setDescription(`🛑 <@${message.author.id}> Anda Sudah Mengklaim Uang Kerja Coba Lagi Dalam ${formatCooldown(user.lastWork - now)}`)
            .setColor("#ff0000");
          return message.reply({ embeds: [embed] });
        }

        const randUang = Math.floor(Math.random() * (500 - 100 + 1)) + 100; 
        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000; 

        user.wallet += randUang;
        user.lastWork = now + randCooldown;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("💼 Working Reward")
          .setDescription(`✅ <@${message.author.id}> Kamu Telah Mendapatkan Uang Saku Sebesar **$${randUang}** dari pekerjaanmu!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // 2. DAILY
      if (command === "!daily") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        
        // Mendapatkan format tanggal hari ini (YYYY-MM-DD) berdasarkan zona waktu lokal server
        const todayDate = new Date().toISOString().slice(0, 10);

        if (user.lastDaily === todayDate) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Daily Rejected")
            .setDescription(`🛑 <@${message.author.id}> Anda Sudah Mengklaim Hari Ini Kembali Lagi Besok`)
            .setColor("#ff0000");
          return message.reply({ embeds: [embed] });
        }

        const randUang = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000;
        user.wallet += randUang;
        user.lastDaily = todayDate; // Menyimpan string tanggal hari ini
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("📅 Daily Reward")
          .setDescription(`✅ <@${message.author.id}> Kamu Telah Mendapatkan Uang Hadiah Harian Sebesar **$${randUang}**!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // 3. WEEKLY
      if (command === "!weekly") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        const now = Date.now();
        const cooldown = 7 * 24 * 60 * 60 * 1000;

        if (now - user.lastWeekly < cooldown) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Weekly Rejected")
            .setDescription(`🛑 <@${message.author.id}> Kembali Lagi Satu Minggu Kedepan Setelah Hari Ini`)
            .setColor("#ff0000");
          return message.reply({ embeds: [embed] });
        }

        const randUang = Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000;
        user.wallet += randUang;
        user.lastWeekly = now;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("📮 Weekly Reward")
          .setDescription(`✅ <@${message.author.id}> Kamu Telah Mendapatkan Uang Hadiah Mingguan Sebesar **$${randUang}**!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // 4. DEPOSITE
      if (command === "!deposite" || command === "!depo" || command === "!depositeall" || command === "!depoall") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        let amountStr = args[0];

        if (command === "!depositeall" || command === "!depoall" || (amountStr && amountStr.toLowerCase() === "all")) {
          const total = user.wallet;
          user.bank += total;
          user.wallet = 0;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("🏦 Deposite Money")
            .setDescription(`💰 <@${message.author.id}> Menyimpan Semua Uang Yang Ada Di Dompet Sebanyak **$${total}** Ke Bank!`)
            .setColor("#50C878");
          message.reply({ embeds: [embed] });
          return;
        }

        if (!amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`${command} Jumlah\`\``);
        }

        const amount = parseInt(amountStr);
        if (amount > user.wallet) {
          return message.reply("❌ Uang Di Saku Kamu Tidak Mencukupi.");
        }

        user.wallet -= amount;
        user.bank += amount;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("🏦 Deposite Money")
          .setDescription(`💰 <@${message.author.id}> Menyimpan Uang Di Bank Sebanyak **$${amount}**!`)
          .setColor("#50C878");
          message.reply({ embeds: [embed] });
        return;
      }

      // 5. WITHDRAW
      if (command === "!withdraw" || command === "!with" || command === "!withdrawall" || command === "!withall") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        let amountStr = args[0];

        if (command === "!withdrawall" || command === "!withall" || (amountStr && amountStr.toLowerCase() === "all")) {
          const total = user.bank;
          user.wallet += total;
          user.bank = 0;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("✍️ Withdraw Money")
            .setDescription(`💵 <@${message.author.id}> Mengambil Semua Uang Dari Bank Sebanyak **$${total}**!`)
            .setColor("#50C878");
          message.reply({ embeds: [embed] });
          return;
        }

        if (!amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`${command} Jumlah\`\``);
        }

        const amount = parseInt(amountStr);
        if (amount > user.bank) {
          return message.reply("❌ Uang Di Bank Kamu Tidak Mencukupi.");
        }

        user.bank -= amount;
        user.wallet += amount;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("✍️ Withdraw Money")
          .setDescription(`💵 <@${message.author.id}> Mengambil Uang Dari Bank Sebanyak **$${amount}**!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // 6. BALANCE
      if (command === "!balance" || command === "!bal") {
        const { user } = getUserData(message.guild.id, message.author.id);
        const embed = new EmbedBuilder()
          .setTitle("💸 Balance Money")
          .setDescription(`👤 **User Saku:** <@${message.author.id}>\n🏧 **Bank Balance:** $${user.bank}\n📥 **Dompet Saku:** $${user.wallet}\n📊 **Level Status:** Lv. ${user.level} *(XP: ${user.xp}/1000)*`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // 7. ROB
      if (command === "!rob") {
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`!rob @user\`\``);
        }
        if (targetMember.id === message.author.id) {
          return message.reply("❌ Kamu Tidak Bisa Merampok Diri Sendiri.");
        }

        const { db, user: attacker } = getUserData(message.guild.id, message.author.id);
        const { user: target } = getUserData(message.guild.id, targetMember.id);

        if (target.wallet < 100) {
          return message.reply("❌ Target Terlalu Miskin, Saku Mereka Tidak Memiliki Cukup Uang Untuk Dirampok.");
        }

        const chance = Math.random();
        if (chance > 0.4) {
          const robAmount = Math.floor(Math.random() * (target.wallet - 50 + 1)) + 50;
          target.wallet -= robAmount;
          attacker.wallet += robAmount;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("💂🏿‍♀️ Robbary User")
            .setDescription(`⚔️ <@${message.author.id}> Telah Mengambil Uang Saku <@${targetMember.id}> Sebesar **$${robAmount}**!`)
            .setColor("#50C878");
          message.reply({ embeds: [embed] });
        } else {
          const fine = Math.floor(Math.random() * (attacker.wallet > 100 ? 100 : attacker.wallet || 50)) + 10;
          attacker.wallet = Math.max(0, attacker.wallet - fine);
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("👮 Arrested by Police")
            .setDescription(`🚨 Sial! <@${message.author.id}> Ketahuan Aksi Merampok. Telah Ditangkap Oleh Polisi Dan Didenda Uang Sebanyak **$${fine}**!`)
            .setColor("#ff0000");
          message.reply({ embeds: [embed] });
        }
        return;
      }

      // 8. HUNT
      if (command === "!hunt" || command === "!buru") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        const now = Date.now();
        if (now < user.lastHunt) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Hunting Rejected")
            .setDescription(`🛑 <@${message.author.id}> Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastHunt - now)}`)
            .setColor("#ff0000");
          return message.reply({ embeds: [embed] });
        }

        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000; 
        user.lastHunt = now + randCooldown;

        const chance = Math.random();
        if (chance < 0.25) {
          const fine = Math.floor(Math.random() * (200 - 50 + 1)) + 50;
          user.wallet = Math.max(0, user.wallet - fine);
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("🐗 Hunt Disaster")
            .setDescription(`💥 Gawat! <@${message.author.id}> Kamu Diserang Oleh Babi Hutan! Uangmu Berkurang Sebanyak **$${fine}** Untuk Biaya Pengobatan Rumah Sakit.`)
            .setColor("#ff0000");
          message.reply({ embeds: [embed] });
        } else {
          const keys = ["rusa", "kelinci", "babi", "ayam", "serigala", "beruang", "harimau", "singa", "macan", "ular", "buaya", "banteng", "rubah", "elang", "burung", "landak", "luwak", "kancil", "tupai", "musang", "gorila", "simpanse", "babon", "hyena", "cheetah", "badak", "gajah", "kudanil", "jerapah", "zebra"];
          const randomKey = keys[Math.floor(Math.random() * keys.length)];
          
          user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("🏹 Hunting Succes")
            .setDescription(`🏹 <@${message.author.id}> Berhasil Memburu Dan Mendapatkan **1 ${shopItems[randomKey].emoji} ${shopItems[randomKey].name}**! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`)
            .setColor("#50C878");
          message.reply({ embeds: [embed] });
        }
        return;
      }

      // FISH
      if (command === "!fish" || command === "!mancing") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        const now = Date.now();
        if (now < user.lastFish) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Fishing Rejected")
            .setDescription(`🛑 <@${message.author.id}> Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastFish - now)}`)
            .setColor("#ff0000");
          return message.reply({ embeds: [embed] });
        }

        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastFish = now + randCooldown;

        const keys = ["lele", "gurame", "tuna", "salmon", "hiu"];
        const randomKey = keys[Math.floor(Math.random() * keys.length)];

        user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("🎣 Fishing Succes")
          .setDescription(`🌊 <@${message.author.id}> Berhasil Memancing Dan Mendapatkan **1 ${shopItems[randomKey].emoji} ${shopItems[randomKey].name}**! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // MINE
      if (command === "!mine" || command === "!mining") {
        const { db, user } = getUserData(message.guild.id, message.author.id);
        const now = Date.now();
        if (now < user.lastMine) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Mining Rejected")
            .setDescription(`🛑 <@${message.author.id}> Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastMine - now)}`)
            .setColor("#ff0000");
          return message.reply({ embeds: [embed] });
        }

        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastMine = now + randCooldown;

        const keys = ["berlian", "emas", "perak", "emerald", "batubara", "minyak"];
        const randomKey = keys[Math.floor(Math.random() * keys.length)];

        user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("⛏️ Mining Succes")
          .setDescription(`💎 <@${message.author.id}> Berhasil Menambang Dan Mendapatkan **1 ${shopItems[randomKey].emoji} ${shopItems[randomKey].name}**! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // INVENTORY
      if (command === "!inventory" || command === "!inv") {
        const { user } = getUserData(message.guild.id, message.author.id);
        let kancut = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) kancut.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }

        const embed = new EmbedBuilder()
          .setTitle("🎒 Your Inventory")
          .setDescription(kancut.length > 0 ? kancut.join("\n") : "✨ Inventory Tas Milikmu Masih Kosong.")
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // SELL
      if (command === "!sell" || command === "!sellall") {
        const { db, user } = getUserData(message.guild.id, message.author.id);

        if (command === "!sellall" || (pipelineArgs[0] && pipelineArgs[0].toLowerCase() === "all")) {
          let totalEarned = 0;
          let totalItems = 0;

          for (const [key, val] of Object.entries(user.inventory)) {
            if (val > 0) {
              const itemConf = shopItems[key];
              if (itemConf) {
                for (let i = 0; i < val; i++) {
                  totalEarned += Math.floor(Math.random() * (itemConf.sellMax - itemConf.sellMin + 1)) + itemConf.sellMin;
                }
                totalItems += val;
                user.inventory[key] = 0;
              }
            }
          }

          if (totalItems === 0) return message.reply("❌ Kamu Tidak Memiliki Barang Apapun Untuk Dijual.");
          user.wallet += totalEarned;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("💰 Sell All Items Succes")
            .setDescription(`💵 <@${message.author.id}> Berhasil Menjual Semua Isi Tas Sebanyak **${totalItems} Item** Dan Mendapatkan Uang Total Sebesar **$${totalEarned}**!`)
            .setColor("#50C878");
          message.reply({ embeds: [embed] });
          return;
        }

        const inputItem = pipelineArgs[0]?.toLowerCase();
        const inputQtyStr = pipelineArgs[1];

        if (!inputItem || (!shopItems[inputItem] && !Object.values(shopItems).some(i => i.name.toLowerCase() === inputItem))) {
          return message.reply(`❌ Format Salah : \`\`!sell|item|jumlah\`\``);
        }

        // Menemukan key item asli jika user memasukkan nama lengkap (seperti "batu bara")
        const itemKey = shopItems[inputItem] ? inputItem : Object.keys(shopItems).find(k => shopItems[k].name.toLowerCase() === inputItem);

        const qty = inputQtyStr ? parseInt(inputQtyStr) : 1;
        if (isNaN(qty) || qty <= 0) {
          return message.reply(`❌ Format Salah : \`\`!sell|item|jumlah\`\``);
        }

        if (!user.inventory[itemKey] || user.inventory[itemKey] < qty) {
          return message.reply("❌ Jumlah Item Di Inventory Kamu Tidak Mencukupi.");
        }

        let earned = 0;
        const itemConf = shopItems[itemKey];
        for (let i = 0; i < qty; i++) {
          earned += Math.floor(Math.random() * (itemConf.sellMax - itemConf.sellMin + 1)) + itemConf.sellMin;
        }

        user.inventory[itemKey] -= qty;
        user.wallet += earned;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("💰 Sell Item Succes")
          .setDescription(`💵 <@${message.author.id}> Berhasil Menjual **${qty} ${itemConf.emoji} ${itemConf.name}** Dan Mendapatkan Uang Saku Sebesar **$${earned}**!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // SHOP
      if (command === "!shop" || command === "!pasar") {
        const itemsArray = Object.entries(shopItems);
        const itemsPerPage = 10;
        const totalPages = Math.ceil(itemsArray.length / itemsPerPage);
        let currentPage = 0;

        const generateEmbed = (page) => {
          const start = page * itemsPerPage;
          const end = start + itemsPerPage;
          const pageItems = itemsArray.slice(start, end);

          let listStr = [];
          for (const [key, val] of pageItems) {
            const randomBuyPrice = Math.floor(Math.random() * (val.buyMax - val.buyMin + 1)) + val.buyMin;
            listStr.push(`${val.emoji} **${val.name}** (\`${key}\`)\n 🔹 Harga Beli: **$${randomBuyPrice}**\n 🔹 Estimasi Jual: **$${val.sellMin} - $${val.sellMax}**`);
          }

          return new EmbedBuilder()
            .setTitle("🏪 Economy Shop Market")
            .setDescription(listStr.join("\n\n"))
            .setFooter({ text: `Halaman ${page + 1} dari ${totalPages}` })
            .setColor("#50C878");
        };

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("shop_prev").setLabel("⬅️ Prev").setStyle(ButtonStyle.Primary).setDisabled(true),
          new ButtonBuilder().setCustomId("shop_next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(totalPages <= 1)
        );

        const shopMsg = await message.reply({ embeds: [generateEmbed(currentPage)], components: [row] });

        const filter = (i) => i.user.id === message.author.id;
        const collector = shopMsg.createMessageComponentCollector({ filter, time: 60000 });

        collector.on("collect", async (interaction) => {
          if (interaction.customId === "shop_prev") {
            currentPage--;
          } else if (interaction.customId === "shop_next") {
            currentPage++;
          }

          const updatedRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("shop_prev").setLabel("⬅️ Prev").setStyle(ButtonStyle.Primary).setDisabled(currentPage === 0),
            new ButtonBuilder().setCustomId("shop_next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(currentPage === totalPages - 1)
          );

          await interaction.update({ embeds: [generateEmbed(currentPage)], components: [updatedRow] });
        });

        collector.on("end", () => {
          const disabledRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("shop_prev").setLabel("⬅️ Prev").setStyle(ButtonStyle.Primary).setDisabled(true),
            new ButtonBuilder().setCustomId("shop_next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(true)
          );
          shopMsg.edit({ components: [disabledRow] }).catch(() => {});
        });
        return;
      }

      // BUY
      if (command === "!buy") {
        const inputItem = pipelineArgs[0]?.toLowerCase();
        const inputQtyStr = pipelineArgs[1];

        if (!inputItem || (!shopItems[inputItem] && !Object.values(shopItems).some(i => i.name.toLowerCase() === inputItem)) || !inputQtyStr || isNaN(inputQtyStr)) {
          return message.reply(`❌ Format Salah : \`\`!buy|item|jumlah\`\``);
        }

        const qty = parseInt(inputQtyStr);
        if (qty <= 0) return message.reply(`❌ Format Salah : \`\`!buy|item|jumlah\`\``);

        // Menemukan key item asli jika user memasukkan nama lengkap (seperti "batu bara")
        const itemKey = shopItems[inputItem] ? inputItem : Object.keys(shopItems).find(k => shopItems[k].name.toLowerCase() === inputItem);

        const { db, user } = getUserData(message.guild.id, message.author.id);
        const itemConf = shopItems[itemKey];
        const randomBuyPrice = Math.floor(Math.random() * (itemConf.buyMax - itemConf.buyMin + 1)) + itemConf.buyMin;
        const totalPrice = randomBuyPrice * qty;

        if (user.wallet < totalPrice) {
          return message.reply("❌ Uang Di Saku Kamu Tidak Mencukupi Untuk Membeli Item Ini.");
        }

        user.wallet -= totalPrice;
        user.inventory[itemKey] = (user.inventory[itemKey] || 0) + qty;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("🛒 Purchase Succes")
          .setDescription(`🛒 <@${message.author.id}> Berhasil Membeli **${qty} ${itemConf.emoji} ${itemConf.name}** Dengan Total Pembayaran Sebesar **$${totalPrice}**!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // TRANSFER
      if (command === "!transfer" || command === "!tf" || command === "!transfermoney") {
        const targetMember = message.mentions.members.first();
        const amountStr = args[1];

        if (!targetMember || !amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`${command} @user jumlah\`\``);
        }

        if (targetMember.id === message.author.id) {
          return message.reply("❌ Kamu Tidak Bisa Mentransfer Uang Ke Dirimu Sendiri.");
        }

        const amount = parseInt(amountStr);
        const { db, user: sender } = getUserData(message.guild.id, message.author.id);
        const { user: receiver } = getUserData(message.guild.id, targetMember.id);

        if (sender.wallet < amount) {
          return message.reply("❌ Uang Di Saku Kamu Tidak Mencukupi Untuk Melakukan Transfer.");
        }

        sender.wallet -= amount;
        receiver.wallet += amount;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("💸 Transfer Money Succes")
          .setDescription(`💸 <@${message.author.id}> Berhasil Mentransfer Uang Kiriman Sebesar **$${amount}** Kepada Target <@${targetMember.id}>!`)
          .setColor("#50C878");
        message.reply({ embeds: [embed] });
        return;
      }

      // LEADERBOARD
      if (command === "!leaderboard" || command === "!lb" || command === "!top") {
        const db = readDB();
        const guildData = db[message.guild.id] || {};
        
        let sorted = Object.keys(guildData)
          .map(userId => ({ id: userId, level: guildData[userId].level || 0 }))
          .filter(u => u.level > 0)
          .sort((a, b) => b.level - a.level);

        if (sorted.length === 0) {
          return message.reply("❌ Belum ada data pengguna dengan level di atas 0.");
        }

        const top10 = sorted.slice(0, 10);

        let lbStr = top10.map((u, index) => {
          let medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `🔹 **#${index + 1}**`;
          return `${medal} <@${u.id}> - **Level ${u.level}**`;
        }).join("\n");

        const embed = new EmbedBuilder()
          .setTitle("🏆 Top High Level Leaderboard")
          .setDescription(`Berikut peringkat pengguna dengan level tertinggi:\n\n${lbStr}`)
          .setColor("#FFD700");

        // Mengambil avatar dari pengguna peringkat 1
        try {
          const top1User = await message.guild.members.fetch(sorted[0].id).catch(() => null);
          if (top1User) {
            embed.setThumbnail(top1User.user.displayAvatarURL({ dynamic: true }));
          }
        } catch (e) {}

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("lb_check_my_rank")
            .setLabel("🔎 Cek Peringkat Saya")
            .setStyle(ButtonStyle.Secondary)
        );

        const lbMsg = await message.reply({ embeds: [embed], components: [row] });

        const collector = lbMsg.createMessageComponentCollector({ time: 60000 });

        collector.on("collect", async (interaction) => {
          if (interaction.customId === "lb_check_my_rank") {
            const userIndex = sorted.findIndex(u => u.id === interaction.user.id);
            if (userIndex === -1) {
              return interaction.reply({ content: `🏆 <@${interaction.user.id}> Peringkat Kamu Yaitu :\nBelum Terdaftar / Level 0`, ephemeral: true });
            }
            const myRank = userIndex + 1;
            const myLevel = sorted[userIndex].level;

            return interaction.reply({
              content: `🏆 <@${interaction.user.id}> Peringkat Kamu Yaitu :\n#${myRank} <@${interaction.user.id}> - Level ${myLevel}`,
              ephemeral: true
            });
          }
        });

        collector.on("end", () => {
          const disabledRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("lb_check_my_rank")
              .setLabel("🔎 Cek Peringkat Saya")
              .setStyle(ButtonStyle.Secondary)
              .setDisabled(true)
          );
          lbMsg.edit({ components: [disabledRow] }).catch(() => {});
        });

        return;
      }

      // ADMIN ADD MONEY
      if (command === "!addmoney") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        const amountStr = args[1];
        if (!targetMember || !amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`!addmoney @user jumlah\`\``);
        }
        const amount = parseInt(amountStr);
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.wallet += amount;
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Menambahkan Uang Sebesar **$${amount}** Ke Saku <@${targetMember.id}>`);
      }

      // ADMIN TAKE MONEY
      if (command === "!takemoney") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        const amountStr = args[1];
        if (!targetMember || !amountStr || isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`!takemoney @user jumlah\`\``);
        }
        const amount = parseInt(amountStr);
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.wallet = Math.max(0, target.wallet - amount);
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Mengurangi Uang Saku <@${targetMember.id}> Sebesar **$${amount}**`);
      }

      // ADMIN CEK INVENTORY
      if (command === "!cekinventory" || command === "!cekinv" || command === "!cektas") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`!${command} @user\`\``);
        }
        const { user: target } = getUserData(message.guild.id, targetMember.id);
        let itemsStr = [];
        for (const [key, val] of Object.entries(target.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }
        const embed = new EmbedBuilder()
          .setTitle(`🎒 Inspect Inventory Bag By Admin`)
          .setDescription(`🔍 Memeriksa isi tas milik: <@${targetMember.id}>\n\n${itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Member Ini Kosong."}`)
          .setColor("#50C878");
        return message.reply({ embeds: [embed] });
      }

      // ADMIN RESET MONEY
      if (command === "!resetmoney") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`!resetmoney @user\`\``);
        }
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.wallet = 0;
        target.bank = 0;
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Mereset Uang Dompet dan Bank <@${targetMember.id}> Menjadi **0**`);
      }

      // ADMIN RESET USER
      if (command === "!resetuser") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`!resetuser @user\`\``);
        }
        const { db } = getUserData(message.guild.id, targetMember.id);
        db[message.guild.id][targetMember.id] = {
          wallet: 0,
          bank: 0,
          lastWork: 0,
          lastDaily: 0,
          lastWeekly: 0,
          lastHunt: 0,
          lastFish: 0,
          lastMine: 0,
          workCooldown: 0,
          inventory: {},
          xp: 0,
          level: 1
        };
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Mereset Total Seluruh Data Pengguna <@${targetMember.id}> Kembali ke Awal`);
      }

      // ADMIN RESET INVENTORY
      if (command === "!resetinventory" || command === "!resetinv" || command === "!resettas") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`!${command} @user\`\``);
        }
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.inventory = {};
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Mengosongkan Dan Mereset Semua Isi Inventory Tas <@${targetMember.id}>`);
      }

      // ADMIN ADD LEVEL
      if (command === "!addlevel") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        const amtStr = args[1];
        if (!targetMember || !amtStr || isNaN(amtStr) || parseInt(amtStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`!addlevel @user jumlah\`\``);
        }
        const val = parseInt(amtStr);
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.level += val;
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Menambahkan Level Pengguna <@${targetMember.id}> Sebanyak **+${val} Level**`);
      }

      // ADMIN TAKE LEVEL
      if (command === "!takelevel") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        const amtStr = args[1];
        if (!targetMember || !amtStr || isNaN(amtStr) || parseInt(amtStr) <= 0) {
          return message.reply(`❌ Format Salah : \`\`!takelevel @user jumlah\`\``);
        }
        const val = parseInt(amtStr);
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.level = Math.max(1, target.level - val);
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Mengurangi Level Pengguna <@${targetMember.id}> Sebanyak **-${val} Level**`);
      }

      // ADMIN RESET LEVEL
      if (command === "!resetlevel") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }
        const targetMember = message.mentions.members.first();
        if (!targetMember) {
          return message.reply(`❌ Format Salah : \`\`!resetlevel @user\`\``);
        }
        const { db, user: target } = getUserData(message.guild.id, targetMember.id);
        target.level = 1;
        target.xp = 0;
        writeDB(db);
        return message.reply(`✅ **Admin Action:** Berhasil Mereset Level Dan XP Pengguna <@${targetMember.id}> Kembali ke Level 1`);
      }
    });
  }
};