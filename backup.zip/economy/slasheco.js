const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { shopItems, writeDB, getUserData, formatCooldown, addXpRandom, readDB } = require("./economy.js");

module.exports = {
  data: [
    new SlashCommandBuilder().setName("work").setDescription("Work To Earn Money").toJSON(),
    new SlashCommandBuilder().setName("daily").setDescription("Claim Daily Money Reward").toJSON(),
    new SlashCommandBuilder().setName("weekly").setDescription("Claim Weekly Money Reward").toJSON(),
    new SlashCommandBuilder()
      .setName("deposite")
      .setDescription("Deposit Money Into The Bank")
      .addStringOption(option => option.setName("jumlah").setDescription("Amount Of Money Or 'all'").setRequired(true))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("withdraw")
      .setDescription("Withdraw Money From The Bank")
      .addStringOption(option => option.setName("jumlah").setDescription("Amount Of Money Or 'all'").setRequired(true))
      .toJSON(),
    new SlashCommandBuilder().setName("balance").setDescription("View Pocket Money And Bank Balance").toJSON(),
    new SlashCommandBuilder()
      .setName("rob")
      .setDescription("Try To Rob Another Member Pocket Money")
      .addUserOption(option => option.setName("user").setDescription("User To Rob").setRequired(true))
      .toJSON(),
    new SlashCommandBuilder().setName("hunt").setDescription("Hunt Wild Animals In The Forest").toJSON(),
    new SlashCommandBuilder().setName("fish").setDescription("Fish In The River Or Sea").toJSON(),
    new SlashCommandBuilder().setName("mine").setDescription("Mine Precious Minerals In The Cave").toJSON(),
    new SlashCommandBuilder().setName("inventory").setDescription("View Content Of Your Bag").toJSON(),
    new SlashCommandBuilder()
      .setName("sell")
      .setDescription("Sell Items From Inventory")
      .addStringOption(option => option.setName("item").setDescription("Item Name Or 'all'").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Items To Sell").setRequired(false))
      .toJSON(),
    new SlashCommandBuilder().setName("shop").setDescription("View List Of Items In The Shop").toJSON(),
    new SlashCommandBuilder()
      .setName("buy")
      .setDescription("Buy Items From The Shop")
      .addStringOption(option => option.setName("item").setDescription("Item Name To Buy").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Items").setRequired(true))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("transfermoney")
      .setDescription("Transfer Pocket Money To Another User")
      .addUserOption(option => option.setName("user").setDescription("Target User For Transfer").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Money").setRequired(true))
      .toJSON(),
    new SlashCommandBuilder()
      .setName("mystats")
      .setDescription("View Complete Profile Information Status")
      .toJSON(),
    new SlashCommandBuilder()
      .setName("cekstats")
      .setDescription("Check Another Member Profile Information Status Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("addmoney")
      .setDescription("Add Member Pocket Money Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Money").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("takemoney")
      .setDescription("Reduce Member Pocket Money Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Money").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("cekinventory")
      .setDescription("Check Another Member Bag Content Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("resetmoney")
      .setDescription("Reset Member Pocket Money and Bank Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("resetuser")
      .setDescription("Reset All Data Of User Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("resetinventory")
      .setDescription("Reset Member Bag Content Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("addlevel")
      .setDescription("Add Member Level Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Level").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("takelevel")
      .setDescription("Reduce Member Level Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .addIntegerOption(option => option.setName("jumlah").setDescription("Amount Of Level").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder().setName("leaderboard").setDescription("Show Top 10 High Level Users").toJSON(),
    
    // PERINTAH BARU: /resetlevel
    new SlashCommandBuilder()
      .setName("resetlevel")
      .setDescription("Reset Member Level and XP to Initial Status Admin Only")
      .addUserOption(option => option.setName("user").setDescription("Target User").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON()
  ],

  setup(client) {
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand() || !interaction.guild) return;

      const { commandName, options, guild, user: author } = interaction;

      // Proteksi Admin Tambahan (Memasukkan resetlevel dan cekstats ke pengecekan izin)
      if (["addmoney", "takemoney", "cekinventory", "resetmoney", "resetuser", "resetinventory", "addlevel", "takelevel", "resetlevel", "cekstats"].includes(commandName)) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin Yang Bisa Gunakan", ephemeral: true });
        }
      }

      // SLASH MYSTATS COMMAND
      if (commandName === "mystats") {
        await interaction.deferReply();
        const { user } = getUserData(guild.id, author.id);
        let itemsStr = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }
        const isiTas = itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Kamu Kosong.";

        const embed = new EmbedBuilder()
          .setTitle("📊 User Status Profile")
          .setDescription(`👤 **User Target:** <@${author.id}>\n💵 **Uang Saku:** $${user.wallet}\n🏦 **Saldo Bank:** $${user.bank}\n📈 **Level Status:** Lv. ${user.level} *(XP: ${user.xp}/${user.level * 100})*\n\n🎒 **Isi Dalam Tas:**\n${isiTas}`)
          .setThumbnail(author.displayAvatarURL({ dynamic: true }))
          .setColor("#0099FF");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // SLASH CEKSTATS COMMAND (ADMIN)
      if (commandName === "cekstats") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const { user } = getUserData(guild.id, targetUser.id);
        let itemsStr = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }
        const isiTas = itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Kamu Kosong.";

        const embed = new EmbedBuilder()
          .setTitle("📊 User Status Profile")
          .setDescription(`👤 **User Target:** <@${targetUser.id}>\n💵 **Uang Saku:** $${user.wallet}\n🏦 **Saldo Bank:** $${user.bank}\n📈 **Level Status:** Lv. ${user.level} *(XP: ${user.xp}/${user.level * 100})*\n\n🎒 **Isi Dalam Tas:**\n${isiTas}`)
          .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
          .setColor("#0099FF");
        return interaction.editReply({ embeds: [embed] });
      }

      // 1. SLASH WORK
      if (commandName === "work") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const now = Date.now();
        if (now < user.lastWork) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Working Rejected")
            .setDescription(`🛑 <@${author.id}> Anda Sudah Mengklaim Uang Kerja Coba Lagi Dalam ${formatCooldown(user.lastWork - now)}`)
            .setColor("#ff0000");
          return interaction.editReply({ embeds: [embed] });
        }

        const randUang = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;

        user.wallet += randUang;
        user.lastWork = now + randCooldown;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("💼 Working Reward")
          .setDescription(`✅ <@${author.id}> Kamu Telah Mendapatkan Uang Saku Sebesar **$${randUang}** dari pekerjaanmu!`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 2. SLASH DAILY
      if (commandName === "daily") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const now = Date.now();
        const cooldown = 24 * 60 * 60 * 1000;

        if (now - user.lastDaily < cooldown) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Daily Rejected")
            .setDescription(`🛑 <@${author.id}> Anda Sudah Mengklaim Hari Ini Kembali Lagi Besok`)
            .setColor("#ff0000");
          return interaction.editReply({ embeds: [embed] });
        }

        const randUang = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000;
        user.wallet += randUang;
        user.lastDaily = now;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("📅 Daily Reward")
          .setDescription(`✅ <@${author.id}> Kamu Telah Mendapatkan Uang Hadiah Harian Sebesar **$${randUang}**!`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 3. SLASH WEEKLY
      if (commandName === "weekly") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const now = Date.now();
        const cooldown = 7 * 24 * 60 * 60 * 1000;

        if (now - user.lastWeekly < cooldown) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Weekly Rejected")
            .setDescription(`🛑 <@${author.id}> Kembali Lagi Satu Minggu Kedepan Setelah Hari Ini`)
            .setColor("#ff0000");
          return interaction.editReply({ embeds: [embed] });
        }

        const randUang = Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000;
        user.wallet += randUang;
        user.lastWeekly = now;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("📮 Weekly Reward")
          .setDescription(`✅ <@${author.id}> Kamu Telah Mendapatkan Uang Hadiah Mingguan Sebesar **$${randUang}**!`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 4. SLASH DEPOSITE
      if (commandName === "deposite") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const amountStr = options.getString("jumlah");

        if (amountStr.toLowerCase() === "all") {
          const total = user.wallet;
          user.bank += total;
          user.wallet = 0;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("🏦 Deposite Money")
            .setDescription(`💰 <@${author.id}> Menyimpan Semua Uang Yang Ada Di Dompet Sebanyak **$${total}** Ke Bank!`)
            .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
          return addXpRandom(guild.id, author.id, interaction);
        }

        if (isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return interaction.editReply(`❌ Format Salah : \`\`/deposite Jumlah\`\``);
        }

        const amount = parseInt(amountStr);
        if (amount > user.wallet) {
          return interaction.editReply("❌ Uang Di Saku Kamu Tidak Mencukupi.");
        }

        user.wallet -= amount;
        user.bank += amount;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("🏦 Deposite Money")
          .setDescription(`💰 <@${author.id}> Menyimpan Uang Di Bank Sebanyak **$${amount}**!`)
          .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 5. SLASH WITHDRAW
      if (commandName === "withdraw") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const amountStr = options.getString("jumlah");

        if (amountStr.toLowerCase() === "all") {
          const total = user.bank;
          user.wallet += total;
          user.bank = 0;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("✍️ Withdraw Money")
            .setDescription(`💵 <@${author.id}> Mengambil Semua Uang Dari Bank Sebanyak **$${total}**!`)
            .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
          return addXpRandom(guild.id, author.id, interaction);
        }

        if (isNaN(amountStr) || parseInt(amountStr) <= 0) {
          return interaction.editReply(`❌ Format Salah : \`\`/withdraw Jumlah\`\``);
        }

        const amount = parseInt(amountStr);
        if (amount > user.bank) {
          return interaction.editReply("❌ Uang Di Bank Kamu Tidak Mencukupi.");
        }

        user.bank -= amount;
        user.wallet += amount;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("✍️ Withdraw Money")
          .setDescription(`💵 <@${author.id}> Mengambil Uang Dari Bank Sebanyak **$${amount}**!`)
          .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 6. SLASH BALANCE
      if (commandName === "balance") {
        await interaction.deferReply();
        const { user } = getUserData(guild.id, author.id);
        const embed = new EmbedBuilder()
          .setTitle("💸 Balance Money")
          .setDescription(`👤 **User Saku:** <@${author.id}>\n🏧 **Bank Balance:** $${user.bank}\n📥 **Dompet Saku:** $${user.wallet}\n📊 **Level Status:** Lv. ${user.level} *(XP: ${user.xp}/${user.level * 100})*`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 7. SLASH ROB
      if (commandName === "rob") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");

        if (targetUser.id === author.id) {
          return interaction.editReply("❌ Kamu Tidak Bisa Merampok Diri Sendiri.");
        }

        const { db, user: attacker } = getUserData(guild.id, author.id);
        const { user: target } = getUserData(guild.id, targetUser.id);

        if (target.wallet < 100) {
          return interaction.editReply("❌ Target Terlalu Miskin, Saku Mereka Tidak Memiliki Cukup Uang Untuk Dirampok.");
        }

        const chance = Math.random();
        if (chance > 0.4) {
          const robAmount = Math.floor(Math.random() * (target.wallet - 50 + 1)) + 50;
          target.wallet -= robAmount;
          attacker.wallet += robAmount;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("💂🏿‍♀️ Robbary User")
            .setDescription(`⚔️ <@${author.id}> Telah Mengambil Uang Saku <@${targetUser.id}> Sebesar **$${robAmount}**!`)
            .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
        } else {
          const fine = Math.floor(Math.random() * (attacker.wallet > 100 ? 100 : attacker.wallet || 50)) + 10;
          attacker.wallet = Math.max(0, attacker.wallet - fine);
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("👮 Arrested By Police")
            .setDescription(`🚨 Sial! <@${author.id}> Ketahuan Aksi Merampok. Telah Ditangkap Oleh Polisi Dan Didenda Uang Sebanyak **$${fine}**!`)
            .setColor("#ff0000");
          await interaction.editReply({ embeds: [embed] });
        }
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 8. SLASH HUNT
      if (commandName === "hunt") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const now = Date.now();
        if (now < user.lastHunt) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Hunting Rejected")
            .setDescription(`🛑 <@${author.id}> Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastHunt - now)}`)
            .setColor("#ff0000");
          return interaction.editReply({ embeds: [embed] });
        }

        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastHunt = now + randCooldown;

        const chance = Math.random();
        if (chance < 0.25) {
          const fine = Math.floor(Math.random() * (200 - 50 + 1)) + 50;
          user.wallet = Math.max(0, user.wallet - fine);
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("🐗 HUNT DISASTER 🐗")
            .setDescription(`💥 Gawat! <@${author.id}> Kamu Diserang Oleh Babi Hutan! Uangmu Berkurang Sebanyak **$${fine}** Untuk Biaya Pengobatan Rumah Hospital.`)
            .setColor("#ff0000");
          await interaction.editReply({ embeds: [embed] });
        } else {
          const keys = ["rusa", "kelinci", "babi", "ayam", "serigala", "beruang", "harimau", "singa", "macan", "ular", "buaya", "banteng", "rubah", "elang", "burung", "landak", "luwak", "kancil", "tupai", "musang", "gorila", "simpanse", "babon", "hyena", "cheetah", "badak", "gajah", "kudanil", "jerapah", "zebra"];
          const randomKey = keys[Math.floor(Math.random() * keys.length)];
          
          user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("🏹 HUNTING SUCCESS 🏹")
            .setDescription(`🎯 <@${author.id}> Berhasil Memburu Dan Mendapatkan **1 ${shopItems[randomKey]?.emoji || ""} ${shopItems[randomKey]?.name || randomKey}**! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`)
            .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
        }
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 2. SLASH FISH
      if (commandName === "fish") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const now = Date.now();
        if (now < user.lastFish) {
          const embed = new EmbedBuilder()
            .setTitle("❌ Fishing Rejected")
            .setDescription(`🛑 <@${author.id}> Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastFish - now)}`)
            .setColor("#ff0000");
          return interaction.editReply({ embeds: [embed] });
        }

        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastFish = now + randCooldown;

        const keys = ["lele", "gurame", "tuna", "salmon", "hiu"];
        const randomKey = keys[Math.floor(Math.random() * keys.length)];

        user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("🎣 Fishing Succes")
          .setDescription(`🌊 <@${author.id}> Berhasil Memancing Dan Mendapatkan **1 ${shopItems[randomKey]?.emoji || ""} ${shopItems[randomKey]?.name || randomKey}**! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 3. SLASH MINE
      if (commandName === "mine") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const now = Date.now();
        if (now < user.lastMine) {
          const embed = new EmbedBuilder()
            .setTitle("❌ MINING REJECTED ❌")
            .setDescription(`🛑 <@${author.id}> Anda Sedang Lelah Coba Lagi Dalam ${formatCooldown(user.lastMine - now)}`)
            .setColor("#ff0000");
          return interaction.editReply({ embeds: [embed] });
        }

        const randCooldown = (Math.floor(Math.random() * (60 - 10 + 1)) + 10) * 60 * 1000;
        user.lastMine = now + randCooldown;

        const keys = ["berlian", "emas", "perak", "emerald", "batubara", "minyak"];
        const randomKey = keys[Math.floor(Math.random() * keys.length)];

        user.inventory[randomKey] = (user.inventory[randomKey] || 0) + 1;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("⛏️ MINING SUCCESS ⛏️")
          .setDescription(`💎 <@${author.id}> Berhasil Menambang Dan Mendapatkan **1 ${shopItems[randomKey]?.emoji || ""} ${shopItems[randomKey]?.name || randomKey}**! Barang Telah Dimasukkan Ke Dalam Inventory Tas Kamu.`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 9. SLASH INVENTORY
      if (commandName === "inventory") {
        await interaction.deferReply();
        const { user } = getUserData(guild.id, author.id);
        let kancut = [];
        for (const [key, val] of Object.entries(user.inventory)) {
          if (val > 0) kancut.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }

        const embed = new EmbedBuilder()
          .setTitle("🎒 Your Inventory")
          .setDescription(kancut.length > 0 ? kancut.join("\n") : "✨ Inventory Tas Milikmu Masih Kosong.")
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 10. SLASH SELL
      if (commandName === "sell") {
        await interaction.deferReply();
        const { db, user } = getUserData(guild.id, author.id);
        const inputItem = options.getString("item");
        const inputQty = options.getInteger("jumlah");

        if (inputItem.toLowerCase() === "all") {
          let totalEarned = 0;
          let totalItems = 0;

          for (const [key, val] of Object.entries(user.inventory)) {
            if (val > 0) {
              const itemConf = shopItems[key];
              if (itemConf) {
                for (let i = 0; i < val; i++) {
                  totalEarned += Math.floor(Math.random() * (itemConf.sellMax - itemConf.sellMin + 1)) + itemConf.sellMin;
                }
                totalItems += val;
                user.inventory[key] = 0;
              }
            }
          }

          if (totalItems === 0) return interaction.editReply("❌ Kamu Tidak Memiliki Barang Apapun Untuk Dijual.");
          user.wallet += totalEarned;
          writeDB(db);

          const embed = new EmbedBuilder()
            .setTitle("💰 Sell All Items")
            .setDescription(`💵 <@${author.id}> Berhasil Menjual Semua Isi Tas Sebanyak **${totalItems} Item** Dan Mendapatkan Uang Total Sebesar **$${totalEarned}**!`)
            .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
          return addXpRandom(guild.id, author.id, interaction);
        }

        const targetInput = inputItem.toLowerCase();
        // Logika pencarian dinamis: Cek key langsung atau cari berdasarkan properti name di shopItems
        const targetKey = shopItems[targetInput] 
          ? targetInput 
          : Object.keys(shopItems).find(k => shopItems[k].name.toLowerCase() === targetInput);

        if (!targetKey) {
          return interaction.editReply(`❌ Format Salah : \`\`/sell item jumlah\`\``);
        }

        const qty = inputQty !== null ? inputQty : 1;
        if (qty <= 0) return interaction.editReply(`❌ Format Salah : \`\`/sell item jumlah\`\``);

        if (!user.inventory[targetKey] || user.inventory[targetKey] < qty) {
          return interaction.editReply("❌ Jumlah Item Di Inventory Kamu Tidak Mencukupi.");
        }

        let earned = 0;
        const itemConf = shopItems[targetKey];
        for (let i = 0; i < qty; i++) {
          earned += Math.floor(Math.random() * (itemConf.sellMax - itemConf.sellMin + 1)) + itemConf.sellMin;
        }

        user.inventory[targetKey] -= qty;
        user.wallet += earned;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("💰 Sell Item Success")
          .setDescription(`💵 <@${author.id}> Berhasil Menjual **${qty} ${itemConf.emoji} ${itemConf.name}** Dan Mendapatkan Uang Saku Sebesar **$${earned}**!`)
          .setColor("#50C878");
          await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 11. SLASH SHOP
      if (commandName === "shop") {
        await interaction.deferReply();
        const itemsArray = Object.entries(shopItems);
        const itemsPerPage = 10;
        const totalPages = Math.ceil(itemsArray.length / itemsPerPage);
        let currentPage = 0;

        const generateEmbed = (page) => {
          const start = page * itemsPerPage;
          const end = start + itemsPerPage;
          const pageItems = itemsArray.slice(start, end);

          let listStr = [];
          for (const [key, val] of pageItems) {
            const randomBuyPrice = Math.floor(Math.random() * (val.buyMax - val.buyMin + 1)) + val.buyMin;
            listStr.push(`${val.emoji} **${val.name}** (\`${key}\`)\n 🔹 Harga Beli: **$${randomBuyPrice}**\n 🔹 Estimasi Jual: **$${val.sellMin} - $${val.sellMax}**`);
          }

          return new EmbedBuilder()
            .setTitle("🏪 Economy Shop Market")
            .setDescription(listStr.join("\n\n"))
            .setFooter({ text: `Halaman ${page + 1} dari ${totalPages}` })
            .setColor("#50C878");
        };

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("shop_prev").setLabel("⬅️ Prev").setStyle(ButtonStyle.Primary).setDisabled(true),
          new ButtonBuilder().setCustomId("shop_next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(totalPages <= 1)
        );

        const shopMsg = await interaction.editReply({ embeds: [generateEmbed(currentPage)], components: [row] });
        addXpRandom(guild.id, author.id, interaction);

        const filter = (i) => i.user.id === author.id;
        const collector = shopMsg.createMessageComponentCollector({ filter, time: 60000 });

        collector.on("collect", async (i) => {
          if (i.customId === "shop_prev") {
            currentPage--;
          } else if (i.customId === "shop_next") {
            currentPage++;
          }

          const updatedRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("shop_prev").setLabel("⬅️ Prev").setStyle(ButtonStyle.Primary).setDisabled(currentPage === 0),
            new ButtonBuilder().setCustomId("shop_next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(currentPage === totalPages - 1)
          );

          await i.update({ embeds: [generateEmbed(currentPage)], components: [updatedRow] });
        });

        collector.on("end", () => {
          const disabledRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("shop_prev").setLabel("⬅️ Prev").setStyle(ButtonStyle.Primary).setDisabled(true),
            new ButtonBuilder().setCustomId("shop_next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(true)
          );
          interaction.editReply({ components: [disabledRow] }).catch(() => {});
        });
        return;
      }

      // 12. SLASH BUY
      if (commandName === "buy") {
        await interaction.deferReply();
        const inputItem = options.getString("item").toLowerCase();
        const qty = options.getInteger("jumlah");

        // Logika pencarian dinamis: Cek key langsung atau cari berdasarkan properti name di shopItems
        const targetKey = shopItems[inputItem] 
          ? inputItem 
          : Object.keys(shopItems).find(k => shopItems[k].name.toLowerCase() === inputItem);

        if (!targetKey || qty <= 0) {
          return interaction.editReply(`❌ Format Salah : \`\`/buy item jumlah\`\``);
        }

        const { db, user } = getUserData(guild.id, author.id);
        const itemConf = shopItems[targetKey];
        const randomBuyPrice = Math.floor(Math.random() * (itemConf.buyMax - itemConf.buyMin + 1)) + itemConf.buyMin;
        const totalPrice = randomBuyPrice * qty;

        if (user.wallet < totalPrice) {
          return interaction.editReply("❌ Uang Di Saku Kamu Tidak Mencukupi Untuk Membeli Item Ini.");
        }

        user.wallet -= totalPrice;
        user.inventory[targetKey] = (user.inventory[targetKey] || 0) + qty;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("🛒 Purchase Success")
          .setDescription(`🎉 <@${author.id}> Berhasil Membeli **${qty} ${itemConf.emoji} ${itemConf.name}** Dengan Total Harga **$${totalPrice}**!`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // 13. SLASH TRANSFERMONEY
      if (commandName === "transfermoney") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const amount = options.getInteger("jumlah");

        if (amount <= 0) {
          return interaction.editReply(`❌ Format Salah : \`\`/transfermoney @user jumlah\`\``);
        }

        if (targetUser.id === author.id) {
          return interaction.editReply("❌ Kamu Tidak Bisa Mentransfer Uang Ke Dirimu Sendiri.");
        }

        const { db, user: sender } = getUserData(guild.id, author.id);
        const { user: receiver } = getUserData(guild.id, targetUser.id);

        if (sender.wallet < amount) {
          return interaction.editReply("❌ Uang Di Saku Kamu Tidak Mencukupi Untuk Melakukan Transfer.");
        }

        sender.wallet -= amount;
        receiver.wallet += amount;
        writeDB(db);

        const embed = new EmbedBuilder()
          .setTitle("💸 Transfer Money Success")
          .setDescription(`💸 <@${author.id}> Berhasil Mentransfer Uang Kiriman Sebesar **$${amount}** Kepada Target <@${targetUser.id}>!`)
          .setColor("#50C878");
        await interaction.editReply({ embeds: [embed] });
        return addXpRandom(guild.id, author.id, interaction);
      }

      // SLASH LEADERBOARD
      if (commandName === "leaderboard") {
        await interaction.deferReply();
        const db = readDB();
        const guildData = db[guild.id] || {};
        
        let allSorted = Object.keys(guildData)
          .map(userId => ({ id: userId, level: guildData[userId].level || 0 }))
          .filter(u => u.level > 0)
          .sort((a, b) => b.level - a.level);

        let sorted = allSorted.slice(0, 10);

        if (sorted.length === 0) {
          return interaction.editReply("❌ Belum ada data pengguna dengan level di atas 0.");
        }

        let lbStr = sorted.map((u, index) => {
          let medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `🔹 **#${index + 1}**`;
          return `${medal} <@${u.id}> - **Level ${u.level}**`;
        }).join("\n");

        // 1. Dapatkan Avatar Pengguna Peringkat 1
        let topUserAvatar = null;
        try {
          const topUser = await client.users.fetch(sorted[0].id);
          topUserAvatar = topUser.displayAvatarURL({ dynamic: true });
        } catch (e) {}

        const embed = new EmbedBuilder()
          .setTitle("🏆 Top High Level Leaderboard")
          .setDescription(`Berikut peringkat pengguna dengan level tertinggi:\n\n${lbStr}`)
          .setColor("#FFD700");

        if (topUserAvatar) {
          embed.setThumbnail(topUserAvatar);
        }

        // 2. Tombol Hitam "🔎 Cek Peringkat Saya"
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("lb_check_rank")
            .setLabel("🔎 Cek Peringkat Saya")
            .setStyle(ButtonStyle.Secondary)
        );

        const lbMsg = await interaction.editReply({ embeds: [embed], components: [row] });

        // Collector untuk memproses klik tombol "Cek Peringkat Saya"
        const collector = lbMsg.createMessageComponentCollector({ time: 120000 });

        collector.on("collect", async (i) => {
          if (i.customId === "lb_check_rank") {
            const userIndex = allSorted.findIndex(u => u.id === i.user.id);
            
            if (userIndex === -1) {
              return i.reply({
                content: `🏆 <@${i.user.id}> Peringkat Kamu Yaitu :\nBelum Terdaftar <@${i.user.id}> - Level 0`,
                ephemeral: true
              });
            }

            const rank = userIndex + 1;
            const userLevel = allSorted[userIndex].level;

            return i.reply({
              content: `🏆 <@${i.user.id}> Peringkat Kamu Yaitu :\n#${rank} <@${i.user.id}> - Level ${userLevel}`,
              ephemeral: true
            });
          }
        });

        return;
      }

      // 14. SLASH ADDMONEY (ADMIN)
      if (commandName === "addmoney") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const amount = options.getInteger("jumlah");
        if (amount <= 0) return interaction.editReply(`❌ Format Salah : \`\`/addmoney @user jumlah\`\``);

        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.wallet += amount;
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Menambahkan Uang Sebesar **$${amount}** Ke Saku <@${targetUser.id}>`);
      }

      // 15. SLASH TAKEMONEY (ADMIN)
      if (commandName === "takemoney") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const amount = options.getInteger("jumlah");
        if (amount <= 0) return interaction.editReply(`❌ Format Salah : \`\`/takemoney @user jumlah\`\``);

        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.wallet = Math.max(0, target.wallet - amount);
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Mengurangi Uang Saku <@${targetUser.id}> Sebesar **$${amount}**`);
      }

      // 16. SLASH CEKINVENTORY (ADMIN)
      if (commandName === "cekinventory") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const { user: target } = getUserData(guild.id, targetUser.id);

        let itemsStr = [];
        for (const [key, val] of Object.entries(target.inventory)) {
          if (val > 0) itemsStr.push(`📦 ${shopItems[key]?.emoji || ""} **${shopItems[key]?.name || key}**: ${val} Buah`);
        }

        const embed = new EmbedBuilder()
          .setTitle(`🎒 Inspect Inventory Bag By Admin`)
          .setDescription(`🔍 Memeriksa isi tas milik: <@${targetUser.id}>\n\n${itemsStr.length > 0 ? itemsStr.join("\n") : "Inventory Member Ini Kosong."}`)
          .setColor("#50C878");
        return interaction.editReply({ embeds: [embed] });
      }

      // SLASH RESET MONEY (ADMIN)
      if (commandName === "resetmoney") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.wallet = 0;
        target.bank = 0;
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Mereset Uang Dompet dan Bank <@${targetUser.id}> Menjadi **0**`);
      }

      // SLASH RESET USER (ADMIN)
      if (commandName === "resetuser") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const { db } = getUserData(guild.id, targetUser.id);
        db[guild.id][targetUser.id] = {
          wallet: 0,
          bank: 0,
          lastWork: 0,
          lastDaily: 0,
          lastWeekly: 0,
          lastHunt: 0,
          lastFish: 0,
          lastMine: 0,
          workCooldown: 0,
          inventory: {},
          xp: 0,
          level: 1
        };
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Mereset Total Seluruh Data Pengguna <@${targetUser.id}> Kembali ke Awal`);
      }

      // SLASH RESET INVENTORY (ADMIN)
      if (commandName === "resetinventory") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.inventory = {};
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Mengosongkan Dan Mereset Semua Isi Inventory Tas <@${targetUser.id}>`);
      }

      // SLASH ADD LEVEL (ADMIN)
      if (commandName === "addlevel") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const val = options.getInteger("jumlah");
        if (val <= 0) return interaction.editReply(`❌ Format Salah : \`\`/addlevel @user jumlah\`\``);

        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.level += val;
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Menambahkan Level Pengguna <@${targetUser.id}> Sebanyak **+${val} Level**`);
      }

      // SLASH TAKE LEVEL (ADMIN)
      if (commandName === "takelevel") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");
        const val = options.getInteger("jumlah");
        if (val <= 0) return interaction.editReply(`❌ Format Salah : \`\`/takelevel @user jumlah\`\``);

        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.level = Math.max(1, target.level - val);
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Mengurangi Level Pengguna <@${targetUser.id}> Sebanyak **-${val} Level**`);
      }

      // SLASH RESET LEVEL (ADMIN) - IMPLEMENTASI BARU
      if (commandName === "resetlevel") {
        await interaction.deferReply();
        const targetUser = options.getUser("user");

        const { db, user: target } = getUserData(guild.id, targetUser.id);
        target.level = 1;
        target.xp = 0;
        writeDB(db);
        return interaction.editReply(`✅ **Admin Action:** Berhasil Mereset Level dan XP <@${targetUser.id}> Kembali ke **Level 1 (0 XP)**`);
      }
    });
  }
};