const { EmbedBuilder } = require("discord.js");
const axios = require('axios');

const PREFIX = "!";

function setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
        if (message.author.bot || !message.content.startsWith(PREFIX + "hd")) return;

        let imageUrl = null;

        if (message.attachments.size > 0) {
            imageUrl = message.attachments.first().url;
        } else if (message.reference) {
            try {
                const repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
                if (repliedMessage.attachments.size > 0) {
                    imageUrl = repliedMessage.attachments.first().url;
                }
            } catch (e) {
                console.error("Gagal mengambil pesan reply:", e);
            }
        }

        if (!imageUrl) return message.reply("❌ Kirim gambar atau reply gambar dengan command `!hd`!");

        const loadingEmbed = new EmbedBuilder()
            .setTitle("🔄 Sedang Di Proses")
            .setDescription("⌛ Mohon Ditunggu Sebentar...")
            .setColor("Blue")
            .setTimestamp();

        const msg = await message.reply({ embeds: [loadingEmbed] });

        try {
            const encodedUrl = encodeURIComponent(imageUrl);
            const apiUrl = `https://api-faa.my.id/faa/hdv4?image=${encodedUrl}`;

            const apiRes = await axios.get(apiUrl, { timeout: 0 });

            // Mengambil hasil dari result.image_upscaled
            const resultUrl = apiRes.data?.result?.image_upscaled;

            if (!resultUrl) {
                throw new Error("API tidak memberikan URL hasil.");
            }

            const finalEmbed = new EmbedBuilder()
                .setTitle("📸 HD Upscale")
                .setDescription(`<@${message.author.id}> Done Bro 😎!\n✅ Gambar Anda Berhasil Ditingkatkan`)
                .setColor("Green")
                .setImage(resultUrl)
                .setTimestamp();

            await msg.edit({ embeds: [finalEmbed] });
        } catch (error) {
            console.error("Error Detail:", error.message);
            await msg.edit({ 
                content: `❌ Gagal memproses gambar. Error: ${error.message}`, 
                embeds: [] 
            });
        }
    });
}

module.exports = { setup };