const { Client, EmbedBuilder, AttachmentBuilder, PermissionFlagsBits } = require('discord.js');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

const PREFIX = '!';
const ALLOWED_CHANNEL_ID = '1438772534295400448';

// Lokasi direktori dan file JSON database
const dbDir = path.join(__dirname, "../database");
const dbFilePath = path.join(dbDir, "cekchannel.json");

// Helper untuk membaca daftar channel dari JSON
function loadChannels() {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(dbFilePath)) {
        fs.writeFileSync(dbFilePath, JSON.stringify([]));
        return [];
    }
    try {
        const data = fs.readFileSync(dbFilePath, "utf8");
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

// Helper untuk menyimpan daftar channel ke JSON
function saveChannels(channels) {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(dbFilePath, JSON.stringify(channels, null, 2));
}

// ===============================
// 🔥 SET OWNER ID
// ===============================
const OWNER_ID = "1341007595288268880"; // <<< GANTI DENGAN ID LO

// ===============================
// 🔥 POLA STRING BIASA
// ===============================
const SUSPICIOUS_PATTERNS = [
  "discord.com/api/webhooks",
  "sendMessageToDiscord",
  "ssl.https",
  "socket.http",
  "request",
  "sendToDiscordEmbed",
  "sampGetCurrentServerName",
  "load",
  "sampGetPlayerNickname",
  "sampGetCurrentServerAddress",
  "onSendDialogResponse",
  "LuaObfuscator.com",
  "logKey",
  "captureKey",
  "recordKey",
  "keystroke",
  "hookkeyboard",
  "getkeystate",
  "readInput",
  "keyboard.",
  "input.",
  "onKeyPress",
  "RegisterHotKey",
  "GetAsyncKeyState",
  "Event.Key",
  "obfuscator",
  "sendToEmbed",
  "eval",
  "curl",
  "SendRequest",
  "PostRequest",
  "GetRequest",
  "fetch",
  "XMLHttpRequest",
  "popen",
  "ProcessBuilder",
  "CookieSteal",
  "assert(load",
  "Function(",
  "return(function",
  "bytecode",
  "debug",
  "debug.sethook",
  "debug.traceback",
  "http.request",
  "request(",
  "shared",
  "keypress",
  "keyrelease",
  "steal",
  "logger",
  "This file was protected with MoonSec V3",
  "MoonSec"
];

const HIGH_RISK_PATTERNS = [
  "request",
  "sendToDiscordEmbed",
  "sampGetCurrentServerName",
  "load",
  "sampGetPlayerNickname",
  "sampGetCurrentServerAddress",
  "onSendDialogResponse",
  "discord.com/api/webhooks",
  "sendMessageToDiscord",
  "logger",
  "registerhotkey"
];

/** Mendapatkan seluruh attachment dari pesan */
async function getAttachments(message) {
  let targetMessage = message;
  if (message.reference && message.reference.messageId) {
    try {
      targetMessage = await message.channel.messages.fetch(message.reference.messageId);
    } catch (e) {}
  }

  if (targetMessage.attachments.size === 0) return null;

  const validAttachments = [];
  for (const [_, attachment] of targetMessage.attachments) {
    const fileName = attachment.name.toLowerCase();
    
    // Validasi Ekstensi File (.lua, .txt, .luac)
    if (!fileName.endsWith('.lua') && !fileName.endsWith('.txt') && !fileName.endsWith('.luac')) {
      const errorEmbed = new EmbedBuilder()
        .setTitle("🚨 File Tidak Support")
        .setColor("Red")
        .setDescription("File yang support untuk dicek adalah file dengan format .lua, .txt, dan .luac . Terima Kasih 😘💕");
      
      await message.reply({ embeds: [errorEmbed] });
      return "INVALID_FORMAT";
    }
    validAttachments.push(attachment);
  }

  return validAttachments;
}

/** SCAN FILE — versi string (includes) */
function analyzeContent(content) {
  const detected = [];
  const lower = content.toLowerCase();
  SUSPICIOUS_PATTERNS.forEach(pattern => {
    if (lower.includes(pattern.toLowerCase())) {
      detected.push(pattern);
    }
  });
  return detected;
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes > 0) return `${minutes} Menit`;
    return `${seconds} Detik`;
}

function extractWebhook(content) {
    const regex = /https:\/\/discord\.com\/api\/webhooks\/\d+\/[a-zA-Z0-9_-]+/g;
    const found = content.match(regex);
    return found ? found[0] : null;
}

/** LISTENER !checkfile */
function setupFileChecker(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot || !message.content.startsWith(PREFIX)) return;
    const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
    const command = args[0].toLowerCase();

    const isAdmin = message.member?.permissions.has(PermissionFlagsBits.Administrator);

    // Command !setchannelcek dan !delchannelcek (Hanya Admin)
    if (command === "setchannelcek" || command === "delchannelcek") {
      if (!isAdmin) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      let targetChannel = message.mentions.channels.first() || message.channel;
      let channelList = loadChannels();

      if (command === "setchannelcek") {
        if (!channelList.includes(targetChannel.id)) {
          channelList.push(targetChannel.id);
          saveChannels(channelList);
          return message.reply(`✅ Channel <#${targetChannel.id}> berhasil ditambahkan ke daftar.`);
        } else {
          return message.reply(`⚠️ Channel <#${targetChannel.id}> sudah ada di daftar.`);
        }
      }

      if (command === "delchannelcek") {
        if (channelList.includes(targetChannel.id)) {
          channelList = channelList.filter(id => id !== targetChannel.id);
          saveChannels(channelList);
          return message.reply(`✅ Channel <#${targetChannel.id}> berhasil dihapus dari daftar.`);
        } else {
          return message.reply(`⚠️ Channel <#${targetChannel.id}> tidak ditemukan di daftar.`);
        }
      }
    }
    
    if (command === 'checkfile' || command === 'cek' || command === 'check') {
      const isOwner = message.author.id === OWNER_ID;
      const customChannels = loadChannels();
      const isAllowedChannel = message.channel.id === ALLOWED_CHANNEL_ID || customChannels.includes(message.channel.id);

      if (!isOwner && !isAllowedChannel) {
        return;
      }
      try {
        const startTime = Date.now();
        const attachments = await getAttachments(message);
        
        if (attachments === "INVALID_FORMAT") return;
        if (!attachments || attachments.length === 0) {
          return message.reply(`❌ Format salah : Kirim file langsung atau reply file dengan \`${PREFIX}checkfile\`.`);
        }
        const loadingMessage = await message.reply('🔎 Sedang mengunduh dan menganalisis file...');
        
        const results = [];
        for (const attachment of attachments) {
          const response = await fetch(attachment.url);
          if (!response.ok) throw new Error(`Gagal mengunduh file ${attachment.name} (HTTP ${response.status})`);
          
          const buffer = await response.arrayBuffer();
          const fileContent = Buffer.from(buffer).toString('utf8');
          const found = analyzeContent(fileContent);

          results.push({
            attachment,
            found,
            content: fileContent
          });
        }

        const duration = Date.now() - startTime;
        sendResultEmbed(message, loadingMessage, results, duration);
      } catch (e) {
        console.error("File Checker Error:", e);
        message.reply(`❌ Gagal memproses file. Error: ${e.message}`);
      }
    }
  });

  // FITUR AUTO-SCAN FILE LANGSUNG
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const customChannels = loadChannels();
    const isAllowedChannel = message.channel.id === ALLOWED_CHANNEL_ID || customChannels.includes(message.channel.id);

    if (!isAllowedChannel) return;
    if (message.attachments.size === 0) return;
    if (message.content.startsWith(PREFIX)) return;
    try {
      const startTime = Date.now();
      const attachments = await getAttachments(message);

      if (attachments === "INVALID_FORMAT") return;
      if (!attachments || attachments.length === 0) return;

      const loadingMessage = await message.reply('🔎 Sedang mengunduh dan menganalisis file...');
      
      const results = [];
      for (const attachment of attachments) {
        const response = await fetch(attachment.url);
        if (!response.ok) throw new Error(`Gagal mengunduh file ${attachment.name} (HTTP ${response.status})`);
        
        const buffer = await response.arrayBuffer();
        const fileContent = Buffer.from(buffer).toString('utf8');
        const found = analyzeContent(fileContent);

        results.push({
          attachment,
          found,
          content: fileContent
        });
      }

      const duration = Date.now() - startTime;
      sendResultEmbed(message, loadingMessage, results, duration);
    } catch (e) {
      console.error("File Checker Error:", e);
    }
  });
}

async function sendResultEmbed(message, loadingMessage, results, duration) {
    const embed = new EmbedBuilder();
    
    const fileNames = results.map(r => `\`${r.attachment.name}\``).join(' , ');
    const fileSizes = results.map(r => formatBytes(r.attachment.size)).join(', ');
    
    let totalHighRisk = 0;
    let totalFoundCount = 0;
    const webhooks = [];
    let detailBlocks = [];

    results.forEach(res => {
      const highRiskMatches = res.found.filter(p => HIGH_RISK_PATTERNS.includes(p.toLowerCase()));
      totalHighRisk += highRiskMatches.length;
      totalFoundCount += res.found.length;

      const webhook = extractWebhook(res.content);
      if (webhook) webhooks.push(webhook);

      if (res.found.length > 0) {
        detailBlocks.push(`**${res.attachment.name}**\nDitemukan Pola Yang Mencurigakan (${res.found.length})\n\`\`\`\n${res.found.join("\n")}\n\`\`\``);
      } else {
        detailBlocks.push(`**${res.attachment.name}**\nTidak Ditemukan Pola Yang Mencurigakan`);
      }
    });

    const commonDesc = `📁 Nama File : ${fileNames}\n📦 Ukuran : ${fileSizes}\n🕒 Durasi : ${formatDuration(duration)}`;

    let threatLevel = "Low";
    let embedColor = "#2ecc71";

    if (totalHighRisk > 1) {
      threatLevel = "High";
      embedColor = "Red";
    } else if (totalFoundCount > 0) {
      threatLevel = "Medium";
      embedColor = "Yellow";
    }

    const titleName = results.length === 1 ? results[0].attachment.name : `${results.length} Files`;
    const webhookText = webhooks.length > 0 ? `🔗 Discord Webhook Detected\n${webhooks.join("\n")}\n\n` : "";

    embed.setColor(embedColor)
        .setTitle(`✅ Scan File Successful : ${titleName}`)
        .setDescription(`${commonDesc}\n⚠️ Threat : ${threatLevel}\n\n📋 Detail :\n${webhookText}${detailBlocks.join("\n")}`);

    await loadingMessage.edit({ content: '', embeds: [embed] });
}

module.exports = setupFileChecker;