// =========================
// embed.js
// Fitur: Buat pesan Embed sederhana
// Format: !createembed, judul, deskripsi
// =========================
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;
    const content = message.content.trim();

    // Command: !createembed, judul, deskripsi
    if (content.toLowerCase().startsWith("!createembed")) {
      const args = content.split("|").map(a => a.trim());
      const judul = args[1];
      const deskripsi = args[2];
      const isCommand = true;

      if (!isCommand) return;

      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      if (!judul || !deskripsi) {
        return message.reply("❌ Format salah : `!createembed|Judul|Deskripsi`");
      }

      const embed = new EmbedBuilder()
        .setColor(0x000000)
        .setTitle(judul)
        .setDescription(deskripsi)
        .setFooter({ text: `Dibuat oleh ${message.author.tag}` })
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });

      if (message.deletable) message.delete().catch(() => {});
    }
  });
}

module.exports = { setup };