const fs = require("fs");

const path = require("path");

const { PermissionFlagsBits } = require("discord.js");

const dbPath = path.join(__dirname, "../database/autotyping.json");

function readDB() {

    if (!fs.existsSync(dbPath)) return {};

    try {

        return JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    } catch (e) {

        return {};

    }

}

function writeDB(data) {

    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

}

module.exports = {

    setup: function(client) {

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot || !message.guild) return;

            const guildId = message.guild.id;

            // Command handler

            if (message.content.startsWith("!autotyping")) {

                if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
                }

                const args = message.content.split(" ");

                const db = readDB();

                if (args[1] === "on") {

                    db[guildId] = { enabled: true };

                    writeDB(db);

                    return message.reply("✅ Auto Typing Berhasil Di Aktifkan");

                } else if (args[1] === "off") {

                    db[guildId] = { enabled: false };

                    writeDB(db);

                    return message.reply("✅ Auto Typing Berhasil Dimatikan");

                }

            }

            // Fitur typing

            const db = readDB();

            if (db[guildId] && db[guildId].enabled) {

                try {

                    await message.channel.sendTyping();

                } catch (err) {

                    console.error("❌ Gagal typing:", err);

                }

            }

        });

    }

};