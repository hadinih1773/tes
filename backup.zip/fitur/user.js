// ======================================
//            user.js
// ======================================
const { EmbedBuilder, ChannelType } = require("discord.js");

// EXPORT SETUP AGAR BISA DIPANGGIL DI INDEX
module.exports.setup = function (client) {

  // ============================
  //   COMMAND: !user / !userinfo
  // ============================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    // memastikan semua member bisa pakai command
    if (message.member && message.channel) {
      message.member.permissionsIn(message.channel).has = () => true;
    }

    const args = message.content.split(" ");
    const command = args[0].toLowerCase();

    if (command === "!user" || command === "!userinfo") {
      let target =
        message.mentions.users.first() || // kalau mention
        message.author; // kalau tidak mention

      const member = await message.guild.members.fetch(target.id).catch(() => null);
      if (!member) return;

      // Ambil semua role kecuali @everyone, urutkan berdasarkan posisi tertinggi
      const roles = member.roles.cache
        .filter((r) => r.id !== message.guild.id)
        .sort((a, b) => b.position - a.position);
        
      const totalRolesCount = roles.size;
      
      // Ambil maksimal 10 role teratas
      const topRolesMapped = roles
        .map((r) => r.toString())
        .slice(0, 10)
        .join(", ");
        
      const rolesDisplay = totalRolesCount > 0 ? topRolesMapped : "Tidak ada role";

      const embed = new EmbedBuilder()
        .setColor("Blue")
        .setTitle(`👤 User Information | ${target.username}`)
        .setThumbnail(target.displayAvatarURL({ size: 1024 }))
        .addFields(
          {
            name: "🗣️ User Tag",
            value: `<@${target.id}>`,
            inline: true
          },
          {
            name: "🆔 User ID",
            value: `${target.id}`,
            inline: true
          },
          {
            name: "👥 Nickname",
            value: `${member.nickname ? member.nickname : "Tidak ada"}`,
            inline: true
          },
          {
            name: "📅 Join Date",
            value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`,
            inline: true
          },
          {
            name: `🎗 Roles [${totalRolesCount}]`,
            value: rolesDisplay,
            inline: false
          }
        )
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    }
  });

  // ============================
  //   COMMAND: !server / !serverinfo
  // ============================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    // memastikan semua member bisa pakai command
    if (message.member && message.channel) {
      message.member.permissionsIn(message.channel).has = () => true;
    }

    const command = message.content.toLowerCase();

    if (command === "!server" || command === "!serverinfo") {
      const guild = message.guild;
      const owner = await guild.fetchOwner();

      // PERBAIKAN DATA AGAR BENAR & AKURAT
      const onlineCount = guild.members.cache.filter(
        (m) => m.presence && m.presence.status !== "offline"
      ).size;

      const rolesCount = guild.roles.cache.size;
      
      // Perhitungan jumlah channel berdasarkan tipenya masing-masing
      const allChannels = guild.channels.cache;
      const textCount = allChannels.filter((c) => c.type === ChannelType.GuildText).size;
      const voiceCount = allChannels.filter((c) => c.type === ChannelType.GuildVoice).size;
      const forumCount = allChannels.filter((c) => c.type === ChannelType.GuildForum).size;
      const announcementCount = allChannels.filter((c) => c.type === ChannelType.GuildAnnouncement).size;
      const stageCount = allChannels.filter((c) => c.type === ChannelType.GuildStageVoice).size;
      const channelsCount = allChannels.size;

      const embed = new EmbedBuilder()
        .setColor("Blue")
        .setTitle(`🌐 Server Information | ${guild.name}`)
        .setThumbnail(guild.iconURL({ size: 1024 }))
        .addFields(
          {
            name: "🖥 Server Name",
            value: `${guild.name}`,
            inline: true
          },
          {
            name: "👑 Server Owner",
            value: `<@${owner.id}>`,
            inline: true
          },
          {
            name: "🆔 Server ID",
            value: `${guild.id}`,
            inline: true
          },
          {
            name: "📖 Server Description",
            value: guild.description || "Tidak ada deskripsi.",
            inline: false
          },
          {
            name: "👥 Members",
            value: `${guild.memberCount}`,
            inline: true
          },
          {
            name: "🟢 Online Members",
            value: `${onlineCount}`,
            inline: true
          },
          {
            name: "🎗 Roles",
            value: `${rolesCount}`,
            inline: true
          },
          {
            name: "#⃣ Channels",
            value: `Total: ${channelsCount}\nText : ${textCount}\nVoice : ${voiceCount}\nForum : ${forumCount}\nAnnouncement : ${announcementCount}\nStage : ${stageCount}`,
            inline: false
          },
          {
            name: "📅 Created Date",
            value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`,
            inline: false
          }
        )
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    }
  });

  // ============================
  //   COMMAND: Hady pp / hady pp
  // ============================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const msg = message.content.toLowerCase();

    if (msg === "hady pp") {
      const avatar = message.author.displayAvatarURL({ size: 1024 });
      return message.channel.send({
        content: `Here is your avatar`,
        files: [avatar]
      });
    }

    if (msg.startsWith("hady pp")) {
      const user = message.mentions.users.first();
      if (!user) return;

      const avatar = user.displayAvatarURL({ size: 1024 });
      return message.channel.send({
        content: `Here is ${user} avatar`,
        files: [avatar]
      });
    }
  });
};