const { EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");
const hady = require("../hady"); // Ambil dari hady.js

module.exports = {
    setup: (client) => {
        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            if (message.author.bot) return;
            if (message.content !== "!urlhd") return;

            const ownerPath = path.join(__dirname, "../database/owner.json");
            if (!fs.existsSync(ownerPath)) return;
            const ownerData = JSON.parse(fs.readFileSync(ownerPath, "utf-8"));

            if (message.author.id !== ownerData.owner) {
                return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
            }

            const webUrl = hady.getUrl();

            const embed = new EmbedBuilder()
                .setColor("Blue")
                .setTitle("🔗 Url Website Hady Community")
                .setDescription(`📢 **Author**\n<@${ownerData.owner}>\n\n📡 **Url Website**\n${webUrl || "Sedang memuat..."}`);

            message.reply({ embeds: [embed] });
        });
    }
};