const fs = require("fs");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const axios = require("axios");

// === LOAD DATA CHANNEL AI YANG TERSIMPAN ===  
const dbPath = "./database/aiChannel.json";  
let allowedChannels = [];  

if (fs.existsSync(dbPath)) {  
  try {
    allowedChannels = JSON.parse(fs.readFileSync(dbPath)).channels || [];  
  } catch (e) {
    allowedChannels = ["1423549957952114800"];
  }
} else {  
  allowedChannels = ["1423549957952114800"];  
  if (!fs.existsSync("./database")) fs.mkdirSync("./database");
  fs.writeFileSync(dbPath, JSON.stringify({ channels: allowedChannels }, null, 2));  
}  

function saveDB() {  
  fs.writeFileSync(dbPath, JSON.stringify({ channels: allowedChannels }, null, 2));  
}  

// === FUNGSI ARNARU AI ===
const ARNARU_AI_API = 'https://arnaru-ai.vercel.app/api/chat';

async function askAI(question, userId = 'default_user', model = 'claude-sonnet-5', webSearch = false, onStreamUpdate = null) {
    const SYSTEM_PROMPT = "Kamu adalah asisten AI super pintar, andal, dan gaul. Wajib gunakan bahasa kasual Indonesia (gw, lu, bro, legit, dll). TAMPILAN VISUAL ADALAH PRIORITAS UTAMA. Ikuti gaya formatting premium ini:\n1. PENGGUNAAN EMOJI: Gunakan emoji secara rapi dan estetis HANYA di luar blok kode markdown (misal untuk mempertegas judul 🏆, status ✅❌, atau reaksi 💀💥).\n2. DATA TERSTRUKTUR: Saat menyajikan info model, konsep dasar, desain sistem, spesifikasi, statistik, probabilitas, atau rincian spesifik, WAJIB bungkus teks tersebut ke dalam blok kode markdown. Di dalam blok kode, buat tata letak yang sejajar/presisi dan rapi. Gunakan simbol peluru sederhana seperti '-', '✓', atau '→'.\n3. KODE SCRIPT: Jika memberikan source code murni, taruh di blok kode dengan nama bahasanya (contoh blok kode lua, pawn, html).\n4. PEMBATAS & HEADER: Gunakan teks tebal (**teks**) untuk judul di luar blok kode. Gunakan garis pembatas Markdown resmi (---) HANYA untuk memisahkan section besar agar elegan. DILARANG KERAS mengetik deretan garis manual panjang seperti ------- atau =======.\n5. Intinya: Buat respons yang visualnya memanjakan mata, perpaduan pas antara obrolan santai ber-emoji di luar, dan blok data yang rapi/teknis di dalam.";

    const conversationId = `${userId}_session_1`;

    try {
        const payload = {
            question: question,
            model: model,
            conversationId: conversationId,
            systemPrompt: SYSTEM_PROMPT,
            webSearch: webSearch
        };

        const response = await axios.post(ARNARU_AI_API, payload, {
            headers: { 'Content-Type': 'application/json' },
            responseType: 'stream',
            timeout: 60000
        });

        let fullAnswer = "";
        let buffer = "";

        return new Promise((resolve, reject) => {
            response.data.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
                let lines = buffer.split('\n');
                
                buffer = lines.pop();

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const jsonStr = line.substring(6).trim();
                        if (jsonStr === '[DONE]') continue;
                        
                        try {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) {
                                fullAnswer += parsed.answer;
                                let cleanedText = fullAnswer.replace(/[-=_]{3,}/g, '');
                                
                                if (onStreamUpdate) {
                                    onStreamUpdate(cleanedText);
                                }
                            }
                        } catch (e) {}
                    }
                }
            });

            response.data.on('end', () => {
                if (buffer.startsWith('data: ')) {
                    try {
                        const jsonStr = buffer.substring(6).trim();
                        if (jsonStr !== '[DONE]') {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) fullAnswer += parsed.answer;
                        }
                    } catch (e) {}
                }
                
                let finalCleaned = fullAnswer.replace(/[-=_]{3,}/g, '');
                resolve(finalCleaned || "Sori ngab, server AInya lagi ampas nih ga ngasih jawaban bener.");
            });

            response.data.on('error', (err) => reject(err));
        });
    } catch (error) {
        throw new Error(error.response?.data?.error || error.response?.data?.message || error.message);
    }
}

function setup(client) {  
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {  
    if (message.author.bot) return;  
    const msg = message.content.toLowerCase();  

    // ==========================  
    // ADMIN ONLY CHECK
    // ==========================  
    if (msg.startsWith("!setchannelai") || msg.startsWith("!delchannelai")) {  
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {  
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");  
      }  
    }  

    // ==========================  
    // COMMAND: !setchannelai
    // ==========================  
    if (msg.startsWith("!setchannelai")) {  
      let target = message.mentions.channels.first() || message.channel;  
      if (!allowedChannels.includes(target.id)) {  
        allowedChannels.push(target.id);  
        saveDB();  
      }  
      return message.channel.send(`✅ Channel **${target}** sekarang sudah aktif AI-nya.`);  
    }  

    // ==========================  
    // COMMAND: !delchannelai
    // ==========================  
    if (msg.startsWith("!delchannelai")) {  
      let target = message.mentions.channels.first() || message.channel;  
      allowedChannels = allowedChannels.filter((c) => c !== target.id);  
      saveDB();  
      return message.channel.send(`🗑️ Channel **${target}** sekarang sudah dimatikan AI-nya.`);  
    }

    // ==========================  
    // COMMAND: !ai (Bisa di mana saja, no history)
    // ==========================  
    if (msg.startsWith("!ai")) {
      const question = message.content.slice(4).trim();
      if (!question) return message.reply("❌ Format Salah : ``!ai query``");
      
      let loadingMsg;
      try {
        await message.channel.sendTyping();
        loadingMsg = await message.reply("<a:loading:1538392412953641051> Bentar Mikir, **JANGAN SPAM**...");
        const answer = await askAI(question, message.author.id);
        
        if (loadingMsg) await loadingMsg.delete().catch(() => {});

        const chunks = answer.match(/[\s\S]{1,1900}/g) || [answer];  
        for (let i = 0; i < chunks.length; i++) {  
          if (i === 0) {
            await message.reply(chunks[i]);  
          } else {
            await message.channel.send(chunks[i]);
          }
        }
      } catch (err) {
        console.error("AI Error (!ai):", err);
        if (loadingMsg) await loadingMsg.delete().catch(() => {});
        message.reply("⚠️ Gagal respon dari API.");
      }
      return; 
    }

    // ==========================  
    // AI HANYA AKTIF DI CHANNEL TERSIMPAN  
    // ==========================  
    if (!allowedChannels.includes(message.channel.id)) return;  

    let loadingMsg;
    try {  
      await message.channel.sendTyping();  
      loadingMsg = await message.reply("<a:loading:1538392412953641051> Bentar Mikir, **JANGAN SPAM**...");
      const answer = await askAI(message.content, message.author.id);

      if (loadingMsg) await loadingMsg.delete().catch(() => {});

      const chunks = answer.match(/[\s\S]{1,1900}/g) || [answer];  
      for (let i = 0; i < chunks.length; i++) {  
        if (i === 0) {
          await message.reply(chunks[i]);  
        } else {
          await message.channel.send(chunks[i]);
        }
      }  
    } catch (err) {  
      console.error("AI Error:", err);  
      if (loadingMsg) await loadingMsg.delete().catch(() => {});
      message.reply("⚠️ Gagal respon dari API.");  
    }  
  });  
}  

module.exports = { setup };