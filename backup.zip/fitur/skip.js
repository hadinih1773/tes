const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const fetch = (...a) => import("node-fetch").then(({ default: f }) => f(...a));

// Lokasi direktori dan file JSON untuk menyimpan daftar channel
const dbDir = path.join(__dirname, "../database");
const channelFilePath = path.join(dbDir, "bpschannel.json");

// Fungsi helper untuk membaca data channel
function loadChannels() {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(channelFilePath)) {
        fs.writeFileSync(channelFilePath, JSON.stringify([]));
        return [];
    }
    try {
        const data = fs.readFileSync(channelFilePath, "utf8");
        return JSON.parse(data);
    } catch (err) {
        return [];
    }
}

// Fungsi helper untuk menyimpan data channel
function saveChannels(channels) {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(channelFilePath, JSON.stringify(channels, null, 2));
}

module.exports = {

    setup: function(client) {

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot) return;

            const args = message.content.split(" ");

            const command = args[0].toLowerCase();
            
            const targetChannelId = "1467106460931461142"; 
            const isAdmin = message.member.permissions.has(PermissionFlagsBits.Administrator);

            // Command setchannelbps & delchannelbps (Hanya Admin)
            if (command === "!setchannelbps" || command === "!delchannelbps") {
                if (!isAdmin) {
                    return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
                }

                let targetChannel = message.mentions.channels.first() || message.channel;
                let channelList = loadChannels();

                if (command === "!setchannelbps") {
                    if (!channelList.includes(targetChannel.id)) {
                        channelList.push(targetChannel.id);
                        saveChannels(channelList);
                        return message.reply(`✅ Channel <#${targetChannel.id}> berhasil ditambahkan ke daftar.`);
                    } else {
                        return message.reply(`⚠️ Channel <#${targetChannel.id}> sudah ada di daftar.`);
                    }
                }

                if (command === "!delchannelbps") {
                    if (channelList.includes(targetChannel.id)) {
                        channelList = channelList.filter(id => id !== targetChannel.id);
                        saveChannels(channelList);
                        return message.reply(`✅ Channel <#${targetChannel.id}> berhasil dihapus dari daftar.`);
                    } else {
                        return message.reply(`⚠️ Channel <#${targetChannel.id}> tidak ditemukan di daftar.`);
                    }
                }
            }

            // Ambil daftar channel dari filebpschannel.json
            const customChannels = loadChannels();

            // Cek apakah channel saat ini termasuk channel yang diizinkan (targetChannelId bawaan ATAU ada di bpschannel.json)
            const isAllowedChannel = message.channel.id === targetChannelId || customChannels.includes(message.channel.id);

            // Cek apakah menggunakan command atau langsung kirim link (diawali https) di channel khusus
            const isCommand = command === "!skip" || command === "!bps" || command === "!skiplink";
            const isDirectLinkInTargetChannel = isAllowedChannel && message.content.toLowerCase().startsWith("https");

            if (isCommand || isDirectLinkInTargetChannel) {

                // Jika mencoba menggunakan command tetapi bukan admin DAN bukan di channel khusus, maka abaikan
                if (isCommand && !isAdmin && !isAllowedChannel) {
                    return; 
                }

                // Jika pakai command, link ada di args[1]. Jika langsung kirim link, link ada di args[0]
                const link = isCommand ? args[1] : args[0];
                
                if (!link) {
                    if (isCommand) return message.reply(`❌ Format Salah : \`\`${command} url\`\``);
                    return;
                }

                const embedProses = new EmbedBuilder()
                    .setTitle("🔄 Sedang Proses Bypass Link")
                    .setDescription("⏳ Mohon Ditunggu Sebentar")
                    .setColor("Blue");

                const msgProses = await message.reply({ embeds: [embedProses] });

                try {
                    let hasilBypass = null;

                    if (link.includes('sub4unlock.co')) {
                        const apiUrl = `https://fgsi.dpdns.org/api/tools/skip/sub4unlock?apikey=fgsiapi-353b23fd-6d&url=${encodeURIComponent(link)}`;
                        const response = await fetch(apiUrl);
                        const json = await response.json();
                        if (json.status && json.data && json.data.linkGo) {
                            hasilBypass = json.data.linkGo;
                        }
                    } else {
                        const apiUrl = `https://tw8rev.vercel.app/api/bypass?url=${encodeURIComponent(link)}&apikey=arnarubypass_9f2d1s5q`;
                        const response = await fetch(apiUrl);
                        const json = await response.json();
                        if (json.success && json.direct) {
                            hasilBypass = json.direct;
                        }
                    }

                    if (hasilBypass) {
                        const embedHasil = new EmbedBuilder()
                            .setTitle("✅ Bypass Link Berhasil")
                            .setDescription(`<@${message.author.id}> Done Bro 😎!\n\n🔗 Link :\n${link}\n\n🔗 Hasil Bypass :\n${hasilBypass}`)
                            .setColor("#50C878");

                        const row = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel("Hasil Bypass")
                                .setStyle(ButtonStyle.Link)
                                .setURL(hasilBypass)
                        );

                        return msgProses.edit({ embeds: [embedHasil], components: [row] });
                    } else {
                        const embedFailed = new EmbedBuilder()
                            .setTitle("❌ Bypass Failed")
                            .setDescription("Gagal melakukan bypass link tersebut.")
                            .setColor("Red");

                        return msgProses.edit({ embeds: [embedFailed], content: null });
                    }
                } catch (err) {
                    console.error(err);
                    const embedFailedCatch = new EmbedBuilder()
                        .setTitle("❌ Bypass Failed")
                        .setDescription("Terjadi kesalahan pada sistem API.")
                        .setColor("Red");

                    return msgProses.edit({ embeds: [embedFailedCatch], content: null });
                }
            }
        });
    }
};