const fs = require("fs");
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  PermissionsBitField,
} = require("discord.js");

const rrFile = "./database/reactionrole.json";
let rrData = {};

// === Load data kalau file ada ===
if (fs.existsSync(rrFile)) {
  rrData = JSON.parse(fs.readFileSync(rrFile, "utf8"));
}

// === Simpan data ke file ===
function saveRR() {
  fs.writeFileSync(rrFile, JSON.stringify(rrData, null, 2));
}

function setup(client) {
  // === Command Reaction Role TANPA SPLIT ===
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith("!rrole")) return;

    // Cek izin admin
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

    const args = message.content.trim().split(/ +/);
    if (args.length < 3)
      return message.reply("❌ Format Salah : `!rrole deskripsi @role1 @role2 ...`");

    // Ambil deskripsi
    const description = args[1];

    // Ambil role mention
    const roleArgs = args.slice(2);
    const roles = [];
    for (const mention of roleArgs) {
      const match = mention.match(/^<@&(\d+)>$/);
      if (match) {
        const role = message.guild.roles.cache.get(match[1]);
        if (role) roles.push(role);
      }
    }

    if (roles.length === 0)
      return message.reply("Minimal tag satu role yang valid.");

    // Bikin embed
    const embed = new EmbedBuilder()
      .setTitle("Reaction Role")
      .setDescription(description)
      .setColor(0x000000)
      .setFooter({ text: "Klik tombol di bawah untuk ambil atau cabut role." });

    // Bikin button
    const rows = [];
    let currentRow = new ActionRowBuilder();
    for (let i = 0; i < roles.length; i++) {
      const role = roles[i];
      const button = new ButtonBuilder()
        .setCustomId(`rr_${role.id}`)
        .setLabel(role.name)
        .setStyle(ButtonStyle.Primary);

      currentRow.addComponents(button);
      if ((i + 1) % 5 === 0 || i === roles.length - 1) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }
    }

    // Kirim pesan
    const sent = await message.channel.send({ embeds: [embed], components: rows });
    await message.delete().catch(() => null);

    // Simpan data
    rrData[sent.id] = {
      channelId: sent.channel.id,
      guildId: sent.guild.id,
      roles: roles.map((r) => r.id),
    };
    saveRR();
    message.channel.send("Reaction role berhasil dibuat!");
  });

  // === Tombol Role ===
  (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith("rr_")) return;

    const roleId = interaction.customId.replace("rr_", "");
    const role = interaction.guild.roles.cache.get(roleId);
    if (!role)
      return interaction.reply({
        content: "Role udah ga ada.",
        ephemeral: true,
      });

    const member = interaction.guild.members.cache.get(interaction.user.id);
    if (member.roles.cache.has(role.id)) {
      await member.roles.remove(role);
      return interaction.reply({
        content: `Role **${role.name}** dicabut.`,
        ephemeral: true,
      });
    } else {
      await member.roles.add(role);
      return interaction.reply({
        content: `Role **${role.name}** diberikan.`,
        ephemeral: true,
      });
    }
  });

  // === Jika pesan reaction role DIHAPUS, hapus di database juga ===
  client.on("messageDelete", async (message) => {
    if (!message.id) return;
    if (rrData[message.id]) {
      delete rrData[message.id];
      saveRR();
      console.log(`Reaction role ${message.id} dihapus dari database.`);
    }
  });

  // === Restore tombol saat bot nyala ulang ===
  client.once("ready", async () => {
    console.log("Memulihkan reaction role...");
    for (const msgId in rrData) {
      const data = rrData[msgId];
      const channel = await client.channels.fetch(data.channelId).catch(() => null);
      if (!channel) continue;
      const msg = await channel.messages.fetch(msgId).catch(() => null);
      if (!msg) continue;
      console.log(`Reaction role aktif lagi di #${channel.name}`);
    }
  });
}

module.exports = { setup };