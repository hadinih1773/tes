const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const Axios = require("axios");

module.exports = {

  setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

      if (message.author.bot) return;

      const args = message.content.split(" ");

      const command = args[0].toLowerCase();

      const query = args.slice(1).join(" ");

      const apikey = "new";

      // ================= SEARCH COMMAND =================

      if (command === "!xxsearch") {

        if (!query) return message.reply("❌ Format Salah : ``!xxsearch judul``");

        const processEmbed = new EmbedBuilder()

          .setColor("Blue")

          .setTitle("Xnxx Search")

          .setDescription("⏳ Sedang mencari video...");

        const msg = await message.reply({ embeds: [processEmbed] });

        try {

          const res = await Axios.get(`https://www.ikyiizyy.my.id/search/xnxx?apikey=${apikey}&q=${encodeURIComponent(query)}`);

          const results = res.data.result.slice(0, 10);

          if (!results || results.length === 0) {

            return msg.edit({ embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Video tidak ditemukan.")] });

          }

          let currentIndex = 0;

          const createEmbed = (index) => {

            const v = results[index];

            return new EmbedBuilder()

              .setColor("Blue")

              .setTitle("🔎 Xnxx Search")

              .setDescription(

                `**📋 Title:** ${v.title}\n`
+               
                `**🔗 Link:** ${v.link}`

              )

              .setFooter({ text: `Hasil ${index + 1} dari ${results.length}` });

          };

          const createButtons = (index) => {

            return new ActionRowBuilder().addComponents(

              new ButtonBuilder().setCustomId("prev").setLabel("⬅️ Previous").setStyle(ButtonStyle.Primary).setDisabled(index === 0),

              new ButtonBuilder().setCustomId("next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(index === results.length - 1)

            );

          };

          await msg.edit({

            embeds: [createEmbed(currentIndex)],

            components: [createButtons(currentIndex)],

          });

          const collector = msg.createMessageComponentCollector({ time: 3600000 });

          collector.on("collect", async (interaction) => {

            if (interaction.user.id !== message.author.id) return interaction.reply({ content: "Bukan buat lu!", ephemeral: true });

            

            if (interaction.customId === "prev") currentIndex--;

            if (interaction.customId === "next") currentIndex++;

            await interaction.update({

              embeds: [createEmbed(currentIndex)],

              components: [createButtons(currentIndex)],

            });

          });

        } catch (err) {

          console.error(err);

          msg.edit({ embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Terjadi kesalahan saat mencari.")] });

        }

      }

      // ================= DOWNLOADER COMMAND =================

      if (command === "!xxdl") {

        const url = args[1];

        if (!url) return message.reply("❌ Format Salah : ``!xxdl url``");

        const processEmbed = new EmbedBuilder()

          .setColor("#50C878") // Emerald Green

          .setTitle("Xnxx Downloader")

          .setDescription("⏳ Sedang memproses video...");

        const msg = await message.reply({ embeds: [processEmbed] });

        try {

          const res = await Axios.get(`https://www.ikyiizyy.my.id/download/xnxx?apikey=${apikey}&url=${encodeURIComponent(url)}`);

          const data = res.data.result;

          const resultEmbed = new EmbedBuilder()

            .setColor("#50C878")

            .setTitle("🔞 Xnxx Downloader")

            .setDescription(

              `**📋 Title:** ${data.title}\n` +

              `**🕕 Duration:** ${data.duration}\n` +

              `**⏳ Quality:** ${data.quality}\n` +

              `**📜 Description:** ${data.description || "No description"}`

            );

          await msg.delete().catch(() => {});

          await message.channel.send({ embeds: [resultEmbed] });

          await message.channel.send({

            files: [{ attachment: data.files.high || data.files.low, name: "video.mp4" }]

          });

        } catch (err) {

          console.error(err);

          if (msg) await msg.delete().catch(() => {});

          message.reply("❌ Gagal mendownload video. Pastikan link benar atau server sedang sibuk.");

        }

      }

    });

  },

};