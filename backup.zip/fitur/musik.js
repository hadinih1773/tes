const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { 
    joinVoiceChannel, 
    createAudioPlayer, 
    createAudioResource, 
    AudioPlayerStatus, 
    getVoiceConnection,
    StreamType
} = require("@discordjs/voice");
const yts = require("yt-search");
const axios = require("axios");

// Map untuk menyimpan player di setiap server
const players = new Map();

module.exports = {
    async setup(client) {
        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            if (message.author.bot || !message.guild) return;

            const prefix = "!";
            if (!message.content.startsWith(prefix)) return;

            const args = message.content.slice(prefix.length).trim().split(/ +/);
            const command = args.shift().toLowerCase();
            const query = args.join(" ");

            // 1. Perintah Play (!hplay, !hp, !play)
            if (command === "hplay" || command === "hp" || command === "play") {
                if (!query) {
                    return message.reply(`❌ Format Salah : \`!${command} url/query\``);
                }

                // Cek apakah user ada di voice channel
                const voiceChannel = message.member.voice.channel;
                if (!voiceChannel) {
                    const rejectEmbed = new EmbedBuilder()
                        .setTitle("🔇 Play Music Rejected")
                        .setDescription(`<@${message.author.id}> Kamu Harus Masuk Ke Salah Satu Channel Voice Untuk Menggunakan Fitur Musik`)
                        .setColor("#ff0000");
                    return message.reply({ embeds: [rejectEmbed] });
                }

                // Reply awal (Emerald Green)
                const processingEmbed = new EmbedBuilder()
                    .setTitle("✅ Music Play Processing")
                    .setDescription(`<@${message.author.id}> Musik Akan Diputar Di Channel Musik Kamu Silahkan Ditunggu`)
                    .setColor("#50c878");
                await message.reply({ embeds: [processingEmbed] });

                try {
                    // Cari lagu
                    let videoUrl = query;
                    if (!query.startsWith("http")) {
                        const searchResults = await yts(query);
                        const video = searchResults.videos[0];
                        if (!video) return message.channel.send("❌ Lagu tidak ditemukan.");
                        videoUrl = video.url;
                    }

                    // Ambil link audio dari API (Alternatif play-dl)
                    const resMp3 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp3?url=${encodeURIComponent(videoUrl)}`, { timeout: 0 });
                    const audioUrl = resMp3.data.output;

                    if (!audioUrl) return message.channel.send("❌ Gagal mendapatkan link audio dari server.");

                    // Gabung ke Voice Channel
                    const connection = joinVoiceChannel({
                        channelId: voiceChannel.id,
                        guildId: message.guild.id,
                        adapterCreator: message.guild.voiceAdapterCreator,
                        selfDeaf: true,
                    });

                    // Dapatkan resource audio dengan inline demuxing agar stabil
                    const resource = createAudioResource(audioUrl, {
                        inputType: StreamType.Arbitrary,
                    });
                    
                    const player = createAudioPlayer();
                    player.play(resource);
                    connection.subscribe(player);

                    players.set(message.guild.id, { player, connection });

                    player.on('error', error => {
                        console.error(`Error: ${error.message}`);
                        message.channel.send("❌ Terjadi kesalahan pada player saat memutar musik.");
                    });

                    player.on(AudioPlayerStatus.Idle, () => {
                        // Logika jika lagu selesai
                    });

                } catch (error) {
                    console.error(error);
                    message.channel.send("❌ Terjadi kesalahan saat mencoba memutar musik.");
                }
            }

            // 2. Perintah Stop (!hstop, !hs, !stop)
            if (command === "hstop" || command === "hs" || command === "stop") {
                const data = players.get(message.guild.id);
                if (data) {
                    data.player.stop();
                    return message.reply("🛑 Musik telah dihentikan.");
                } else {
                    return message.reply("❌ Tidak ada musik yang sedang diputar.");
                }
            }

            // 3. Perintah Leave (!hleft, !hl, !leave)
            if (command === "hleft" || command === "hl" || command === "leave") {
                const connection = getVoiceConnection(message.guild.id);
                if (connection) {
                    connection.destroy();
                    players.delete(message.guild.id);
                    return message.reply("👋 Berhasil keluar dari channel voice.");
                } else {
                    return message.reply("❌ Bot tidak berada di channel voice.");
                }
            }
        });
    }
};