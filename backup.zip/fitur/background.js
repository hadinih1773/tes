const axios = require("axios");

const { AttachmentBuilder, EmbedBuilder } = require("discord.js");

const REMOVE_BG_KEY = "s5CmtWemsJHj31uriVWfs934";

module.exports = function (client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (msg) => {

        if (msg.author.bot) return;

        if (!msg.content.startsWith("!removebg")) return;

        // Ambil gambar: direct upload / reply

        let image;

        if (msg.attachments.size > 0) {

            image = msg.attachments.first().url;

        } else if (msg.reference) {

            const repliedMsg = await msg.channel.messages.fetch(msg.reference.messageId);

            if (repliedMsg.attachments.size > 0) {

                image = repliedMsg.attachments.first().url;

            }

        }

        if (!image) {

            return msg.reply("Kirim gambar atau reply gambar untuk menghapus background!");

        }

        // ===== Progress Embed =====

        let progress = new EmbedBuilder()

            .setTitle("Processing Remove Background")

            .setDescription("Menghapus background gambar...\n```\n[■■□□□□□□] 20%\n```")

            .setColor("Yellow");

        let progressMsg = await msg.reply({ embeds: [progress] });

        await new Promise(r => setTimeout(r, 400));

        progress.setDescription("Menghapus background gambar...\n```\n[■■■■■□□□] 60%\n```");

        await progressMsg.edit({ embeds: [progress] });

        await new Promise(r => setTimeout(r, 400));

        progress.setDescription("Menghapus background gambar...\n```\n[■■■■■■■■] 100%\n```");

        await progressMsg.edit({ embeds: [progress] });

        // ===== Remove BG API =====

        try {

            const response = await axios({

                method: 'post',

                url: "https://api.remove.bg/v1.0/removebg",

                data: {

                    image_url: image,

                    size: "auto"

                },

                headers: {

                    "X-Api-Key": REMOVE_BG_KEY

                },

                responseType: 'arraybuffer'

            });

            const buffer = Buffer.from(response.data, "binary");

            const editedImage = new AttachmentBuilder(buffer, { name: "removebg.png" });

            await progressMsg.edit({

                embeds: [

                    new EmbedBuilder()

                        .setTitle("Background Removed!")

                        .setDescription("Berhasil menghapus background 🎉")

                        .setColor("Blue")

                ],

                files: [editedImage]

            });

        } catch (err) {

            console.log(err);

            msg.reply("Gagal menghapus background! Pastikan gambarnya valid.");

        }

    });

};