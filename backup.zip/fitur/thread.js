const fs = require("fs");
const { PermissionsBitField } = require("discord.js");

// =================== DATA AUTO-THREAD BARU (LOGIKA DIGANTI) ===================
// ========== AUTO THREAD DATA ==========
let autoThreadChannels = {};
const autoThreadFile = "./database/autothread.json";

if (fs.existsSync(autoThreadFile)) {
  try {
    autoThreadChannels = JSON.parse(fs.readFileSync(autoThreadFile, "utf8"));
  } catch (e) {
    console.error("Gagal membaca autothread.json:", e);
    autoThreadChannels = {};
  }
}

function saveAutoThreads() {
  try {
    fs.writeFileSync(autoThreadFile, JSON.stringify(autoThreadChannels, null, 2));
  } catch (e) {
    console.error("Gagal menyimpan autothread.json:", e);
  }
}

function setup(client) {
  // Handler untuk command-thread
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const content = message.content.trim();
    const command = content.split(/[\s|]/)[0].toLowerCase();
    const args = content.split(" ").slice(1);

    // =================== PERINTAH THREAD ===================
    if (command === "!locktr") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageThreads))
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

      if (message.channel.isThread()) {
        try {
          await message.channel.setLocked(true);
          return message.reply("Thread berhasil di-lock!");
        } catch (err) {
          console.error("Gagal lock thread:", err);
          return message.reply("Gagal lock thread.");
        }
      }
      return message.reply("Perintah ini cuma bisa di thread.");
    }

    if (command === "!unlocktr") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageThreads))
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

      if (message.channel.isThread()) {
        try {
          await message.channel.setLocked(false);
          return message.reply("Thread berhasil di-unlock!");
        } catch (err) {
          console.error("Gagal unlock thread:", err);
          return message.reply("Gagal unlock thread.");
        }
      }
      return message.reply("Perintah ini cuma bisa di thread.");
    }

    if (command === "!deletetr") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageThreads))
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

      if (message.channel.isThread()) {
        try {
          await message.channel.delete();
          return;
        } catch (err) {
          console.error("Gagal hapus thread:", err);
          return message.reply("Gagal menghapus thread. Pastikan bot punya izin 'Manage Threads'.");
        }
      }
      return message.reply("Gagal! Perintah ini **hanya bisa** digunakan di dalam Thread, bukan di channel utama.");
    }

    if (command === "!createtr") {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageThreads))
            return message.reply("Hanya admin yang bisa membuat thread dari pesan!");

        const name = args.join(" ") || "New Thread";
        const targetMessage = message.reference ? await message.channel.messages.fetch(message.reference.messageId) : null;

        if (!targetMessage) return message.reply("Reply pesan (teks, gambar, video, atau link) yang ingin dijadikan thread!");

        try {
            await targetMessage.startThread({
                name: name,
                autoArchiveDuration: 60,
            });
            return message.reply(`Thread berhasil dibuat dengan nama: **${name}**`);
        } catch (err) {
            console.error(err);
            return message.reply("Gagal membuat thread. Pastikan bot punya izin 'Create Public Threads'.");
        }
    }

    // =================== ADMIN COMMANDS AUTO THREAD BARU ===================
    if (command === "!setautotr") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

      const targetChannel = message.mentions.channels.first();
      let threadTitle;

      if (targetChannel) {
        threadTitle = args.slice(1).join(" ").trim();
      } else {
        threadTitle = args.join(" ").trim();
      }

      const finalChannel = targetChannel || message.channel;

      if (!threadTitle || threadTitle.length < 1)
        return message.reply("Format Salah : `!setautotr #channel judul` atau `!setautotr judul`");

      autoThreadChannels[finalChannel.id] = threadTitle;
      saveAutoThreads();
      return message.reply(
        `Auto-thread aktif di ${finalChannel} dengan judul thread: **${threadTitle}**`
      );
    }

    if (command === "!removeautotr") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

      const finalChannel = message.mentions.channels.first() || message.channel;

      if (!autoThreadChannels[finalChannel.id])
        return message.reply("Channel ini belum diatur auto-thread!");

      delete autoThreadChannels[finalChannel.id];
      saveAutoThreads();
      return message.reply(`Auto-thread dimatikan untuk channel ${finalChannel}`);
    }
  });

  // =================== AUTO THREAD LISTENER (WITH 5s DELAY ARCHIVE) ===================
  (client._msgHandlers = client._msgHandlers || []).push(async (msg) => {
    if (msg.author.bot) return;
    if (msg.channel.isThread()) return;

    const threadTitle = autoThreadChannels[msg.channel.id];
    if (!threadTitle) return;

    const hasAttachment = msg.attachments.size > 0;
    const hasEmbed = msg.embeds.length > 0;
    const isForwarded = msg.reference && !msg.content.startsWith('!');
    const hasLink = msg.content.includes("https://");

    if (hasAttachment || hasEmbed || isForwarded || hasLink) {
      try {
        const thread = await msg.startThread({
          name: threadTitle,
          autoArchiveDuration: 60,
        });

        // Tunggu 5 detik sebelum di-archive otomatis
        setTimeout(async () => {
          try {
            await thread.setArchived(true);
          } catch (e) {
            // Abaikan jika thread sudah di-archive manual atau dihapus
          }
        }, 5000);
      } catch (err) {
        console.error(
          `Gagal bikin thread di channel ${msg.channel.name} (${msg.channel.id}):`,
          err
        );
      }
    }
  });
}

module.exports = { setup };