const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const axios = require("axios");

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;
      const args = message.content.split(" ");
      const command = args[0].toLowerCase();
      const url = args[1];

      if (command === "!ytdl") {
        if (!url) {
          return message.reply("❌ Format Salah : ``!ytdl url``");
        }

        const processingEmbed = new EmbedBuilder()
          .setColor("Yellow")
          .setAuthor({
            name: "YouTube Downloader",
            iconURL: "https://cdn-icons-png.flaticon.com/512/1384/1384060.png",
          })
          .setDescription(`⏳ Sedang mengunduh dan mengirimkan **Video & Audio**, mohon tunggu...`);

        const msg = await message.reply({ embeds: [processingEmbed] });

        try {
          // Fetch Data dari API
          const resMp4 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp4?url=${encodeURIComponent(url)}`);
          const resMp3 = await axios.get(`https://velynapi.vercel.app/api/downloader/ytmp3?url=${encodeURIComponent(url)}`);

          const dataMp4 = resMp4.data.data;
          const dataMp3 = resMp3.data;

          if (!dataMp4.url || !dataMp3.output) {
            return msg.edit({
              embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Gagal mengambil file dari server.")],
            });
          }

          // Download Buffer Video
          const videoRes = await axios.get(dataMp4.url, { responseType: 'arraybuffer' });
          const videoBuffer = Buffer.from(videoRes.data);
          
          // Download Buffer Audio
          const audioRes = await axios.get(dataMp3.output, { responseType: 'arraybuffer' });
          const audioBuffer = Buffer.from(audioRes.data);

          const safeTitle = dataMp4.title.replace(/[^\w\s]/gi, '');
          
          const videoAttach = new AttachmentBuilder(videoBuffer, { name: `${safeTitle}.mp4` });
          const audioAttach = new AttachmentBuilder(audioBuffer, { name: `${safeTitle}.mp3` });

          const resultEmbed = new EmbedBuilder()
            .setColor("Green")
            .setTitle("YouTube Downloader")
            .setDescription(`<@${message.author.id}> Done Bro 😎!\n\n**Judul:** ${dataMp4.title}\n🔗 **Link YouTube**\n${url}`)
            .setFooter({ text: "YouTube Downloader" })
            .setTimestamp();

          await message.reply({ embeds: [resultEmbed] });
          await message.channel.send({ files: [videoAttach, audioAttach] });
          await msg.delete().catch(() => null);

        } catch (error) {
          console.error("Downloader Error:", error.message);
          msg.edit({
            embeds: [
              new EmbedBuilder()
                .setColor("Red")
                .setDescription("❌ Gagal mengirim file. Ukuran file mungkin melebihi batas Discord atau server sedang sibuk."),
            ],
          });
        }
      }
    });
  },
};
