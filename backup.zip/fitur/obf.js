const {
  AttachmentBuilder,
  EmbedBuilder,
  SlashCommandBuilder,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require("discord.js");

const axios = require("axios");
const path = require("path");
const fs = require("fs");

const {
  obfuscate: luaObfuscate
} = require("../lib/enc.js");

const TARGET_CHANNEL_ID = "1500848335693680742";

// Lokasi direktori dan file JSON database
const dbDir = path.join(__dirname, "../database");
const dbFilePath = path.join(dbDir, "obfchannel.json");

// Helper untuk membaca daftar channel dari JSON
function loadChannels() {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(dbFilePath)) {
        fs.writeFileSync(dbFilePath, JSON.stringify([]));
        return [];
    }
    try {
        const data = fs.readFileSync(dbFilePath, "utf8");
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

// Helper untuk menyimpan daftar channel ke JSON
function saveChannels(channels) {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(dbFilePath, JSON.stringify(channels, null, 2));
}

function setup(client) {

  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

    if (message.author.bot) return;

    const isAdmin =
      message.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      );

    const args = message.content.trim().split(/\s+/);
    const command = args[0].toLowerCase();

    // Command !setchannelobf dan !delchannelobf (Hanya Admin)
    if (command === "!setchannelobf" || command === "!delchannelobf") {
      if (!isAdmin) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      let targetChannel = message.mentions.channels.first() || message.channel;
      let channelList = loadChannels();

      if (command === "!setchannelobf") {
        if (!channelList.includes(targetChannel.id)) {
          channelList.push(targetChannel.id);
          saveChannels(channelList);
          return message.reply(`✅ Channel <#${targetChannel.id}> berhasil ditambahkan ke daftar.`);
        } else {
          return message.reply(`⚠️ Channel <#${targetChannel.id}> sudah ada di daftar.`);
        }
      }

      if (command === "!delchannelobf") {
        if (channelList.includes(targetChannel.id)) {
          channelList = channelList.filter(id => id !== targetChannel.id);
          saveChannels(channelList);
          return message.reply(`✅ Channel <#${targetChannel.id}> berhasil dihapus dari daftar.`);
        } else {
          return message.reply(`⚠️ Channel <#${targetChannel.id}> tidak ditemukan di daftar.`);
        }
      }
    }

    const customChannels = loadChannels();
    const isTargetChannel =
      message.channel.id === TARGET_CHANNEL_ID || customChannels.includes(message.channel.id);

    const isCommand =
      message.content.toLowerCase().startsWith("!obf");

    if (!isAdmin && !isTargetChannel) return;

    if (
      isTargetChannel &&
      !isCommand &&
      message.attachments.size === 0
    ) return;

    if (!isTargetChannel && !isCommand) return;

    let attachment =
      message.attachments.first();

    if (!attachment && message.reference) {

      const repliedMsg =
        await message.channel.messages.fetch(
          message.reference.messageId
        );

      attachment =
        repliedMsg.attachments.first();

    }

    if (
      !attachment ||
      (
        !attachment.name.endsWith(".lua") &&
        !attachment.name.endsWith(".txt")
      )
    ) {

      const errorEmbed =
        new EmbedBuilder()
          .setTitle("❌ Obfuscator Not Respond")
          .setColor("#FF0000")
          .setDescription(
            "Hanya File dengan Format .lua dan .txt yang Bisa Diobfuscator"
          );

      const reply = await message.reply({
        embeds: [errorEmbed]
      });

      setTimeout(() => {
        reply.delete().catch(() => {});
      }, 5000);

      return;

    }

    await promptObfuscationType(
      message,
      attachment,
      message.author
    );

  });

  (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {

    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName !== "obfuscate")
      return;

    const file =
      interaction.options.getAttachment("file");

    if (
      !file.name.endsWith(".lua") &&
      !file.name.endsWith(".txt")
    ) {

      const errorEmbed =
        new EmbedBuilder()
          .setTitle("❌ Obfuscator Not Respond")
          .setColor("#FF0000")
          .setDescription(
            "Hanya File dengan Format .lua dan .txt yang Bisa Diobfuscator"
          );

      return interaction.reply({
        embeds: [errorEmbed],
        ephemeral: true
      });

    }

    await promptObfuscationType(
      interaction,
      file,
      interaction.user
    );

  });

}

async function promptObfuscationType(context, attachment, user) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("obf_wearedevs")
      .setLabel("WeAreDevs")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("obf_luaobfuscator")
      .setLabel("Lua Obfuscator")
      .setStyle(ButtonStyle.Success)
  );

  let initialMessage;
  const contentText = `<@${user.id}> Silahkan Pilih Tipe Obfuscator Yang Diinginkan`;

  if (context.reply) {
    initialMessage = await context.reply({
      content: contentText,
      components: [row],
      ephemeral: context.deferred ? true : false,
      fetchReply: true
    });
  } else if (context.channel) {
    initialMessage = await context.channel.send({
      content: contentText,
      components: [row]
    });
  }

  const targetChannel = context.channel || context.message?.channel;
  if (!targetChannel) return;

  const filter = (i) => i.user.id === user.id;
  const collector = targetChannel.createMessageComponentCollector({
    filter,
    componentType: ComponentType.Button,
    time: 60000
  });

  collector.on("collect", async (interaction) => {
    if (interaction.message.id !== (initialMessage?.id || interaction.message.id)) return;
    if (!interaction.deferred && !interaction.replied) {
      await interaction.deferUpdate();
    }
    collector.stop(interaction.customId);
  });

  collector.on("end", async (collected, reason) => {
    if (reason === "time") {
      if (initialMessage && initialMessage.delete) initialMessage.delete().catch(() => {});
      return;
    }

    const processingEmbed = new EmbedBuilder()
      .setColor("#00BFFF")
      .setTitle("🔄 Obfuscate Processing")
      .setDescription("🤖 : Bot Sedang Memproses Kode, Mohon Jangan Spamming");

    if (context.editReply) {
      await context.editReply({ content: "", embeds: [processingEmbed], components: [] });
    } else if (initialMessage && initialMessage.edit) {
      await initialMessage.edit({ content: "", embeds: [processingEmbed], components: [] });
    }

    await processObfuscation(context, attachment, user, reason, initialMessage);
  });
}

async function processObfuscation(
  context,
  attachment,
  user,
  obfType,
  loadingMessage
) {

  const isAdmin =
    context.member?.permissions?.has(
      PermissionsBitField.Flags.Administrator
    );

  const targetChannel = isAdmin
    ? context.channel
    : (
      context.client.channels.cache.get(
        TARGET_CHANNEL_ID
      ) || context.channel
    );

  try {

    const response = await axios.get(
      attachment.url,
      {
        responseType: "text"
      }
    );

    const originalCode =
      response.data;

    const originalSize =
      Buffer.byteLength(
        originalCode,
        "utf8"
      );

    let obfuscatedCode = "";

    if (obfType === "obf_wearedevs") {
      obfuscatedCode = await luaObfuscate(originalCode);
    } else if (obfType === "obf_luaobfuscator") {
      const sessionResponse = await axios.post('https://api.luaobfuscator.com/v1/obfuscator/newscript', originalCode, {
          headers: { 'content-type': 'text', 'apikey': '2eacf7f3-840f-e5a9-dba4-ca117effd02b2b07' },
          timeout: 0
      });

      const sessionId = sessionResponse.data.sessionId;
      if (!sessionId) throw new Error("Gagal membuat session ID dari LuaObfuscator");

      const apiResponse = await axios.post('https://api.luaobfuscator.com/v1/obfuscator/obfuscate', {
          MinifiyAll: true,
          Virtualize: true
      }, {
          headers: { 'content-type': 'application/json', 'apikey': '2eacf7f3-840f-e5a9-dba4-ca117effd02b2b07', 'sessionId': sessionId },
          timeout: 0
      });

      obfuscatedCode = apiResponse.data.code;
    }

    if (!obfuscatedCode) throw new Error("Gagal mendapatkan kode dari API Obfuscator");

    const obfuscatedSize =
      Buffer.byteLength(
        obfuscatedCode,
        "utf8"
      );

    const buffer = Buffer.from(
      obfuscatedCode,
      "utf8"
    );

    const fileExtension = path.extname(attachment.name);
    const baseName = path.basename(attachment.name, fileExtension);
    const outputFileName = `${baseName}_Obfuscate${fileExtension}`;

    const fileAttachment =
      new AttachmentBuilder(
        buffer,
        {
          name: outputFileName
        }
      );

    const embed =
      new EmbedBuilder()
        .setTitle("✅ Obfuscate File Successful")
        .setColor("#50C878")
        .setDescription(
          `👤 **User Request**\n<@${user.id}>\n\n📁 **File Name**\n${attachment.name}\n\n📦 **Original Size**\n${(originalSize / 1024).toFixed(2)} KB\n\n📮 **Obfuscated Size**\n${(obfuscatedSize / 1024).toFixed(2)} KB`
        );

    await targetChannel.send({
      content: `<@${user.id}> Silahkan Cek DM Dari Bot!! Terima Kasih`,
      embeds: [embed]
    });

    await user.send({
      content: `✅ <@${user.id}> File Telah Sukses Di Obfuscate. Silahkan Di Cek Dibawah Ini.`,
      files: [fileAttachment]
    }).catch(() => {
      console.log(`Gagal mengirim DM ke user ${user.tag}, pastikan DM mereka terbuka.`);
    });

    if (loadingMessage && loadingMessage.delete) {
      loadingMessage.delete().catch(() => {});
    }

    if (
      context.delete &&
      context.guild
    ) {
      context.delete().catch(() => {});
    }

  } catch (error) {

    console.log(error);

    if (loadingMessage && loadingMessage.delete) {
      loadingMessage.delete().catch(() => {});
    }

    const errorEmbed = new EmbedBuilder()
      .setColor("#FF0000")
      .setTitle("❌ Obfuscate Failed")
      .setDescription(`${error.message}`);

    let failReply;
    if (context.editReply) {
      failReply = await context.editReply({ content: "", embeds: [errorEmbed], components: [] });
    } else if (context.reply) {
      failReply = await context.reply({ embeds: [errorEmbed] });
    } else if (context.channel) {
      failReply = await context.channel.send({ embeds: [errorEmbed] });
    }

    if (context.delete && context.guild) {
      context.delete().catch(() => {});
    }

    if (failReply && failReply.delete) {
      setTimeout(() => {
        failReply.delete().catch(() => {});
      }, 5000);
    }

  }

}

const data = [

  new SlashCommandBuilder()
    .setName("obfuscate")
    .setDescription(
      "Protecting .lua Source Code Files From Being Remade By Others"
    )
    .addAttachmentOption(option =>
      option
        .setName("file")
        .setDescription(
          "Upload file yang ingin di-obfuscate"
        )
        .setRequired(true)
    )
    .toJSON()

];

module.exports = {
  setup,
  data
};