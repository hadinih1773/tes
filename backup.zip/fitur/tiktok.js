const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require("discord.js");
const Axios = require("axios");
const cheerio = require("cheerio");

/* ================= TIKWM ENGINE ================= */
async function tiktokSearchVideo(query) {
  const res = await Axios.get(`https://api.ootaizumi.web.id/search/tiktok?query=${encodeURIComponent(query)}`);
  return res.data.result; // Menggunakan .result sesuai JSON baru
}

async function tiktokdl(url) {
  const res = await Axios.get(`https://api-faa.my.id/faa/tiktok?url=${encodeURIComponent(url)}`);
  return res.data.result;
}

/* ================= MODULE SETUP ================= */
module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;

      const content = message.content.toLowerCase();
      const args = message.content.split(" ");
      const command = args[0].toLowerCase();
      const query = args.slice(1).join(" ");

      // DOWNLOAD COMMANDS
      if (command === "!ttdl" || command === "!tt" || command === "!tiktok") {
        const url = args[1];

        if (!url) {
          return message.reply(`❌ Format Salah :\n\`${command} url\``);
        }

        const processEmbed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle("🎵 TikTok Downloader")
          .setDescription(`⏳ Sedang mendownload video dan audio TikTok...`);

        const msg = await message.reply({ embeds: [processEmbed] });

        try {
          const data = await tiktokdl(url);
          
          let files = [];

          if (data.type === "image" || Array.isArray(data.data)) {
            for (let i = 0; i < data.data.length; i++) {
              const imgRes = await Axios({
                method: "GET",
                url: data.data[i],
                responseType: "arraybuffer",
                headers: { "user-agent": "Mozilla/5.0" }
              });
              files.push({ attachment: Buffer.from(imgRes.data), name: `tiktok_${i + 1}.jpg` });
            }
          } else {
            const videoUrl = typeof data.data === "string" ? data.data : (data.nowm || data.url || data.no_watermark);
            const videoRes = await Axios({
              method: "GET",
              url: videoUrl,
              responseType: "arraybuffer",
              headers: { "user-agent": "Mozilla/5.0" }
            });
            files.push({ attachment: Buffer.from(videoRes.data), name: "tiktok.mp4" });

            if (data.music_info && data.music_info.url) {
              const audioRes = await Axios({
                method: "GET",
                url: data.music_info.url,
                responseType: "arraybuffer",
                headers: { "user-agent": "Mozilla/5.0" }
              });
              files.push({ attachment: Buffer.from(audioRes.data), name: "tiktok.mp3" });
            }
          }

          const resultEmbed = new EmbedBuilder()
            .setColor("#000000")
            .setTitle("🎵 TikTok Downloader")
            .setThumbnail(data.cover)
            .setDescription(
              `${message.author} Done Bro 😎!\n\n` +
              `📝 **Judul:** ${data.title}\n` +
              `🔗 **Url Tiktok:**\n${url}`
            )
            .setFooter({ text: "TikTok Downloader" });

          await msg.delete().catch(() => {});
          
          // Kirim embed balasan ke pesan user
          await message.reply({ embeds: [resultEmbed] });
          
          // Kirim file terpisah agar embed tidak tertekan memanjang ke bawah
          await message.channel.send({ files });
        } catch (err) {
          console.error(err);
          if (msg) await msg.delete().catch(() => {});
          message.reply(`❌ Gagal mendownload konten TikTok.`);
        }
      }

      // SEARCH COMMAND
      if (command === "!ttsearch" || command === "!tts"){
        if (!query) return message.reply("❌ Format Salah : ``!tts/ttsearch judul``");

        const searchProcessEmbed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle("🎵 TikTok Search")
          .setDescription(`⏳ Sedang mencari video: **${query}**...`);

        const msgSearch = await message.reply({ embeds: [searchProcessEmbed] });

        try {
          const results = await tiktokSearchVideo(query);
          
          if (!results || results.length === 0) {
            return msgSearch.edit({ embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Video tidak ditemukan.")] });
          }

          let currentIndex = 0;

          const createEmbed = (index) => {
            const v = results[index];
            return new EmbedBuilder()
              .setColor("Blue")
              .setTitle("🔎 TikTok Search")
              .setThumbnail(v.cover)
              .setDescription(
                `**Judul:** ${v.title || "No Title"}\n` +
                `👤 **Nama Creator :** ${v.music_info?.author || "Unknown"}\n\n` +
                `📊 **Stats:**\n` +
                `👁️ Views: ${v.play_count?.toLocaleString() || 0}\n` +
                `❤️ Likes: ${v.digg_count?.toLocaleString() || 0}\n` +
                `💬 Comments: ${v.comment_count?.toLocaleString() || 0}\n` +
                `🔁 Shares: ${v.share_count?.toLocaleString() || 0}\n` +
                `📥 Downloads: ${v.download_count?.toLocaleString() || 0}\n\n` +
                `🎵 **Music:** ${v.music_info?.title || "No Music"}\n` +
                `📅 **Created At:** ${v.create_time || "Unknown"}\n\n` +
                `🔗 **Link Video:**\nhttps://www.tiktok.com/@user/video/${v.video_id}`
              )
              .setFooter({ text: `Hasil ${index + 1} dari ${results.length} | TikTok Downloader` });
          };

          const createButtons = (index) => {
            return new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("prev").setLabel("⬅️ Previous").setStyle(ButtonStyle.Primary).setDisabled(index === 0),
              new ButtonBuilder().setCustomId("next").setLabel("Next ➡️").setStyle(ButtonStyle.Primary).setDisabled(index === results.length - 1)
            );
          };

          await msgSearch.edit({
            embeds: [createEmbed(currentIndex)],
            components: [createButtons(currentIndex)],
          });

          const collector = msgSearch.createMessageComponentCollector({ time: 3600000 });

          collector.on("collect", async (interaction) => {
            if (interaction.user.id !== message.author.id) return interaction.reply({ content: "Bukan buat lu cik!", ephemeral: true });

            if (interaction.customId === "prev") currentIndex--;
            if (interaction.customId === "next") currentIndex++;

            await interaction.update({ embeds: [createEmbed(currentIndex)], components: [createButtons(currentIndex)] });
          });
        } catch (err) {
          console.error(err);
          msgSearch.edit({ embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Terjadi kesalahan saat mencari video.")] });
        }
      }
    });
  },
};