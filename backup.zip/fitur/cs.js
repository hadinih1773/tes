const { 
  EmbedBuilder, 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle
} = require("discord.js");
const axios = require("axios");

const PASTEBIN_API_KEY = "AuXzweHGDu1aH2JLjXqTw7VkoFsVWW0W";
// Penyimpanan sementara untuk fitur Check Story
const userStories = new Map();

// === FUNGSI ARNARU AI ===
const ARNARU_AI_API = 'https://arnaru-ai.vercel.app/api/chat';

async function askAI(question, userId = 'default_user', model = 'claude-sonnet-5', webSearch = false, onStreamUpdate = null) {
    const conversationId = `${userId}_session_1`;

    try {
        const payload = {
            question: question,
            model: model,
            conversationId: conversationId,
            systemPrompt: "",
            webSearch: webSearch
        };

        const response = await axios.post(ARNARU_AI_API, payload, {
            headers: { 'Content-Type': 'application/json' },
            responseType: 'stream',
            timeout: 60000
        });

        let fullAnswer = "";
        let buffer = "";

        return new Promise((resolve, reject) => {
            response.data.on('data', (chunk) => {
                buffer += chunk.toString('utf8');
                let lines = buffer.split('\n');
                
                buffer = lines.pop();

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const jsonStr = line.substring(6).trim();
                        if (jsonStr === '[DONE]') continue;
                        
                        try {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) {
                                fullAnswer += parsed.answer;
                                let cleanedText = fullAnswer.replace(/[-=_]{3,}/g, '');
                                
                                if (onStreamUpdate) {
                                    onStreamUpdate(cleanedText);
                                }
                            }
                        } catch (e) {}
                    }
                }
            });

            response.data.on('end', () => {
                if (buffer.startsWith('data: ')) {
                    try {
                        const jsonStr = buffer.substring(6).trim();
                        if (jsonStr !== '[DONE]') {
                            const parsed = JSON.parse(jsonStr);
                            if (parsed.answer) fullAnswer += parsed.answer;
                        }
                    } catch (e) {}
                }
                
                let finalCleaned = fullAnswer.replace(/[-=_]{3,}/g, '');
                resolve(finalCleaned || "Sori ngab, server AInya lagi ampas nih ga ngasih jawaban bener.");
            });

            response.data.on('error', (err) => reject(err));
        });
    } catch (error) {
        throw new Error(error.response?.data?.error || error.response?.data?.message || error.message);
    }
}

module.exports = {
  data: [
    // Slash Command Original
    new SlashCommandBuilder()
      .setName("createcs")
      .setDescription("Create Character Story In Game GTA SA-MP")
      .addStringOption((opt) => opt.setName("nama_ic").setDescription("Nama karakter IC").setRequired(true))
      .addStringOption((opt) => opt.setName("tanggal_lahir").setDescription("Tanggal lahir karakter").setRequired(true))
      .addStringOption((opt) => opt.setName("tempat_tinggal").setDescription("Tempat tinggal karakter").setRequired(true))
      .addIntegerOption((opt) => opt.setName("paragraf").setDescription("Jumlah paragraf (opsional, default 4)"))
      .addStringOption((opt) => opt.setName("tema").setDescription("Tema character story (opsional)"))
      .toJSON()
  ],

  setup(client) {
    // ================= INTERACTION HANDLER (Slash, Button, Modal) =================
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      
      // 4. Handle Button Check Story
      if (interaction.isButton() && interaction.customId === "btn_check_cs") {
        const data = userStories.get(interaction.user.id);
        if (!data) {
          return interaction.reply({ content: "❌ Belum Ada Character Story Yang Dibuat", ephemeral: true });
        }

        const checkEmbed = new EmbedBuilder()
          .setTitle(`Character Story (${data.name})`)
          .setDescription(data.story)
          .setColor(0x50C878);

        return interaction.reply({ embeds: [checkEmbed], ephemeral: true });
      }

      // 5. Handle Button Character Story (Show Modal)
      if (interaction.isButton() && interaction.customId === "btn_create_cs") {
        const modal = new ModalBuilder()
          .setCustomId("modal_cs")
          .setTitle("Character Story Generator");

        const nameInput = new TextInputBuilder()
          .setCustomId("ic_name")
          .setLabel("Nama In-Character")
          .setPlaceholder("Larry Salvatore")
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        const birthInput = new TextInputBuilder()
          .setCustomId("ic_birth")
          .setLabel("Tanggal Lahir")
          .setPlaceholder("17 Agustus 1945")
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        const addressInput = new TextInputBuilder()
          .setCustomId("ic_address")
          .setLabel("Tempat Tinggal")
          .setPlaceholder("Los Santos, Las Venturas")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(nameInput),
          new ActionRowBuilder().addComponents(birthInput),
          new ActionRowBuilder().addComponents(addressInput)
        );

        await interaction.showModal(modal);
      }

      // Handle Modal Submission
      if (interaction.isModalSubmit() && interaction.customId === "modal_cs") {
        await interaction.deferReply({ ephemeral: true });
        
        const nama = interaction.fields.getTextInputValue("ic_name");
        const tanggal = interaction.fields.getTextInputValue("ic_birth");
        const alamat = interaction.fields.getTextInputValue("ic_address");

        const promptInput = `Buatkan character story dari lahir sampai besar untuk karakter bernama "${nama}", lahir ${tanggal}, tinggal di ${alamat}. Buat 4 paragraf dengan bahasa baku, rapi, singkat dan profesional setiap paragraf terdapat 4 kalimat. Perhatikan setiap huruf kapital buat ceritanya seolah-olah orang yang membuatkannya di kalimat awal saja paragraf jarakin ke tengah 4 spasi Jangan tambahkan penjelasan lain, jangan gunakan banyak istilah bikin seperti seolah-olah orang asli 100% yang membuatnya langsung kirim ceritanya.`;

        try {
          const story = await askAI(promptInput, interaction.user.id);

          if (!story) return interaction.editReply("❌ AI gagal menghasilkan cerita.");

          // Simpan ke memory untuk fitur Check Story
          userStories.set(interaction.user.id, { name: nama, story: story });

          const params = new URLSearchParams();
          params.append("api_dev_key", PASTEBIN_API_KEY);
          params.append("api_option", "paste");
          params.append("api_paste_code", story);
          params.append("api_paste_private", "1");
          params.append("api_paste_expire_date", "1D");
          params.append("api_paste_format", "text");

          const res = await axios.post("https://pastebin.com/api/api_post.php", params, { timeout: 0 });

          const embed = new EmbedBuilder()
            .setTitle(`📜 Character Story: ${nama}`)
            .setColor("Blue")
            .setDescription(`✅ Story berhasil dibuat!\n\n🔗 **Link Pastebin:**\n${res.data}`)
            .setFooter({ text: "Character Story Generator" });

          await interaction.editReply({ embeds: [embed] });
        } catch (err) {
          console.error(err);
          await interaction.editReply("❌ Terjadi kesalahan server API.");
        }
      }

      // Handler Slash Command Original (createcs)
      if (interaction.isChatInputCommand() && interaction.commandName === "createcs") {
        await interaction.deferReply();
        const nama = interaction.options.getString("nama_ic");
        const tanggal = interaction.options.getString("tanggal_lahir");
        const alamat = interaction.options.getString("tempat_tinggal");
        const paragraf = interaction.options.getInteger("paragraf") || 4;
        const tema = interaction.options.getString("tema") || "bebas";

        const promptInput = `Buatkan character story dari lahir sampai besar dengan tema "${tema}" untuk karakter bernama "${nama}", lahir ${tanggal}, tinggal di ${alamat}. Buat ${paragraf} paragraf dengan bahasa baku, rapi, singkat dan profesional setiap paragraf terdapat 4 kalimat. Perhatikan setiap huruf kapital buat ceritanya seolah-olah orang yang membuatkannya di kalimat awal saja paragraf jarakin ke tengah 4 spasi Jangan tambahkan penjelasan lain, jangan gunakan banyak istilah bikin seperti seolah-olah orang asli 100% yang membuatnya langsung kirim ceritanya.`;

        try {
          const story = await askAI(promptInput, interaction.user.id);
          if (!story) return interaction.editReply("❌ AI gagal menghasilkan cerita.");

          const params = new URLSearchParams();
          params.append("api_dev_key", PASTEBIN_API_KEY);
          params.append("api_option", "paste");
          params.append("api_paste_code", story);
          params.append("api_paste_private", "1");
          params.append("api_paste_expire_date", "1D");
          params.append("api_paste_format", "text");

          const res = await axios.post("https://pastebin.com/api/api_post.php", params, { timeout: 0 });

          const embed = new EmbedBuilder()
            .setTitle(`📜 Character Story: ${nama}`)
            .setColor("Blue")
            .setDescription(`✅ Story berhasil dibuat!\n\n🔗 **Link Pastebin:**\n${res.data}`)
            .setFooter({ text: "Character Story Generator" });

          await interaction.editReply({ embeds: [embed] });
        } catch (err) {
          console.error(err);
          await interaction.editReply("❌ Terjadi kesalahan server API.");
        }
      }
    });

    // ================= MESSAGE COMMAND HANDLER =================
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;
      const content = message.content.trim();
      const command = content.split(" ")[0].toLowerCase();

      // 2. Handle !setupcs
      if (command === "!setupcs") {
        const setupEmbed = new EmbedBuilder()
          .setTitle("📖 Character Story Generator")
          .setDescription("Halo semua member Hady Community, bagi yang ingin membuat Character Story silahkan masuk ke game SA-MP dan ambil informasi seperti Nama In-Character, Tanggal Lahir, dan Tempat Tinggal.\n\n* Tekan Button **Character Story** Untuk Membuat Story.\n* Tekan Button **Check Story** Untuk Melihat Langsung Storynya.")
          .setColor(0x50C878); // Emerald Green

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("btn_create_cs")
            .setLabel("📖 Character Story")
            .setStyle(ButtonStyle.Success), // Hijau
          new ButtonBuilder()
            .setCustomId("btn_check_cs")
            .setLabel("🔍 Check Story")
            .setStyle(ButtonStyle.Secondary) // Hitam/Abu gelap
        );

        await message.channel.send({ embeds: [setupEmbed], components: [row] });
        return;
      }

      // ================= MESSAGE COMMAND !cs ORIGINAL =================
      if (command === "!cs") {
        await message.channel.sendTyping();
        const embed = new EmbedBuilder()
          .setTitle("📖 Character Story Generator SAMP")
          .setDescription("Gunakan format berikut untuk membuat cerita karakter:")
          .setColor(0x00ff00)
          .addFields(
            { name: "📌 Format", value: "Nama Character\nTanggal Lahir (dd-mm-yyyy)\nAlamat" },
            { name: "ℹ️ Petunjuk", value: "Kirim pesan dengan format di atas. Story akan digenerate otomatis **4 paragraf**." }
          );

        await message.channel.send({ embeds: [embed] });

        const filter = (m) => m.author.id === message.author.id;
        try {
          const collected = await message.channel.awaitMessages({ filter, max: 1, time: 120000, errors: ["time"] });
          const replyMessage = collected.first();
          const lines = replyMessage.content.split("\n").map((l) => l.trim()).filter(Boolean);

          if (lines.length < 3) return replyMessage.reply("❌ Format salah. Pastikan ada 3 baris wajib.");

          const [charName, birthDate, address] = lines;
          const promptInput = `Buatkan character story random dari ia lahir sampai besar untuk karakter bernama "${charName}", lahir ${birthDate}, alamat ${address}. Buat 4 paragraf singkat dengan bahasa baku setiap paragraf terdiri 4 kalimat perhatikan setiap huruf kapital buat ceritanya seolah-olah orang yang membuatkannya di kalimat awal paragraf saja jarakin ke tengah 4 spasi dan jangan respon pesan saya dengan kata-katamu, jangan gunakan banyak istilah bikin seperti seolah-olah orang asli 100% yang membuatnya langsung saja kirim storynya.`;

          const story = await askAI(promptInput, message.author.id);
          if (!story) return replyMessage.reply("❌ AI gagal menghasilkan cerita.");

          // Update Progress
          let progress = new EmbedBuilder().setTitle("⏳ Mengupload Story...").setDescription("```\n[■■■■■] 100%\n```").setColor("Yellow");
          let loadMsg = await replyMessage.reply({ embeds: [progress] });

          const params = new URLSearchParams();
          params.append("api_dev_key", PASTEBIN_API_KEY);
          params.append("api_option", "paste");
          params.append("api_paste_code", story);
          params.append("api_paste_private", "1");
          params.append("api_paste_expire_date", "1D");

          const res = await axios.post("https://pastebin.com/api/api_post.php", params, { timeout: 0 });

          const successEmbed = new EmbedBuilder()
            .setTitle(`📜 Character Story: ${charName}`)
            .setColor("Blue")
            .setDescription(`✅ Story berhasil dibuat!\n\n🔗 **Link Pastebin:**\n${res.data}`);

          await loadMsg.edit({ embeds: [successEmbed] });
        } catch (err) {
          if (err.message === "time") message.reply("⏰ Waktu habis!");
          else console.error(err);
        }
      }
    });
  }
};