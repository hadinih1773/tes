const { EmbedBuilder, AttachmentBuilder, PermissionFlagsBits } = require("discord.js");
const axios = require('axios');
const https = require('https');
const fs = require('fs');
const path = require('path');

// Ganti ID channel di bawah ini
const CHANNEL_ID_EDIT = "1458482356854984846"; 

// Lokasi file JSON database
const dbDir = path.join(__dirname, "../database");
const dbFilePath = path.join(dbDir, "imgchannel.json");

// Helper untuk membaca daftar channel dari JSON
function loadChannels() {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(dbFilePath)) {
        fs.writeFileSync(dbFilePath, JSON.stringify([]));
        return [];
    }
    try {
        const data = fs.readFileSync(dbFilePath, "utf8");
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

// Helper untuk menyimpan daftar channel ke JSON
function saveChannels(channels) {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(dbFilePath, JSON.stringify(channels, null, 2));
}

// Konfigurasi koneksi super cepat & tanpa timeout
const fastAxios = axios.create({
    timeout: 0,
    httpsAgent: new https.Agent({ 
        keepAlive: true, 
        maxSockets: 100,
        rejectUnauthorized: false 
    })
});

function setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
        if (message.author.bot) return;

        const args = message.content.split(" ");
        const command = args[0].toLowerCase();
        const isAdmin = message.member?.permissions.has(PermissionFlagsBits.Administrator);

        // Command !setchannelimg dan !delchannelimg (Hanya Admin)
        if (command === "!setchannelimg" || command === "!delchannelimg") {
            if (!isAdmin) {
                return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
            }

            let targetChannel = message.mentions.channels.first() || message.channel;
            let channelList = loadChannels();

            if (command === "!setchannelimg") {
                if (!channelList.includes(targetChannel.id)) {
                    channelList.push(targetChannel.id);
                    saveChannels(channelList);
                    return message.reply(`✅ Channel <#${targetChannel.id}> berhasil ditambahkan ke daftar.`);
                } else {
                    return message.reply(`⚠️ Channel <#${targetChannel.id}> sudah ada di daftar.`);
                }
            }

            if (command === "!delchannelimg") {
                if (channelList.includes(targetChannel.id)) {
                    channelList = channelList.filter(id => id !== targetChannel.id);
                    saveChannels(channelList);
                    return message.reply(`✅ Channel <#${targetChannel.id}> berhasil dihapus dari daftar.`);
                } else {
                    return message.reply(`⚠️ Channel <#${targetChannel.id}> tidak ditemukan di daftar.`);
                }
            }
        }

        // Cek apakah channel diizinkan
        const customChannels = loadChannels();
        const isAllowedChannel = message.channel.id === CHANNEL_ID_EDIT || customChannels.includes(message.channel.id);

        const isCommand = message.content.startsWith("!editgambar");
        const isAutoChannel = isAllowedChannel;

        if (!isCommand && !isAutoChannel) return;

        let imageUrl = null;
        let prompt = "";

        if (isCommand) {
            prompt = message.content.slice(11).trim();
        } else {
            prompt = message.content.trim();
        }

        // Ambil Gambar (Lampiran atau Reply)
        if (message.attachments.size > 0) {
            imageUrl = message.attachments.first().url;
        } else if (message.reference) {
            try {
                const repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
                if (repliedMessage.attachments.size > 0) {
                    imageUrl = repliedMessage.attachments.first().url;
                }
            } catch (e) {}
        }

        // Jika tidak ada gambar, bot diam saja
        if (!imageUrl) return;

        if (!prompt) prompt = "enhance quality";

        const loadingEmbed = new EmbedBuilder()
            .setTitle("🔄 Sedang Di Proses")
            .setDescription("⏳ Harap Bersabar, dan Jangan Spam")
            .setColor("Blue");

        const msg = await message.reply({ embeds: [loadingEmbed] });

        try {
            const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`;
            
            // Request performa tinggi
            const response = await fastAxios.get(apiUrl, { responseType: 'arraybuffer' });
            const attachment = new AttachmentBuilder(Buffer.from(response.data), { name: 'edited.png' });

            if (isCommand) {
                // Hasil untuk Command !editgambar (Embed Hijau)
                const successEmbed = new EmbedBuilder()
                    .setTitle("🖼 Image Edit")
                    .setDescription(`<@${message.author.id}> Done Bro 😎!`)
                    .setColor("Green")
                    .setImage('attachment://edited.png');

                await msg.edit({ embeds: [successEmbed], files: [attachment] });
            } else {
                // Hasil untuk Auto Channel (Reply tanpa tag & tanpa embed hasil)
                await message.reply({ 
                    files: [attachment], 
                    allowedMentions: { replied_user: false } 
                });
                await msg.delete().catch(() => {});
            }
        } catch (error) {
            await msg.edit({ content: "❌ Gagal memproses gambar. API sedang sibuk.", embeds: [] });
        }
    });
}

module.exports = { setup };