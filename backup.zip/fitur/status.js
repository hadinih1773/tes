// =========================
// status.js
// Fitur: Status Bot ON / OFF dengan Webhook
// =========================

const { EmbedBuilder, PermissionsBitField } = require("discord.js");

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const content = message.content;
    if (!content.startsWith("!on") && !content.startsWith("!off")) return;

    const isCommand = true;
    if (!isCommand) return;

    // Cek izin admin
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
    }

    const isOn = content.startsWith("!on");
    // Menggunakan Hijau Emerald (0x50C878) untuk online dan Merah (0xFF0000) untuk offline
    const color = isOn ? 0x50C878 : 0xff0000;

    let targetChannel = null;
    let note = "";
    const args = content.split(" ");

    // Helper Function untuk mengirim Webhook
    async function sendStatusWebhook(channel, embed) {
      try {
        const webhooks = await channel.fetchWebhooks();
        let webhook = webhooks.find(wh => wh.name === "Hady Status WH");

        if (!webhook) {
          webhook = await channel.createWebhook({
            name: "Hady Status WH",
            avatar: client.user.displayAvatarURL(),
          });
        }

        await webhook.send({
          content: "@everyone",
          username: "📡 Information Status | Hady Community",
          avatarURL: client.user.displayAvatarURL(),
          embeds: [embed]
        });
      } catch (error) {
        console.error("Gagal mengirim webhook:", error);
        await channel.send({ content: "@everyone", embeds: [embed] });
      }
    }

    // =============================================
    // CASE 1: !on note (tanpa mention channel)
    // =============================================
    if (!message.mentions.channels.first()) {
      note = args.slice(1).join(" ");
      await message.delete().catch(() => {});
      if (!note) return;

      const descriptionText = isOn 
        ? `✅ Bot Is Now **Online!**\n\n📋 **Note** :\n` + "```" + note + "```"
        : `❌ Bot Now Is **Offline!**\n\n📋 **Note** :\n` + "```" + note + "```";

      const embed = new EmbedBuilder()
        .setTitle("📣 Status Bot")
        .setDescription(descriptionText)
        .setColor(color)
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter({ text: "Status update oleh " + message.author.tag })
        .setTimestamp();

      await sendStatusWebhook(message.channel, embed);
      return;
    }

    // =============================================
    // CASE 2: !on #channel note (pakai mention)
    // =============================================
    targetChannel = message.mentions.channels.first();
    note = args.slice(2).join(" ");

    if (!note) {
      return message.reply("❌ Format Salah : `!on #channel note` atau `!off #channel note`");
    }

    const descriptionText = isOn 
      ? `✅ Bot Is Now **Online!**\n\n📋 **Note** :\n` + "```" + note + "```"
      : `❌ Bot Now Is **Offline!**\n\n📋 **Note** :\n` + "```" + note + "```";

    const embed = new EmbedBuilder()
      .setTitle("📣 Status Bot")
      .setDescription(descriptionText)
      .setColor(color)
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({ text: "Status update oleh " + message.author.tag })
      .setTimestamp();

    await sendStatusWebhook(targetChannel, embed);
    message.reply(`Status bot dikirim ke ${targetChannel}.`);
  });
}

module.exports = { setup };