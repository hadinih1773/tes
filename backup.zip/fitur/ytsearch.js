const axios = require("axios");
const yts = require("yt-search");
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;

      const prefix = "!";
      if (!message.content.startsWith(prefix)) return;

      const args = message.content.slice(prefix.length).trim().split(/ +/);
      const cmd = args.shift().toLowerCase();

      if (cmd !== "yts") return;

      const query = args.join(" ");
      if (!query) return message.reply("❌ Format Salah : ``!yts judul``");

      const loadingEmbed = new EmbedBuilder()
        .setColor("Yellow")
        .setDescription("🔍 Mencari video YouTube...");

      const msg = await message.reply({ embeds: [loadingEmbed] });

      try {
        const resYts = await yts(query);
        const data = resYts.all.filter(v => v.type === "video");
        
        if (!data || !data.length) {
          return msg.edit({
            embeds: [
              new EmbedBuilder()
                .setColor("Red")
                .setDescription("❌ Video tidak ditemukan."),
            ],
          });
        }

        const videos = data.slice(0, 10);
        let index = 0;

        const makeEmbed = (i) => {
          const v = videos[i];
          return new EmbedBuilder()
            .setColor("Blue")
            .setTitle(v.title)
            .setURL(v.url)
            .setDescription(
              `**${i + 1} / ${videos.length}**\n\n` +
                `⏳ Durasi: ${v.timestamp || "0:00"}\n` +
                `👀 Views: ${v.views.toLocaleString()}\n` +
                `📺 Channel: ${v.author.name}\n\n` +
                `🔗 ${v.url}`
            )
            .setImage(`https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`)
            .setFooter({ text: "Gunakan tombol untuk pindah video" });
        };

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("prev")
            .setLabel("⬅️ Prev")
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId("next")
            .setLabel("➡️ Next")
            .setStyle(ButtonStyle.Secondary)
        );

        await msg.edit({
          embeds: [makeEmbed(index)],
          components: [row],
        });

        const collector = msg.createMessageComponentCollector({
          filter: (i) => {
            if (i.user.id === message.author.id) return true;
            i.reply({ content: "❌ Ini bukan buat kamu", ephemeral: true });
            return false;
          },
          time: 0,
        });

        collector.on("collect", async (i) => {
          if (i.customId === "prev") {
            index = (index - 1 + videos.length) % videos.length;
          } else if (i.customId === "next") {
            index = (index + 1) % videos.length;
          }
          await i.update({
            embeds: [makeEmbed(index)],
            components: [row],
          });
        });
      } catch (err) {
        console.error(err);
        return msg.edit({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setDescription("❌ Terjadi error saat mencari video."),
          ],
        });
      }
    });
  },
};