const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const axios = require("axios");

const https = require('https');

const agent = new https.Agent({

	rejectUnauthorized: true,

	maxVersion: 'TLSv1.3',

	minVersion: 'TLSv1.2'

});

async function pinterest(query) {

	return new Promise(async (resolve, reject) => {

		const baseUrl = 'https://www.pinterest.com/resource/BaseSearchResource/get/';

		const params = {

			source_url: '/search/pins/?q=' + encodeURIComponent(query),

			data: JSON.stringify({

				options: {

					isPrefetch: false,

					query,

					scope: 'pins',

					no_fetch_context_on_resource: false

				},

				context: {}

			}),

			_: Date.now()

		};

		const headers = {

			'accept': 'application/json, text/javascript, */*, q=0.01',

			'accept-encoding': 'gzip, deflate',

			'accept-language': 'en-US,en;q=0.9',

			'dnt': '1',

			'referer': 'https://www.pinterest.com/',

			'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',

			'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',

			'sec-ch-ua-mobile': '?0',

			'sec-ch-ua-model': '""',

			'sec-ch-ua-platform': '"Windows"',

			'sec-ch-ua-platform-version': '"10.0.0"',

			'sec-fetch-dest': 'empty',

			'sec-fetch-mode': 'cors',

			'sec-fetch-site': 'same-origin',

			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',

			'x-app-version': 'c056fb7',

			'x-pinterest-appstate': 'active',

			'x-pinterest-pws-handler': 'www/[username]/[slug].js',

			'x-pinterest-source-url': '/hargr003/cat-pictures/',

			'x-requested-with': 'XMLHttpRequest'

		};

		try {

			const { data } = await axios.get(baseUrl, { httpsAgent: agent, headers, params });

			const results = data.resource_response?.data?.results?? [];

			const result = results.map(item => ({

				pin: 'https://www.pinterest.com/pin/' + item.id?? '',

				link: item.link?? '',

				created_at: (new Date(item.created_at)).toLocaleDateString('id-ID', {

					day: 'numeric',

					month: 'long',

					year: 'numeric'

				}) ?? '',

				id: item.id?? '',

				images_url: item.images?.['736x']?.url?? '',

				grid_title: item.grid_title?? ''

			}));

			resolve(result);

		} catch (e) {

			reject([])

		}

	});

}

/* ================= MODULE SETUP ================= */

module.exports = {

  setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

      if (message.author.bot) return;

      const args = message.content.split(" ");

      const command = args[0].toLowerCase();

      const query = args.slice(1).join(" ");

      if (command === "!pinsearch") {

        if (!query) return message.reply("❌ Format Salah : ``!pinsearch query``");

        const processEmbed = new EmbedBuilder()

          .setColor("Green")

          .setTitle("Pinterest Search")

          .setDescription(`⏳ Sedang mencari gambar: **${query}**...`);

        const msg = await message.reply({ embeds: [processEmbed] });

        try {

          const results = await pinterest(query);

          const data = results.slice(0, 10);

          if (!data || data.length === 0) {

            return msg.edit({ embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Gambar tidak ditemukan.")] });

          }

          let currentIndex = 0;

          const createEmbed = (index) => {

            const item = data[index];

            return new EmbedBuilder()

              .setColor("Green")

              .setTitle("🔎 Pinterest Search")

              .setDescription(`${message.author} Done Bro 😎!`)

              .setImage(item.images_url)

              .setFooter({ text: `Gambar ${index + 1} dari ${data.length} | Source: Pinterest` });

          };

          const createButtons = (index) => {

            return new ActionRowBuilder().addComponents(

              new ButtonBuilder()

                .setCustomId("prev_pin")

                .setLabel("⬅️ Previous")

                .setStyle(ButtonStyle.Primary)

                .setDisabled(index === 0),

              new ButtonBuilder()

                .setCustomId("next_pin")

                .setLabel("Next ➡️")

                .setStyle(ButtonStyle.Primary)

                .setDisabled(index === data.length - 1)

            );

          };

          await msg.edit({

            embeds: [createEmbed(currentIndex)],

            components: [createButtons(currentIndex)],

          });

          const collector = msg.createMessageComponentCollector();

          collector.on("collect", async (interaction) => {

            if (interaction.user.id !== message.author.id) {

              return interaction.reply({ content: "Bukan buat lu cik!", ephemeral: true });

            }

            if (interaction.customId === "prev_pin") currentIndex--;

            if (interaction.customId === "next_pin") currentIndex++;

            await interaction.update({

              embeds: [createEmbed(currentIndex)],

              components: [createButtons(currentIndex)],

            });

          });

        } catch (err) {

          msg.edit({ embeds: [new EmbedBuilder().setColor("Red").setDescription("❌ Gagal mengambil data.")] });

        }

      }

    });

  },

};