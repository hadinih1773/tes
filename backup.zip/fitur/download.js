const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const dbPath = path.join(__dirname, "..", "database", "download.json");

function loadDownloadData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify({ channels: [] }));
      return { channels: [] };
    }
    const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
    if (!Array.isArray(data.channels)) {
      data.channels = [];
    }
    return data;
  } catch {
    return { channels: [] };
  }
}

function saveDownloadData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database download.json:", err);
  }
}

module.exports = {
  setup: (client) => {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // Command Tambah Channel
      if (command === "!setchanneldl" || command === "!setchanneldownload") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        const targetChannel = message.mentions.channels.first() || message.channel;
        const data = loadDownloadData();

        if (!data.channels.includes(targetChannel.id)) {
          data.channels.push(targetChannel.id);
          saveDownloadData(data);
          return message.reply(`✅ Berhasil menambahkan channel download di <#${targetChannel.id}>`);
        } else {
          return message.reply(`❌ Channel <#${targetChannel.id}> sudah terdaftar.`);
        }
      }

      // Command Hapus Channel
      if (command === "!delchanneldl" || command === "!delchanneldownload") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        const targetChannel = message.mentions.channels.first() || message.channel;
        const data = loadDownloadData();

        if (data.channels.includes(targetChannel.id)) {
          data.channels = data.channels.filter((id) => id !== targetChannel.id);
          saveDownloadData(data);
          return message.reply(`✅ Berhasil menghapus channel download dari <#${targetChannel.id}>`);
        } else {
          return message.reply(`❌ Channel <#${targetChannel.id}> tidak terdaftar sebagai channel download.`);
        }
      }

      // Deteksi URL di channel terdaftar
      const data = loadDownloadData();
      if (data.channels.includes(message.channel.id)) {
        
        // --- DETEKSI TIKTOK ---
        const tiktokRegex = /(https?:\/\/(?:vt|www|vm)\.tiktok\.com\/[^\s]+|https?:\/\/(?:www\.)?tiktok\.com\/@[^\s]+\/video\/[^\s]+)/gi;
        const matchTiktok = message.content.match(tiktokRegex);

        if (matchTiktok) {
          const tiktokUrl = matchTiktok[0];

          // Send Embed Proses (Biru)
          const processEmbed = new EmbedBuilder()
            .setColor("#0099FF")
            .setTitle("🔄 Sedang Proses Download")
            .setDescription("⏳ Mohon Ditunggu Jangan Spamm..");

          const processMsg = await message.reply({ embeds: [processEmbed] }).catch(() => null);

          try {
            const apiUrl = `https://api-faa.my.id/faa/tiktok?url=${encodeURIComponent(tiktokUrl)}`;
            const res = await axios.get(apiUrl, { timeout: 30000 });
            const resultData = res.data;

            if (resultData && resultData.status && resultData.result) {
              const result = resultData.result;
              const title = result.title || "No Title";

              // Embed Hasil (Hitam)
              const resultEmbed = new EmbedBuilder()
                .setColor("#000000")
                .setTitle("📟 TikTok Downloader")
                .setDescription(title);

              if (result.type === "video") {
                const videoUrl = result.data || (result.alternatives && result.alternatives.hd) || (result.alternatives && result.alternatives.sd);
                
                if (processMsg) await processMsg.delete().catch(() => null);

                await message.reply({
                  embeds: [resultEmbed],
                  files: [{ attachment: videoUrl, name: "tiktok.mp4" }]
                });
              } else if (result.type === "image") {
                const images = Array.isArray(result.data) ? result.data : [];
                const attachments = images.map((imgUrl, index) => ({
                  attachment: imgUrl,
                  name: `image_${index + 1}.jpeg`
                }));

                if (processMsg) await processMsg.delete().catch(() => null);

                await message.reply({
                  embeds: [resultEmbed],
                  files: attachments
                });
              } else {
                if (processMsg) await processMsg.delete().catch(() => null);
                await message.reply("❌ Tipe konten tidak didukung.").catch(() => null);
              }
            } else {
              if (processMsg) await processMsg.delete().catch(() => null);
              await message.reply("❌ Gagal mengambil data dari API TikTok.").catch(() => null);
            }
          } catch (err) {
            console.error("Error downloading TikTok:", err);
            if (processMsg) await processMsg.delete().catch(() => null);
            await message.reply("❌ Terjadi kesalahan saat memproses link TikTok.").catch(() => null);
          }
        }

        // --- DETEKSI INSTAGRAM ---
        const igRegex = /(https?:\/\/(?:www\.)?instagram\.com\/(?:p|reel|reels|tv)\/[^\s]+)/gi;
        const matchIg = message.content.match(igRegex);

        if (matchIg) {
          const igUrl = matchIg[0];

          // Send Embed Proses (Biru)
          const processEmbed = new EmbedBuilder()
            .setColor("#0099FF")
            .setTitle("🔄 Sedang Proses Download")
            .setDescription("⏳ Mohon Ditunggu Jangan Spamm..");

          const processMsg = await message.reply({ embeds: [processEmbed] }).catch(() => null);

          try {
            const apiUrl = `https://velynapi.vercel.app/api/downloader/instagram?url=${encodeURIComponent(igUrl)}`;
            const res = await axios.get(apiUrl, { timeout: 30000 });
            const resultData = res.data;

            if (resultData && resultData.status && resultData.data && Array.isArray(resultData.data.url)) {
              // Embed Hasil Instagram (Pink #E1306C)
              const resultEmbed = new EmbedBuilder()
                .setColor("#E1306C")
                .setTitle("📟 Instagram Downloader")
                .setDescription("Succes ✅");

              const attachments = resultData.data.url.map((mediaUrl, index) => ({
                attachment: mediaUrl,
                name: `instagram_${index + 1}.mp4`
              }));

              if (processMsg) await processMsg.delete().catch(() => null);

              await message.reply({
                embeds: [resultEmbed],
                files: attachments
              });
            } else {
              if (processMsg) await processMsg.delete().catch(() => null);
              await message.reply("❌ Gagal mengambil data dari API Instagram.").catch(() => null);
            }
          } catch (err) {
            console.error("Error downloading Instagram:", err);
            if (processMsg) await processMsg.delete().catch(() => null);
            await message.reply("❌ Terjadi kesalahan saat memproses link Instagram.").catch(() => null);
          }
        }

        // --- DETEKSI FACEBOOK ---
        const fbRegex = /(https?:\/\/(?:www\.|web\.|m\.)?(?:facebook\.com|fb\.watch)\/[^\s]+)/gi;
        const matchFb = message.content.match(fbRegex);

        if (matchFb) {
          const fbUrl = matchFb[0];

          // Send Embed Proses (Biru)
          const processEmbed = new EmbedBuilder()
            .setColor("#0099FF")
            .setTitle("🔄 Sedang Proses Download")
            .setDescription("⏳ Mohon Ditunggu Jangan Spamm..");

          const processMsg = await message.reply({ embeds: [processEmbed] }).catch(() => null);

          try {
            const apiUrl = `https://api-faa.my.id/faa/fbdownload?url=${encodeURIComponent(fbUrl)}`;
            const res = await axios.get(apiUrl, { timeout: 30000 });
            const resultData = res.data;

            if (resultData && resultData.status && resultData.result) {
              const info = resultData.result.info || {};
              const media = resultData.result.media || {};
              const videoUrl = media.video_hd || media.video_sd;
              const title = info.title || "No Title";

              if (videoUrl) {
                // Embed Hasil Facebook (Biru Logo Facebook #1877F2)
                const resultEmbed = new EmbedBuilder()
                  .setColor("#1877F2")
                  .setTitle("📟 Facebook Downloader")
                  .setDescription(title);

                if (processMsg) await processMsg.delete().catch(() => null);

                await message.reply({
                  embeds: [resultEmbed],
                  files: [{ attachment: videoUrl, name: "facebook.mp4" }]
                });
              } else {
                if (processMsg) await processMsg.delete().catch(() => null);
                await message.reply("❌ Video Facebook tidak ditemukan.").catch(() => null);
              }
            } else {
              if (processMsg) await processMsg.delete().catch(() => null);
              await message.reply("❌ Gagal mengambil data dari API Facebook.").catch(() => null);
            }
          } catch (err) {
            console.error("Error downloading Facebook:", err);
            if (processMsg) await processMsg.delete().catch(() => null);
            await message.reply("❌ Terjadi kesalahan saat memproses link Facebook.").catch(() => null);
          }
        }

      }
    });
  }
};