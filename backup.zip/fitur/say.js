const { PermissionsBitField } = require("discord.js");

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const content = message.content.trim();

    if (!content.toLowerCase().startsWith("!say")) return;

    const raw = content.slice(4).trim();

    if (!raw) {
      return message.reply("❌ Format salah :`!say pesan`\natau\n`!say #channel pesan`");
    }

    // Ambil mention channel pertama
    const channelMention = message.mentions.channels.first();

    let deskripsi = raw;
    let targetChannel = message.channel;

    // Jika pesan dimulai dengan mention channel, maka target dirubah
    if (channelMention && raw.startsWith(channelMention.toString())) {
      targetChannel = channelMention;
      // Hapus mention channel dari string untuk mengambil pesannya saja
      deskripsi = raw.replace(channelMention.toString(), "").trim();
    }

    if (!deskripsi) {
      return message.reply("Pesan tidak boleh kosong!");
    }

    // Cek izin admin
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
    }

    try {
      // Kirim pesan ke target channel (bisa channel sekarang atau channel yang dimention)
      await targetChannel.send(deskripsi);
      
      if (message.deletable) {
        await message.delete().catch(() => {});
      }
    } catch (err) {
      console.error("Error di command !say:", err);
      message.reply("Gagal mengirim pesan.");
    }
  });
}

module.exports = { setup };