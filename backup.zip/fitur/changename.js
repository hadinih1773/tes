const { Client } = require('discord.js');

const PREFIX = '!';

// PENTING: GANTI ID CHANNEL DI BAWAH INI

const ALLOWED_CHANNEL_ID = '1440517187273228429'; 

/**

 * Menyiapkan listener untuk command !changename.

 * Fungsi ini memungkinkan anggota mengubah nickname-nya sendiri di guild tersebut.

 * @param {Client} client Discord Client instance.

 */

function setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

        // Abaikan bot dan pesan tanpa prefix

        if (message.author.bot || !message.content.startsWith(PREFIX)) return;

        

        // Memastikan pesan datang dari guild dan bukan DM

        if (!message.guild || !message.member) return;

        // ======================================

        // BATASAN CHANNEL

        // Command hanya dapat dieksekusi di channel yang diizinkan.

        // ======================================

        if (message.channel.id !== ALLOWED_CHANNEL_ID) {

            // Drop secara diam-diam (silent drop)

            return; 

        }

        // UBAHAN LO:

        // Dari "!changename|nama" → "!changename nama"

        const args = message.content.slice(PREFIX.length).trim().split(" ");

        const command = args.shift().toLowerCase();

        const newNickname = args.join(" ").trim();

        if (command === 'changename') {

            // Periksa format command

            if (!newNickname || newNickname.length === 0) {

                return message.reply(`❌ Format salah : \`${PREFIX}changename nama baru\`.`);

            }

            const member = message.member; 

            try {

                // Batasan Nama Discord

                if (newNickname.length > 32) {

                    return message.reply('❌ Nama panggilan (nickname) maksimal 32 karakter.');

                }

                

                // Coba ubah nickname sendiri

                await member.setNickname(newNickname);

                // Kirim konfirmasi

                await message.reply(`✅ Nama panggilan Anda berhasil diubah menjadi **${newNickname}**.`);

            } catch (error) {

                console.error(`Gagal mengubah nickname untuk ${member.user.tag}:`, error);

                

                let errorMessage = '❌ Gagal mengubah nama panggilan.';

                // Penanganan error permission

                if (error.code === 50013) {

                    errorMessage += ' Bot tidak memiliki izin "Manage Nicknames" (Kelola Nama Panggilan) di server ini.';

                } else {

                    errorMessage += ` Error: ${error.message}`;

                }

                await message.reply(errorMessage);

            }

        }

    });

}

module.exports = { setup };