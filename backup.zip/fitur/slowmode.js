const { PermissionsBitField } = require("discord.js");

module.exports = {
    setup: function(client) {
        // HANDLE MESSAGE COMMAND
        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            try {
                if (message.author.bot || !message.guild) return;

                const args = message.content.split(" ");
                const command = args[0].toLowerCase();

                if (command === "!slow") {
                    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
                    }

                    const action = args[1]?.toLowerCase();

                    if (action === "off") {
                        await message.channel.setRateLimitPerUser(0);
                        return message.reply("✅ Slowmode Berhasil Dimatikan.");
                    }

                    if (action === "on") {
                        const timeInput = args[2];
                        if (!timeInput) return message.reply("❌ Format Salah : ``!slowmode on 1s/1m/1h``");

                        const time = parseInt(timeInput);
                        const unit = timeInput.charAt(timeInput.length - 1).toLowerCase();
                        let seconds = 0;

                        if (unit === "s") seconds = time;
                        else if (unit === "m") seconds = time * 60;
                        else if (unit === "h") seconds = time * 3600;
                        else return message.reply("❌ Format waktu salah! Gunakan s, m, atau h.");

                        if (seconds > 21600) return message.reply("Maksimal slowmod adalah 6 jam (21600s).");

                        try {
                            await message.channel.setRateLimitPerUser(seconds);
                            return message.reply(`✅ Slowmod Berhasil Diaktifkan Selama ${timeInput}.`);
                        } catch (err) {
                            return message.reply("Gagal mengatur slowmod.");
                        }
                    }
                }
            } catch (err) {
                console.log("ERR slowmode messageCreate:", err);
            }
        });
    }
};