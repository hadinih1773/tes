const axios = require('axios');
const FormData = require('form-data');
const { EmbedBuilder } = require('discord.js');

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const content = message.content.trim();
    const args = content.split(/\s+/);
    const command = args[0].toLowerCase();

    // ================= !fakeff =================
    if (command === "!fakeff" || command === "!lobbyff") {
      const nama = args.slice(1).join(" ");
      if (!nama) {
        return message.reply(`❌ Format Salah : \`\`${command} nama\`\``);
      }

      const msg = await message.reply("🕕 Sedang memproses...");
      try {
        const apiUrl = `https://api.nexray.web.id/maker/fakelobyff?nickname=${encodeURIComponent(nama)}`;
        await message.channel.send({ files: [{ attachment: apiUrl, name: 'fakeff.png' }] });
        await msg.delete();
      } catch (e) {
        console.error(e);
        msg.edit("❌ Terjadi kesalahan saat mengambil data.");
      }
    }

    // ================= !fakeml =================
    if (command === "!fakeml" || command === "!lobbyml") {
      const nama = args.slice(1).join(" ");
      if (!nama) {
        return message.reply(`❌ Format Salah : \`\`${command} nama\`\``);
      }

      const msg = await message.reply("🕕 Sedang memproses avatar...");
      try {
        let avatarUrl = message.author.displayAvatarURL({ extension: 'jpg', size: 1024 });

        // Cek jika ada lampiran gambar
        if (message.attachments.size > 0) {
          avatarUrl = message.attachments.first().url;
        } else if (message.reference) {
          // Cek jika mereply pesan yang berisi gambar
          const repliedMsg = await message.channel.messages.fetch(message.reference.messageId);
          if (repliedMsg.attachments.size > 0) {
            avatarUrl = repliedMsg.attachments.first().url;
          }
        }

        // Upload ke tmpfiles untuk mendapatkan direct link yang dibutuhkan API
        const response = await axios.get(avatarUrl, { responseType: 'arraybuffer' });
        const form = new FormData();
        form.append('file', Buffer.from(response.data), { filename: 'avatar.jpg', contentType: 'image/jpeg' });

        const uploadRes = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
          headers: form.getHeaders(),
          timeout: 30000
        });

        if (uploadRes.data?.data?.url) {
          const directUrl = uploadRes.data.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
          const apiUrl = `https://api.nexray.web.id/maker/fakelobyml?avatar=${encodeURIComponent(directUrl)}&nickname=${encodeURIComponent(nama)}`;
          
          await message.channel.send({ files: [{ attachment: apiUrl, name: 'fakeml.png' }] });
          await msg.delete();
        }
      } catch (error) {
        console.error(error);
        msg.edit("❌ Gagal memproses gambar. Pastikan format benar.");
      }
    }

    // ================= !fakecall =================
    if (command.startsWith("!fakecall")) {
      // Split menggunakan pipe |
      const parts = content.split('|').map(s => s.trim());
      // parts[0] adalah !fakecall
      if (parts.length < 3) {
        return message.reply("❌ Format Salah : `!fakecall|nama|durasi`").then(m => setTimeout(() => m.delete(), 5000));
      }

      const nama = parts[1];
      const durasi = parts[2];
      const msg = await message.reply("🕕 Memproses panggilan...");

      try {
        let avatarUrl = message.author.displayAvatarURL({ extension: 'jpg', size: 1024 });

        if (message.attachments.size > 0) {
          avatarUrl = message.attachments.first().url;
        }

        const apiUrl = `https://api.zenzxz.my.id/maker/fakecall?nama=${encodeURIComponent(nama)}&durasi=${encodeURIComponent(durasi)}&avatar=${encodeURIComponent(avatarUrl)}`;
        
        await message.channel.send({ files: [{ attachment: apiUrl, name: 'fakecall.png' }] });
        await msg.delete();
      } catch (e) {
        console.error(e);
        msg.edit("❌ Terjadi kesalahan sistem.");
      }
    }
  });
}

module.exports = { setup };