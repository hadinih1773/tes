// pin.js
const { PermissionsBitField } = require("discord.js");

function setup(client) {

  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const content = message.content.trim();
    const cmd = content.split(/\s+/)[0].toLowerCase();

    // ================= !pin =================
    if (cmd !== "!pin") return;

    // cek izin admin
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      const reply = await message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      setTimeout(() => reply.delete().catch(() => {}), 5000);
      return;
    }

    // Cek apakah pesan direply
    const targetMsg = message.reference
      ? await message.channel.messages.fetch(message.reference.messageId).catch(() => null)
      : null;

    if (!targetMsg) {
      const reply = await message.reply("❌ Reply ke pesan yang mau di-pin dulu!");
      setTimeout(() => reply.delete().catch(() => {}), 5000);
      return;
    }

    try {
      if (targetMsg.pinned) {
        const reply = await message.reply("⚠️ Pesan ini sudah terpinned sebelumnya!");
        setTimeout(() => reply.delete().catch(() => {}), 5000);
        return;
      }

      await targetMsg.pin();
      const reply = await message.reply("✅ Pesan berhasil di-pin!");
      setTimeout(() => reply.delete().catch(() => {}), 5000);

    } catch (error) {
      console.error("Gagal pin pesan:", error);
      const reply = await message.reply("❌ Gagal mem-pin pesan. Cek izin bot atau status server.");
      setTimeout(() => reply.delete().catch(() => {}), 5000);
    }
  });

  // ================= !unpin =================
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;

    const content = message.content.trim();
    const cmd = content.split(/\s+/)[0].toLowerCase();

    if (cmd !== "!unpin") return;

    // cek izin admin
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      const reply = await message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      setTimeout(() => reply.delete().catch(() => {}), 5000);
      return;
    }

    // Cek apakah pesan direply
    const targetMsg = message.reference
      ? await message.channel.messages.fetch(message.reference.messageId).catch(() => null)
      : null;

    if (!targetMsg) {
      const reply = await message.reply("❌ Reply ke pesan yang mau di-unpin dulu!");
      setTimeout(() => reply.delete().catch(() => {}), 5000);
      return;
    }

    try {
      if (!targetMsg.pinned) {
        const reply = await message.reply("⚠️ Pesan ini belum di-pin!");
        setTimeout(() => reply.delete().catch(() => {}), 5000);
        return;
      }

      await targetMsg.unpin();
      const reply = await message.reply("✅ Pesan berhasil di-unpin!");
      setTimeout(() => reply.delete().catch(() => {}), 5000);

    } catch (error) {
      console.error("Gagal unpin pesan:", error);
      const reply = await message.reply("❌ Gagal unpin pesan. Cek izin bot atau status server.");
      setTimeout(() => reply.delete().catch(() => {}), 5000);
    }
  });
}

module.exports = { setup };