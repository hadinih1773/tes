const { PermissionsBitField, EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  // 1 & 3. Registrasi Slash Command agar dibaca oleh register.js
  data: [
    new SlashCommandBuilder()
      .setName("addemoji")
      .setDescription("Add Emoji To Server")
      .addStringOption(option => option.setName("nama").setDescription("Nama emoji baru").setRequired(true))
      .addAttachmentOption(option => option.setName("image").setDescription("Upload gambar emoji").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("addsticker")
      .setDescription("Add Sticker To Server")
      .addStringOption(option => option.setName("nama").setDescription("Nama stiker baru").setRequired(true))
      .addAttachmentOption(option => option.setName("image").setDescription("Upload gambar stiker").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("delemoji")
      .setDescription("Delete Emoji From Your Server")
      .addStringOption(option => option.setName("nama").setDescription("Nama emoji yang ingin dihapus").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
    new SlashCommandBuilder()
      .setName("delsticker")
      .setDescription("Delete Sticker From Server")
      .addStringOption(option => option.setName("nama").setDescription("Nama stiker yang ingin dihapus").setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON()
  ],

  setup(client) {
    // Handler untuk Slash Commands (interactionCreate) supaya tidak bentrok/error kek tadi
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      const { commandName, guild, member } = interaction;

      if (commandName === "addemoji" || commandName === "addsticker" || commandName === "delemoji" || commandName === "delsticker") {
        // 2. Proteksi admin tambahan di sisi code
        if (!member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return interaction.reply({ content: "❌ Hanya Admin yang dapat menggunakan command ini.", ephemeral: true });
        }

        const nameArg = interaction.options.getString("nama");

        if (commandName === "addemoji" || commandName === "addsticker") {
          const attachment = interaction.options.getAttachment("image");
          await interaction.deferReply();

          try {
            if (commandName === "addsticker") {
              const sticker = await guild.stickers.create({
                file: attachment.url,
                name: nameArg,
                tags: nameArg,
              });

              const successEmbed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("✅ Stiker Berhasil Ditambahkan")
                .setDescription(`Stiker **${sticker.name}** telah ditambahkan ke server.`)
                .setThumbnail(attachment.url);

              await interaction.editReply({ embeds: [successEmbed] });
            } else if (commandName === "addemoji") {
              const emoji = await guild.emojis.create({
                attachment: attachment.url,
                name: nameArg,
              });

              const successEmbed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("✅ Emoji Berhasil Ditambahkan")
                .setDescription(`Emoji **${emoji.name}** ${emoji.toString()} telah ditambahkan ke server.`)
                .setThumbnail(attachment.url);

              await interaction.editReply({ embeds: [successEmbed] });
            }
          } catch (error) {
            console.error(error);
            if (error.code === 30039) {
              return interaction.editReply("❌ Slot sudah penuh!");
            }
            await interaction.editReply(`❌ Gagal menambahkan ${commandName === "addsticker" ? "stiker" : "emoji"}. Pastikan format file sesuai dan ukuran server mencukupi.`);
          }
        } else if (commandName === "delemoji" || commandName === "delsticker") {
          await interaction.deferReply();

          try {
            if (commandName === "delsticker") {
              const sticker = guild.stickers.cache.find(s => s.name === nameArg);
              if (!sticker) return interaction.editReply("❌ Stiker tidak ditemukan!");

              await sticker.delete();
              await interaction.editReply(`✅ Stiker **${nameArg}** berhasil dihapus.`);
            } else if (commandName === "delemoji") {
              const emoji = guild.emojis.cache.find(e => e.name === nameArg);
              if (!emoji) return interaction.editReply("❌ Emoji tidak ditemukan!");

              await emoji.delete();
              await interaction.editReply(`✅ Emoji **${nameArg}** berhasil dihapus.`);
            }
          } catch (error) {
            console.error(error);
            await interaction.editReply(`❌ Gagal menghapus ${commandName === "delsticker" ? "stiker" : "emoji"}.`);
          }
        }
      }
    });

    // Handler untuk Prefix/Pesan Teks Biasa (!addsticker & !addemoji dll)
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();
      const nameArg = args.slice(1).join(" ");

      if (command === "!addsticker" || command === "!addemoji" || command === "!delsticker" || command === "!delemoji") {
        // 2. Proteksi admin pesan teks biasa
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return message.reply("❌ Hanya Admin yang dapat menggunakan command ini.");
        }

        if (command === "!addsticker" || command === "!addemoji") {
          let attachment = message.attachments.first();
          if (!attachment && message.reference) {
            const repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
            attachment = repliedMessage.attachments.first();
          }

          if (!attachment) {
            return message.reply(`❌ Kirim gambar atau reply gambar dengan command \`${command} [nama]\``);
          }

          if (!nameArg) {
            return message.reply(`❌ Berikan nama! Contoh: \`${command} Lucu\``);
          }

          const msg = await message.reply("⏳ Sedang memproses...");

          try {
            if (command === "!addsticker") {
              const sticker = await message.guild.stickers.create({
                file: attachment.url,
                name: nameArg,
                tags: nameArg,
              });

              const successEmbed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("✅ Stiker Berhasil Ditambahkan")
                .setDescription(`Stiker **${sticker.name}** telah ditambahkan ke server.`)
                .setThumbnail(attachment.url);

              await msg.edit({ content: null, embeds: [successEmbed] });
            } else if (command === "!addemoji") {
              const emoji = await message.guild.emojis.create({
                attachment: attachment.url,
                name: nameArg,
              });

              const successEmbed = new EmbedBuilder()
                .setColor("Green")
                .setTitle("✅ Emoji Berhasil Ditambahkan")
                .setDescription(`Emoji **${emoji.name}** ${emoji.toString()} telah ditambahkan ke server.`)
                .setThumbnail(attachment.url);

              await msg.edit({ content: null, embeds: [successEmbed] });
            }
          } catch (error) {
            console.error(error);
            if (error.code === 30039) {
              return msg.edit("❌ Slot sudah penuh!");
            }
            await msg.edit(`❌ Gagal menambahkan ${command === "!addsticker" ? "stiker" : "emoji"}. Pastikan format file sesuai dan ukuran server mencukupi.`);
          }
        } else if (command === "!delsticker" || command === "!delemoji") {
          if (!nameArg) {
            return message.reply(`❌ Berikan nama! Contoh: \`${command} Lucu\``);
          }

          const msg = await message.reply("⏳ Sedang memproses...");

          try {
            if (command === "!delsticker") {
              const sticker = message.guild.stickers.cache.find(s => s.name === nameArg);
              if (!sticker) return msg.edit("❌ Stiker tidak ditemukan!");

              await sticker.delete();
              await msg.edit(`✅ Stiker **${nameArg}** berhasil dihapus.`);
            } else if (command === "!delemoji") {
              const emoji = message.guild.emojis.cache.find(e => e.name === nameArg);
              if (!emoji) return msg.edit("❌ Emoji tidak ditemukan!");

              await emoji.delete();
              await msg.edit(`✅ Emoji **${nameArg}** berhasil dihapus.`);
            }
          } catch (error) {
            console.error(error);
            await msg.edit(`❌ Gagal menghapus ${command === "!delsticker" ? "stiker" : "emoji"}.`);
          }
        }
      }
    });
  },
};