const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const axios = require("axios");

/* ================= MODULE SETUP ================= */

module.exports = {
    setup(client) {
        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            if (message.author.bot) return;

            const args = message.content.split(" ");
            const command = args[0].toLowerCase();
            const url = args[1];

            if (command === "!igdl" || command === "!ig") {
                if (!url) return message.reply(`❌ Format Salah : \`${command} url\``);

                const processEmbed = new EmbedBuilder()
                    .setColor("Blue")
                    .setTitle("🎵 Instagram Downloader")
                    .setDescription(`⏳ Sedang mendownload media Instagram...`);

                const msg = await message.reply({ embeds: [processEmbed] });

                try {
                    // Mengambil data dari API Instagram Downloader baru
                    const res = await axios.get(
                        `https://api-faa.my.id/faa/igdl?url=${encodeURIComponent(url)}`,
                        { timeout: 0 }
                    );

                    if (!res.data || !res.data.status || !res.data.result || !Array.isArray(res.data.result.url)) {
                        throw new Error("Gagal mengambil link dari API.");
                    }

                    const mediaUrls = [...new Set(res.data.result.url)];
                    const isVideo = res.data.result.metadata ? res.data.result.metadata.isVideo : false;

                    const resultEmbed = new EmbedBuilder()
                        .setColor("LuminousVividPink")
                        .setTitle("🎵 Instagram Downloader")
                        .setDescription(`${message.author} Done Bro 😎!\n\n🔗 **Url Instagram**\n${url}\n📦 **Total Media**: ${mediaUrls.length}`)
                        .setFooter({ text: "Instagram Downloader" });

                    // Hapus pesan "Sedang mendownload..."
                    await msg.delete().catch(() => {});

                    // Kirim Embed informasi awal dengan mereply pesan user
                    await message.reply({ embeds: [resultEmbed] });

                    // Looping untuk mengunduh dan mengirimkan setiap foto/video satu per satu
                    for (let i = 0; i < mediaUrls.length; i++) {
                        const mediaUrl = mediaUrls[i];

                        try {
                            // Unduh data media sebagai Buffer
                            const fileRes = await axios.get(mediaUrl, { responseType: "arraybuffer" });

                            // Tentukan apakah media berupa video atau gambar berdasarkan metadata API
                            const fileName = isVideo ? `instagram_${i + 1}.mp4` : `instagram_${i + 1}.jpg`;

                            const attachment = new AttachmentBuilder(Buffer.from(fileRes.data), { name: fileName });

                            // Kirim file ke channel
                            await message.channel.send({ files: [attachment] });
                        } catch (mediaError) {
                            console.error(`Gagal mengirim media ke-${i + 1}:`, mediaError);
                            if (mediaError.code === 40005) {
                                message.channel.send(`❌ File ke-${i + 1} gagal dikirim: Ukuran file terlalu besar.`);
                            }
                        }
                    }
                } catch (err) {
                    console.error(err);
                    if (msg) await msg.delete().catch(() => {});
                    message.reply("❌ Gagal mendownload media.");
                }
            }
        });
    },
};