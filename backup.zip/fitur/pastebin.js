const axios = require("axios");

const { EmbedBuilder } = require("discord.js");

const PASTEBIN_API_KEY = "AuXzweHGDu1aH2JLjXqTw7VkoFsVWW0W";

module.exports = function (client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (msg) => {

        if (msg.author.bot) return;

        // Semua member boleh pakai

        // (tidak ada pembatasan permission)

        if (!msg.content.startsWith("!pastebin")) return;

        let teks = msg.content.slice(9).trim();

        if (!teks) return msg.reply("❌ Format Salah : `!pastebin teksnya`");

        // ========== Progress Embed ==========

        let progress = new EmbedBuilder()

            .setTitle("Pastebin Generator")

            .setDescription("Membuat pastebin...\n```\n[■■□□□□□□] 20%\n```")

            .setColor("Yellow");

        let loadingMsg = await msg.reply({ embeds: [progress] });

        // Update progress

        await new Promise(r => setTimeout(r, 400));

        progress.setDescription("Membuat pastebin...\n```\n[■■■■■□□□] 50%\n```");

        await loadingMsg.edit({ embeds: [progress] });

        await new Promise(r => setTimeout(r, 400));

        progress.setDescription("Membuat pastebin...\n```\n[■■■■■■■■] 100%\n```");

        await loadingMsg.edit({ embeds: [progress] });

        // ========== Kirim ke Pastebin ==========

        try {

            const params = new URLSearchParams();

            params.append("api_dev_key", PASTEBIN_API_KEY);

            params.append("api_option", "paste");

            params.append("api_paste_code", teks);

            params.append("api_paste_private", "1");

            params.append("api_paste_expire_date", "1D");

            params.append("api_paste_format", "text");

            const res = await axios.post("https://pastebin.com/api/api_post.php", params);

            const pasteUrl = res.data;

            // Embed hasil

            const successEmbed = new EmbedBuilder()

                .setTitle("Pastebin Berhasil Dibuat")

                .setColor("Blue")

                .setDescription(`Teks berhasil diupload!\n\n🔗 **Link Pastebin:**\n${pasteUrl}`)

                .setFooter({ text: "Pastebin Generator" });

            await loadingMsg.edit({ embeds: [successEmbed] });

        } catch (err) {

            msg.reply("Gagal membuat pastebin!");

        }

    });

};