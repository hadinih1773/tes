const fs = require("fs");

const { PermissionsBitField, EmbedBuilder } = require("discord.js");

const stickyFile = "./database/sticky.json";

let stickyData = {};

let stickyQueue = {}; // track proses sticky per channel

if (fs.existsSync(stickyFile)) {

  stickyData = JSON.parse(fs.readFileSync(stickyFile, "utf8"));

}

function saveSticky() {

  fs.writeFileSync(stickyFile, JSON.stringify(stickyData, null, 2));

}

function setup(client) {

  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

    if (message.author.bot) return;

    // ===== AUTO UPDATE STICKY BOT STYLE =====

    const channelId = message.channel.id;

    if (stickyData[channelId] && stickyData[channelId].length > 0) {

      if (stickyQueue[channelId]) return;

      stickyQueue[channelId] = true;

      const channelStickies = stickyData[channelId];

      // hapus semua sticky lama

      for (let i = 0; i < channelStickies.length; i++) {

        const s = channelStickies[i];

        if (s.lastMsgId) {

          const oldMsg = await message.channel.messages.fetch(s.lastMsgId).catch(() => null);

          if (oldMsg) await oldMsg.delete().catch(() => null);

        }

      }

      // kirim ulang sticky sesuai urutan

      for (let i = 0; i < channelStickies.length; i++) {

        const s = channelStickies[i];

        let newMsg;

        if (s.type === "embed") {

          const embed = new EmbedBuilder()

            .setDescription(s.content)

            .setColor(0x000000);

          newMsg = await message.channel.send({ embeds: [embed] });

        } else {

          newMsg = await message.channel.send(s.content);

        }

        s.lastMsgId = newMsg.id;

      }

      saveSticky();

      stickyQueue[channelId] = false;

    }

    // ===== COMMAND STICKY =====

    if (!message.content.startsWith("!")) return;

    const content = message.content;

    const command = content.split(" ")[0].toLowerCase();

    // ==== HANYA ADMIN YANG BISA ====

    const adminCommands = ["!sticky", "!stickyembed", "!unsticky"];

    if (adminCommands.includes(command)) {

      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

      }

    }

    // --- !sticky / !stickyembed ---

    if (command === "!sticky" || command === "!stickyembed") {

      const text = content.slice(command.length).trim();

      if (!text) return message.reply("❌ Format Salah : `" + command + " <teks>`");

      if (!stickyData[channelId]) stickyData[channelId] = [];

      if (stickyData[channelId].some(s => s.content === text && s.type === (command === "!stickyembed" ? "embed" : "normal"))) {

        return message.reply("Sticky ini sudah ada sebelumnya!");

      }

      let newMsg;

      if (command === "!stickyembed") {

        const embed = new EmbedBuilder()

          .setDescription(text)

          .setColor(0x000000);

        newMsg = await message.channel.send({ embeds: [embed] });

      } else {

        newMsg = await message.channel.send(text);

      }

      stickyData[channelId].push({

        content: text,

        lastMsgId: newMsg.id,

        type: command === "!stickyembed" ? "embed" : "normal",

      });

      saveSticky();

      return message.reply(`Sticky baru ditambahkan! Total sticky di channel ini: ${stickyData[channelId].length}`);

    }

    // --- !unsticky ---

    if (command === "!unsticky") {

      if (!stickyData[channelId] || stickyData[channelId].length === 0)

        return message.reply("❌ Tidak ada sticky di channel ini.");

      const channelStickies = stickyData[channelId];

      for (const s of channelStickies) {

        if (s.lastMsgId) {

          const oldMsg = await message.channel.messages.fetch(s.lastMsgId).catch(() => null);

          if (oldMsg) await oldMsg.delete().catch(() => null);

        }

      }

      delete stickyData[channelId];

      saveSticky();

      return message.reply("✅ Semua sticky di channel ini berhasil dihapus!");

    }

  });

}

module.exports = { setup };