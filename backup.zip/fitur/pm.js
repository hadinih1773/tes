// pm.js

const { PermissionsBitField } = require("discord.js");

// Ganti ini dengan ID user yang boleh pakai command
const allowedUsers = ["1341007595288268880"];

// Buat penyimpan sementara antara pengirim dan penerima
const pmSessions = new Map(); // key: targetId, value: pengirimId

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith("!pm")) return;

    // Cek izin user
    if (!allowedUsers.includes(message.author.id)) {
      return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
    }

    // Format baru: !pm @user pesan
    const args = message.content.trim().split(/ +/);
    if (args.length < 3) {
      return message.reply("❌ Format salah : `!pm @user pesan`");
    }

    const targetStr = args[1];
    const msgContent = args.slice(2).join(" ");
    let targetUser;

    // Mention
    if (message.mentions.users.size > 0) {
      targetUser = message.mentions.users.first();
    } else {
      // User ID
      try {
        targetUser = await client.users.fetch(targetStr, { force: true });
      } catch {
        return message.reply("❌ User tidak ditemukan!");
      }
    }

    if (!targetUser) return message.reply("❌ User tidak ditemukan!");

    // Kirim DM
    try {
      const dmChannel = await targetUser.createDM();
      await dmChannel.send(msgContent);
      pmSessions.set(targetUser.id, message.author.id);
      return message.reply(`✅ Pesan berhasil dikirim ke **${targetUser.tag}**`);
    } catch (error) {
      console.error("Gagal mengirim DM:", error);
      if (error.code === 50007) {
        return message.reply("❌ Gagal mengirim DM. User ini menonaktifkan pesan langsung.");
      }
      return message.reply("❌ Terjadi error saat mengirim DM. Cek log console untuk info lebih lanjut.");
    }
  });

  // Balasan DM user → diteruskan ke admin
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (message.guild) return;
    if (message.author.bot) return;

    const senderId = message.author.id;
    if (!pmSessions.has(senderId)) return;

    const originalSenderId = pmSessions.get(senderId);
    try {
      const originalUser = await client.users.fetch(originalSenderId, { force: true });
      await originalUser.send({
        content: `💬 **Balasan dari ${message.author.tag}:**\n${message.content}`
      });
      await message.channel.send({
        content: `📨 Pesan kamu sudah diteruskan ke ${originalUser.tag}.`
      });
    } catch (err) {
      console.error("Gagal meneruskan balasan:", err);
    }
  });
}

module.exports = { setup };