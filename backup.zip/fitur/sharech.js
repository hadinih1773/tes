const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "..", "database", "sharech.json");

function loadData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return [];
  }
}

function saveData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database sharech.json:", err);
  }
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // --- CONFIG COMMAND: !sharech ---
      if (command === "!sharechannel" || command === "!sharech") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then(msg => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const channel = message.mentions.channels.first();
        if (!channel) return message.reply(`❌ Format Salah : \`\`${command} #channel\`\``);

        let allowedChannels = loadData();
        if (!allowedChannels.includes(channel.id)) {
          allowedChannels.push(channel.id);
          saveData(allowedChannels);
          return message.reply(`✅ Channel ${channel} berhasil ditambahkan ke daftar izin share link.`);
        } else {
          return message.reply(`ℹ️ Channel ${channel} sudah terdaftar sebelumnya.`);
        }
      }

      // --- CONFIG COMMAND: !delsharech ---
      if (command === "!delsharech") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then(msg => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const channel = message.mentions.channels.first();
        if (!channel) return message.reply("❌ Format salah. Contoh: `!delsharech #channel`");

        let allowedChannels = loadData();
        if (allowedChannels.includes(channel.id)) {
          allowedChannels = allowedChannels.filter(id => id !== channel.id);
          saveData(allowedChannels);
          return message.reply(`✅ Channel ${channel} berhasil dihapus dari daftar izin share link.`);
        } else {
          return message.reply(`❌ Channel ${channel} tidak ditemukan dalam daftar.`);
        }
      }

      // --- PROTECTION SYSTEM FILTER ---
      const allowedChannels = loadData();

      // Jika pesan dikirim di channel yang diizinkan ATAU pengirim adalah Admin, bot tidak merespons
      if (allowedChannels.includes(message.channel.id) || message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return;
      }

      // Regex untuk mendeteksi invite Discord dan WhatsApp (Grup & Channel)
      const inviteRegex = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discord(app)?\.com\/invite|chat\.whatsapp\.com\/[A-Za-z0-9_-]+|whatsapp\.com\/channel\/[A-Za-z0-9_-]+)/gi;

      if (inviteRegex.test(message.content)) {
        const matches = message.content.match(inviteRegex);
        const detectedUrl = matches ? matches[0] : "Url Tidak Diketahui";

        // Ambil list mention channel yang diizinkan untuk ditaruh di isi embed
        const allowedChannelsMentions = allowedChannels.length > 0 
          ? allowedChannels.map(id => `<#${id}>`).join(", ") 
          : "Belum ada channel yang diizinkan";

        // Hapus pesan pelanggar secara instan
        await message.delete().catch(() => null);

        // Eksekusi Timeout / Temp-Mute member selama 30 Menit (30 * 60 * 1000 milidetik)
        await message.member.timeout(30 * 60 * 1000, "Mengirim link invite di channel terlarang").catch(() => null);

        // Membikin struktur embed info random color
        const warnEmbed = new EmbedBuilder()
          .setColor(Math.floor(Math.random() * 16777215))
          .setTitle("🔗 Url Invite Terdeteksi")
          .setDescription(`<@${message.author.id}> Kamu Telah Mengirimkan Link Invite Ke Channel Yang Tidak Diizinkan, Kamu Akan Di Timeout Selama 30 Menit\n\n**Url Yang Terdeteksi :**\n${detectedUrl}\n\n**Channel Yang Diizinkan :**\n${allowedChannelsMentions}`)
          .setTimestamp();

        // Mengirim embed lalu otomatis menghapusnya setelah 10 detik
        const alertMsg = await message.channel.send({ embeds: [warnEmbed] });
        setTimeout(() => {
          alertMsg.delete().catch(() => null);
        }, 10000);
      }
    });
  }
};