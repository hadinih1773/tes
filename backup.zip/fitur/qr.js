// =====================
// qr.js
// Fitur: Membuat QR code dari teks, link, atau gambar/pesan yang di-reply.
// Command: !toqr [teks/link] atau !toqr (dengan reply/attachment)
// =====================

const { Client, AttachmentBuilder } = require('discord.js');
const QRCode = require('qrcode'); // Import library qrcode

// GANTI DENGAN PREFIX BOT ANDA
const PREFIX = '!';

/**
 * Mendapatkan konten (teks atau URL gambar) dari pesan, attachment, atau pesan yang di-reply.
 * @param {Message} message Objek pesan Discord.
 * @returns {{content: string|null, isImage: boolean}} Konten yang akan di-encode dan flag apakah itu gambar.
 */
async function getMessageContent(message) {
    let content = message.content.slice(PREFIX.length).trim().split(/ +/).slice(1).join(' ');
    let isImage = false;

    // 1. Cek Teks Langsung
    if (content) {
        return { content, isImage: false };
    }

    // 2. Cek Attachment pada pesan saat ini
    const attachment = message.attachments.first();

    // *** TAMBAHAN: dukung file apa pun ***
    if (attachment) {
        if (attachment.contentType?.startsWith('image')) {
            return { content: attachment.url, isImage: true };
        } else {
            return { content: attachment.url, isImage: false };
        }
    }

    // 3. Cek Reply (Jika user reply pesan lain)
    let repliedMessage;

    if (message.reference && message.reference.messageId) {
        try {
            repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
        } catch (e) {
            console.error("Failed to fetch replied message:", e);
        }
    }

    if (repliedMessage) {
        // Cek attachment di pesan yang direply
        const replyAttachment = repliedMessage.attachments.first();

        // *** TAMBAHAN: dukung file di reply ***
        if (replyAttachment) {
            if (replyAttachment.contentType?.startsWith('image')) {
                return { content: replyAttachment.url, isImage: true };
            } else {
                return { content: replyAttachment.url, isImage: false };
            }
        }

        // Cek Teks di pesan yang di-reply
        if (repliedMessage.content) {
            return { content: repliedMessage.content, isImage: false };
        }
    }

    return { content: null, isImage: false };
}


/**
 * Menyiapkan listener untuk command !toqr.
 * @param {Client} client Discord Client instance.
 */
function setupQRCommand(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
        if (message.author.bot || !message.content.startsWith(PREFIX)) return;

        const args = message.content.slice(PREFIX.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();

        if (command === 'teks2qr') {
            await message.channel.sendTyping();

            const { content: textToEncode, isImage } = await getMessageContent(message);

            if (!textToEncode) {
                return message.reply(`Format penggunaan salah, Bwang.\n\nCara pakai:\n1. \`${PREFIX}teks2qr [teks atau link]\`\n2. \`${PREFIX}teks2qr\` **(dan kirim gambar bersamaan)**\n3. \`${PREFIX}teks2qr\` **(dan reply pesan berisi teks/gambar/file)**`);
            }

            if (textToEncode.length > 500) {
                return message.reply("Teks atau URL terlalu panjang, Bwang. Maksimal 500 karakter untuk QR code yang stabil.");
            }

            try {
                const qrBuffer = await QRCode.toBuffer(textToEncode, {
                    type: 'png',
                    errorCorrectionLevel: 'H',
                    scale: 8
                });

                const qrAttachment = new AttachmentBuilder(qrBuffer, { name: 'qrcode.png' });

                const contentType = isImage ? `URL Gambar` : `Teks / File`;
                const displayData = textToEncode.length > 50 ? `${textToEncode.substring(0, 50)}...` : textToEncode;

                message.reply({
                    // FIX emoji → sudah benar
                    content: `✅ QR code siap, Bwang!\nKonten (${contentType}): \`${displayData}\``,
                    files: [qrAttachment]
                });

            } catch (e) {
                console.error("QR Code Error:", e);
                message.reply("❌ Gagal membuat QR code. Ada masalah dengan data atau library.");
            }
        }

    });
}

module.exports = setupQRCommand;