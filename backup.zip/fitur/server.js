const fs = require("fs");
const path = require("path");

function setup(client) {
  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
    if (!message.guild) return;
    if (message.author.bot) return;

    // Pisahkan command dan argumennya
    const args = message.content.trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // ===============================
    // COMMAND: !servername nama baru
    // ===============================
    if (command === "!servername" || command === "!setnamedc") {
      if (!message.member.permissions.has("Administrator")) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      const newName = message.content
      .replace("!servername", "")
      .replace("!setnamedc", "")
      .trim();

      if (!newName) {
        return message.reply(`❌ Format Salah : \`\`${command} nama server\`\``);
      }

      try {
        await message.guild.setName(newName);
        message.reply(`✅ Nama server berhasil diubah menjadi **${newName}**`);
      } catch (err) {
        message.reply("❌ Gagal mengubah nama server.");
      }
    }

    // ====================================
    // COMMAND: !serverdeskripsi deskripsi
    // ====================================
    if (command === "!serverdeskripsi") {
      if (!message.member.permissions.has("Administrator")) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      const newDesc = message.content.replace("!serverdeskripsi", "").trim();

      if (!newDesc) {
        return message.reply("❌ Format Salah : ``!serverdeskripsi deskripsi``");
      }

      try {
        await message.guild.edit({ description: newDesc });
        message.reply("✅ Deskripsi server berhasil diubah!");
      } catch (err) {
        message.reply("❌ Gagal mengubah deskripsi server.");
      }
    }

    // ================================
    // COMMAND: !servericon
    // (TIDAK DIUBAH)
    // ================================
    if (command === "!servericon" || command === "!setppdc") {
      if (!message.member.permissions.has("Administrator")) {
        return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
      }

      let imageURL = null;

      if (message.reference) {
        const replied = await message.channel.messages
          .fetch(message.reference.messageId)
          .catch(() => null);

        if (replied && replied.attachments && replied.attachments.size > 0) {
          imageURL = replied.attachments.first().url;
        }
      }

      if (message.attachments && message.attachments.size > 0) {
        imageURL = message.attachments.first().url;
      }

      if (!imageURL) {
        return message.reply("⚠️ Kirim gambar atau reply gambar untuk dijadikan icon server.");
      }

      try {
        await message.guild.setIcon(imageURL);
        message.reply("✅ Icon server berhasil diubah!");
      } catch (err) {
        message.reply("❌ Gagal mengubah icon server.");
      }
    }
  });
}

module.exports = { setup };