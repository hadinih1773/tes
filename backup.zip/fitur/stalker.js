const axios = require('axios');

const { EmbedBuilder } = require('discord.js');

module.exports = {

    setup: (client) => {

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            const prefix = '!';

            if (!message.content.startsWith(prefix) || message.author.bot) return;

            const args = message.content.slice(prefix.length).trim().split(/ +/);

            const command = args.shift().toLowerCase();

            // Embed Proses Biru

            const procEmbed = new EmbedBuilder()

                .setTitle('🔄 Sedang Di Proses')

                .setDescription('⏳ Harap Menunggu..')

                .setColor('#3498db');

            // Fitur FF Stalk

            if (command === 'ffstalk') {

                const userId = args[0];

                if (!userId) return message.reply('**Format Salah!**\nGunakan: ``!ffstalk user id``');

                const statusMsg = await message.reply({ embeds: [procEmbed] });

                try {

                    const response = await axios.get(`https://www.ikyiizyy.my.id/stalk/ff?apikey=new&id=${userId}`);

                    const res = response.data;

                    if (res.status !== true) throw new Error();

                    const resultEmbed = new EmbedBuilder()

                        .setTitle('🎮 Free Fire Stalker')

                        .setColor('#2ecc71')

                        .setThumbnail(res.result.img_url)

                        .setDescription(`👤 **Nickname :** ${res.result.nickname}\n\n🏴 **Region :** ${res.result.region}\n\n🔎 **ID Game :** ${userId}`);

                    await statusMsg.edit({ embeds: [resultEmbed] });

                } catch (error) {

                    await statusMsg.edit({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('ID tidak ditemukan')] });

                }

            }

            // Fitur TikTok Stalk

            if (command === 'ttstalk') {

                const username = args[0];

                if (!username) return message.reply('**Format Salah!**\nGunakan: ``!ttstalk username``');

                const statusMsg = await message.reply({ embeds: [procEmbed] });

                try {

                    const response = await axios.get(`https://www.ikyiizyy.my.id/stalk/tiktok?apikey=new&user=${username}`);

                    const res = response.data;

                    if (res.status !== true) throw new Error();

                    const resultEmbed = new EmbedBuilder()

                        .setTitle('📼 Tiktok Stalker')

                        .setColor('#2ecc71')

                        .setThumbnail(res.result.avatarLarger)

                        .setDescription(`👤 **Nickname :** ${res.result.nickname}\n\n🔎 **User ID :** ${res.result.uniqueId}\n\n👁 **Followers :** ${res.result.followerCount}\n\n👀 **Following :** ${res.result.followingCount}\n\n❤ **Likes :** ${res.result.heart}`);

                    await statusMsg.edit({ embeds: [resultEmbed] });

                } catch (error) {

                    await statusMsg.edit({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('Username tidak ditemukan')] });

                }

            }

            // Fitur Instagram Stalk

            if (command === 'igstalk') {

                const username = args[0];

                if (!username) return message.reply('**Format Salah!**\nGunakan: ``!igstalk username``');

                const statusMsg = await message.reply({ embeds: [procEmbed] });

                try {

                    const response = await axios.get(`https://api.ryzumi.vip/api/stalk/instagram?username=${username}`);

                    const res = response.data;

                    const resultEmbed = new EmbedBuilder()

                        .setTitle('🎥 Instagram Stalker')

                        .setColor('#2ecc71')

                        .setThumbnail(res.avatar)

                        .setDescription(`👤 **Name :** ${res.name || '-'}\n\n👥 **Username :** ${res.username || username}\n\n📝 **Posts :** ${res.posts || '0'}\n\n👥 **Followers :** ${res.followers || '0'}\n\n👣 **Following :** ${res.following || '0'}\n\n📜 **Bio :** ${res.bio || '-'}`);

                    await statusMsg.edit({ embeds: [resultEmbed] });

                } catch (error) {

                    await statusMsg.edit({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('Username tidak ditemukan')] });

                }

            }

            // Fitur Twitter Stalk

            if (command === 'twstalk') {

                const username = args[0];

                if (!username) return message.reply('**Format Salah!**\nGunakan: ``!twstalk username``');

                const statusMsg = await message.reply({ embeds: [procEmbed] });

                try {

                    const response = await axios.get(`https://api.ryzumi.vip/api/stalk/twitter?username=${username}`);

                    const res = response.data.user;

                    const resultEmbed = new EmbedBuilder()

                        .setTitle('✖️ Twitter Stalker')

                        .setColor('#2ecc71')

                        .setThumbnail(res.avatar_url)

                        .setImage(res.banner_url)

                        .setDescription(`👤 Nama : ${res.name}\n\n👥 Username : ${res.screen_name}\n\n🆔 User ID : ${res.id}\n\n📜 Bio : ${res.description || '-'}\n\n📍Location : ${res.location || '-'}\n\n🛅 Joined : ${res.joined_at}\n\n👁 Followers : ${res.followers}\n\n👀 Following : ${res.following}\n\n❤ Likes : ${res.likes}\n\n🔗 Website : ${res.website.url || '-'}`);

                    await statusMsg.edit({ embeds: [resultEmbed] });

                } catch (error) {

                    await statusMsg.edit({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('Username tidak ditemukan')] });

                }

            }

            // Fitur Mobile Legends Stalk

            if (command === 'mlstalk') {

                const userId = args[0];

                const zoneId = args[1] || '';

                if (!userId) return message.reply('**Format Salah!**\nGunakan: ``!mlstalk userId zoneId``');

                

                const statusMsg = await message.reply({ embeds: [procEmbed] });

                try {

                    const response = await axios.get(`https://api.ryzumi.vip/api/stalk/mobile-legends?userId=${userId}&zoneId=${zoneId}`);

                    const res = response.data;

                    

                    if (res.success !== true) throw new Error();

                    const resultEmbed = new EmbedBuilder()

                        .setTitle('🏟 Mobile Legends Stalker')

                        .setColor('#2ecc71')

                        .setDescription(`👤 Username : ${res.username}\n\n🏴 Region : ${res.region || '-'}`);

                    await statusMsg.edit({ embeds: [resultEmbed] });

                } catch (error) {

                    await statusMsg.edit({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('User ID / Zone ID tidak ditemukan')] });

                }

            }

            // Fitur GitHub Stalk

            if (command === 'gitstalk') {

                const username = args[0];

                if (!username) return message.reply('**Format Salah!**\nGunakan: ``!gitstalk username``');

                

                const statusMsg = await message.reply({ embeds: [procEmbed] });

                try {

                    const response = await axios.get(`https://api.ryzumi.vip/api/stalk/github?username=${username}`);

                    const res = response.data;

                    const resultEmbed = new EmbedBuilder()

                        .setTitle('📡 GitHub Stalker')

                        .setColor('#2ecc71')

                        .setThumbnail(res.avatar_url)

                        .setDescription(`👤 Nama : ${res.name || '-'}\n\n👥 Username : ${res.login}\n\n🆔 ID GitHub : ${res.id}\n\n📜 Bio : ${res.bio || '-'}\n\n📍 Location : ${res.location || '-'}\n\n🔄 Repository Publik : ${res.public_repos}\n\n👁 Followers : ${res.followers}\n\n👀 Following : ${res.following}\n\n🔗 Website : ${res.blog || '-'}`);

                    await statusMsg.edit({ embeds: [resultEmbed] });

                } catch (error) {

                    await statusMsg.edit({ embeds: [new EmbedBuilder().setColor('#ff0000').setDescription('Username tidak ditemukan')] });

                }

            }

        });

    }

};