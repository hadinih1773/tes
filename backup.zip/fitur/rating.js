const { 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 

  TextInputBuilder, 
  TextInputStyle, 

  PermissionsBitField 
} = require("discord.js");

const cooldowns = new Map();

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      // ================= COMMAND !rating =================
      if (message.content.startsWith("!rating")) {
        const parts = message.content.split("|");

        if (parts.length < 4) {
          return message.reply("❌ Format Salah : ``!rating|@user/id|jumlah rating|ulasan``");
        }

        const targetInput = parts[1].trim();
        const jumlahRating = parts[2].trim();
        const ulasan = parts.slice(3).join("|").trim();

        // Ambil ID target dari mention (@user) atau ID langsung
        const targetId = targetInput.replace(/[<@!>]/g, "");
        const targetMember = await message.guild.members.fetch(targetId).catch(() => null);

        if (!targetMember) {
          return message.reply("❌ User tidak ditemukan.");
        }

        // Cek apakah target memiliki izin Administrator
        if (!targetMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return message.reply(`❌ <@${targetMember.id}> Tidak Memiliki Izin Administrator. Hanya Admin Yang Bisa Di Rating`);
        }

        // Hapus pesan command secara otomatis
        await message.delete().catch(() => {});

        // Buat embed rating berwarna kuning cerah
        const embed = new EmbedBuilder()
          .setTitle(`✨ ${message.guild.name} | Rating Administrator`)
          .setColor("#FFFF00")
          .setThumbnail(targetMember.user.displayAvatarURL({ dynamic: true }))
          .setDescription(`👤 User : <@${message.author.id}>\n\n✨ Rating : ${jumlahRating}\n\n📚 Ulasan : ${ulasan}`)
          .setFooter({
            text: `By ${message.author.username}`,
            iconURL: message.author.displayAvatarURL({ dynamic: true })
          })
          .setTimestamp();

        return message.channel.send({
          content: `<@${targetMember.id}> Kamu Telah Di Rating Oleh <@${message.author.id}>. Berikut Isi Detainya`,
          embeds: [embed]
        });
      }

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // ================= COMMAND !setchannelrating =================
      if (command === "!setchannelrating") {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        const targetChannel = message.mentions.channels.first();
        if (!targetChannel) return message.reply("❌ Format Salah : ``!setchannelrating #channel``");

        const embed = new EmbedBuilder()
          .setTitle("✨ Rating Menu")
          .setDescription("👤 Nama : @usertag\n\n🌟 Rating :\n\n📋 Ulasan :")
          .setColor("#3498db");

        const row = new ActionRowBuilder().addComponents(

          new ButtonBuilder()
            .setCustomId("open_rating_modal")
            .setLabel("Rating Semua")
            .setStyle(ButtonStyle.Primary)
        );

        await targetChannel.send({ embeds: [embed], components: [row] });
        return message.reply(`✅ Berhasil mengirim menu rating ke ${targetChannel}`);
      }

      // ================= COMMAND !delchannelrating =================
      if (command === "!delchannelrating") {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        // Logic database dihapus sesuai perintah
        return message.reply("✅ Berhasil menghapus semua data rating di channel ini.");
      }
    });

    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      // HANDLE BUTTON
      if (interaction.isButton()) {
        if (interaction.customId === "open_rating_modal") {
          // Cooldown Check
          const now = Date.now();
          if (cooldowns.has(interaction.user.id)) {
            const expirationTime = cooldowns.get(interaction.user.id) + 5000;
            if (now < expirationTime) {
              return interaction.reply({ 
                content: "❌ Tunggu Beberapa Saat Lagi", 
                ephemeral: true 
              });
            }
          }

          cooldowns.set(interaction.user.id, now);

          const modal = new ModalBuilder()
            .setCustomId("rating_modal")
            .setTitle("Rating");

          const ratingInput = new TextInputBuilder()
            .setCustomId("rating_value")
            .setLabel("Rating")
            .setPlaceholder("Disini")
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

          const ulasanInput = new TextInputBuilder()
            .setCustomId("ulasan_value")
            .setLabel("Ulasan")
            .setPlaceholder("Disini")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(ratingInput),
            new ActionRowBuilder().addComponents(ulasanInput)
          );

          await interaction.showModal(modal);
        }
      }

      // HANDLE MODAL SUBMIT
      if (interaction.isModalSubmit()) {
        if (interaction.customId === "rating_modal") {
          const rating = interaction.fields.getTextInputValue("rating_value");
          const ulasan = interaction.fields.getTextInputValue("ulasan_value");

          const resultEmbed = new EmbedBuilder()
            .setTitle("✨ Rating Menu")
            .setColor("#3498db")
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setDescription(`👤 Nama : <@${interaction.user.id}>\n\n🌟 Rating : ${rating}\n\n📋 Ulasan : ${ulasan}`);

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("open_rating_modal")
              .setLabel("Rating Semua")
              .setStyle(ButtonStyle.Primary)
          );

          // Kirim embed hasil rating langsung tanpa simpan ke database
          await interaction.channel.send({
            embeds: [resultEmbed],
            components: [row]
          });

          // Respon ephemeral agar interaksi selesai
          await interaction.reply({ content: "✅ Rating berhasil dikirim!", ephemeral: true });
        }
      }
    });
  },
};