const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

const axios = require('axios');

module.exports = {

    setup: (client) => {

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (!message.content.startsWith('!text2img') || message.author.bot) return;

            const args = message.content.slice('!text2img'.length).trim().split(/ +/);

            const prompt = args.join(' ');

            if (!prompt) return;

            const processEmbed = new EmbedBuilder()

                .setColor(0x0099FF)

                .setTitle('🔄 Generate Image Proses')

                .setDescription('⏳ Sedang Diproses, Mohon Ditunggu');

            const statusMsg = await message.channel.send({ embeds: [processEmbed] });

            try {

                const apiUrl = `https://api-faa.my.id/faa/ai-text2img-pro?prompt=${encodeURIComponent(prompt)}`;

                

                const response = await axios.get(apiUrl, { 

                    timeout: 0,

                    responseType: 'arraybuffer' 

                });

                

                const attachment = new AttachmentBuilder(response.data, { name: 'generated-image.png' });

                const successEmbed = new EmbedBuilder()

                    .setColor(0x00FF00)

                    .setTitle('🖼 Generate Image Succes')

                    .setDescription(`<@${message.author.id}> Gambar Berhasil Di Generate Sesuai Prompt`)

                    .setImage('attachment://generated-image.png');

                await statusMsg.edit({ embeds: [successEmbed], files: [attachment] });

            } catch (error) {

                console.error(error);

            }

        });

    }

};