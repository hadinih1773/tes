const axios = require("axios");

const fs = require("fs");

const path = require("path");

const https = require("https");

const { 

    EmbedBuilder, 

    PermissionFlagsBits, 

    ActionRowBuilder, 

    ButtonBuilder, 

    ButtonStyle 

} = require("discord.js");

const dbPath = path.resolve(__dirname, "../database/listserver.json");

if (!fs.existsSync(dbPath)) {

    fs.writeFileSync(dbPath, JSON.stringify({ channels: [] }));

}

const agent = new https.Agent({

    rejectUnauthorized: false,

    keepAlive: true

});

async function fetchServers() {

    try {

        const res = await axios.get("https://sa-mp.co.id/api/server.php", {

            params: { _: Date.now() },

            headers: {

                "Accept": "application/json, text/javascript, */*; q=0.01",

                "X-Requested-With": "XMLHttpRequest",

                "Referer": "https://sa-mp.co.id/",

                "Cache-Control": "no-cache, no-store, must-revalidate",

                "Pragma": "no-cache",

                "Expires": "0",

                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

            },

            httpsAgent: agent,

            timeout: 30000

        });

        

        // Pastikan data yang dikembalikan adalah array

        if (Array.isArray(res.data)) {

            return res.data.slice(0, 30);

        } else if (res.data && typeof res.data === 'object' && Array.isArray(res.data.servers)) {

             return res.data.servers.slice(0, 30);

        }

        return null;

    } catch (err) {

        console.error("Fetch error:", err.message);

        return null;

    }

}

function createEmbeds(servers) {

    // Validasi tambahan untuk mencegah crash forEach

    if (!Array.isArray(servers)) return [];

    const embed1 = new EmbedBuilder()

        .setColor("Green")

        .setTitle("🖥 List Server GTA SA-MP Indonesia 🇮🇩")

        .setTimestamp();

    const embed2 = new EmbedBuilder()

        .setColor("Green")

        .setTitle("🖥 List Server GTA SA-MP Indonesia 🇮🇩")

        .setTimestamp()

        .setFooter({ text: "Auto-update setiap 1 menit" });

    servers.forEach((s, i) => {

        let weburl = s.weburl ? s.weburl.trim() : "";

        let webLink = "-";

        if (weburl && weburl !== "-" && weburl !== "none") {

            webLink = `[Click In Here](${weburl.startsWith("http") ? weburl : "http://" + weburl})`;

        }

        const value =

            `🚨 Status: \`${s.online ? "Online" : "Offline"}\`\n` +

            `📡 IP: \`${s.ipAddress}:${s.port}\`\n` +

            `👤 Player: \`${s.onlinePlayers}/${s.maxplayers}\`\n` +

            `🎮 Gamemode: \`${s.gamemode}\`\n` +

            `🔗 Link: ${webLink}`;

        if (i < 15) {

            embed1.addFields({ name: `**${i + 1}. ${s.hostname}**`, value });

        } else {

            embed2.addFields({ name: `**${i + 1}. ${s.hostname}**`, value });

        }

    });

    return servers.length > 15 ? [embed1, embed2] : [embed1];

}

const refreshButton = new ActionRowBuilder().addComponents(

    new ButtonBuilder()

        .setCustomId("refresh_servers")

        .setLabel("Refresh Server")

        .setStyle(ButtonStyle.Success)

);

module.exports = {

    setup(client) {

        /* ===== AUTO UPDATE (MULTI-CHANNEL) ===== */

        setInterval(async () => {

            try {

                const data = JSON.parse(fs.readFileSync(dbPath));

                if (!data.channels || data.channels.length === 0) return;

                const servers = await fetchServers();

                if (!servers || !Array.isArray(servers)) return;

                const embeds = createEmbeds(servers);

                for (const channelId of data.channels) {

                    const channel = client.channels.cache.get(channelId);

                    if (!channel) continue;

                    try {

                        const messages = await channel.messages.fetch({ limit: 10 });

                        const botMsg = messages.find(m => m.author.id === client.user.id && m.components.length > 0);

                        if (botMsg) {

                            await botMsg.edit({ embeds: embeds, components: [refreshButton] }).catch(() => {});

                        } else {

                            await channel.send({ embeds: embeds, components: [refreshButton] });

                        }

                    } catch (e) {

                        console.error(`Error updating channel ${channelId}:`, e.message);

                    }

                }

            } catch (err) {

                console.error("Auto update interval error:", err.message);

            }

        }, 60000);

        /* ===== BUTTON REFRESH ===== */

        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {

            if (!interaction.isButton()) return;

            if (interaction.customId !== "refresh_servers") return;

            await interaction.deferReply({ ephemeral: true });

            const servers = await fetchServers();

            if (!servers || !Array.isArray(servers)) {

                return interaction.editReply({ content: "❌ Gagal mengambil data terbaru dari server." });

            }

            const embeds = createEmbeds(servers);

            await interaction.message.edit({

                embeds: embeds,

                components: [refreshButton]

            }).catch(() => {});

            await interaction.editReply({ content: "🔄 Leaderboard Server Sudah Di Refresh" });

        });

        /* ===== COMMAND SET & DELETE CHANNEL ===== */

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot) return;

            // Command !listserver (Semua member bisa gunakan, tanpa button)
            if (message.content === "!listserver") {
                const servers = await fetchServers();
                if (!servers || !Array.isArray(servers)) return message.reply("❌ Gagal mengambil data server.");
                const embeds = createEmbeds(servers);
                return message.channel.send({ embeds: embeds });
            }

            // Command !infoserver
            if (message.content.startsWith("!infoserver")) {

                if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {

                    return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

                }

                const channelMention = message.mentions.channels.first();

                if (!channelMention) {

                    return message.reply("❌ Format salah! Gunakan: `!infoserver #channel`.");

                }

                let data = JSON.parse(fs.readFileSync(dbPath));

                if (!data.channels.includes(channelMention.id)) {

                    data.channels.push(channelMention.id);

                    fs.writeFileSync(dbPath, JSON.stringify(data));

                }

                message.reply(`✅ Berhasil set channel monitoring ke ${channelMention}.`);

                const servers = await fetchServers();

                if (!servers || !Array.isArray(servers)) return;

                const embeds = createEmbeds(servers);

                await channelMention.send({

                    embeds: embeds,

                    components: [refreshButton]

                });

            }

            // Command !dinfoserver

            if (message.content.startsWith("!dinfoserver")) {

                if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {

                    return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

                }

                const channelMention = message.mentions.channels.first();

                if (!channelMention) {

                    return message.reply("❌ Format salah! Gunakan: `!dinfoserver #channel`.");

                }

                let data = JSON.parse(fs.readFileSync(dbPath));

                if (data.channels.includes(channelMention.id)) {

                    data.channels = data.channels.filter(id => id !== channelMention.id);

                    fs.writeFileSync(dbPath, JSON.stringify(data));

                    message.reply(`✅ Berhasil menghapus channel ${channelMention} dari monitoring.`);

                } else {

                    message.reply(`❌ Channel ${channelMention} tidak terdaftar dalam monitoring.`);

                }

            }

        });

    }

};