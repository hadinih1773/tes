const { Client, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const fetch = require("node-fetch");
const FormData = require("form-data");
const axios = require('axios');
const { uploadToTelegraph, uploadTo0x0, uploadToTmpfiles, uploadToCatbox } = require('../lib/uploader');

// Fungsi Hady Uploader
async function uploadHady(buffer, filename) {
  const form = new FormData();
  form.append('file', buffer, filename);

  const res = await axios.post('https://hadytools.vercel.app/api/uploader', form, {
    headers: form.getHeaders()
  });

  return res.data.result.url;
}

const PREFIX = "!";

// --- KONFIGURASI UNTUK UPLOAD TEKS ---
const PASTE_API_ENDPOINT = "https://hastebin.com/documents";
const PASTE_BASE_URL = "https://hastebin.com/";

/**
 * Mendapatkan semua konten dari pesan.
 */
async function getMessageContent(message) {
    let targetMessage = message;
    let text = "";
    let files = [];
    let isReply = false;

    if (message.reference && message.reference.messageId) {
        try {
            targetMessage = await message.channel.messages.fetch(message.reference.messageId);
            isReply = true;
        } catch (e) {}
    }

    targetMessage.attachments.forEach((attachment) => {
        files.push({
            url: attachment.url,
            name: attachment.name,
            contentType: attachment.contentType
        });
    });

    if (targetMessage.content) {
        if (isReply) {
            text = targetMessage.content.trim();
        } else {
            text = message.content.slice(PREFIX.length + 7).trim();
        }
    }

    return { text, files };
}

/**
 * Mengunggah teks ke layanan Hastebin.
 */
async function uploadTextToLink(text) {
    const response = await fetch(PASTE_API_ENDPOINT, {
        method: "POST",
        body: text,
        headers: { "Content-Type": "text/plain" },
    });
    const json = await response.json();
    if (json.key) {
        return `${PASTE_BASE_URL}raw/${json.key}`;
    }
    throw new Error("Gagal mendapatkan kunci dari API Teks.");
}

/**
 * Menyiapkan listener untuk command link maker.
 */
function setupLinkMaker(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
        if (message.author.bot || !message.content.startsWith(PREFIX)) return;

        const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
        const command = args.shift().toLowerCase();

        if (command === "tourl") {
            const { text, files } = await getMessageContent(message);

            if (!text && files.length === 0) {
                return message.reply(`❌ Tidak ada gambar atau teks yang ditemukan!`);
            }

            // 1. Embed Proses (Reply ke pesan user)
            const processEmbed = new EmbedBuilder()
                .setTitle("🔄 Sedang Di Proses..")
                .setDescription("Mohon Ditunggu Sedang Konversi Ke Direct Link")
                .setColor("Blue");

            const loadingMessage = await message.reply({ embeds: [processEmbed] });

            try {
                const embed = new EmbedBuilder()
                    .setTitle(`🔗 Hasil Konversi ke Direct Link`)
                    .setColor("Green");

                let resultString = "";
                const buttons = [];

                // --- 1. PROSES TEKS ---
                if (text && files.length === 0) {
                    const textLink = await uploadTextToLink(text);
                    resultString += `📝 **Teks:** [Link Teks](${textLink})\n`;

                    if (textLink && textLink.startsWith("http")) {
                        buttons.push(
                            new ButtonBuilder()
                                .setLabel("Teks Link")
                                .setStyle(ButtonStyle.Link)
                                .setURL(textLink)
                        );
                    }
                }

                // --- 2. PROSES FILE/GAMBAR ---
                if (files.length > 0) {
                    for (let i = 0; i < files.length; i++) {
                        const file = files[i];
                        
                        const response = await fetch(file.url);
                        const buffer = await response.buffer();
                        
                        // Upload ke berbagai layanan
                        let catbox, telegraph, tmpfiles, oxo, hady;

                        try { catbox = await uploadToCatbox(buffer, file.name); } catch (e) { catbox = "❌ Eror"; }
                        try { telegraph = await uploadToTelegraph(buffer, file.name); } catch (e) { telegraph = "❌ Eror"; }
                        try { tmpfiles = await uploadToTmpfiles(buffer, file.name); } catch (e) { tmpfiles = "❌ Eror"; }
                        try { oxo = await uploadTo0x0(buffer, file.name); } catch (e) { oxo = "❌ Eror"; }
                        try { hady = await uploadHady(buffer, file.name); } catch (e) { hady = "❌ Eror"; }

                        resultString += `📄 **File ${i + 1}:**\n`;
                        resultString += `Catbox : ${catbox}\n`;
                        resultString += `Telegraph : ${telegraph}\n`;
                        resultString += `Tmpfiles : ${tmpfiles}\n`;
                        resultString += `Oxo : ${oxo}\n`;
                        resultString += `Hady Tools : ${hady}\n\n`;

                        // Pengecekan Link Sukses untuk Tombol Button
                        if (catbox && catbox.startsWith("http")) {
                            buttons.push(new ButtonBuilder().setLabel("Catbox").setStyle(ButtonStyle.Link).setURL(catbox));
                        }
                        if (telegraph && telegraph.startsWith("http")) {
                            buttons.push(new ButtonBuilder().setLabel("Telegraph").setStyle(ButtonStyle.Link).setURL(telegraph));
                        }
                        if (tmpfiles && tmpfiles.startsWith("http")) {
                            buttons.push(new ButtonBuilder().setLabel("Tmpfiles").setStyle(ButtonStyle.Link).setURL(tmpfiles));
                        }
                        if (oxo && oxo.startsWith("http")) {
                            buttons.push(new ButtonBuilder().setLabel("Oxo").setStyle(ButtonStyle.Link).setURL(oxo));
                        }
                        if (hady && hady.startsWith("http")) {
                            buttons.push(new ButtonBuilder().setLabel("Hady Tools").setStyle(ButtonStyle.Link).setURL(hady));
                        }
                    }
                }

                embed.setDescription(resultString || "Berhasil diproses.");

                // Menyusun Button ke dalam ActionRow (maksimal 5 button per baris)
                const components = [];
                if (buttons.length > 0) {
                    // Discord membatasi maksimal 5 button per ActionRow
                    for (let i = 0; i < buttons.length; i += 5) {
                        const row = new ActionRowBuilder().addComponents(buttons.slice(i, i + 5));
                        components.push(row);
                    }
                }

                // 4. Embed proses dihapus
                await loadingMessage.delete().catch(() => {});

                // 2. Embed hasil dikirim sebagai Reply pesan user
                await message.reply({ embeds: [embed], components });

            } catch (e) {
                console.error(e);
                await loadingMessage.delete().catch(() => {});
                message.reply(`❌ Gagal: ${e.message}`);
            }
        }
    });
}

module.exports = setupLinkMaker;