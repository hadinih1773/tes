const { EmbedBuilder } = require("discord.js");

const axios = require('axios');

const FormData = require("form-data");

const fetch = require("node-fetch");

const PREFIX = "!";

/**

 * Upload Buffer ke Catbox.moe

 */

async function CatBox(buffer, fileName) {

    try {

        const formData = new FormData();

        formData.append('fileToUpload', buffer, { filename: fileName });

        formData.append('reqtype', 'fileupload');

        formData.append('userhash', '');

        const response = await axios.post('https://catbox.moe/user/api.php', formData, {

            headers: {

                ...formData.getHeaders(),

            },

            timeout: 0

        });

        return response.data;

    } catch (error) {

        console.error("Error at Catbox uploader:", error);

        throw new Error("Terjadi kesalahan saat upload ke Catbox.");

    }

}

/**

 * Mendapatkan konten gambar dari pesan langsung atau reply

 */

async function getMessageImage(message) {

    let targetMessage = message;

    if (message.reference && message.reference.messageId) {

        try {

            targetMessage = await message.channel.messages.fetch(message.reference.messageId);

        } catch (e) {}

    }

    

    const attachment = targetMessage.attachments.first();

    if (!attachment || !attachment.contentType.startsWith("image/")) return null;

    

    return {

        url: attachment.url,

        name: attachment.name

    };

}

/**

 * Setup module blurwajah

 */

function setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

        if (message.author.bot || !message.content.startsWith(PREFIX)) return;

        const args = message.content.slice(PREFIX.length).trim().split(/\s+/);

        const command = args.shift().toLowerCase();

        if (command === "blurwajah") {

            const imageData = await getMessageImage(message);

            

            if (!imageData) {

                return message.reply(`❌ Tidak ada gambar yang ditemukan!`);

            }

            const embedProses = new EmbedBuilder()

                .setTitle(`🔄 Blur Wajah Diproses!`)

                .setDescription(`⏳ Mohon Ditunggu Sebentar`)

                .setColor("Blue");

            const loadingMessage = await message.reply({ embeds: [embedProses] });

            try {

                // 1. Ambil buffer gambar asli

                const resImg = await fetch(imageData.url);

                const bufferAsli = await resImg.buffer();

                // 2. Upload ke Catbox untuk dapat link input API

                const inputCatbox = await CatBox(bufferAsli, imageData.name);

                

                // 3. Kirim ke API Blur Wajah menggunakan parameter 'image' sesuai screenshot

                const apiResponse = await axios.get(`https://api-faa.my.id/faa/blurwajah?image=${inputCatbox}`, { timeout: 0 });

                

                // Mengambil hasil langsung dari .result sesuai screenshot sukses

                const blurImageUrl = apiResponse.data.result;

                if (!blurImageUrl) {

                    throw new Error("API tidak memberikan URL hasil.");

                }

                // 4. Langsung tampilkan hasil dari link API tanpa upload ulang ke Catbox

                const embedHasil = new EmbedBuilder()

                    .setTitle(`✅ Blur Wajah Berhasil`)

                    .setDescription(`<@${message.author.id}> Done Bro 😎!\nWajah Objek Sudah Di Blur, Hasilnya Dibawah 👇`)

                    .setImage(blurImageUrl)

                    .setColor("Green");

                await loadingMessage.edit({ embeds: [embedHasil] });

            } catch (e) {

                console.error(e);

                await loadingMessage.edit({ content: `❌ Gagal: ${e.message}`, embeds: [] });

            }

        }

    });

}

module.exports = { setup };