const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");
const os = require("os");
const axios = require("axios");

const dbPath = path.join(__dirname, "..", "database", "monitoring.json");

function loadMonitoringData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify({}));
      return {};
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return {};
  }
}

function saveMonitoringData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database monitoring.json:", err);
  }
}

function generateProgressBar(percent) {
  const total = 18;
  const progress = Math.round((percent / 100) * total);
  const empty = total - progress;
  return "[" + "▓".repeat(Math.max(0, progress)) + "░".repeat(Math.max(0, empty)) + "]";
}

function formatBytes(bytes) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
}

function getCpuLoad() {
  const cpus = os.cpus();
  let user = 0, nice = 0, sys = 0, idle = 0, irq = 0;
  for (let cpu of cpus) {
    for (let type in cpu.times) {
      if (type === "user") user += cpu.times[type];
      if (type === "nice") nice += cpu.times[type];
      if (type === "sys") sys += cpu.times[type];
      if (type === "idle") idle += cpu.times[type];
      if (type === "irq") irq += cpu.times[type];
    }
  }
  const total = user + nice + sys + idle + irq;
  return Math.min(100, Math.round(((total - idle) / total) * 100));
}

let publicIp = "127.0.0.1";
async function fetchIp() {
  try {
    const res = await axios.get("https://api.ipify.org?format=json", { timeout: 3000 });
    publicIp = res.data.ip;
  } catch {
    publicIp = "127.0.0.1";
  }
}
fetchIp();

module.exports = {
  setup: function (client) {
    // System Real-time Auto Update Loop
    setInterval(async () => {
      const data = loadMonitoringData();
      if (!data.channelId || !data.messageId) return;

      try {
        const channel = await client.channels.fetch(data.channelId).catch(() => null);
        if (!channel) return;

        const targetMessage = await channel.messages.fetch(data.messageId).catch(() => null);
        if (!targetMessage) return;

        const embed = await buildEmbed(client);
        await targetMessage.edit({ embeds: [embed] }).catch(() => null);
      } catch (err) {
        console.error("Auto update monitoring error:", err);
      }
    }, 5000);

    // Kirim Embed Baru Setiap 1 Jam (3600000 ms) Tanpa Menghapus Embed Lama
    setInterval(async () => {
      const data = loadMonitoringData();
      if (!data.channelId) return;

      try {
        const channel = await client.channels.fetch(data.channelId).catch(() => null);
        if (!channel) return;

        const embed = await buildEmbed(client);
        const newMsg = await channel.send({ embeds: [embed] }).catch(() => null);

        if (newMsg) {
          saveMonitoringData({
            channelId: data.channelId,
            messageId: newMsg.id
          });
        }
      } catch (err) {
        console.error("Hourly monitoring broadcast error:", err);
      }
    }, 3600000);

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      if (command === "!setchannelmonitoring" || command === "!setchannelmonitor") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        const targetChannel = message.mentions.channels.first() || message.channel;
        const initialEmbed = await buildEmbed(client);
        const sentMsg = await targetChannel.send({ embeds: [initialEmbed] });

        saveMonitoringData({
          channelId: targetChannel.id,
          messageId: sentMsg.id
        });

        if (message.channel.id !== targetChannel.id) {
          message.reply(`✅ Berhasil mengatur channel monitoring di <#${targetChannel.id}>`);
        }
      }

      if (command === "!deletechannelmonitoring" || command === "!delchannelmonitor") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        const targetChannel = message.mentions.channels.first() || message.channel;
        const data = loadMonitoringData();

        if (data.channelId === targetChannel.id) {
          try {
            const channel = await client.channels.fetch(data.channelId).catch(() => null);
            if (channel && data.messageId) {
              const targetMessage = await channel.messages.fetch(data.messageId).catch(() => null);
              if (targetMessage) await targetMessage.delete().catch(() => null);
            }
          } catch (err) {
            console.error("Gagal menghapus pesan monitoring:", err);
          }

          saveMonitoringData({});
          return message.reply(`✅ Berhasil menghapus channel monitoring dari <#${targetChannel.id}>`);
        } else {
          return message.reply(`❌ Channel <#${targetChannel.id}> tidak terdaftar sebagai channel monitoring.`);
        }
      }

      if (command === "!info" || command === "!system") {
        const infoEmbed = await buildEmbed(client);
        const infoMsg = await message.reply({ embeds: [infoEmbed] });

        // Auto update embed real-time untuk command !info setiap 5 detik
        const infoInterval = setInterval(async () => {
          try {
            const updatedEmbed = await buildEmbed(client);
            await infoMsg.edit({ embeds: [updatedEmbed] });
          } catch (err) {
            clearInterval(infoInterval);
          }
        }, 5000);
      }
    });
  }
};

async function buildEmbed(client) {
  // Menggunakan Discord Dynamic Timestamp (UNIX Timestamp)
  const timestamp = Math.floor(Date.now() / 1000);
  const formattedFormattedTime = `<t:${timestamp}:F>`;

  const cpuPercent = getCpuLoad();
  const cpuBar = generateProgressBar(cpuPercent);

  // RAM Usage (Real-time dari Process Memory Bot & Container Limits)
  const memUsed = process.memoryUsage().rss;
  let memTotal = os.totalmem();
  if (process.env.SERVER_MEMORY) {
    memTotal = parseInt(process.env.SERVER_MEMORY) * 1024 * 1024;
  }
  const memPercent = Math.min(100, Math.round((memUsed / memTotal) * 100));
  const ramBar = generateProgressBar(memPercent);

  // DISK Usage (Statistik Fisik/Container Root Path)
  let diskUsed = 0;
  let diskTotal = 100 * 1024 * 1024 * 1024; 

  try {
    const fsStats = fs.statfsSync("/");
    diskTotal = fsStats.blocks * fsStats.bsize;
    diskUsed = (fsStats.blocks - fsStats.bfree) * fsStats.bsize;
  } catch {
    diskUsed = memUsed * 3;
    diskTotal = memTotal * 5;
  }

  if (process.env.SERVER_DISK) {
    diskTotal = parseInt(process.env.SERVER_DISK) * 1024 * 1024;
  }

  const diskPercent = Math.min(100, Math.round((diskUsed / diskTotal) * 100));
  const diskBar = generateProgressBar(diskPercent);

  const wsPing = Math.round(client.ws.ping) || 0;
  const botUptime = formatUptime(process.uptime());
  const sysUptime = formatUptime(os.uptime());

  const description =
    `🕒 **Waktu** : ${formattedFormattedTime}\n\n` +
    `🛠 **Resources Usage**\n` +
    `🛡 **CPU Bot Load** : ${cpuPercent}%\n` +
    `${cpuBar}\n` +
    `🏮 **RAM Bot Usage** : ${formatBytes(memUsed)} / ${formatBytes(memTotal)}\n` +
    `${ramBar}\n` +
    `🧿 **DISK Bot Usage** : ${formatBytes(diskUsed)} / ${formatBytes(diskTotal)}\n` +
    `${diskBar}\n\n` +
    `🌏 **Network & Latency**\n` +
    `🕹 **WS Ping** : ${wsPing}ms\n` +
    `🎛 **IP** : \`\`${publicIp}\`\`\n\n` +
    `🕒 **Uptime**\n` +
    `⏰ **Bot Uptime** : \`\`${botUptime}\`\`\n` +
    `🖥 **System Uptime** : \`\`${sysUptime}\`\``;

  return new EmbedBuilder()
    .setColor("#000000")
    .setTitle("📡 Helper | System Monitoring")
    .setDescription(description);
}