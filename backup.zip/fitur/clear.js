const { PermissionsBitField } = require("discord.js");
const fs = require("fs");
const path = require("path");

const ownerPath = path.join(__dirname, "../database/owner.json");

function getOwner() {
    if (!fs.existsSync(ownerPath)) return null;
    try {
        const data = JSON.parse(fs.readFileSync(ownerPath, "utf-8"));
        return data.owner;
    } catch (e) {
        return null;
    }
}

function setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

        if (message.author.bot) return;

        const content = message.content.trim();

        const args = content.split(" ").slice(1);

        const command = content.split(" ")[0].toLowerCase();

        // Hanya respon kalau command diawali "!cc"

        if (command !== "!cc") return;

        // Kalau bukan admin -> bot diam aja
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        // Cek apakah di server

        if (!message.guild) return;

        const param = args[0]?.toLowerCase();

        // ======================

        // === CLEAR ALL FIX ===

        // ======================

        if (param === "all") {
            const ownerId = getOwner();
            if (message.author.id !== ownerId) {
                return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
            }

            if (message.channel.isThread()) return;

            await message.channel.send("**PERINGATAN:** Semua pesan di channel ini akan dihapus. Mohon tunggu...");

            try {

                const oldChannel = message.channel;

                // Ambil posisi sebelum delete

                const position = oldChannel.position;

                // Ambil semua property penting

                const parent = oldChannel.parent;

                const name = oldChannel.name;

                const topic = oldChannel.topic;

                const nsfw = oldChannel.nsfw;

                const rateLimit = oldChannel.rateLimitPerUser;

                const permissionOverwrites = oldChannel.permissionOverwrites.cache.map(po => ({

                    id: po.id,

                    allow: po.allow.bitfield,

                    deny: po.deny.bitfield,

                    type: po.type

                }));

                // Buat channel baru **di posisi yang sama**

                const newChannel = await oldChannel.guild.channels.create({

                    name: name,

                    type: oldChannel.type,

                    topic: topic,

                    nsfw: nsfw,

                    parent: parent,

                    rateLimitPerUser: rateLimit,

                    permissionOverwrites: permissionOverwrites

                });

                // Pindahkan ke posisi lama setelah channel dibuat

                await newChannel.setPosition(position).catch(() => {});

                // Hapus channel lama

                await oldChannel.delete().catch(() => {});

                // PESAN AUTO DELETE DI CHANNEL BARU

                const msg = await newChannel.send("Channel berhasil dibersihkan.");

                setTimeout(() => msg.delete().catch(() => {}), 5000);

            } catch (error) {

                console.error("Gagal menghapus semua pesan (cc all):", error);

                await message.author.send(

                    `Gagal menghapus seluruh pesan di channel ${message.channel.name}. Pastikan bot punya izin **Manage Channels** dan **Manage Messages**.`

                ).catch(() => {});

            }

            return;

        }

        // ============================

        // === CLEAR JUMLAH PESAN  ===

        // ============================

        const amount = parseInt(param);

        if (isNaN(amount) || amount < 1 || amount > 100) return;

        const totalToDelete = amount > 99 ? 100 : amount + 1;

        try {

            const deleted = await message.channel.bulkDelete(totalToDelete, true);

            const confirmMsg = await message.channel.send(`Berhasil menghapus **${deleted.size - 1}** pesan!`);

            setTimeout(() => confirmMsg.delete().catch(() => {}), 5000);

        } catch (error) {

            console.error("Gagal menghapus pesan (cc <jumlah>):", error);

        }

    });

}

module.exports = { setup };