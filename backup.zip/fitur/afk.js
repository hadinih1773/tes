const { EmbedBuilder } = require("discord.js");

const fs = require("fs");

// Baca file JSON saat bot hidup

let afk = fs.existsSync("./database/afk.json")

    ? JSON.parse(fs.readFileSync("./database/afk.json"))

    : {};

function saveAFK() {

    fs.writeFileSync("./database/afk.json", JSON.stringify(afk, null, 2));

}

function format(ms) {

    let s = Math.floor(ms / 1000);

    const h = Math.floor(s / 3600);

    s %= 3600;

    const m = Math.floor(s / 60);

    s %= 60;

    return `${h} Jam ${m} Menit ${s} Detik`;

}

function setup(client) {

    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

        if (message.author.bot || !message.guild) return;

        const guildId = message.guild.id;

        const userId = message.author.id;

        // Inisialisasi object guild jika belum ada

        if (!afk[guildId]) afk[guildId] = {};

        // =====================

        // COMMAND !afk

        // =====================

        if (message.content.toLowerCase().startsWith("!afk")) {

            const alasan = message.content.slice(4).trim() || "❌ Format Salah : ``!afk alasan``";

            afk[guildId][userId] = {

                alasan,

                namaAsli: message.member.nickname || message.author.username,

                waktu: Date.now()

            };

            saveAFK();

            await message.member.setNickname(`[ AFK ] ${afk[guildId][userId].namaAsli}`).catch(() => {});

            const embed = new EmbedBuilder()

                .setTitle("AFK System")

                .setDescription(`${message.author} Anda Sekarang AFK\nAlasan: **${alasan}**`)

                .setColor("Blue");

            return message.reply({ embeds: [embed] });

        }

        // =====================

        // Jika user AFK ngechat → AFK hilang

        // =====================

        if (afk[guildId] && afk[guildId][userId]) {

            const data = afk[guildId][userId];

            const lama = format(Date.now() - data.waktu);

            await message.member.setNickname(data.namaAsli).catch(() => {});

            

            delete afk[guildId][userId];

            saveAFK();

            return message.reply(`Selamat Datang Kembali ${message.author} Kamu Sudah Afk Selama ${lama}`);

        }

        // =====================

        // Jika orang tag user AFK

        // =====================

        const mention = message.mentions.users.first();

        if (mention && afk[guildId] && afk[guildId][mention.id]) {

            return message.reply(`${mention} Sedang AFK`);

        }

    });

}

module.exports = { setup };

