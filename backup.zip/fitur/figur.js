const { EmbedBuilder, AttachmentBuilder, PermissionFlagsBits } = require("discord.js");
const axios = require('axios');
const https = require('https');
const fs = require('fs');
const path = require('path');

// Ganti ID channel di bawah ini
const CHANNEL_ID_FIGUR = "1458516093571170405"; 

// Lokasi direktori dan file JSON database
const dbDir = path.join(__dirname, "../database");
const dbFilePath = path.join(dbDir, "figurchannel.json");

// Helper untuk membaca daftar channel dari JSON
function loadChannels() {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(dbFilePath)) {
        fs.writeFileSync(dbFilePath, JSON.stringify([]));
        return [];
    }
    try {
        const data = fs.readFileSync(dbFilePath, "utf8");
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

// Helper untuk menyimpan daftar channel ke JSON
function saveChannels(channels) {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(dbFilePath, JSON.stringify(channels, null, 2));
}

// Prompt khusus Figurin
const FIGUR_PROMPT = "Using the model, create a 1/7 scale commercialized figurine of the characters in the picture, in a realistic style, in a real environment. The figurine is placed on an aesthetic computer desk. The figurine has a round transparant acrylic base, with no text on the base. The content on the computer screen is the ZBrush modeling process of this figurine. Next to the computer screen is a BANDAI-style toy packaging box printed with the original art work. The packaging features two-dimensional flat illustrations. Maintain original aspect ratio and resolution.";

// Konfigurasi koneksi super cepat (Ultra Low Latency)
const fastAxios = axios.create({
    timeout: 0,
    httpsAgent: new https.Agent({ 
        keepAlive: true, 
        maxSockets: 100, // Ditingkatkan untuk handle spam lebih baik
        rejectUnauthorized: false 
    })
});

function setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
        if (message.author.bot) return;

        const args = message.content.split(" ");
        const command = args[0].toLowerCase();
        const isAdmin = message.member?.permissions.has(PermissionFlagsBits.Administrator);

        // Command !setchannelfigur dan !delchannelfigur (Hanya Admin)
        if (command === "!setchannelfigur" || command === "!delchannelfigur") {
            if (!isAdmin) {
                return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
            }

            let targetChannel = message.mentions.channels.first() || message.channel;
            let channelList = loadChannels();

            if (command === "!setchannelfigur") {
                if (!channelList.includes(targetChannel.id)) {
                    channelList.push(targetChannel.id);
                    saveChannels(channelList);
                    return message.reply(`✅ Channel <#${targetChannel.id}> berhasil ditambahkan ke daftar.`);
                } else {
                    return message.reply(`⚠️ Channel <#${targetChannel.id}> sudah ada di daftar.`);
                }
            }

            if (command === "!delchannelfigur") {
                if (channelList.includes(targetChannel.id)) {
                    channelList = channelList.filter(id => id !== targetChannel.id);
                    saveChannels(channelList);
                    return message.reply(`✅ Channel <#${targetChannel.id}> berhasil dihapus dari daftar.`);
                } else {
                    return message.reply(`⚠️ Channel <#${targetChannel.id}> tidak ditemukan di daftar.`);
                }
            }
        }

        // Cek apakah channel diizinkan
        const customChannels = loadChannels();
        const isAllowedChannel = message.channel.id === CHANNEL_ID_FIGUR || customChannels.includes(message.channel.id);

        const isCommand = message.content.startsWith("!tofigure");
        const isAutoChannel = isAllowedChannel;

        if (!isCommand && !isAutoChannel) return;

        let imageUrl = null;

        // Ambil Gambar (Lampiran atau Reply)
        if (message.attachments.size > 0) {
            imageUrl = message.attachments.first().url;
        } else if (message.reference) {
            try {
                const repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
                if (repliedMessage.attachments.size > 0) {
                    imageUrl =repliedMessage.attachments.first().url;
                }
            } catch (e) {}
        }

        if (!imageUrl) {
            if (isCommand || isAutoChannel) {
                return message.reply("⚠️ **Kirim Gambar Yang Mau Dijadikan Figure**");
            }
            return;
        }

        const loadingEmbed = new EmbedBuilder()
            .setTitle("🔄 Sedang Di Proses")
            .setDescription("⏳ Harap Bersabar, dan Jangan Spam")
            .setColor("Blue");

        const msg = await message.reply({ embeds: [loadingEmbed] });

        try {
            // URL API dengan parameter tambahan untuk menjaga ukuran asli
            const apiUrl = `https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(FIGUR_PROMPT)}`;
            
            // Request performa tinggi langsung ke buffer
            const response = await fastAxios.get(apiUrl, { responseType: 'arraybuffer' });
            
            const attachment = new AttachmentBuilder(Buffer.from(response.data), { name: 'figur_result.png' });

            // Balas langsung ke pesan user tanpa tag (Allowed Mentions false)
            await message.reply({ 
                files: [attachment], 
                allowedMentions: { replied_user: false } 
            });

            // Hapus embed proses secara instan
            await msg.delete().catch(() => {});
        } catch (error) {
            await msg.edit({ content: "❌ Gagal memproses gambar. Pastikan API tersedia.", embeds: [] });
        }
    });
}

module.exports = { setup };