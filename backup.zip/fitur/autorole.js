// autorole.js

const fs = require("fs");
const path = require("path");
const { PermissionFlagsBits } = require("discord.js");

const autoroleFile = path.join(__dirname, "..", "database", "autorole.json");

// pastikan file autorole.json ada
if (!fs.existsSync(autoroleFile)) {
  fs.writeFileSync(autoroleFile, JSON.stringify({}, null, 2));
}

module.exports = {
  setup(client) {

    // ============================
    // COMMAND HANDLER
    // ============================
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;

      const msg = message.content.toLowerCase();

      // ============================
      // !autorole @role
      // ============================
      if (msg.startsWith("!autorole")) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan.");
        }

        const role = message.mentions.roles.first();
        if (!role) {
          return message.reply("❌ Format Salah : ``!autorole @role``.");
        }

        const data = JSON.parse(fs.readFileSync(autoroleFile, "utf8"));
        data[message.guild.id] = role.id;

        fs.writeFileSync(autoroleFile, JSON.stringify(data, null, 2));

        return message.reply(`✅ Autorole berhasil diset ke **${role.name}**`);
      }

      // ============================
      // !deleteautorole
      // ============================
      if (msg === "!deleteautorole") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan.");
        }

        const data = JSON.parse(fs.readFileSync(autoroleFile, "utf8"));

        if (!data[message.guild.id]) {
          return message.reply("⚠️ Autorole belum diset di server ini.");
        }

        delete data[message.guild.id];
        fs.writeFileSync(autoroleFile, JSON.stringify(data, null, 2));

        return message.reply("✅ Autorole berhasil dihapus.");
      }
    });

    // ============================
    // AUTO ROLE SAAT MEMBER JOIN
    // ============================
    client.on("guildMemberAdd", async (member) => {
      try {
        const data = JSON.parse(fs.readFileSync(autoroleFile, "utf8"));
        const roleId = data[member.guild.id];
        if (!roleId) return;

        const role = member.guild.roles.cache.get(roleId);
        if (!role) return;

        await member.roles.add(role).catch(() => {});
      } catch (err) {
        console.error("Autorole error:", err);
      }
    });

  }
};