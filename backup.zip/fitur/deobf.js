const { EmbedBuilder, AttachmentBuilder, PermissionFlagsBits } = require("discord.js");
const axios = require("axios");
const FormData = require("form-data");
const path = require("path");
const fs = require("fs");

// ==================== CONFIGURATION ====================
const ALLOWED_CHANNEL_ID = "1517436289358757998"; 
// =======================================================

// Lokasi direktori dan file JSON database
const dbDir = path.join(__dirname, "../database");
const dbFilePath = path.join(dbDir, "deobfchannel.json");

// Helper untuk membaca daftar channel dari JSON
function loadChannels() {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(dbFilePath)) {
        fs.writeFileSync(dbFilePath, JSON.stringify([]));
        return [];
    }
    try {
        const data = fs.readFileSync(dbFilePath, "utf8");
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

// Helper untuk menyimpan daftar channel ke JSON
function saveChannels(channels) {
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(dbFilePath, JSON.stringify(channels, null, 2));
}

const OBFUSCATOR_SIGNATURES = {
  "obfuscator.com": [
    /local\s+[A-Za-z_]+\s*=\s*\{[^\}]{200,\}}/i,
    /-- Obfuscated by obfuscator\.com/i,
    /loadstring\(.*base64.*\)/i,
    /local\s+[a-zA-Z_]+\s*=\s*"[A-Za-z0-9+/=]{100,}"/i,
    /\bLuaObfuscator\b/i
  ],
  "Prometheus / MoonSec v3": [
    /-- Prometheus/i,
    /-- MoonSec/i,
    /local\s+[a-z]+\s*=\s*\{\s*\[1\]\s*=/i,
    /xor_key/i,
    /string\.byte.*string\.char.*for.*do/i,
    /\bMoonSecurity\b/i,
    /moonsec/i
  ],
  "Yasu": [
    /-- Yasu/i,
    /YASU/i,
    /local\s+[A-Z_]{5,}\s*=\s*\{/i,
    /rawget.*rawset/i,
    /getfenv\(\)/i,
    /setfenv\(/i
  ]
};

function detectObfuscator(content) {
  for (const [name, patterns] of Object.entries(OBFUSCATOR_SIGNATURES)) {
    let score = 0;
    for (const pattern of patterns) {
      if (pattern.test(content)) score++;
    }
    if (score >= 1) return name;
  }
  return "Unknown / Plain Lua";
}

function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
}

// Fungsi Utama Proses Deobfuscator
async function handleDeobfuscation(message, fileAttachment) {
  // 1. Kirim Embed Proses Awal (Warna Biru diubah ke #00BFFF)
  const processingEmbed = new EmbedBuilder()
    .setColor("#00BFFF")
    .setTitle("🔄 Deobfuscate Processing")
    .setDescription("🤖 : Sedang Memproses Kode Jangan Spamming, Dan Tunggu Sampai Selesai")
    .setTimestamp();

  const loadingMessage = await message.reply({ embeds: [processingEmbed] });

  try {
    // 2. Download File dari Discord
    const fileResponse = await axios.get(fileAttachment.url, { responseType: "arraybuffer" });
    const fileBuffer = Buffer.from(fileResponse.data);
    const fileContentText = fileBuffer.toString("utf-8");

    const detectedType = detectObfuscator(fileContentText);
    const originalFileName = fileAttachment.name || "script.lua";

    // 3. Setup Multipart Form Data untuk API POST upload file
    const form = new FormData();
    form.append("file", fileBuffer, {
      filename: originalFileName,
      contentType: "text/plain"
    });

    // 4. Request Menggunakan Skema Retry Percobaan (Max 3 Kali)
    let apiResponse;
    let lastError = null;

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        apiResponse = await axios.post("https://tw8rev-deobfuscator.vercel.app/api/deobfuscate", form, {
          headers: {
            ...form.getHeaders()
          },
          timeout: 90000
        });
        lastError = null;
        break;
      } catch (err) {
        lastError = err;
      }
    }

    if (lastError) {
      throw new Error(`Koneksi API Gagal setelah 3 kali percobaan: ${lastError.message}`);
    }

    const data = apiResponse.data;

    // Mengikuti penanganan dari struktur response .json() Python kamu
    if (data && (data.success || data.result)) {
      const resultClean = data.result || data.deobfuscated || "";
      
      // Bagian header telah dihapus sesuai instruksi
      const finalCodeOutput = resultClean;
      
      // Aturan penamaan file output sesuai instruksi yang diperbarui
      const fileExtension = path.extname(originalFileName);
      const baseName = path.basename(originalFileName, fileExtension);
      const outputFileName = `${baseName}_deobfuscator${fileExtension}`;
      
      const outputBuffer = Buffer.from(finalCodeOutput, "utf-8");
      const fileSizeFormatted = formatBytes(outputBuffer.length);
      const outputAttachment = new AttachmentBuilder(outputBuffer, { name: outputFileName });

      // 5. Build Embed Sukses Warna Hijau Emerald (#50C878) dengan Title Baru
      const successEmbed = new EmbedBuilder()
        .setColor("#50C878")
        .setTitle("✅ Deobfuscate File Successful")
        .setDescription(`👤 **User Request**\n<@${message.author.id}>\n\n📁 **File Name**\n${outputFileName}\n\n📦 **Size File**\n${fileSizeFormatted}`)
        .setTimestamp();

      // 6. Kirim hasil sesuai urutan: @tag, hasil file, embed hasil
      await message.channel.send({
        content: `<@${message.author.id}>`,
        files: [outputAttachment],
        embeds: [successEmbed]
      });

      await loadingMessage.delete().catch(() => null);
    } else {
      throw new Error(data.result || "Struktur data respons dari API mengembalikan nilai gagal.");
    }

  } catch (error) {
    console.error("❌ Error Deobfuscator:", error);
    
    // Embed Gagal Berwarna Merah sesuai instruksi
    const errorEmbed = new EmbedBuilder()
      .setColor("#FF0000")
      .setTitle("❌ Deobfuscate Failed")
      .setDescription(`${error.message}`)
      .setTimestamp();

    await loadingMessage.edit({
      content: null,
      embeds: [errorEmbed]
    });
  }
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();
      
      // Cek apakah user adalah administrator
      const isAdmin = message.member.permissions.has(PermissionFlagsBits.Administrator);

      // Command !setchanneldeobf dan !delchanneldeobf (Hanya Admin)
      if (command === "!setchanneldeobf" || command === "!delchanneldeobf") {
        if (!isAdmin) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
        }

        let targetChannel = message.mentions.channels.first() || message.channel;
        let channelList = loadChannels();

        if (command === "!setchanneldeobf") {
          if (!channelList.includes(targetChannel.id)) {
            channelList.push(targetChannel.id);
            saveChannels(channelList);
            return message.reply(`✅ Channel <#${targetChannel.id}> berhasil ditambahkan ke daftar.`);
          } else {
            return message.reply(`⚠️ Channel <#${targetChannel.id}> sudah ada di daftar.`);
          }
        }

        if (command === "!delchanneldeobf") {
          if (channelList.includes(targetChannel.id)) {
            channelList = channelList.filter(id => id !== targetChannel.id);
            saveChannels(channelList);
            return message.reply(`✅ Channel <#${targetChannel.id}> berhasil dihapus dari daftar.`);
          } else {
            return message.reply(`⚠️ Channel <#${targetChannel.id}> tidak ditemukan di daftar.`);
          }
        }
      }

      const customChannels = loadChannels();
      const isTargetChannel = message.channel.id === ALLOWED_CHANNEL_ID || customChannels.includes(message.channel.id);

      // Pemicu 1: Menggunakan Command !deobf
      if (command === "!deobf") {
        // Jika bukan admin DAN bukan di channel yang ditentukan, kunci aksesnya
        if (!isAdmin && !isTargetChannel) {
          return message.reply(`❌ Perintah ini hanya dapat digunakan di channel <#${ALLOWED_CHANNEL_ID}>!`)
            .then(msg => {
              setTimeout(() => msg.delete().catch(() => null), 5000);
            });
        }

        let fileAttachment = message.attachments.first();

        if (!fileAttachment && message.reference && message.reference.messageId) {
          try {
            const repliedMsg = await message.channel.messages.fetch(message.reference.messageId);
            fileAttachment = repliedMsg.attachments.first();
          } catch (err) {
            // Gagal memuat pesan reply
          }
        }

        if (!fileAttachment) {
          return message.reply("❌ Kirim file atau reply file script yang ingin di-deobfuscate.");
        }

        // Jalankan proses (Hasil otomatis dikirim ke tempat command dieksekusi)
        await handleDeobfuscation(message, fileAttachment);
      } 
      
      // Pemicu 2: Kirim file langsung tanpa command di channel id yang diizinkan
      else if (isTargetChannel && message.attachments.size > 0) {
        const fileAttachment = message.attachments.first();
        // Jalankan proses langsung
        await handleDeobfuscation(message, fileAttachment);
      }
    });
  }
};