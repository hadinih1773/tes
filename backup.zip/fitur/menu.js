const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const tampilkanMenu = async (message) => {
    const deskripsiUtama = `**Selamat Datang ${message.author} Di Menu List Command**\n\n🤖 **Informasi Bot**\n> Nama Bot : <@1478220003609415691> (\`1478220003609415691\`)\n> Owner Bot : [hadinih_](https://discord.com/users/1341007595288268880) (\`1341007595288268880\`)\n> Link Server : [Hady Community](https://discord.gg/4uzdM25KYv)\n> Website Owner : [HadyOfficial](https://hadyofficial.vercel.app/)\n\nBot Discord Serbaguna Yang Dirancang Untuk Memudahkan Kita. 😉\n\n🧿 **Fitur Unggulan**\n🔷 Checking File\n🔷 Character Story Generator\n🔷 Auto Convert Top4Top\n🔷 Image Edit, Create Figure\n🔷 Downloader\n🔷 Obfuscator, Deobfuscator\n🔷 AI Chat Bot\n🔷 Spam, Check, Delete Webhook\n\n📣 **Ketentuan**\n⚠️ Bot ini Kadang Masih Bug dan Juga Eror. Tolong Jangan Di Spam dan Tunggu Bot Memproses Terlebih Dahulu. Jika ada Eror, Harap Lapor Ke Owner, Gunakan Command \`!owner\` 🥶🥶\n\n😁 **Gunakanlah Bot dengan Bijak, Supaya Selalu Online 24/7** 🎯`;
    
    const fields = [
        {
            name: "🎞 Admin & Discord Features",
            value: [
                "`!ar, !dar, !listar` - Membuat Auto Responder",
                "`!createembed|[judul]|[deskripsi]` - Membuat Pesan Embed",
                "`!on, !off` - Information Status Bot",
                "`!createchannel, !deletechannel, !renamechannel` - Membuat, Menghapus, Mengganti Nama Channel",
                "`!createcategory [category nama]` - Membuat Category",
                "`!say [text]` - Membuat Bot Mengulang Chat Kita",
                "`!locktr, !unlocktr, !deletetr, !createtr` - Mengelola Thread Message",
                "`!sticky, !stickyembed, !unsticky` - Membuat Sticky Message",
                "`!giveaways [durasi] [jumlah pemenang] [hadiah]` - Membuat Giveaway Message",
                "`!cc [Jumlah], !cc all` - Menghapus Pesan Dalam Channel",
                "`!menu` - Melihat Isi Commands Bot",
                "`!rrole [deskripsi] [@role]` - Membuat Reaction Roles",
                "`!pm [@user/id] [text]` - Membuat Bot Dm Seseorang",
                "`!pin` - Mem Pinned Chat Dengan di Reply",
                "`!unpin` - Menghapus Pinned Chat Dengan Di Reply",
                "`!nama [@user] [new name]` - Mengganti Nama Discordnya",
                "`!setchannelai` - Untuk Setting Channel AI",
                "`!delchannelai` - Untuk Hapus Channel AI",
                "`!setautotr [#channel] [thread name] !setautotr [thread name]` - Membuat Channel Menjadi Auto Thread",
                "`!removeautotr [#channel]` - Menghapus Auto Thread Dari Channel",
                "`!servername [new name]` Mengubah Nama Server",
                "`!serverdeskripsi [deskripsi]` - Mengubah Deskripsi Server",
                "`!servericon [image]` - Mengubah Profil/Icon Server",
                "`!chat [text]` - Chat Tapi Ada Logo APP",
                "`!chatembed [text]` - Chat Logo APP Versi Embed",
                "`!lockch dan !unlockch` - Channel Dikunci Untuk Send Messages",
                "`!autorole [@role]` - Membuat Auto Role Ketika User Join",
                "`!deleteautorole` - Menghapus Auto Role",
                "`!giveroleall [@role]` - Memberi Role Ke Semua Member",
                "`!takeroleall` - Mengambil Role Dari Semua Member",
                "`!addsticker [nama sticker]` - Add Sticker To Discord",
                "`!addemoji [nama emoji]` - Add Emoji To Discord",
                "`!rating [#channel]` - Setting Channel Rating",
                "`!delrating [#channel]` - Hapus Channel Rating",
                "`!infoserver [#channel]` - Leaderboard Server SAMP",
                "`!dinfoserver [#channel]` - Menghapus List Server",
                "`!autotyping [on/off]` - Bot Auto Typing Di Channel",
                "`!slow [on] [time]` - Mengaktifkan Slowmode Di Channel",
                "`!slow [off]` - Mematikan Slowmode Di Channel",
                "`!sharech, !delsharech [#channel]` - Setting Channel Yang Bisa Share Url Invite",
                "`!setupiklan, !setupcs, !setupspam` - Memunculkan Panel Setup",
                "`!setchannelprotect, !protectch, !setnochat` - Setting Chanel Yang Dilarang Chat",
                "`!deletechannelprotect, !dprotectch, !delchprotect` - Menghapus Channel Dilarang Chat",
                "`!setchannelbps, !delchannelbps` - Settings Channel Fitur Bypass Url",
                "`!setchannelimg, !delchannelimg` - Settings Channel Fitur Edit Image",
                "`!setchannelfigur, !delchannelfigur` - Settings Channel Fitur Create Figur",
                "`!setchannelcek, !delchannelcek` - Settings Channel Fitur Check MonetLoader",
                "`!setchannelobf, !delchannelobf` - Settings Channel Fitur Obfuscator",
                "`!setchanneldeof, !delchanneldeobf` - Settings Channel Fitur Deobfuscator"
            ].join('\n')
        },
        {
            name: "👑 Owner Menu",
            value: [
                "`!sambutan [on/off]` - Untuk Membuat Welcome Owner Aktif dan Mati",
                "`!backup` - Untuk Backup Database Bot",
                "`!monitor` - Untuk Monitoring Bot",
                "`!settimebackup [time]` - Membuat Waktu Backup",
                "`!setchannelbackup` - Setting Channel Backup",
                "`!delchannelbackup` - Menghapus Channel Backup",
                "`!giverole [@user] [@role]` - Memberikan Roles Kepada Orang",
                "`!takerole [@user] [@role]` - Mengambil Roles Orang",
                "`!changelogs [judul] [deskripsi]` - Untuk Membuat Changelogs Bot",
                "`!bbowner [judul/url]` - Membuat Link Boombox Top4Top",
                "`!setbbch [#channel]` - Add Channel Boombox All In One",
                "`!unsetbbch [#channel]` - Delete Channel Boombox All In One",
                "`!sewa|id server|@owner` - Menambahkan Sewa Bot Ke Server",
                "`!delsewa|id server` - Menghapus Bot Dari Server Sewa",
                "`!listsewa` - Melihat Isi List Sewa Server",
                "`!setnamebot [name]` - Mengubah Nama Bot",
                "`!sebiobot [deskripsi]` - Mengubah Bio Bot",
                "`!setppbot [image]` - Mengubah Foto Bot",
                "`!setbannerbot [image]` - Mengubah Banner Bot",
                "`!broadcast [text]` - Membuat Pesan Broadcast Ke Semua Member",
                "`!kuncifitur dan !bukafitur` - Mengunci Channel Yang Ada Fitur Bot",
                "`!self dan !public` - Menonaktifkan dan Mengaktifkan Bot Di Server",
                "`!bbopen dan !bblock` - Membuka Dan Mengunci Channel Boombox",
                "`!locbot` - Melihat List Server Bot",
                "`!blacklist/!bl [@user]` - Blacklist User Dari Akses Bot",
                "`!unblacklist/!unbl [@user]` - Menghapus Blacklist User",
                "`!self/!public` - Manager Akses Bot",
                "`!selfall/!publicall` - Manage Akses Bot Global"
            ].join('\n')
          },
      {
               name: "🛡 Protect Menu",
               value: [
                "`!antispam [on/off]` - Menghapus Pesan Spam Chat",
                "`!antikasar [on/off]` - Menghapus Pesan Mengandung Kata Kasar",
                "`!antikata, !antiword [on/off]` - Menghapus Semua Pesan Teks",
                "`!antiimage, !antivideo` - Menghapus Pesan Gambar Dan Video",
                "`!antimedia` - Menghapus Semua Pesan Media Hanya Bisa Kirim Teks"
            ].join('\n')
        },
        {
            name: "⚠️ Moderation Discord",
            value: [
                "`!x [@user/id] [reason]` - Ban Seseorang",
                "`!+ [@user/id]` - Unban Seseorang",
                "`!t [@user/id] [time] [reason]` - Timeout Seseorang",
                "`!ut [@user/id]` - UnTimeout Seseorang",
                "`!k [@user/id] [reason]` - Kick Seseorang",
                "`!w [@user/id] [reason]` - Warn Seseorang",
                "`!uw [@user/id]` - Unwarn Seseorang",
                "`!cw [@user/id]` - Clear Warn Seseorang",
                "`!cwk [@user/id]` - Cek Warn Seseorang"
            ].join('\n')
        },
        {
            name: "📰 System Notice",
            value: [
                "`!notiftest` - Melihat Test Dari Notif System",
                "`!setnotifch|[#channel]` - Setting Channel Notif",
                "`!setpagi|[text]` - Setting Pesan Notif Untuk Pagi Hari",
                "`!setmalam|[text]` - Setting Pesan Notif Untuk Malam",
                "`!settimenotif|[jam pagi]|[jam malam]` - Setting Waktu Notif",
                "`!unsetnotifch|[#channel]` - UnSetting Channel Notif"
            ].join('\n')
        },
        {
            name: "🎨 Image Tools",
            value: [
                "`!removebg [image]` - Untuk Menghilangkan Background Gambar",
                "`!hd [image]` - Penaikkan Resolusi Gambar (HD)",
                "`!editgambar [prompt] [image]` - Mengedit Gambar Sesuai Kemauan",
                "`!tofigure [image]` - Membuat Gambar Menjadi Figure",
                "`!text2img [prompt]` - Membuat Gambar Dari Prompt",
                "`!brat [text]` - Membuat Sticker Brat",
                "`!bratvid [text]` - Membuat Sticker Brat Video/Gif",
                "`!iqc [text]|[jam]|[batre]` - Membuat Gambar Pesan Iphone",
                "`!blurwajah` - Memblur Wajah Pada Gambar",
                "`!fakeff, !fakeml, !fakecall` - Membuat Gambar Fake"
            ].join('\n')
        },
        {
            name: "🛠 Utility Tools",
            value: [
                "`!checkfile` - Untuk Scan File Lua, Txt, Dll <#1438772534295400448>",
                "`!pastebin [text]` - Untuk Mengimport Teks Jadi link Pastebin",
                "`!cs` - Untuk Membuat Character Story SAMP <#1499917216395825224>",
                "`!teks2qr` - Membuat QR Code",
                "`!tourl` - Membuat Direct Download Link",         
                "`!obf` - Proteksi File Lua dan Js",
                "`!deobf` - Membuka Source Code Lua"
             ].join('\n')
        },
        {
            name: "🔎 Search Menu",
            value: [                           
                "`!ytsearch [judul video]` - Untuk Mengambil Link Video Dari YouTube",
                "`!ttsearch [judul]` - Mencari Link Tiktok",
                "`!pinsearch [query]` - Mencari Gambar Di Pinterest",
                "`!bbs, !bbsearch [query]` - Mencari Url Top4Top Dari Database"
            ].join('\n')
        },
        {
            name: "📟 Downloader Menu",
            value: [
                "`!ytdl [link]` - Download Video & Audio YouTube",
                "`!ttdl [link]` - Download Video & Audio Tiktok",
                "`!tt [link]` - Download Tiktok",
                "`!igdl [link]` - Download Video Instagram",
                "`!ig [link]` - Download Instagram"
            ].join('\n')
        },
        {
            name: "👁 Stalker Menu",
            value: [
                "`!ffstalk [user id]` - Stalk Game Free Fire",
                "`!mlstalk [user id]` - Stalk Game Mobile Legends",
                "`!ttstalk [username]` - Stalk Profil Tiktok",
                "`!igstalk [username]` - Stalk Profil Instagram",
                "`!twstalk [username]` - Stalk Profil Twitter",
                "`!gitstalk [username]` - Stalk Profil GitHub"
            ].join('\n')
        },
        {
            name: "🎯 Fun Menu",
            value: [
                "`!tod [@user]` - Bot Memberi Truth Or Dare",
                "`!ramal [@user]` - Ramalan Fun Dari Bot",
                "`!tebakkata` - Bot Akan Memberi Game Tebak Kata Dengan Clue",
                "`!roasting [@user]` - Bot Akan Rosting User",
                "`!english` - Bot Akan Memberi Game English",
                "`!tebakgambar` - Tebak Gambar Ini!",
                "`!tebakbendera` - Tebak Bendera Negara",
                "`!siapakahaku` - Siapakah Aku??",
                "`!susunkata` - Susun Kata Menjadi Bagus",
                "`!tebaktebakan` - Tebak Dari Petunjuk",
                "`!tekateki` - Teka Teki",
                "`!family100` - Game Family 100 Seperti Televisi"
            ].join('\n')
        },
        {
            name: "🆔 ID Cheking",
            value: [
                "`!getiduser [@user]` - Mendapatkan User ID",
                "`!cekiduser [user id]` - Cek User ID Siapa?",
                "`!getidguild` - Mendapatkan ID Server Discord",
                "`!cekidguild [guild id]` - Cek ID Guild",
                "`!linkdc` - Memberikan Link Invite Discord"
            ].join('\n')
        },
        {
            name: "🗣️ Public Features",
            value: [
                "`!myw` - Melihat Warn",
                "`!owner` - Untuk Melihat Owner",
                "`!ping` - Melihat Ping Status Bot",
                "`!changename [new name]` - Untuk Mengubah Nama Server <#1440517187273228429>",
                "`!afk dan !afk [alasan]` - Status AFK",
                "`!user` - Untuk Melihat User Information Kita",
                "`!user [@user]` - Melihat Info Orang",
                "`!server` - Melihat Info Server",
                "`Hady pp` - Melihat Avatar Seseorang",
                "`Hady pp [@user]` - Melihat Avatar Yang Di Tag",
                "`!ai [question]` - Untuk Menggunakan Fitur Chatbot Tapi Pakai Command, Chat AI <#1530547957001093260>",
                "`!bb [judul]` - Membuat Link Top4Top Dari Query di <#1455010588932702248>",
                "`hady welcome dan hady leave` - Melihat Test Pesan Welcome dan Leave",
                "`!skip [url]` - Bypass Link <#1467106460931461142>",
                "`!listserver` - Menampilkan Leaderboard Server SA-MP"
            ].join('\n')
        },
        {
            name: "💰 Economy Menu",
            value: [
                "`!work` - Bekerja Untuk Mendapatkan Uang",
                "`!daily` - Mengklaim Hadiah Uang Harian",
                "`!weekly` - Mengklaim Hadiah Uang Mingguan",
                "`!deposite [jumlah], !depositeall, !depoall` - Menyimpan Uang Ke Bank",
                "`!withdraw [jumlah], !withdrawall, !withall` - Mengambil Uang Dari Bank",
                "`!balance` - Melihat Saldo Dompet Dan Bank",
                "`!rob` - Merampok Uang Dompet Pengguna Lain",
                "`!hunt` - Berburu Hewan Liar Di Hutan",
                "`!fish` - Memancing Ikan Di Sungai Atau Laut",
                "`!mine` - Menambang Mineral Berharga Di Gua",
                "`!inventory, !inv, !tas` - Melihat Isi Tas Pribadi",
                "`!sell [item] [jumlah], !sellall` - Menjual Barang Dari Inventory",
                "`!shop` - Melihat Daftar Barang Di Toko",
                "`!buy [item] [jumlah]` - Membeli Barang Dari Toko",
                "`!transfermoney, !tf, !transfer [@user] [jumlah]` - Mentransfer Uang Ke Pengguna Lain",
                "`!mystats, !me, !stats` - Melihat Informasi Lengkap Profil Status",
                "`!addmoney [@user] [jumlah]` - Menambahkan Uang Saku Pengguna Khusus Admin",
                "`!takemoney [@user] [jumlah]` - Mengurangi Uang Saku Pengguna Khusus Admin",
                "`!cekinventory, !cekinv, !cektas [@user]` - Memeriksa Isi Tas Pengguna Lain (Only Admin)",
                "`!cekstats [@user]` - Melihat Status Player (Only Admin)",
                "`!resetmoney [@user]` - Reset Semua Uang Player (Only Admin)",
                "`!resetuser [@user]` - Reset Semua Yang Dimiliki Player (Only Admin)",
                "`!resetlevel [@user]` - Reset Level Player (Only Admin)"
            ].join('\n')
        }
    ];

    // Membagi otomatis jika isi kategori melebihi batas 1500 karakter agar rapi
    const daftarHalaman = [
        { tipe: 'utama', judul: `☠️ ${message.client.user.username} || List Command Menu`, isi: deskripsiUtama, referensiKategori: "all_menu" }
    ];

    for (const f of fields) {
        const baris = f.value.split('\n');
        let teksHalaman = "";
        let counterBagian = 1;

        for (const b of baris) {
            if ((teksHalaman + b).length > 1500) {
                daftarHalaman.push({
                    tipe: 'kategori',
                    judul: `${f.name} (Bagian ${counterBagian})`,
                    isi: teksHalaman.trim(),
                    referensiKategori: f.name
                });
                teksHalaman = "";
                counterBagian++;
            }
            teksHalaman += b + "\n";
        }
        if (teksHalaman.trim().length > 0) {
            daftarHalaman.push({
                tipe: 'kategori',
                judul: counterBagian > 1 ? `${f.name} (Bagian ${counterBagian})` : f.name,
                isi: teksHalaman.trim(),
                referensiKategori: f.name
            });
        }
    }

    let halamanSekarang = 0;

    const buatEmbed = (indeks) => {
        const dataHalaman = daftarHalaman[indeks];
        const embed = new EmbedBuilder()
            .setTitle(dataHalaman.judul)
            .setDescription(dataHalaman.isi)
            .setColor("Blue")
            .setThumbnail(message.client.user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: `Halaman ${indeks + 1}/${daftarHalaman.length} | By ${message.client.user.tag} -_-` });

        if (dataHalaman.tipe === 'utama' || dataHalaman.tipe === 'kategori') {
            embed.setImage("https://api.kabox.my.id/file/6e09ea1245f60bda.gif");
        }
        return embed;
    };

    const buatKomponen = (indeks) => {
        const tombolPrev = new ButtonBuilder()
            .setCustomId('prev_menu')
            .setLabel('⬅️ Prev')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(indeks === 0);

        const tombolAll = new ButtonBuilder()
            .setCustomId('all_menu')
            .setLabel('🌀 All Menu')
            .setStyle(ButtonStyle.Primary);

        const tombolNext = new ButtonBuilder()
            .setCustomId('next_menu')
            .setLabel('Next ➡️')
            .setStyle(ButtonStyle.Success)
            .setDisabled(indeks === daftarHalaman.length - 1);

        const rowButton = new ActionRowBuilder().addComponents(tombolPrev, tombolAll, tombolNext);

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('pilih_menu')
            .setPlaceholder('👉 Pilih Kategori Menu')
            .addOptions(
                new StringSelectMenuOptionBuilder().setLabel('🌀 All Menu').setValue('all_menu'),
                ...fields.map(f => new StringSelectMenuOptionBuilder().setLabel(f.name).setValue(f.name))
            );
            
        const dataHalaman = daftarHalaman[indeks];
        if (dataHalaman.referensiKategori) {
            const opsiCocok = selectMenu.options.find(opt => opt.data.value === dataHalaman.referensiKategori);
            if (opsiCocok) opsiCocok.setDefault(true);
        }

        const rowSelect = new ActionRowBuilder().addComponents(selectMenu);

        return [rowSelect, rowButton];
    };

    const response = await message.channel.send({
        embeds: [buatEmbed(halamanSekarang)],
        components: buatKomponen(halamanSekarang)
    });

    try {
        const audioPath = path.join(__dirname, '../vn/menu.mp3');
        if (fs.existsSync(audioPath)) {
            await message.channel.send({
                files: [{
                    attachment: audioPath,
                    name: 'HC Assistant.mp3'
                }]
            });
        }
    } catch (audioErr) {
        // Silent error jika terjadi kendala pada pembacaan file audio
    }

    // Kolektor tanpa parameter 'time' agar selalu aktif selamanya
    const collector = response.createMessageComponentCollector();

    collector.on('collect', async (i) => {
        const targetId = message.author?.id || message.user?.id;
        if (i.user.id !== targetId) {
            return i.reply({ content: "❌ Kamu tidak bisa menggunakan menu ini.", ephemeral: true });
        }

        // Handle aksi dari Select Menu
        if (i.isStringSelectMenu() && i.customId === 'pilih_menu') {
            const selectedValue = i.values[0];
            
            if (selectedValue === 'all_menu') {
                halamanSekarang = 0;
                await i.update({
                    embeds: [buatEmbed(halamanSekarang)],
                    components: buatKomponen(halamanSekarang)
                }).catch(() => {});
                
                // Mengirimkan semua menu terpisah ke channel
                for (const field of fields) {
                    const embed = new EmbedBuilder()
                        .setTitle(field.name)
                        .setDescription(field.value)
                        .setColor("Blue")
                        .setFooter({ text: `By ${message.client.user.tag} -_-` });
                    await message.channel.send({ embeds: [embed] });
                }
                return;
            } else {
                const indeksCocok = daftarHalaman.findIndex(h => h.referensiKategori === selectedValue);
                if (indeksCocok !== -1) {
                    halamanSekarang = indeksCocok;
                }
            }
        } 
        // Handle aksi dari Buttons
        else if (i.isButton()) {
            if (i.customId === 'all_menu') {
                await i.reply({ content: "Mengirimkan seluruh menu...", ephemeral: true });
                for (const field of fields) {
                    const embed = new EmbedBuilder()
                        .setTitle(field.name)
                        .setDescription(field.value)
                        .setColor("Blue")
                        .setFooter({ text: `By ${message.client.user.tag} -_-` });
                    await message.channel.send({ embeds: [embed] });
                }
                return;
            }

            if (i.customId === 'next_menu') {
                if (halamanSekarang < daftarHalaman.length - 1) halamanSekarang++;
            } else if (i.customId === 'prev_menu') {
                if (halamanSekarang > 0) halamanSekarang--;
            }
        }

        await i.update({
            embeds: [buatEmbed(halamanSekarang)],
            components: buatKomponen(halamanSekarang)
        }).catch(() => {});
    });
};

module.exports = {
    setup: (client) => {
        if (!client._msgHandlers) client._msgHandlers = [];
        client._msgHandlers.push(async (message) => {
            const command = message.content.trim().toLowerCase();
            if (command === "!menu" || command === "!help") {
                await tampilkanMenu(message);
            }
        });
    },
    tampilkanMenu
};