const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

// Jalur ke file owner.json
const ownerPath = path.join(__dirname, "..", "database", "owner.json");

module.exports = {
    data: [
        new SlashCommandBuilder()
            .setName("linkinvitebot")
            .setDescription("Dapatkan link invite bot (Hanya Owner).")
            .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
            .toJSON()
    ],
    setup: function(client) {
        (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            if (interaction.commandName === "linkinvitebot") {
                // Load data owner
                let ownerData = { owner: "" };
                try {
                    if (fs.existsSync(ownerPath)) {
                        ownerData = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
                    }
                } catch (e) {
                    console.error("Gagal membaca owner.json:", e);
                }
                // Proteksi Owner
                if (interaction.user.id !== ownerData.owner) {
                    return interaction.reply({ 
                        content: "❌ Hanya Owner Yang Bisa Gunakan", 
                        ephemeral: true 
                    });
                }
                const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;
                
                return interaction.reply({ 
                    content: `Berikut adalah link invite bot :\n${inviteLink}`, 
                    ephemeral: true 
                });
            }
        });
        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
            if (message.author.bot) return;
            const args = message.content.split(" ");
            const command = args[0].toLowerCase();
            // !linkdc
            if (command === "!linkdc") {
                if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return message.reply("❌ Hanya Admin Yang Bisa Gunakan");
                }
                try {
                    const defaultChannel = message.guild.channels.cache
                        .filter(c => c.type === 0 && c.permissionsFor(message.guild.members.me).has("CreateInstantInvite"))
                        .first();
                    
                    if (defaultChannel) {
                        const invite = await defaultChannel.createInvite({ maxAge: 0, maxUses: 0 });
                        return message.reply(`Berikut adalah link invite server ini: ${invite.url}`);
                    } else {
                        return message.reply("Saya tidak memiliki izin untuk membuat link invite di server ini.");
                    }
                } catch (err) {
                    return message.reply("Gagal membuat link invite.");
                }
            }
            // !getidch #channel
            if (command === "!getidch" || command === "!idch") {
                const channel = message.mentions.channels.first() || message.channel;
                if (!channel) return;
                return message.reply(`\`\`${channel.id}\`\``);
            }
            // !getidguild
            if (command === "!getidguild" || command === "!idguild") {
                return message.reply(`\`\`${message.guild.id}\`\``);
            }
            // !cekidch id channel
            if (command === "!cekidch" || command === "!cekch") {
                const id = args[1];
                if (!id) return;
                return message.reply(`<#${id}>`);
            }
            // !getiduser @user
            if (command === "!getiduser" || command === "!iduser") {
                let user = message.mentions.users.first();
                
                // Cek jika command membalas (reply) pesan seseorang
                if (!user && message.reference) {
                    const repliedMessage = await message.channel.messages.fetch(message.reference.messageId);
                    user = repliedMessage.author;
                }
                
                if (!user) return;
                return message.reply(`\`\`${user.id}\`\``);
            }
            // !cekiduser id user
            if (command === "!cekiduser" || command === "!cekid") {
                const id = args[1];
                if (!id) return;
                return message.reply(`<@${id}>`);
            }
            // !cekidguild id server
            if (command === "!cekidguild") {
                const id = args[1];
                if (!id) return;
                try {
                    const guild = await client.guilds.fetch(id);
                    let inviteLink = "Tidak dapat membuat link invite";
                    const defaultChannel = guild.channels.cache
                        .filter(c => c.type === 0 && c.permissionsFor(guild.members.me).has("CreateInstantInvite"))
                        .first();
                    if (defaultChannel) {
                        const invite = await defaultChannel.createInvite({ maxAge: 0, maxUses: 0 });
                        inviteLink = invite.url;
                    }
                    const embed = new EmbedBuilder()
                        .setColor("Blue")
                        .setTitle("📋 Information Guild ID")
                        .setDescription(`**Nama Server** :\n${guild.name}\n\n**ID Server** :\n${id}\n\n**Link Invite Server** :\n${inviteLink}`);
                    return message.reply({ embeds: [embed] });
                } catch (err) {
                    return message.reply("Bot tidak ada di server tersebut atau ID salah.");
                }
            }
        });
    }
};