const { ChannelType, PermissionsBitField } = require("discord.js");

function setup(client) {

(client._msgHandlers = client._msgHandlers || []).push(async (message) => {

if (message.author.bot) return;  

const content = message.content.toLowerCase();  

// COMMAND YANG MASIH ADA

if (

    !content.startsWith("!createchannel") &&

    !content.startsWith("!deletechannel") &&

    !content.startsWith("!renamechannel") &&

    !content.startsWith("!createcategory")

) return;

if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

    return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

}

// ====================================================

// CREATE CHANNEL (BARU) → !createchannel nama type

// ====================================================

if (content.startsWith("!createchannel")) {

    const args = message.content.split(" ").slice(1); // ambil setelah command

    const nama = args[0]; 

    const typeArg = args[1]?.toLowerCase() || "text";

    if (!nama)

        return message.reply("❌ Format Salah : `!createchannel nama text/voice/forum`");

    let type = ChannelType.GuildText;

    if (typeArg === "voice") type = ChannelType.GuildVoice;

    else if (typeArg === "forum") type = ChannelType.GuildForum;

    try {

        const channel = await message.guild.channels.create({

            name: nama,

            type,

        });

        message.reply(`Channel **${channel.name}** (${typeArg}) berhasil dibuat!`);

    } catch (err) {

        console.error(err);

        message.reply("Gagal bikin channel.");

    }

}

// ====================================================

// DELETE CHANNEL (BARU) → !deletechannel #channel

// ====================================================

if (content.startsWith("!deletechannel")) {

    const args = message.content.split(" ");

    const target = args[1];

    if (!target)

        return message.reply("❌ Format Salah : `!deletechannel #channel`");

    try {

        let channel;

        if (target.startsWith("<#") && target.endsWith(">")) {

            const channelId = target.replace(/[<#>]/g, "");

            channel = await message.guild.channels.fetch(channelId);

        }

        if (!channel) return message.reply("Channel tidak ditemukan!");

        await channel.delete();

        message.reply(`Channel **${channel.name}** berhasil dihapus.`);

    } catch (err) {

        console.error("Gagal hapus channel:", err);

        message.reply("Terjadi error saat menghapus channel.");

    }

}

// ====================================================

// RENAME CHANNEL (BARU) → !renamechannel #channel nama-baru

// ====================================================

if (content.startsWith("!renamechannel")) {

    const args = message.content.split(" ");

    const target = args[1];

    const newName = args.slice(2).join(" ").trim();

    if (!target || !newName) {

        return message.reply("❌ Format Salah : `!renamechannel #channel nama baru`");

    }

    try {

        let channel;

        if (target.startsWith("<#") && target.endsWith(">")) {

            const channelId = target.replace(/[<#>]/g, "");

            channel = await message.guild.channels.fetch(channelId);

        }

        if (!channel)

            return message.reply("Channel tidak ditemukan!");

        await channel.setName(newName);

        message.reply(`Channel **${channel.name}** berhasil diubah jadi **${newName}**.`);

    } catch (err) {

        console.error("Gagal rename channel:", err);

        message.reply("Terjadi error saat mengganti nama channel.");

    }

}

// ====================================================

// CREATE CATEGORY (BARU) → !createcategory nama

// ====================================================

if (content.startsWith("!createcategory")) {

    const args = message.content.split(" ").slice(1);

    const nama = args.join(" ").trim();

    if (!nama)

        return message.reply("❌ Format Salah : `!createcategory nama`");

    try {

        const category = await message.guild.channels.create({

            name: nama,

            type: ChannelType.GuildCategory,

        });

        message.reply(`Kategori **${category.name}** berhasil dibuat!`);

    } catch (err) {

        console.error(err);

        message.reply("Gagal bikin kategori.");

    }

}

// ====================================================

// PERINTAH LO → HAPUS DELETECATEGORY dan RENAMECATEGORY

// ====================================================

// SAYA TIDAK MENYERTAKAN KEDUANYA LAGI. SELESAI.

});

}

module.exports = { setup };
