// system.js  
const { EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = "./database/notif_settings.json";

// Tanpa default bawaan — semua SET lewat command
let settings = {};
if (fs.existsSync(path)) {
  settings = JSON.parse(fs.readFileSync(path));
} else {
  fs.writeFileSync(path, JSON.stringify(settings, null, 2));
}

function saveSettings() {
  fs.writeFileSync(path, JSON.stringify(settings, null, 2));
}

module.exports = {
  setup(client) {

    // =====================================
    //        FUNGSI NOTIF PAGI
    // =====================================
    function sendMorning() {
      const channel = client.channels.cache.get(settings.channel);
      if (!channel) return;

      const embed = new EmbedBuilder()
        .setColor("Yellow")
        .setTitle("[ System Notice ]")
        .setDescription(settings.textMorning);

      channel.send({
        content: "@everyone",
        embeds: [embed]
      });
    }

    // =====================================
    //        FUNGSI NOTIF MALAM
    // =====================================
    function sendNight() {
      const channel = client.channels.cache.get(settings.channel);
      if (!channel) return;

      const embed = new EmbedBuilder()
        .setColor("Blue")
        .setTitle("[ System Notice ]")
        .setDescription(settings.textNight);

      channel.send({
        content: "@everyone",
        embeds: [embed]
      });
    }

    // =====================================
    //  FIX WAKTU WIB (UTC+7) + TIMER
    // =====================================
    setInterval(() => {
      if (!settings.morning || !settings.night || !settings.channel) return;

      const now = new Date();
      const wibHours = (now.getUTCHours() + 7) % 24;
      const wibMinutes = now.getUTCMinutes();

      const h = wibHours.toString().padStart(2, "0");
      const m = wibMinutes.toString().padStart(2, "0");

      const nowTime = `${h}:${m}`;

      if (nowTime === settings.morning) sendMorning();
      if (nowTime === settings.night) sendNight();

    }, 60000);

    // =====================================
    //      COMMAND HANDLER
    // =====================================
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot) return;
      const msg = message.content.toLowerCase();

      // ==========================================
      //              !notiftest
      // ==========================================
      if (msg === "!notiftest") {

        if (!message.member.permissions.has("Administrator"))
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

        // Jika pagi & malam dua-duanya sudah diset
        const embed = new EmbedBuilder()
          .setColor("Green")
          .setTitle("[ System Notice ]")
          .setDescription(
            `**Teks Pagi:**\n${settings.textMorning || "-"}\n\n` +
            `**Teks Malam:**\n${settings.textNight || "-"}`
          );

        return message.channel.send({
          content: "@everyone",
          embeds: [embed]
        });
      }

      // ==========================================
      //        SET CHANNEL NOTIF
      // ==========================================
      if (msg.startsWith("!setnotifch")) {
        if (!message.member.permissions.has("Administrator"))
          return message.reply("Kamu bukan admin!");

        const ch = message.mentions.channels.first();
        if (!ch)
          return message.reply("Tag channelnya!\nContoh:\n`!setnotifch | #general`");

        settings.channel = ch.id;
        saveSettings();

        return message.reply(`Channel notif diatur ke ${ch}`);
      }

      // ==========================================
      //        UNSET CHANNEL NOTIF
      // ==========================================
      if (msg.startsWith("!unsetnotifch")) {
        if (!message.member.permissions.has("Administrator"))
          return message.reply("Kamu bukan admin!");

        const ch = message.mentions.channels.first();
        if (!ch)
          return message.reply("Tag channelnya!\nContoh:\n`!unsetnotifch | #general`");

        if (ch.id !== settings.channel) {
          return message.reply("Channel itu **bukan** channel notif yang sedang dipakai.");
        }

        settings.channel = "";
        saveSettings();

        return message.reply(`Channel notif dimatikan.`);
      }

      // ==========================================
      //       SET WAKTU PAGI & MALAM
      // ==========================================
      if (msg.startsWith("!settimenotif")) {
        if (!message.member.permissions.has("Administrator"))
          return message.reply("Kamu bukan admin!");

        const parts = message.content.split("|").map(x => x.trim());
        if (!parts[1] || !parts[2])
          return message.reply("Format salah.\nContoh:\n`!settimenotif | 05:00 | 22:00`");

        settings.morning = parts[1];
        settings.night = parts[2];

        saveSettings();

        return message.reply(
          `Waktu notif diatur:\n🌅 Pagi: **${settings.morning}**\n🌙 Malam: **${settings.night}**`
        );
      }

      // ==========================================
      //        SET TEKS PAGI
      // ==========================================
      if (msg.startsWith("!setpagi")) {
        if (!message.member.permissions.has("Administrator"))
          return message.reply("Kamu bukan admin!");

        const parts = message.content.split("|").map(x => x.trim());
        if (!parts[1])
          return message.reply("Format salah.\nContoh:\n`!setpagi | Selamat pagi semua`");

        settings.textMorning = parts[1];
        saveSettings();

        return message.reply("Teks notifikasi pagi berhasil diatur.");
      }

      // ==========================================
      //        SET TEKS MALAM
      // ==========================================
      if (msg.startsWith("!setmalam")) {
        if (!message.member.permissions.has("Administrator"))
          return message.reply("Kamu bukan admin!");

        const parts = message.content.split("|").map(x => x.trim());
        if (!parts[1])
          return message.reply("Format salah.\nContoh:\n`!setmalam | Selamat malam semuanya`");

        settings.textNight = parts[1];
        saveSettings();

        return message.reply("Teks notifikasi malam berhasil diatur.");
      }

      // ==========================================
      //              !notif INFO
      // ==========================================
      if (msg === "!notif") {
        if (!message.member.permissions.has("Administrator"))
          return message.reply("Kamu bukan admin!");

        const embed = new EmbedBuilder()
          .setColor("Purple")
          .setTitle("Pengaturan Notifikasi")
          .addFields(
            {
              name: "📢 Channel",
              value: settings.channel ? `<#${settings.channel}>` : "Tidak diset",
              inline: false
            },
            { name: "🌅 Jam Pagi", value: settings.morning || "-", inline: true },
            { name: "🌙 Jam Malam", value: settings.night || "-", inline: true },
            { name: "☀️ Teks Pagi", value: settings.textMorning || "-", inline: false },
            { name: "🌑 Teks Malam", value: settings.textNight || "-", inline: false },
          );

        return message.channel.send({ embeds: [embed] });
      }

    });

  }
};