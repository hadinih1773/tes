const { PermissionsBitField } = require("discord.js");

function nama(client) {

  (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

    // Biar bot gak respon ke dirinya sendiri

    if (message.author.bot) return;

    // Pastikan command diawali dengan !nama

    if (!message.content.startsWith("!nama")) return;

    // Cek izin admin (hanya admin yang bisa gunakan)

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

      return message.reply("❌ Hanya Admin Yang Bisa Gunakan");

    }

    // Format command: !nama @user NamaBaru

    const args = message.content.trim().split(/\s+/);

    const member = message.mentions.members.first();

    if (!member) {

      return message.reply("❌ Format salah : `!nama @user NamaBaru`");

    }

    // Ambil nama baru tanpa split koma, langsung gabung dari args

    const newName = args.slice(2).join(" ");

    if (!newName) {

      return message.reply("⚠️ Nama barunya mana?");

    }

    // Cek apakah bot punya izin dan role lebih tinggi

    const botMember = await message.guild.members.fetch(client.user.id);

    if (botMember.roles.highest.position <= member.roles.highest.position && message.guild.ownerId !== member.id) {

      return message.reply("⚠️ Bot gak bisa ubah nama orang yang rolenya sama atau lebih tinggi dari bot.");

    }

    // Ubah nickname

    try {

      await message.guild.members.edit(member.id, { nick: newName });

      message.reply(`✅ Nama **${member.user.tag}** berhasil diubah jadi **${newName}**`);

    } catch (err) {

      console.error(err);

      message.reply("⚠️ Gagal ubah nama. Pastikan bot punya izin Manage Nicknames & role di atas target.");

    }

  });

}

// panggil pakai const setupName = require("./nama"); setupName(client);

module.exports = function setupName(client) {

  nama(client);

};