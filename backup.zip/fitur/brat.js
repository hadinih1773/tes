const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

const axios = require('axios');

module.exports = {

    setup: (client) => {

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            if (message.author.bot) return;

            const isBrat = message.content.startsWith('!brat ');

            const isBratVid = message.content.startsWith('!bratvid ');

            if (!isBrat && !isBratVid) return;

            const command = isBrat ? '!brat' : '!bratvid';

            const args = message.content.slice(command.length).trim().split(/ +/);

            const text = args.join(' ');

            if (!text) return;

            // 1. Embed Proses (Biru) membalas pesan user

            const processEmbed = new EmbedBuilder()

                .setColor(0x0099FF)

                .setTitle('🔄 Brat Sedang Proses')

                .setDescription('⏳ Sedang Diproses, Mohon Ditunggu');

            const statusMsg = await message.reply({ embeds: [processEmbed] });

            try {

                // Tentukan API dan nama file (diubah ke .gif untuk bratvid)

                const apiBase = isBrat ? 'brat' : 'bratvid';

                const fileName = isBrat ? 'brat.png' : 'brat.gif';

                const apiUrl = `https://api-faa.my.id/faa/${apiBase}?text=${encodeURIComponent(text)}`;

                

                const response = await axios.get(apiUrl, { 

                    timeout: 0, 

                    responseType: 'arraybuffer' 

                });

                const attachment = new AttachmentBuilder(response.data, { name: fileName });

                // 2. Kirim hasil berupa file saja tanpa teks/tag

                await message.channel.send({ 

                    files: [attachment] 

                });

                

                // Hapus pesan status proses

                await statusMsg.delete().catch(() => null);

            } catch (error) {

                console.error(error);

                await statusMsg.edit({ content: `Gagal membuat ${isBrat ? 'gambar' : 'video'} brat.`, embeds: [] });

            }

        });

    }

};