const axios = require('axios');

const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

module.exports = {

    setup: (client) => {

        (client._msgHandlers = client._msgHandlers || []).push(async (message) => {

            const prefix = '!';

            if (!message.content.startsWith(prefix) || message.author.bot) return;

            const args = message.content.slice(prefix.length).trim().split(/ +/);

            const command = args.shift().toLowerCase();

            if (command === 'iqc') {

                const input = args.join(' ');

                const parts = input.split('|');

                if (parts.length < 3) {

                    return message.reply('❌ Format Salah : `!iqc teks|jam|batre`');

                }

                const prompt = parts[0].trim();

                const jam = parts[1].trim();

                const batre = parts[2].trim();

                const procEmbed = new EmbedBuilder()

                    .setColor('#f39c12')

                    .setDescription('⌛ **Sedang membuat gambar...**');

                const statusMsg = await message.channel.send({ embeds: [procEmbed] });

                try {

                    const apiUrl = `https://api-faa.my.id/faa/iqcv2?prompt=${encodeURIComponent(prompt)}&jam=${encodeURIComponent(jam)}&batre=${encodeURIComponent(batre)}`;

                    

                    // Kita ambil data sebagai 'arraybuffer' karena API mengirimkan file gambar langsung

                    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

                    // Bungkus data gambar menjadi attachment Discord

                    const attachment = new AttachmentBuilder(Buffer.from(response.data), { name: 'iqc-result.png' });

                    // Kirim gambarnya saja

                    await message.channel.send({ files: [attachment] });

                    // Hapus pesan loading

                    await statusMsg.delete();

                } catch (error) {

                    console.error('Error IQC:', error.message);

                    const errEmbed = new EmbedBuilder()

                        .setColor('#ff0000')

                        .setDescription('❌ Gagal mengambil gambar dari API. Pastikan format benar.');

                    

                    await statusMsg.edit({ embeds: [errEmbed] });

                }

            }

        });

    }

};