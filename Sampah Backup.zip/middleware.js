import { createClient } from "@supabase/supabase-js";

// ==========================================================
// middleware.js
// Berjalan di setiap request ke website (bukan cuma /api).
// Kalau IP pengunjung ada di tabel "blocked_ips" (diisi otomatis
// oleh api/_antispam.js saat spam terdeteksi), request langsung
// ditolak dengan halaman 403 - IP itu tidak bisa melihat/membuka
// halaman apa pun di website ini lagi.
// ==========================================================

export const config = {
    runtime: "nodejs",
    // Semua path KECUALI asset gambar & favicon (biar tidak boros query DB
    // untuk file statis yang tidak penting untuk diblokir).
    matcher: "/((?!src/image|favicon.ico).*)"
};

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
);

function getIp(request) {
    const fwd = request.headers.get("x-forwarded-for");
    if (fwd) return fwd.split(",")[0].trim();
    return request.headers.get("x-real-ip") || "unknown";
}

function blockedPage(ip) {
    return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Akses Diblokir</title>
<style>
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
    background:#0d0f14;color:#fff;font-family:sans-serif;text-align:center;}
  .box{padding:32px;}
  h1{font-size:28px;margin-bottom:8px;color:#ff5c7a;}
  p{color:#9aa0ab;}
  code{color:#5c8bff;}
</style>
</head>
<body>
  <div class="box">
    <h1>🚫 Akses Diblokir</h1>
    <p>IP kamu (<code>${ip}</code>) diblokir otomatis karena terdeteksi melakukan spam.</p>
  </div>
</body>
</html>`;
}

export default async function middleware(request) {
    const ip = getIp(request);

    try {
        const { data } = await supabase
            .from("blocked_ips")
            .select("ip")
            .eq("ip", ip)
            .maybeSingle();

        if (data) {
            return new Response(blockedPage(ip), {
                status: 403,
                headers: { "Content-Type": "text/html; charset=utf-8" }
            });
        }
    } catch (err) {
        console.error("Gagal cek status blokir IP di middleware:", err);
        // fail-open: kalau DB error, jangan sampai memblokir semua orang
    }

    // Lanjut ke request asli
}
