// ==========================================================
// config.js
// PENTING: Sejak perbaikan keamanan, file ini TIDAK BOLEH lagi
// diisi password apa pun. File ini di-load ke browser semua
// pengunjung (bisa dibuka lewat View Source / DevTools), jadi
// apa pun yang ditaruh di sini otomatis bocor ke publik.
//
// Semua password (LOCK_PASSWORD, ADMIN_USERNAME, ADMIN_PASSWORD,
// MOD_DELETE_PASSWORD, SNIPPET_DELETE_PASSWORD) sekarang disimpan
// sebagai Environment Variable di server (Vercel) dan divalidasi
// lewat /api/auth.js, /api/changelog.js, /api/mod.js, /api/snippet.js.
// ==========================================================

const SITE_CONFIG = {};
