const { 
  SlashCommandBuilder, 
  EmbedBuilder, 
  ChannelType, 
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbFolder = path.join(__dirname, "../database");
const backupFile = path.join(dbFolder, "serverbackup.json");
const ownerFile = path.join(dbFolder, "owner.json");

// Pastikan database siap
if (!fs.existsSync(dbFolder)) fs.mkdirSync(dbFolder);
if (!fs.existsSync(backupFile)) fs.writeFileSync(backupFile, JSON.stringify({}, null, 2));

const getOwnerId = () => {
  try {
    if (fs.existsSync(ownerFile)) {
      const data = JSON.parse(fs.readFileSync(ownerFile, "utf8"));
      return data.owner;
    }
  } catch (err) {
    console.error("Gagal membaca file owner.json:", err);
  }
  return null;
};

const loadBackups = () => JSON.parse(fs.readFileSync(backupFile, "utf8"));
const saveBackups = (data) => fs.writeFileSync(backupFile, JSON.stringify(data, null, 2));

module.exports = {
  data: [
    new SlashCommandBuilder()
      .setName("backupserver")
      .setDescription("Backing Up The Entire Server Structure ")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option =>
        option.setName("server")
          .setDescription("Nama atau ID Server yang ingin di-backup (Opsional)")
          .setRequired(false)
          .setAutocomplete(true)
      )
      .toJSON(),
    new SlashCommandBuilder()
      .setName("restoreserver")
      .setDescription("Restore Server Backup Position ")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption(option => 
        option.setName("server")
          .setDescription("Nama atau ID Server yang telah di-backup")
          .setRequired(true)
          .setAutocomplete(true)
      )
      .toJSON()
  ],

  setup(client) {
    
    // === FUNGSI INTI BACKUP ===
    async function runBackup(guild) {
      const roles = guild.roles.cache
        .filter(r => !r.managed)
        .sort((a, b) => b.position - a.position)
        .map(r => ({
          name: r.name,
          color: r.color,
          hoist: r.hoist,
          permissions: r.permissions.bitfield.toString(),
          mentionable: r.mentionable,
          isEveryone: r.name === "@everyone"
        }));

      const channels = guild.channels.cache
        .filter(c => 
          c.type === ChannelType.GuildCategory || 
          c.type === ChannelType.GuildText || 
          c.type === ChannelType.GuildVoice ||
          c.type === ChannelType.GuildAnnouncement ||
          c.type === ChannelType.GuildForum ||
          c.type === ChannelType.GuildStageVoice
        )
        .map(c => {
          const permissionOverwrites = c.permissionOverwrites.cache.map(o => ({
            id: o.id,
            type: o.type,
            allow: o.allow.bitfield.toString(),
            deny: o.deny.bitfield.toString()
          }));

          return {
            id: c.id,
            name: c.name,
            type: c.type,
            position: c.position,
            parentId: c.parentId,
            nsfw: c.nsfw || false,
            rateLimitPerUser: c.rateLimitPerUser || 0,
            topic: c.topic || null,
            userLimit: c.userLimit || 0,
            permissionOverwrites
          };
        });

      const backups = loadBackups();
      // Mengabaikan / memperbarui data jika ID server sudah pernah di-backup
      backups[guild.id] = {
        serverName: guild.name,
        backupTime: Date.now(),
        roles,
        channels
      };
      saveBackups(backups);
    }

    // === FUNGSI HAPUS SEMUA CHANNEL & ROLE (KECUALI CHANNEL SAAT INI) ===
    async function runDeleteAll(guild, currentChannelId) {
      const currentChannels = await guild.channels.fetch();
      for (const [id, channel] of currentChannels) {
        if (id !== currentChannelId) {
          await channel.delete().catch(() => {});
        }
      }

      const currentRoles = await guild.roles.fetch();
      for (const [_, role] of currentRoles) {
        if (role.name !== "@everyone" && !role.managed) {
          await role.delete().catch(() => {});
        }
      }
    }

    // === FUNGSI INTI RESTORE ===
    async function runRestore(guild, backupData) {
      // Map untuk menyimpan relasi ID role lama dengan objek role baru
      const roleMap = new Map();

      // Konfigurasi Ulang Role
      for (const rData of backupData.roles) {
        if (rData.isEveryone) {
          await guild.roles.everyone.setPermissions(BigInt(rData.permissions)).catch(() => {});
          roleMap.set(guild.id, guild.roles.everyone.id);
        } else {
          const newRole = await guild.roles.create({
            name: rData.name,
            color: rData.color,
            hoist: rData.hoist,
            permissions: BigInt(rData.permissions),
            mentionable: rData.mentionable
          }).catch(() => null);

          if (newRole) {
            const oldRole = guild.roles.cache.find(r => r.name === rData.name);
            if (oldRole) roleMap.set(oldRole.id, newRole.id);
          }
        }
      }

      const categoryMap = new Map();
      const textAndVoiceChannels = [];

      // Urutkan susunan channel berdasarkan posisi
      const sortedChannels = backupData.channels.sort((a, b) => a.position - b.position);

      // Buat Kategori Terlebih Dahulu
      for (const cData of sortedChannels) {
        if (cData.type === ChannelType.GuildCategory) {
          const overwrites = (cData.permissionOverwrites || []).map(o => ({
            id: roleMap.get(o.id) || (o.id === guild.id ? guild.roles.everyone.id : o.id),
            type: o.type,
            allow: BigInt(o.allow),
            deny: BigInt(o.deny)
          }));

          const newCategory = await guild.channels.create({
            name: cData.name,
            type: ChannelType.GuildCategory,
            permissionOverwrites: overwrites
          }).catch(() => null);

          if (newCategory) categoryMap.set(cData.id, newCategory.id);
        } else {
          textAndVoiceChannels.push(cData);
        }
      }

      // Buat Channel Teks, Voice, Announcement, Forum, dan Stage
      for (const cData of textAndVoiceChannels) {
        const overwrites = (cData.permissionOverwrites || []).map(o => ({
          id: roleMap.get(o.id) || (o.id === guild.id ? guild.roles.everyone.id : o.id),
          type: o.type,
          allow: BigInt(o.allow),
          deny: BigInt(o.deny)
        }));

        await guild.channels.create({
          name: cData.name,
          type: cData.type,
          parent: categoryMap.get(cData.parentId) || null,
          nsfw: cData.nsfw,
          topic: cData.topic,
          rateLimitPerUser: cData.rateLimitPerUser,
          userLimit: cData.userLimit,
          permissionOverwrites: overwrites
        }).catch(() => null);
      }
    }

    // === HANDLE INTERACTION (SLASH COMMAND & AUTOCOMPLETE) ===
    (client._interactionHandlers = client._interactionHandlers || []).push(async (interaction) => {
      const ownerId = getOwnerId();

      // HANDLE AUTOCOMPLETE UNTUK BACKUPSERVER & RESTORESERVER
      if (interaction.isAutocomplete()) {
        if (interaction.user.id !== ownerId) return await interaction.respond([]);

        if (interaction.commandName === "backupserver") {
          const focusedValue = interaction.options.getFocused().toLowerCase();
          const choices = client.guilds.cache.map(g => ({
            name: g.name,
            value: g.id
          }));

          const filtered = choices.filter(choice =>
            choice.name.toLowerCase().includes(focusedValue) || choice.value.includes(focusedValue)
          ).slice(0, 25);

          return await interaction.respond(filtered);
        }

        if (interaction.commandName === "restoreserver") {
          const focusedValue = interaction.options.getFocused().toLowerCase();
          const backups = loadBackups();
          
          const choices = Object.keys(backups).map(id => ({
            name: backups[id].serverName,
            value: id
          }));

          const filtered = choices.filter(choice =>
            choice.name.toLowerCase().includes(focusedValue) || choice.value.includes(focusedValue)
          ).slice(0, 25);

          return await interaction.respond(filtered);
        }

        return;
      }

      // HANDLE SLASH COMMANDS EXECUTION
      if (!interaction.isChatInputCommand()) return;
      
      const { commandName, options, guild, user, channel } = interaction;

      if (commandName === "backupserver" || commandName === "restoreserver") {
        if (user.id !== ownerId) {
          return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
        }
      }

      if (commandName === "backupserver") {
        await interaction.deferReply({ ephemeral: true });
        const targetGuildId = options.getString("server");
        const targetGuild = targetGuildId ? client.guilds.cache.get(targetGuildId) : guild;

        if (!targetGuild) {
          return interaction.editReply({ content: "❌ Server tidak ditemukan atau bot tidak berada di server tersebut." });
        }

        try {
          await runBackup(targetGuild);
          await interaction.editReply({ content: `✅ Struktur server **${targetGuild.name}** berhasil dicadangkan ke database.` });
        } catch (err) {
          console.error(err);
          await interaction.editReply({ content: "❌ Terjadi kesalahan saat melakukan backup." });
        }
      }

      if (commandName === "restoreserver") {
        await interaction.deferReply({ ephemeral: true });
        const backupKey = options.getString("server");
        const backups = loadBackups();

        if (!backups[backupKey]) {
          return interaction.editReply({ content: "❌ Data cadangan server tidak ditemukan." });
        }

        const backupData = backups[backupKey];

        // Buat Embed Preview berwarna Hijau Emerald (#50C878)
        const embed = new EmbedBuilder()
          .setTitle("📋 Server Restore Preview")
          .setColor("#50C878")
          .setDescription(`**Server Name:** ${backupData.serverName}\n**Backup Time:** <t:${Math.floor(backupData.backupTime / 1000)}:F>`)
          .addFields(
            { name: "Roles Count", value: `${backupData.roles ? backupData.roles.length : 0}`, inline: true },
            { name: "Channels Count", value: `${backupData.channels ? backupData.channels.length : 0}`, inline: true }
          );

        // Buat Barisan Button
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("delete_all")
            .setLabel("🚮 Delete All")
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId("restore")
            .setLabel("🔄 Restore")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId("cancel")
            .setLabel("❌ Cancel")
            .setStyle(ButtonStyle.Danger)
        );

        const response = await interaction.editReply({
          embeds: [embed],
          components: [row]
        });

        // Filter kolektor hanya untuk owner yang memanggil perintah
        const collector = response.createMessageComponentCollector({
          filter: i => i.user.id === ownerId,
          time: 60000
        });

        collector.on("collect", async (i) => {
          await i.deferUpdate().catch(() => {});

          if (i.customId === "delete_all") {
            await interaction.editReply({ content: "⏳ Memproses penghapusan seluruh channel & role...", embeds: [embed], components: [row] });
            try {
              await runDeleteAll(guild, channel.id);
              await interaction.editReply({ content: "✅ Seluruh channel & role berhasil dihapus (kecuali channel ini).", embeds: [embed], components: [row] });
            } catch (err) {
              console.error(err);
              await interaction.editReply({ content: "❌ Terjadi kesalahan saat menghapus channel/role.", embeds: [embed], components: [row] });
            }
          } else if (i.customId === "restore") {
            await interaction.editReply({ content: "⏳ Memproses pemulihan struktur server...", embeds: [embed], components: [row] });
            try {
              await runRestore(guild, backupData);
              await interaction.editReply({ content: "✅ Pemulihan struktur server selesai dilakukan sesuai data cadangan!", embeds: [embed], components: [row] });
            } catch (err) {
              console.error(err);
              await interaction.editReply({ content: "❌ Terjadi kesalahan saat memulihan struktur server.", embeds: [embed], components: [row] });
            }
          } else if (i.customId === "cancel") {
            await interaction.editReply({ content: "❌ Proses dibatalkan.", embeds: [], components: [] });
          }
        });

        collector.on("end", async (_, reason) => {
          if (reason === "time") {
            await interaction.editReply({ components: [] }).catch(() => {});
          }
        });
      }
    });

  }
};
