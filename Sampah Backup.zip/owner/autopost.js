const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  InteractionType
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const dbPath = path.join(__dirname, "..", "database", "autopost.json");
const ownerDbPath = path.join(__dirname, "..", "database", "owner.json");

// Memory storage sementara untuk draf pengisian data per user
const createSessions = new Map();
const editSessions = new Map();
const activeIntervals = new Map();

function loadOwners() {
  try {
    if (!fs.existsSync(ownerDbPath)) return [];
    const data = JSON.parse(fs.readFileSync(ownerDbPath, "utf8"));
    if (typeof data.owner === "string") return [data.owner];
    if (Array.isArray(data.owner)) return data.owner;
    if (Array.isArray(data)) return data;
    if (data.owners && Array.isArray(data.owners)) return data.owners;
    if (data.ownerId) return [data.ownerId];
    return [];
  } catch {
    return [];
  }
}

function isOwner(userId) {
  const owners = loadOwners();
  return owners.includes(userId);
}

function loadAutoPostData() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify({ sessions: [] }, null, 2));
      return { sessions: [] };
    }
    const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
    if (!Array.isArray(data.sessions)) data.sessions = [];
    return data;
  } catch {
    return { sessions: [] };
  }
}

function saveAutoPostData(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database autopost.json:", err);
  }
}

// Fungsi untuk menjalankan loop posting pesan
function startAutoPostLoop(session) {
  if (activeIntervals.has(session.name)) {
    clearInterval(activeIntervals.get(session.name));
  }

  if (!session.enabled) return;

  const delayMs = (parseInt(session.delay) || 60) * 1000;

  const interval = setInterval(async () => {
    try {
      await axios.post(
        `https://discord.com/api/v10/channels/${session.channelId}/messages`,
        { content: session.message },
        {
          headers: {
            Authorization: session.token.startsWith("Bot ") ? session.token : session.token,
            "Content-Type": "application/json"
          }
        }
      );
    } catch (err) {
      console.error(`Error AutoPost [${session.name}]:`, err.response?.data || err.message);
    }
  }, delayMs);

  activeIntervals.set(session.name, interval);
}

// Inisialisasi interval dari database saat file dimuat
function initAllIntervals() {
  const data = loadAutoPostData();
  data.sessions.forEach((s) => {
    if (s.enabled) startAutoPostLoop(s);
  });
}
initAllIntervals();

function buildCreateEmbed(draft) {
  const check = (val) => (val ? "✅" : "⬜");
  const desc =
    `📝 Isi Data Berikut Untuk Membuat AutoPost\n\n` +
    `**📋 Status Pengisian**\n` +
    `${check(draft.name)} 📌 Nama\n` +
    `${check(draft.token)} 🔑 Token\n` +
    `${check(draft.channelId)} 📡 Channel\n` +
    `${check(draft.message)} 📝 Pesan\n` +
    `${check(draft.delay)} ⏱️ Delay`;

  const embed = new EmbedBuilder()
    .setColor("#50C878")
    .setTitle("📝 Create AutoPost")
    .setDescription(desc);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ap_c_name").setLabel("📌 Nama").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ap_c_token").setLabel("🔑 Token").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ap_c_channel").setLabel("📡 Channel").setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ap_c_message").setLabel("📝 Pesan").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ap_c_delay").setLabel("⏱️ Delay").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ap_c_save").setLabel("💾 Simpan").setStyle(ButtonStyle.Success)
  );

  return { embeds: [embed], components: [row1, row2] };
}

module.exports = {
  setup: (client) => {
    // Handler Command
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      if (command === "!setupautopost") {
        if (!isOwner(message.author.id)) {
          return message.reply("❌ Hanya Owner Yang Bisa Gunakan");
        }

        const mainEmbed = new EmbedBuilder()
          .setColor("#50C878")
          .setTitle("📌 Panel AutoPost")
          .setDescription(
            "Control Panel AutoPost\n\n" +
            "Cara Penggunaan :\n" +
            "* Tekan Button Create Untuk Membuat Sesi\n" +
            "* Tekan Button Edit Untuk Edit AutoPost\n" +
            "* Tekan Button Delete Untuk Menghapus\n" +
            "* Tekan Button Toggle Untuk Mematikan Dan Menghidupkan\n" +
            "* Tekan Button List Untuk Melihat List AutoPost"
          );

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("ap_btn_create").setLabel("➕ Create").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId("ap_btn_edit").setLabel("✏️ Edit").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId("ap_btn_delete").setLabel("🗑 Delete").setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId("ap_btn_toggle").setLabel("🔄 Toggle").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId("ap_btn_list").setLabel("📋 List").setStyle(ButtonStyle.Secondary)
        );

        return message.reply({ embeds: [mainEmbed], components: [row] });
      }
    });

    // Handler Interaksi Button & Modal
    client.on("interactionCreate", async (interaction) => {
      try {
        if (!interaction.customId || !interaction.customId.startsWith("ap_")) return;

        if (!isOwner(interaction.user.id)) {
          return interaction.reply({ content: "❌ Hanya Owner Yang Bisa Gunakan", ephemeral: true });
        }

        // --- BUTTON UTAMA ---
        if (interaction.isButton()) {
          const id = interaction.customId;

          // 1. CREATE BUTTON
          if (id === "ap_btn_create") {
            createSessions.set(interaction.user.id, {});
            const payload = buildCreateEmbed({});
            return interaction.reply({ ...payload, ephemeral: true });
          }

          // 2. EDIT BUTTON
          if (id === "ap_btn_edit") {
            const db = loadAutoPostData();
            if (db.sessions.length === 0) {
              return interaction.reply({ content: "❌ Belum ada sesi AutoPost yang dibuat.", ephemeral: true });
            }

            const rows = [];
            let currentRow = new ActionRowBuilder();

            db.sessions.forEach((s, idx) => {
              if (currentRow.components.length === 5) {
                rows.push(currentRow);
                currentRow = new ActionRowBuilder();
              }
              currentRow.addComponents(
                new ButtonBuilder()
                  .setCustomId(`ap_editselect_${s.name}`)
                  .setLabel(`✏️ ${s.name}`)
                  .setStyle(ButtonStyle.Primary)
              );
            });
            if (currentRow.components.length > 0) rows.push(currentRow);

            return interaction.reply({
              content: "Pilih sesi AutoPost yang ingin diedit:",
              components: rows,
              ephemeral: true
            });
          }

          // Pilih Sesi yang Diedit
          if (id.startsWith("ap_editselect_")) {
            const sessionName = id.replace("ap_editselect_", "");
            const db = loadAutoPostData();
            const session = db.sessions.find((s) => s.name === sessionName);

            if (!session) {
              return interaction.reply({ content: "❌ Sesi tidak ditemukan.", ephemeral: true });
            }

            editSessions.set(interaction.user.id, { ...session, originalName: session.name });
            const payload = buildCreateEmbed(session);
            return interaction.reply({ content: `✏️ Editing: **${session.name}**`, ...payload, ephemeral: true });
          }

          // 3. DELETE BUTTON
          if (id === "ap_btn_delete") {
            const db = loadAutoPostData();
            if (db.sessions.length === 0) {
              return interaction.reply({ content: "❌ Belum ada sesi AutoPost.", ephemeral: true });
            }

            const rows = [];
            let currentRow = new ActionRowBuilder();

            db.sessions.forEach((s) => {
              if (currentRow.components.length === 5) {
                rows.push(currentRow);
                currentRow = new ActionRowBuilder();
              }
              currentRow.addComponents(
                new ButtonBuilder()
                  .setCustomId(`ap_delconfirm_${s.name}`)
                  .setLabel(`🗑 ${s.name}`)
                  .setStyle(ButtonStyle.Danger)
              );
            });
            if (currentRow.components.length > 0) rows.push(currentRow);

            return interaction.reply({
              content: "Pilih sesi AutoPost yang ingin dihapus:",
              components: rows,
              ephemeral: true
            });
          }

          // Konfirmasi Hapus
          if (id.startsWith("ap_delconfirm_")) {
            const sessionName = id.replace("ap_delconfirm_", "");
            let db = loadAutoPostData();

            db.sessions = db.sessions.filter((s) => s.name !== sessionName);
            saveAutoPostData(db);

            if (activeIntervals.has(sessionName)) {
              clearInterval(activeIntervals.get(sessionName));
              activeIntervals.delete(sessionName);
            }

            return interaction.update({
              content: `✅ Sesi **${sessionName}** berhasil dihapus!`,
              components: []
            });
          }

          // 4. TOGGLE BUTTON
          if (id === "ap_btn_toggle") {
            const db = loadAutoPostData();
            if (db.sessions.length === 0) {
              return interaction.reply({ content: "❌ Belum ada sesi AutoPost.", ephemeral: true });
            }

            const rows = [];
            let currentRow = new ActionRowBuilder();

            db.sessions.forEach((s) => {
              if (currentRow.components.length === 5) {
                rows.push(currentRow);
                currentRow = new ActionRowBuilder();
              }
              const statusEmoji = s.enabled ? "🟢 ON" : "🔴 OFF";
              currentRow.addComponents(
                new ButtonBuilder()
                  .setCustomId(`ap_toggleswitch_${s.name}`)
                  .setLabel(`${s.name} (${statusEmoji})`)
                  .setStyle(s.enabled ? ButtonStyle.Success : ButtonStyle.Secondary)
              );
            });
            if (currentRow.components.length > 0) rows.push(currentRow);

            return interaction.reply({
              content: "Pilih sesi untuk mengubah status ON/OFF:",
              components: rows,
              ephemeral: true
            });
          }

          // Switch Status Toggle
          if (id.startsWith("ap_toggleswitch_")) {
            const sessionName = id.replace("ap_toggleswitch_", "");
            let db = loadAutoPostData();
            const session = db.sessions.find((s) => s.name === sessionName);

            if (session) {
              session.enabled = !session.enabled;
              saveAutoPostData(db);

              if (session.enabled) {
                startAutoPostLoop(session);
              } else if (activeIntervals.has(sessionName)) {
                clearInterval(activeIntervals.get(sessionName));
                activeIntervals.delete(sessionName);
              }

              const statusTxt = session.enabled ? "🟢 DIHIDUPKAN" : "🔴 DIMATIKAN";
              return interaction.update({
                content: `✅ Sesi **${sessionName}** berhasil **${statusTxt}**!`,
                components: []
              });
            }
          }

          // 5. LIST BUTTON
          if (id === "ap_btn_list") {
            const db = loadAutoPostData();
            if (db.sessions.length === 0) {
              return interaction.reply({ content: "📋 **List AutoPost**\nBelum ada sesi yang tersimpan.", ephemeral: true });
            }

            let listStr = "📋 **List AutoPost Active & Registered:**\n\n";
            db.sessions.forEach((s, idx) => {
              const status = s.enabled ? "🟢 ON" : "🔴 OFF";
              listStr += `**${idx + 1}. ${s.name}** [${status}]\n`;
              listStr += `├ 📡 Channel: <#${s.channelId}>\n`;
              listStr += `├ ⏱️ Delay: ${s.delay} Detik\n`;
              listStr += `└ 📝 Pesan: ${s.message.substring(0, 30)}...\n\n`;
            });

            return interaction.reply({ content: listStr, ephemeral: true });
          }

          // --- BUTTON FORM INPUT (CREATE / EDIT) ---
          const fields = ["name", "token", "channel", "message", "delay"];
          for (let field of fields) {
            if (id === `ap_c_${field}`) {
              const modal = new ModalBuilder()
                .setCustomId(`ap_m_${field}`)
                .setTitle(`Isi ${field.toUpperCase()}`);

              const input = new TextInputBuilder()
                .setCustomId(`ap_input_${field}`)
                .setLabel(`Masukkan ${field.toUpperCase()}`)
                .setStyle(field === "message" ? TextInputStyle.Paragraph : TextInputStyle.Short)
                .setRequired(true);

              modal.addComponents(new ActionRowBuilder().addComponents(input));
              return interaction.showModal(modal);
            }
          }

          // SIMPAN SESI CREATE/EDIT
          if (id === "ap_c_save") {
            const isEditing = editSessions.has(interaction.user.id);
            const draft = isEditing
              ? editSessions.get(interaction.user.id)
              : createSessions.get(interaction.user.id);

            if (!draft || !draft.name || !draft.token || !draft.channelId || !draft.message || !draft.delay) {
              return interaction.reply({
                content: "❌ Harap lengkapi semua data (Nama, Token, Channel, Pesan, Delay) terlebih dahulu!",
                ephemeral: true
              });
            }

            let db = loadAutoPostData();

            if (isEditing) {
              const idx = db.sessions.findIndex((s) => s.name === draft.originalName);
              if (idx !== -1) {
                db.sessions[idx] = {
                  name: draft.name,
                  token: draft.token,
                  channelId: draft.channelId,
                  message: draft.message,
                  delay: parseInt(draft.delay) || 60,
                  enabled: draft.enabled ?? true
                };
              }
              editSessions.delete(interaction.user.id);
            } else {
              if (db.sessions.some((s) => s.name === draft.name)) {
                return interaction.reply({ content: "❌ Nama sesi sudah digunakan, gunakan nama lain!", ephemeral: true });
              }
              const newSession = {
                name: draft.name,
                token: draft.token,
                channelId: draft.channelId,
                message: draft.message,
                delay: parseInt(draft.delay) || 60,
                enabled: true
              };
              db.sessions.push(newSession);
              startAutoPostLoop(newSession);
              createSessions.delete(interaction.user.id);
            }

            saveAutoPostData(db);

            return interaction.update({
              content: `✅ Berhasil menyimpan sesi AutoPost **${draft.name}**!`,
              embeds: [],
              components: []
            });
          }
        }

        // --- HANDLER MODAL INPUT ---
        if (interaction.type === InteractionType.ModalSubmit) {
          const mId = interaction.customId;
          const isEditing = editSessions.has(interaction.user.id);
          const sessionMap = isEditing ? editSessions : createSessions;
          let draft = sessionMap.get(interaction.user.id) || {};

          if (mId === "ap_m_name") {
            draft.name = interaction.fields.getTextInputValue("ap_input_name");
          } else if (mId === "ap_m_token") {
            draft.token = interaction.fields.getTextInputValue("ap_input_token");
          } else if (mId === "ap_m_channel") {
            let ch = interaction.fields.getTextInputValue("ap_input_channel");
            draft.channelId = ch.replace(/[<#@&>]/g, "").trim();
          } else if (mId === "ap_m_message") {
            draft.message = interaction.fields.getTextInputValue("ap_input_message");
          } else if (mId === "ap_m_delay") {
            draft.delay = interaction.fields.getTextInputValue("ap_input_delay");
          }

          sessionMap.set(interaction.user.id, draft);
          const payload = buildCreateEmbed(draft);

          return interaction.update(payload);
        }
      } catch (err) {
        console.error("Error pada handler interaction AutoPost:", err);
      }
    });
  }
};