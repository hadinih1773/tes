const { EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "..", "database", "protectch.json");

function loadProtectedChannels() {
  try {
    if (!fs.existsSync(dbPath)) {
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
  } catch {
    return [];
  }
}

function saveProtectedChannels(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Gagal menyimpan database protectch.json:", err);
  }
}

module.exports = {
  setup(client) {
    (client._msgHandlers = client._msgHandlers || []).push(async (message) => {
      if (message.author.bot || !message.guild) return;

      const args = message.content.split(" ");
      const command = args[0].toLowerCase();

      // COMMAND: !setnochat
      if (command === "!setnochat" || command === "!setchannelprotect" || command === "!setprotectch" || command === "!protectch") {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then((msg) => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const targetChannel = message.mentions.channels.first() || message.channel;
        let channels = loadProtectedChannels();

        if (!channels.includes(targetChannel.id)) {
          channels.push(targetChannel.id);
          saveProtectedChannels(channels);
        }

        const protectEmbed = new EmbedBuilder()
          .setColor("#50C878")
          .setTitle("🛡 Protect Spamming & User Phising")
          .setDescription(
            "# Do Not Send Messages In This Channel\n\n" +
            "🇮🇩 **Indonesia** :\n" +
            "👋 Halo Semua, 📢 Channel Ini Dibuat Khusus Melindungi Server Dari Spamming Atau Akun Yang Terkena Hack Dan Phising. 😔😔\n\n" +
            "🏴󠁧󠁢󠁥󠁮󠁧󠁿 **English** :\n" +
            "👋 Hello Everyone, 📢 This Channel Is Made Specifically To Protect Servers From Spamming Or Accounts That Are Exposed To Hacking And Phishing. 😔😔\n" +
            "# Last One Do Not Send Messages In Here"
          );

        const kickButton = new ButtonBuilder()
          .setCustomId("kick_counter_btn")
          .setLabel("🚷 Kicks")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(true);

        const row = new ActionRowBuilder().addComponents(kickButton);

        return targetChannel.send({ embeds: [protectEmbed], components: [row] });
      }

      // COMMAND: !delprotectch, !delchprotect, !deletechannelprotect
      if (
        command === "!delprotectch" ||
        command === "!delchprotect" ||
        command === "!deletechannelprotect" || command === "!dprotectch"
      ) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return message.reply("❌ Hanya Admin Yang Bisa Gunakan").then((msg) => {
            setTimeout(() => msg.delete().catch(() => null), 5000);
          });
        }

        const targetChannel = message.mentions.channels.first() || message.channel;
        let channels = loadProtectedChannels();

        if (channels.includes(targetChannel.id)) {
          channels = channels.filter((id) => id !== targetChannel.id);
          saveProtectedChannels(channels);
          return message.reply(`✅ Channel <#${targetChannel.id}> telah dihapus dari daftar channel protect.`);
        } else {
          return message.reply(`❌ Channel <#${targetChannel.id}> tidak terdaftar sebagai channel protect.`);
        }
      }

      // SISTEM PROTEKSI NO CHAT
      const protectedChannels = loadProtectedChannels();
      if (protectedChannels.includes(message.channel.id)) {
        if (message.member && message.member.permissions.has(PermissionFlagsBits.Administrator)) {
          return;
        }

        const user = message.author;
        const member = message.member;

        // 1. Hapus pesan yang memicu
        await message.delete().catch(() => null);

        // 2. DM ke User
        const dmMessage = 
          `<@${user.id}>\n` +
          `Kamu Telah Di Kick Dari Server ${message.guild.name}. Jika Tidak Sengaja Chatting Di Channel, Silahkan DM Ke Owner. \n` +
          `# [@hadinih_](https://discord.com/users/1341007595288268880)`;

        await user.send(dmMessage).catch(() => null);

        // 3. Hapus semua chat user di seluruh channel server
        message.guild.channels.cache.forEach(async (ch) => {
          if (ch.isTextBased()) {
            try {
              const messages = await ch.messages.fetch({ limit: 100 }).catch(() => null);
              if (messages) {
                const userMessages = messages.filter((m) => m.author.id === user.id);
                if (userMessages.size > 0) {
                  await ch.bulkDelete(userMessages, true).catch(async () => {
                    for (const m of userMessages.values()) {
                      await m.delete().catch(() => null);
                    }
                  });
                }
              }
            } catch {}
          }
        });

        // 4. Kick User dari Server
        if (member && member.kickable) {
          await member.kick("Melanggar aturan No-Chat Channel").catch(() => null);
        }

        // 5. Update Counter Button di Pesan Utama Channel
        try {
          const channelMessages = await message.channel.messages.fetch({ limit: 20 }).catch(() => null);
          if (channelMessages) {
            const mainMsg = channelMessages.find(m => m.embeds.length > 0 && m.components.length > 0);
            if (mainMsg) {
              const currentLabel = mainMsg.components[0].components[0].label;
              let currentCount = 0;
              
              if (currentLabel.includes(":")) {
                currentCount = parseInt(currentLabel.split(":")[1].trim()) || 0;
              }
              
              const newCount = currentCount + 1;
              const updatedButton = new ButtonBuilder()
                .setCustomId("kick_counter_btn")
                .setLabel(`🚷 Kicks : ${newCount}`)
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true);

              const newRow = new ActionRowBuilder().addComponents(updatedButton);
              await mainMsg.edit({ components: [newRow] }).catch(() => null);
            }
          }
        } catch {}
      }
    });
  }
};