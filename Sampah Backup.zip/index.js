require("dotenv").config();
const { Client, GatewayIntentBits, Partials } = require("discord.js");
const fs = require("fs");
const path = require("path");
const express = require("express");

const { registerAllCommands } = require("./register.js");
const main = require("./main");
const botbb = require("./botbb");
// const telegram = require("./telegram");
// const { setup: fix } = require("./fix");
// const { setup: backup } = require("./backup");
const hady = require("./hady");
const botsewa = require("./botsewa");
const boteco = require("./boteco");
const botbcp = require("./botbcp");
const app = express();

function isUserBlacklisted(userId) {
    try {
        const blacklistPath = path.join(__dirname, "./database/blacklist.json");
        if (!fs.existsSync(blacklistPath)) return false;
        const data = JSON.parse(fs.readFileSync(blacklistPath, "utf8"));
        return Array.isArray(data) && data.includes(userId);
    } catch (err) {
        return false;
    }
}

function getOwnerId() {
    try {
        const ownerPath = path.join(__dirname, "./database/owner.json");
        const data = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
        return data.owner;
    } catch (err) {
        return null;
    }
}

function isGuildSelfMode(guildId) {
    try {
        const selfPath = path.join(__dirname, "./database/self.json");
        if (!fs.existsSync(selfPath)) return false;
        const data = JSON.parse(fs.readFileSync(selfPath, "utf8"));
        return !!(data && data[guildId] === true);
    } catch (err) {
        return false;
    }
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User],
});

// Setup Hady Website & Server
hady.setup(client, app);

app.get("/", (_, res) => res.send("Bot is alive!"));

// REGISTER COMMANDS SECARA OTOMATIS 
// Dipindahkan ke atas sebelum modul dimuat agar aplikasi Discord sinkron lebih dulu
if (typeof registerAllCommands === 'function') registerAllCommands(client);

// AUTO-LOAD MODULES (Untuk menjalankan fungsi setup/client)
const folders = ["./fitur", "./slashcommands", "./owner", "./protect", "./game", "./scrape", "./all", "./slashall"];
folders.forEach(folder => {
    const folderPath = path.join(__dirname, folder);
    if (!fs.existsSync(folderPath)) return;
    const files = fs.readdirSync(folderPath).filter(file => file.endsWith(".js"));
    for (const file of files) {
        try {
            const modulePath = `./${folder}/${file}`;
            const importedModule = require(modulePath);
            if (importedModule && typeof importedModule.setup === "function") {
                importedModule.setup(client);
            } else if (typeof importedModule === "function") {
                importedModule(client);
            }
        } catch (err) {
            console.error(`❌ Gagal memuat module ${file}:`, err);
        }
    }
});

main.setup(client);
// telegram.setup(client);
// fix(client);
// backup(client);
botsewa.setup(client);
botbb.setup(client);
boteco.setup(client);
botbcp.setup(client);
// LISTENER TERPUSAT (messageCreate) - menjalankan semua handler yang didaftarkan
// oleh modul-modul fitur melalui client._msgHandlers agar tidak ada listener
// messageCreate ganda/bentrok di setiap file.
client.on("messageCreate", async (message) => {
    if (message.author.bot) return;

    // Menolak pesan yang berasal dari Direct Message (DM)
    if (!message.guild) return;

    if (isUserBlacklisted(message.author.id)) return;

    if (message.guild && isGuildSelfMode(message.guild.id) && message.author.id !== getOwnerId()) return;

    for (const handler of client._msgHandlers || []) {
        try {
            await handler(message);
        } catch (err) {
            console.error("❌ Error pada messageCreate handler:", err);
        }
    }
});

client.login(process.env.DISCORD_TOKEN);