const supabase = require("./supabaseClient");
const { checkBruteForce, recordFailedAttempt, resetAttempts } = require("./_bruteforce");
const { getClientIp, isIpBlocked, verifyCaptcha, checkAndTrackSpam } = require("./_antispam");

// Password hapus snippet diambil dari environment variable server (BUKAN config.js lagi),
// supaya tidak pernah ikut terkirim ke browser pengunjung.
const DELETE_PASSWORD = process.env.SNIPPET_DELETE_PASSWORD;

module.exports = async (req, res) => {

    if (req.method === "GET") {
        const { data, error } = await supabase
            .from("snippets")
            .select("*")
            .order("created_at", { ascending: true });

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal mengambil data: " + error.message });
        }

        // Mapping supaya field cocok dengan yang dipakai di frontend (createdAt bukan created_at)
        const mapped = data.map(s => ({
            id: s.id,
            title: s.title,
            author: s.author,
            contact: s.contact,
            language: s.language,
            tags: s.tags || [],
            description: s.description,
            code: s.code,
            views: s.views,
            copies: s.copies,
            createdAt: s.created_at
        }));

        return res.status(200).json(mapped);
    }

    if (req.method === "POST") {
        const body = req.body || {};
        const { title, author, contact, language, tags, description, code, captchaId, captchaAnswer } = body;

        const ip = getClientIp(req);
        if (await isIpBlocked(ip)) {
            return res.status(403).json({ error: "IP Anda telah diblokir karena terdeteksi spam." });
        }

        // Catat waktu post untuk deteksi spam (>1 post dalam 5 detik dari IP yang sama)
        const spamCheck = await checkAndTrackSpam(req, "snippet");
        if (spamCheck.blocked) {
            return res.status(429).json({ error: "Terdeteksi spam! IP Anda telah diblokir otomatis." });
        }

        const captchaCheck = await verifyCaptcha(captchaId, captchaAnswer);
        if (!captchaCheck.valid) {
            return res.status(400).json({ error: captchaCheck.message });
        }

        if (!title || !code) {
            return res.status(400).json({ error: "Judul & Code wajib diisi!" });
        }

        const { data, error } = await supabase
            .from("snippets")
            .insert([{
                title,
                author: author || "Anonim",
                contact: contact || "",
                language: language || "JavaScript",
                tags: Array.isArray(tags) ? tags : [],
                description: description || "",
                code,
                views: 1,
                copies: 0
            }])
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menyimpan ke storage: " + error.message });
        }

        return res.status(201).json({
            id: data.id,
            title: data.title,
            author: data.author,
            contact: data.contact,
            language: data.language,
            tags: data.tags || [],
            description: data.description,
            code: data.code,
            views: data.views,
            copies: data.copies,
            createdAt: data.created_at
        });
    }

    if (req.method === "DELETE") {
        const body = req.body || {};
        const { id, password } = body;

        const bf = await checkBruteForce(req, "snippet");
        if (bf.blocked) {
            return res.status(429).json({ error: `Terlalu banyak percobaan salah. Coba lagi dalam ${bf.sisaMenit} menit.` });
        }

        if (password !== DELETE_PASSWORD) {
            await recordFailedAttempt(bf.key, bf.existing);
            return res.status(401).json({ error: "Password salah!" });
        }
        await resetAttempts(bf.key);

        if (!id) {
            return res.status(400).json({ error: "ID snippet wajib diisi!" });
        }

        const { error } = await supabase
            .from("snippets")
            .delete()
            .eq("id", id);

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menghapus dari storage: " + error.message });
        }

        return res.status(200).json({ success: true });
    }

    if (req.method === "PATCH") {
        const body = req.body || {};
        const { id } = body;

        if (!id) {
            return res.status(400).json({ error: "ID snippet wajib diisi!" });
        }

        // Ambil dulu nilai copies saat ini
        const { data: current, error: fetchError } = await supabase
            .from("snippets")
            .select("copies")
            .eq("id", id)
            .single();

        if (fetchError) {
            console.error(fetchError);
            return res.status(404).json({ error: "Snippet tidak ditemukan" });
        }

        const { data, error } = await supabase
            .from("snippets")
            .update({ copies: (current.copies || 0) + 1 })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal update storage: " + error.message });
        }

        return res.status(200).json({
            id: data.id,
            copies: data.copies
        });
    }

    res.setHeader("Allow", ["GET", "POST", "DELETE", "PATCH"]);
    return res.status(405).json({ error: `Method ${req.method} tidak diizinkan` });
};