const { checkBruteForce, recordFailedAttempt, resetAttempts } = require("./_bruteforce");

// ==========================================================
// api/auth.js
// Verifikasi password dilakukan di server, bukan di browser.
// Password asli disimpan sebagai Environment Variable di Vercel,
// jadi TIDAK PERNAH dikirim ke config.js / browser pengunjung.
//
// Wajib set environment variable ini di Vercel:
//   LOCK_PASSWORD
//   ADMIN_USERNAME
//   ADMIN_PASSWORD
// ==========================================================

module.exports = async (req, res) => {

    if (req.method !== "POST") {
        res.setHeader("Allow", ["POST"]);
        return res.status(405).json({ error: `Method ${req.method} tidak diizinkan` });
    }

    const body = req.body || {};
    const { action } = body;

    // ---------- Buka kunci website (index.html) ----------
    if (action === "unlock-site") {
        const { password } = body;

        const bf = await checkBruteForce(req, "unlock-site");
        if (bf.blocked) {
            return res.status(429).json({ error: `Terlalu banyak percobaan salah. Coba lagi dalam ${bf.sisaMenit} menit.` });
        }

        if (password !== process.env.LOCK_PASSWORD) {
            await recordFailedAttempt(bf.key, bf.existing);
            return res.status(401).json({ error: "Password salah!" });
        }

        await resetAttempts(bf.key);
        return res.status(200).json({ ok: true });
    }

    // ---------- Login Admin Panel (lock.html) ----------
    if (action === "admin-login") {
        const { username, password } = body;

        const bf = await checkBruteForce(req, "admin-login");
        if (bf.blocked) {
            return res.status(429).json({ error: `Terlalu banyak percobaan salah. Coba lagi dalam ${bf.sisaMenit} menit.` });
        }

        if (username !== process.env.ADMIN_USERNAME || password !== process.env.ADMIN_PASSWORD) {
            await recordFailedAttempt(bf.key, bf.existing);
            return res.status(401).json({ error: "Username atau Password salah" });
        }

        await resetAttempts(bf.key);
        return res.status(200).json({ ok: true });
    }

    return res.status(400).json({ error: "Action tidak dikenal" });
};
