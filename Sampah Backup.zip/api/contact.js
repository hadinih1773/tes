// ==========================================================
// api/contact.js
// Menerima data form Kontak dari index.html lalu meneruskannya
// ke grup Telegram lewat Bot API.
//
// Token bot disimpan di sini (server-side), BUKAN di config.js,
// supaya tidak ikut ter-load ke browser pengunjung (config.js
// dikirim ke client via <script src="config.js">, jadi apa pun
// isinya bisa dilihat siapa saja lewat "View Page Source").
//
// Kalau mau lebih aman lagi, pindahkan dua nilai di bawah ini
// ke Environment Variables Vercel (Settings > Environment Variables)
// dengan nama yang sama: TELEGRAM_BOT_TOKEN & TELEGRAM_CHAT_ID.
// Kode ini otomatis memakai env var itu kalau tersedia.
// ==========================================================

const TELEGRAM_BOT_TOKEN =
  process.env.TELEGRAM_BOT_TOKEN || "8919903078:AAEVmr78zIe95HraJVtSiZ-B1U57NkFB_-M";

// GANTI dengan ID grup Telegram tujuan.
// Cara dapat chat_id grup:
// 1. Masukkan bot ke grup tujuan.
// 2. Kirim pesan apa saja di grup itu.
// 3. Buka https://api.telegram.org/bot<TOKEN>/getUpdates di browser.
// 4. Cari "chat":{"id": -100xxxxxxxxxx, ...} lalu salin angkanya (termasuk tanda minus).
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "-1003759869127";

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

module.exports = async (req, res) => {
  try {
    if (req.method !== "POST") {
      return res.status(405).json({ status: false, error: "Method tidak diizinkan." });
    }

    const chunks = [];
    for await (const chunk of req) {
      chunks.push(chunk);
    }
    const raw = Buffer.concat(chunks).toString("utf8");

    let body = {};
    try {
      body = JSON.parse(raw || "{}");
    } catch {
      return res.status(400).json({ status: false, error: "Body tidak valid." });
    }

    const nama = (body.nama || "").toString().trim().slice(0, 80);
    const kontak = (body.kontak || "").toString().trim().slice(0, 120);
    const pesan = (body.pesan || "").toString().trim().slice(0, 1000);

    if (!nama || !kontak || !pesan) {
      return res.status(400).json({ status: false, error: "Semua kolom wajib diisi." });
    }

    if (!TELEGRAM_CHAT_ID || TELEGRAM_CHAT_ID === "GANTI_DENGAN_CHAT_ID_GRUP") {
      return res.status(500).json({
        status: false,
        error: "TELEGRAM_CHAT_ID belum diatur di api/contact.js."
      });
    }

    const text =
      `📩 <b>Pesan Baru dari Website</b>\n\n` +
      `👤 <b>Nama:</b> ${escapeHtml(nama)}\n` +
      `📞 <b>Kontak:</b> ${escapeHtml(kontak)}\n` +
      `💬 <b>Pesan:</b> ${escapeHtml(pesan)}`;

    const tgRes = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: TELEGRAM_CHAT_ID,
          text,
          parse_mode: "HTML"
        })
      }
    );

    const tgData = await tgRes.json();

    if (!tgData.ok) {
      return res.status(502).json({
        status: false,
        error: tgData.description || "Gagal mengirim ke Telegram."
      });
    }

    return res.status(200).json({ status: true, message: "Pesan terkirim." });
  } catch (err) {
    return res.status(500).json({ status: false, error: "Terjadi kesalahan server." });
  }
};
