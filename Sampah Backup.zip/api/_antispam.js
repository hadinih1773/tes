const supabase = require("./supabaseClient");
const { notifySpamDetected, notifyIpBlocked } = require("./notifspam");

// ==========================================================
// api/_antispam.js
// Proteksi anti-spam untuk endpoint POST publik (mod.js & snippet.js):
//   1. verifyCaptcha()     -> validasi captcha server-side (sekali pakai)
//   2. isIpBlocked()       -> cek apakah IP sudah pernah diblokir
//   3. checkAndTrackSpam() -> kalau IP yang sama post lagi dalam < 5 detik
//                             dari post sebelumnya, dianggap SPAM:
//                             - kirim notif Telegram "Spam Terdeteksi"
//                             - IP langsung diblokir (insert ke blocked_ips)
//                             - kirim notif Telegram "Block IP Succes"
//
// Perlu 2 tabel tambahan di Supabase:
//
//   post_activity
//     ip            text primary key
//     last_post_at  timestamptz not null
//     spam_count    int default 0
//
//   blocked_ips
//     ip          text primary key
//     blocked_at  timestamptz not null
//     spam_count  int default 0
//     reason      text
// ==========================================================

const SPAM_WINDOW_MS = 5 * 1000; // 5 detik

function getClientIp(req) {
    const fwd = req.headers["x-forwarded-for"];
    if (fwd) return fwd.split(",")[0].trim();
    return (req.socket && req.socket.remoteAddress) || "unknown";
}

async function isIpBlocked(ip) {
    const { data, error } = await supabase
        .from("blocked_ips")
        .select("ip")
        .eq("ip", ip)
        .maybeSingle();

    if (error) {
        console.error("Gagal cek IP blokir:", error.message);
        return false; // fail-open supaya error DB tidak mengunci semua orang
    }
    return !!data;
}

async function verifyCaptcha(captchaId, captchaAnswer) {
    if (!captchaId || !captchaAnswer) {
        return { valid: false, message: "Captcha wajib diisi!" };
    }

    const { data, error } = await supabase
        .from("captchas")
        .select("*")
        .eq("id", captchaId)
        .maybeSingle();

    if (error || !data) {
        return { valid: false, message: "Captcha tidak valid, silakan refresh captcha." };
    }
    if (data.used) {
        return { valid: false, message: "Captcha sudah dipakai, silakan refresh captcha." };
    }
    if (new Date(data.expires_at).getTime() < Date.now()) {
        return { valid: false, message: "Captcha kedaluwarsa, silakan refresh captcha." };
    }
    if (String(captchaAnswer).trim() !== String(data.answer).trim()) {
        return { valid: false, message: "Jawaban captcha salah!" };
    }

    // Tandai dipakai supaya token yang sama tidak bisa dipakai ulang (anti-replay)
    await supabase.from("captchas").update({ used: true }).eq("id", captchaId);

    return { valid: true };
}

// Panggil di awal setiap POST (sebelum/di samping cek captcha) supaya
// percobaan spam tetap tercatat walaupun captcha-nya juga salah.
async function checkAndTrackSpam(req, endpointName) {
    const ip = getClientIp(req);
    const now = Date.now();

    const { data: existing, error: fetchError } = await supabase
        .from("post_activity")
        .select("*")
        .eq("ip", ip)
        .maybeSingle();

    if (fetchError) {
        console.error("Gagal cek aktivitas post:", fetchError.message);
        return { ip, blocked: false };
    }

    if (existing) {
        const diff = now - new Date(existing.last_post_at).getTime();

        if (diff < SPAM_WINDOW_MS) {
            // Post lagi dalam < 5 detik dari post sebelumnya = SPAM
            const spamCount = (existing.spam_count || 0) + 1;

            await supabase
                .from("post_activity")
                .update({ last_post_at: new Date(now).toISOString(), spam_count: spamCount })
                .eq("ip", ip);

            await notifySpamDetected({ ip, spamCount, endpoint: endpointName });

            await supabase.from("blocked_ips").upsert(
                {
                    ip,
                    blocked_at: new Date(now).toISOString(),
                    spam_count: spamCount,
                    reason: `Spam post di /api/${endpointName}`
                },
                { onConflict: "ip" }
            );

            await notifyIpBlocked({ ip, spamCount });

            return { ip, blocked: true, spamCount };
        }
    }

    await supabase.from("post_activity").upsert(
        { ip, last_post_at: new Date(now).toISOString(), spam_count: 0 },
        { onConflict: "ip" }
    );

    return { ip, blocked: false };
}

module.exports = { getClientIp, isIpBlocked, verifyCaptcha, checkAndTrackSpam };
