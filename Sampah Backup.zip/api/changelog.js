const supabase = require("./supabaseClient");
const { checkBruteForce, recordFailedAttempt, resetAttempts } = require("./_bruteforce");

// Password admin diambil dari environment variable server (BUKAN config.js lagi),
// supaya tidak pernah ikut terkirim ke browser pengunjung.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

module.exports = async (req, res) => {

    if (req.method === "GET") {
        const { data, error } = await supabase
            .from("changelogs")
            .select("*")
            .order("entry_date", { ascending: true })
            .order("created_at", { ascending: true });

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal mengambil data: " + error.message });
        }

        const mapped = data.map(c => ({
            id: c.id,
            title: c.title,
            version: c.version || "",
            tag: c.tag || "update",
            changes: c.changes || [],
            date: c.entry_date,
            createdAt: c.created_at
        }));

        return res.status(200).json(mapped);
    }

    if (req.method === "POST") {
        const body = req.body || {};
        const { title, version, tag, changes, date, password } = body;

        const bf = await checkBruteForce(req, "changelog");
        if (bf.blocked) {
            return res.status(429).json({ error: `Terlalu banyak percobaan salah. Coba lagi dalam ${bf.sisaMenit} menit.` });
        }

        if (password !== ADMIN_PASSWORD) {
            await recordFailedAttempt(bf.key, bf.existing);
            return res.status(401).json({ error: "Password admin salah!" });
        }
        await resetAttempts(bf.key);

        if (!title || !Array.isArray(changes) || changes.length === 0) {
            return res.status(400).json({ error: "Judul & daftar perubahan wajib diisi!" });
        }

        const { data, error } = await supabase
            .from("changelogs")
            .insert([{
                title,
                version: version || "",
                tag: tag || "update",
                changes,
                entry_date: date || new Date().toISOString().slice(0, 10)
            }])
            .select()
            .single();

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menyimpan ke storage: " + error.message });
        }

        return res.status(201).json({
            id: data.id,
            title: data.title,
            version: data.version || "",
            tag: data.tag || "update",
            changes: data.changes || [],
            date: data.entry_date,
            createdAt: data.created_at
        });
    }

    if (req.method === "DELETE") {
        const body = req.body || {};
        const { id, password } = body;

        const bf = await checkBruteForce(req, "changelog");
        if (bf.blocked) {
            return res.status(429).json({ error: `Terlalu banyak percobaan salah. Coba lagi dalam ${bf.sisaMenit} menit.` });
        }

        if (password !== ADMIN_PASSWORD) {
            await recordFailedAttempt(bf.key, bf.existing);
            return res.status(401).json({ error: "Password admin salah!" });
        }
        await resetAttempts(bf.key);

        if (!id) {
            return res.status(400).json({ error: "ID changelog wajib diisi!" });
        }

        const { error } = await supabase
            .from("changelogs")
            .delete()
            .eq("id", id);

        if (error) {
            console.error(error);
            return res.status(500).json({ error: "Gagal menghapus dari storage: " + error.message });
        }

        return res.status(200).json({ success: true });
    }

    res.setHeader("Allow", ["GET", "POST", "DELETE"]);
    return res.status(405).json({ error: `Method ${req.method} tidak diizinkan` });
};
