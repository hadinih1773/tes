const supabase = require("./supabaseClient");
const { nanoid } = require("nanoid");

// ==========================================================
// api/captcha.js
// Endpoint GET yang membuat soal captcha matematika sederhana
// dan menyimpan jawabannya di Supabase (tabel "captchas").
// Jawaban TIDAK pernah dikirim ke browser, hanya soalnya saja,
// jadi berbeda dari captcha canvas lama yang dicek di client
// (makanya dulu bisa gampang dilewati bot).
//
// Perlu tabel Supabase "captchas":
//   id          text primary key
//   answer      text not null
//   expires_at  timestamptz not null
//   used        boolean default false
//   created_at  timestamptz default now()
// ==========================================================

const CAPTCHA_TTL_MS = 5 * 60 * 1000; // captcha berlaku 5 menit

module.exports = async (req, res) => {
    if (req.method !== "GET") {
        res.setHeader("Allow", ["GET"]);
        return res.status(405).json({ error: `Method ${req.method} tidak diizinkan` });
    }

    const a = Math.floor(Math.random() * 9) + 1;
    const b = Math.floor(Math.random() * 9) + 1;
    const answer = String(a + b);
    const id = nanoid();
    const expiresAt = new Date(Date.now() + CAPTCHA_TTL_MS).toISOString();

    const { error } = await supabase
        .from("captchas")
        .insert([{ id, answer, expires_at: expiresAt, used: false }]);

    if (error) {
        console.error(error);
        return res.status(500).json({ error: "Gagal membuat captcha: " + error.message });
    }

    return res.status(200).json({ captchaId: id, question: `${a} + ${b} = ?` });
};
