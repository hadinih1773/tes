// ==========================================================
// api/notifspam.js
// Kirim notifikasi ke Telegram saat ada spam post terdeteksi
// dan saat sebuah IP otomatis diblokir.
//
// Token & chat id diambil dari cara yang sama seperti di
// api/contact.js: pakai Environment Variable Vercel
// (TELEGRAM_BOT_TOKEN & TELEGRAM_CHAT_ID) kalau ada,
// fallback ke nilai yang sama dengan contact.js kalau belum diset.
// ==========================================================

const TELEGRAM_BOT_TOKEN =
    process.env.TELEGRAM_BOT_TOKEN || "8919903078:AAEVmr78zIe95HraJVtSiZ-B1U57NkFB_-M";

const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "-1003759869127";

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function formatWaktu(date) {
    return date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + " WIB";
}

async function sendTelegram(text) {
    try {
        const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text, parse_mode: "HTML" })
        });
        const data = await res.json();
        if (!data.ok) console.error("Gagal kirim notif Telegram:", data.description);
    } catch (err) {
        console.error("Error kirim notif Telegram:", err.message);
    }
}

async function notifySpamDetected({ ip, spamCount, endpoint }) {
    const text =
        `🚨 <b>Spam Terdeteksi</b>\n\n` +
        `⏱️ <b>Waktu:</b> ${formatWaktu(new Date())}\n` +
        `📊 <b>Jumlah Spam:</b> ${spamCount}\n` +
        `📡 <b>IP:</b> <code>${escapeHtml(ip)}</code>` +
        (endpoint ? `\n📍 <b>Endpoint:</b> ${escapeHtml(endpoint)}` : "");

    await sendTelegram(text);
}

async function notifyIpBlocked({ ip, spamCount }) {
    const text =
        `🚫 <b>Block IP Succes</b>\n\n` +
        `📡 <b>IP:</b> <code>${escapeHtml(ip)}</code>\n` +
        `📊 <b>Jumlah Spam:</b> ${spamCount}\n` +
        `📑 <b>Keterangan:</b> Beliau Sudah Di Block Mampus`;

    await sendTelegram(text);
}

module.exports = { notifySpamDetected, notifyIpBlocked };
