const supabase = require("./supabaseClient");

// ==========================================================
// _bruteforce.js
// Proteksi anti-bruteforce untuk endpoint yang pakai password
// (changelog.js, mod.js, snippet.js).
// Percobaan gagal disimpan di tabel Supabase "login_attempts"
// supaya tetap tercatat walau function Vercel restart/cold start.
// ==========================================================

const MAX_ATTEMPTS = 5;              // maksimal percobaan salah
const WINDOW_MS = 15 * 60 * 1000;    // 15 menit jendela hitung percobaan
const LOCKOUT_MS = 15 * 60 * 1000;   // 15 menit kena kunci kalau kehabisan percobaan

function getClientIp(req) {
    const fwd = req.headers["x-forwarded-for"];
    if (fwd) return fwd.split(",")[0].trim();
    return (req.socket && req.socket.remoteAddress) || "unknown";
}

// Dipanggil di awal, sebelum cek password
async function checkBruteForce(req, endpointName) {
    const ip = getClientIp(req);
    const key = `${endpointName}:${ip}`;
    const now = Date.now();

    const { data, error } = await supabase
        .from("login_attempts")
        .select("*")
        .eq("key", key)
        .maybeSingle();

    if (error) {
        console.error("Gagal cek anti-bruteforce:", error.message);
        return { blocked: false, key };
    }

    if (data && data.locked_until && new Date(data.locked_until).getTime() > now) {
        const sisaMenit = Math.ceil((new Date(data.locked_until).getTime() - now) / 60000);
        return { blocked: true, key, sisaMenit };
    }

    return { blocked: false, key, existing: data };
}

// Dipanggil kalau password salah
async function recordFailedAttempt(key, existing) {
    const now = Date.now();
    let attempts = 1;

    if (existing && existing.last_attempt && (now - new Date(existing.last_attempt).getTime()) < WINDOW_MS) {
        attempts = (existing.attempts || 0) + 1;
    }

    const lockedUntil = attempts >= MAX_ATTEMPTS
        ? new Date(now + LOCKOUT_MS).toISOString()
        : null;

    const { error } = await supabase
        .from("login_attempts")
        .upsert({
            key,
            attempts,
            last_attempt: new Date(now).toISOString(),
            locked_until: lockedUntil
        }, { onConflict: "key" });

    if (error) console.error("Gagal simpan percobaan gagal:", error.message);
}

// Dipanggil kalau password benar, supaya hitungan direset
async function resetAttempts(key) {
    const { error } = await supabase
        .from("login_attempts")
        .delete()
        .eq("key", key);

    if (error) console.error("Gagal reset percobaan:", error.message);
}

module.exports = { checkBruteForce, recordFailedAttempt, resetAttempts };
