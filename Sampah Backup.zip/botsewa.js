const { Client } = require("discord.js");
const fs = require("fs");
const path = require("path");
const express = require("express");

// Import modul yang diperlukan
const { registerAllCommands } = require("./registersewa.js");
const { setup: fix } = require("./fix");

function isUserBlacklisted(userId) {
    try {
        const blacklistPath = path.join(__dirname, "./database/blacklist.json");
        if (!fs.existsSync(blacklistPath)) return false;
        const data = JSON.parse(fs.readFileSync(blacklistPath, "utf8"));
        return Array.isArray(data) && data.includes(userId);
    } catch (err) {
        return false;
    }
}

function getOwnerId() {
    try {
        const ownerPath = path.join(__dirname, "./database/owner.json");
        const data = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
        return data.owner;
    } catch (err) {
        return null;
    }
}

function isGuildSelfMode(guildId) {
    try {
        const selfPath = path.join(__dirname, "./database/self.json");
        if (!fs.existsSync(selfPath)) return false;
        const data = JSON.parse(fs.readFileSync(selfPath, "utf8"));
        return !!(data && data[guildId] === true);
    } catch (err) {
        return false;
    }
}

const setup = (mainClient) => {
    // Menggunakan konfigurasi yang sama dengan bot utama agar tidak ada disallowed intents
    const client = new Client({
        intents: mainClient.options.intents,
        partials: mainClient.options.partials,
    });

    const app = express();
    app.get("/", (_, res) => res.send(`${client.user.username} is alive!`));

    // REGISTER COMMANDS (Logika pengumpulan command sekarang ada di registers)
    // Dipindahkan ke atas sebelum modul dimuat seperti index.js agar sinkron lebih dulu
    if (typeof registerAllCommands === 'function') {
        client.token = process.env.DISCORD_TOKEN_SEWA; 
        registerAllCommands(client);
    }

    // AUTO-LOAD MODULES (Hanya untuk menjalankan fungsi setup/module)
    const folders = ["./fitur", "./slashcommands", "./owner", "./protect", "./game", "./scrape", "./dc", "./all", "./slashall"];
    folders.forEach(folder => {
        const folderPath = path.join(__dirname, folder);
        if (!fs.existsSync(folderPath)) return;
        const files = fs.readdirSync(folderPath).filter(file => file.endsWith(".js"));
        for (const file of files) {
            try {
                const modulePath = `./${folder}/${file}`;
                const importedModule = require(modulePath);
                if (importedModule && typeof importedModule.setup === "function") {
                    importedModule.setup(client);
                } else if (typeof importedModule === "function") {
                    importedModule(client);
                }
            } catch (err) {
                console.error(`❌ [${client.user.username}] Gagal memuat module ${file}:`, err);
            }
        }
    });

    fix(client);

    // LISTENER TERPUSAT (messageCreate) - menjalankan semua handler yang didaftarkan
    // oleh modul-modul fitur melalui client._msgHandlers agar tidak ada listener
    // messageCreate ganda/bentrok di setiap file.
    client.on("messageCreate", async (message) => {
        if (message.author.bot) return;

        if (!message.guild) return;

        if (isUserBlacklisted(message.author.id)) return;

        if (message.guild && isGuildSelfMode(message.guild.id) && message.author.id !== getOwnerId()) return;

        for (const handler of client._msgHandlers || []) {
            try {
                await handler(message);
            } catch (err) {
                console.error(`❌ [${client.user.username}] Error pada messageCreate handler:`, err);
            }
        }
    });

    // Menampilkan pesan saat bot online
    client.once("ready", () => {
        console.log(`✅ ${client.user.username} Has Logged`);
    });

    // LOGIN MENGGUNAKAN TOKEN
    client.login(process.env.DISCORD_TOKEN_SEWA);
};

module.exports = { setup };