require("dotenv").config();
const { REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

/**
 * Fungsi ini bertugas memindai folder secara otomatis, mengumpulkan data command,
 * dan mendaftarkannya ke seluruh guild.
 */
function isUserBlacklisted(userId) {
  try {
    const blacklistPath = path.join(__dirname, "./database/blacklist.json");
    if (!fs.existsSync(blacklistPath)) return false;
    const data = JSON.parse(fs.readFileSync(blacklistPath, "utf8"));
    return Array.isArray(data) && data.includes(userId);
  } catch (err) {
    return false;
  }
}

function getOwnerId() {
  try {
    const ownerPath = path.join(__dirname, "./database/owner.json");
    const data = JSON.parse(fs.readFileSync(ownerPath, "utf8"));
    return data.owner;
  } catch (err) {
    return null;
  }
}

function isGuildSelfMode(guildId) {
  try {
    const selfPath = path.join(__dirname, "./database/self.json");
    if (!fs.existsSync(selfPath)) return false;
    const data = JSON.parse(fs.readFileSync(selfPath, "utf8"));
    return !!(data && data[guildId] === true);
  } catch (err) {
    return false;
  }
}

async function registerAllCommands(client) {
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN_HCBCP || client.token);
  const finalJSONList = [];
  
  // Folder yang akan dipindai secara otomatis
  const folders = ["./slashall", "./all"];

  folders.forEach(folder => {
    const folderPath = path.join(__dirname, folder);
    if (!fs.existsSync(folderPath)) return;
    
    const files = fs.readdirSync(folderPath).filter(file => file.endsWith(".js"));
    
    for (const file of files) {
      try {
        const modulePath = path.join(folderPath, file);
        const m = require(modulePath);
        
        // Cek jika module memiliki properti 'data' (Slash Command)
        if (m && m.data) {
          if (Array.isArray(m.data)) {
            m.data.forEach(d => finalJSONList.push(typeof d.toJSON === 'function' ? d.toJSON() : d));
          } else {
            finalJSONList.push(typeof m.data.toJSON === 'function' ? m.data.toJSON() : m.data);
          }
        }
      } catch (err) {
        console.error(`❌ [${client.user.username}] Gagal memproses command di file ${file}:`, err);
      }
    }
  });

  const registerToGuild = async (guildId, guildName) => {
    try {
      await rest.put(
        Routes.applicationGuildCommands(client.user.id, guildId),
        { body: finalJSONList }
      );
    } catch (err) {
      console.error(`❌ [${client.user.username}] Gagal sinkronisasi di server: ${guildName}`);
    }
  };

  client.once("ready", async () => {
    try {
      // Hapus global commands lama
      await rest.put(Routes.applicationCommands(client.user.id), { body: [] });

      const guilds = Array.from(client.guilds.cache.values());
      for (const guild of guilds) {
        await registerToGuild(guild.id, guild.name);
      }
      console.log(`✅ [${client.user.username}] Sukses Mendaftarkan di ${guilds.length} Server Sebanyak ${finalJSONList.length} Slash Command`);
    } catch (error) {
      console.error(`❌ [${client.user.username}] Terjadi kesalahan pada proses registrasi:`, error);
    }
  });

  client.on("guildCreate", async (guild) => {
    console.log(`📥 [${client.user.username}] Bot masuk ke server baru: ${guild.name}, mendaftarkan command...`);
    await registerToGuild(guild.id, guild.name);
  });

  // LISTENER TERPUSAT (interactionCreate) - menjalankan semua handler slash command
  // yang didaftarkan oleh modul-modul fitur melalui client._interactionHandlers agar
  // tidak ada listener interactionCreate ganda/bentrok di setiap file.
  client.on("interactionCreate", async (interaction) => {
    if (interaction.isChatInputCommand && interaction.isChatInputCommand()) {
      if (isUserBlacklisted(interaction.user.id)) {
        return interaction.reply({ content: `❌ <@${interaction.user.id}> Kamu Tidak Bisa Menggunakan Slash Command. Karena Di Blacklist. Silahkan Hubungi Owner..`, ephemeral: true });
      }
      if (interaction.guild && isGuildSelfMode(interaction.guild.id) && interaction.user.id !== getOwnerId()) {
        return interaction.reply({ content: `❌ Bot Sedang Mode Self. Tidak Bisa Digunakan`, ephemeral: true });
      }
    }

    for (const handler of client._interactionHandlers || []) {
      try {
        await handler(interaction);
      } catch (err) {
        console.error(`❌ [${client.user.username}] Error pada interactionCreate handler:`, err);
      }
    }
  });
}

module.exports = { registerAllCommands };